/**
 * V2.7.103 超量程估算与真人估算核对（替换 V2.7.102 的 endi_human_e2e.ts）。
 * 规则：
 *   超量程（坐垫 + 靠背）：接触区基准估算力 9.8 × m > 90 N 且连续拟合估算力 9.8 × m_fit > 90 N（双重确认超过 5 块砝码）
 *       立即启动，压力 ×2、面积取轮廓；任一回落 ≤ 90 N 连续 500 ms 后取消。坐垫 ×2 由适配层施加（核心输出基准值），靠背 ×2 在核心内施加。
 *   真人（仅坐垫）：全帧基准面积 ΣS > 600 cm² 且全帧基准力 ΣF > 300 N 时启动，非标准档接触区压力 ×0.4、面积 ×0.9，
 *       不再乘 ×2（与超量程互斥）；条件连续不满足 500 ms 后退出；无接触立即退出。
 *   实时会话中系数切换按 120 ms S 曲线过渡；静态单帧直接取目标系数。
 * 场景：
 *   R0 真实标定数据（坐垫 31 表 6200 帧、靠背 44 表 8800 帧，1–5 块）：不得出现超量程与真人估算；
 *   S1 坐垫砝码超量程：真实 1–5 块 + 5 块帧 ADC 放大（模拟更重砝码）超过 90 N → ×2，回落后 500 ms 取消；
 *   S2 坐垫纯真人：合成臀部轮廓逐渐坐下（先 > 90 N 但面积 ≤ 600 → ×2；面积 > 600 且力 > 300 → ×0.4/×0.8，不乘 ×2）；
 *   S3 坐垫大面积轻载：面积 > 600 cm² 但力 ≤ 300 N → 不启动真人，按超量程 ×2；
 *   S4 坐垫小面积重载：力 > 300 N 但面积 ≤ 600 cm² → 不启动真人，按超量程 ×2；
 *   S5 坐垫砝码 + 真人：标准档砝码区系数 1，真人区 1/0.8；
 *   S6 坐垫真人退出防抖：条件不满足后保持 500 ms 再退出；
 *   S7 坐垫静态单帧：真人 / 超量程直接取目标系数；
 *   B1 靠背砝码超量程：同 S1，靠背无真人系数；V2.7.108 起超量程面积 = T39 轮廓 × 2（区压强 = 2F/2S = F/S），
 *      逐帧核对区面积 / 区压强 / 逐格压强同步 / 框选面积（超量程区每格 2.60 cm²）；
 *   S8 V2.7.104：坐垫每一帧（R0 + S1–S7，含过渡帧）平均压强卡片文字 = 热力图压强格子平均文字；
 *   S9 V2.7.110：坐垫真人估算区逐格压强最大格 = 原比例分配最大格 × 1.5（过渡中按 1–1.5），区内格子平均仍 = 区压强，
 *      ADC 越大压强越大（允许 0.001 N/cm² 取整差），非真人区仍按原比例分配（γ = 1）；R0 真实数据不触发；
 *   逐格压强与框选：格子平均 = 平均压强，区内格子平均 = 区压强，最大压强 = 格子最大值，框选面积 = 全帧面积。
 * 用法：npx tsx tests/endi_over_human_e2e.ts <坐垫 CSV 目录> <靠背 CSV 目录> [输出 JSON]
 */
import fs from "node:fs";
import path from "node:path";
import { calculateLiveSensorForce, resetLiveSeatForce, resetLiveBackrestForce, type ContinuousForceFrame } from "../client/src/lib/sensorForce";
import {
  calculateEndiSeatForce, endiNativeToAlgorithm,
  ENDI_SEAT_HUMAN_FORCE_FACTOR as KF, ENDI_SEAT_HUMAN_AREA_FACTOR as KS, ENDI_SEAT_OVER_RANGE_GAIN as GAIN,
  ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N as F_OVER, ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2 as S_HUMAN, ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N as F_HUMAN,
  ENDI_SEAT_HUMAN_EXIT_HOLD_MS as HOLD, ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN as PEAK_GAIN,
} from "../client/src/lib/endiSeatForce";
import {
  ENDI_BACKREST_OVER_RANGE_FORCE_THRESHOLD_N as B_OVER, ENDI_BACKREST_OVER_RANGE_GAIN as B_GAIN,
  ENDI_BACKREST_OVER_RANGE_AREA_GAIN as B_AGAIN, ENDI_BACKREST_CELL_AREA_CM2 as B_CELL, ENDI_BACKREST_BASE_AREA_CM2 as B_BASE,
} from "../client/src/lib/endiBackrestForce";
import { calculateDisplayedArea } from "../client/src/lib/displayArea";
import { lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { attachEndiPointPressure, endiContourOwnerMatrix, endiPointPressureMatrix, endiSeatSelectionHumanAreaDeduction, endiSelectionAreaFactorAdjustment } from "../client/src/lib/endiPointPressure";
import { roundForceN, roundAreaCm2, pressureKPaFromForceArea, formatPressureNcm2, kPaToNcm2 } from "../client/src/lib/pressureUnits";
import { EndiAlgorithm } from "../client/src/lib/endiCushion/endiCushionCore.js";
import { EndiBackrestAlgorithm } from "../client/src/lib/endiBackrest/endiBackrestCore.js";

type M = number[][];
const seatDir = process.argv[2];
const backDir = process.argv[3];
const outPath = process.argv[4];
const DT = 50;
const SMOOTH = 120;

// ------------------------------------------------------------------ 工具
function parsePhys(text: string, R: number, C: number): { t: number; phys: M }[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const tsCol = lines[h].split(",").indexOf("采集时间戳（ms）");
  const ts: number[] = []; let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) { ts.push(Number(lines[i].split(",")[tsCol])); i++; }
  const frames: { t: number; phys: M }[] = []; let k = -1;
  while (i < lines.length) {
    const l = lines[i];
    if (/^--- 帧序号 #\d+ ---/.test(l)) { k++; i++; continue; }
    if (l.startsWith("插值前原始物理矩阵") && k >= 0) {
      const phys: M = [];
      for (let r = 0; r < R; r++) phys.push(lines[i + 2 + r].split(",").slice(1, C + 1).map(Number));
      frames.push({ t: ts[k], phys }); i += R + 2; continue;
    }
    i++;
  }
  return frames;
}
/** 坐垫：算法方向 → 原生方向（endiNativeToAlgorithm 的逆）。 */
function algToNative(a: M): M {
  const n = a.length;
  const out: M = Array.from({ length: n }, () => new Array<number>(n).fill(0));
  for (let R = 0; R < n; R++) for (let C = 0; C < n; C++) out[R][C] = a[C][n - 1 - R];
  return out;
}
/** 靠背：算法方向 25×32 → 原生 32×25（转置）。 */
const transpose = (a: M): M => a[0].map((_, c) => a.map(row => row[c]));
const zeros = (n = 23): M => Array.from({ length: n }, () => new Array<number>(n).fill(0));
const scaleAdc = (a: M, s: number): M => a.map(r => r.map(v => (v > 0 ? Math.min(255, Math.max(1, Math.round(v * s))) : 0)));
/** 双峰椭圆（臀部）合成轮廓，算法方向。 */
function humanBlob(cr: number, cc: number, scale: number, base: M = zeros()): M {
  const a = base.map(r => r.slice());
  const lobes = [[cr, cc - 3.2], [cr, cc + 3.2]];
  for (let r = 0; r < 23; r++) for (let c = 0; c < 23; c++) {
    let v = 0;
    for (const [lr, lc] of lobes) v = Math.max(v, 150 * Math.exp(-(((r - lr) / 3.6) ** 2 + ((c - lc) / 2.8) ** 2) / 1.6));
    v *= scale;
    if (v >= 6) a[r][c] = Math.max(a[r][c], Math.min(255, Math.round(v)));
  }
  return a;
}
function plateau(r0: number, r1: number, c0: number, c1: number, v: number): M {
  const a = zeros();
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) a[r][c] = v;
  return a;
}
function heavySmall(peak: number, w: number): M {
  const a = zeros();
  for (let r = 0; r < 23; r++) for (let c = 0; c < 23; c++) {
    const v = peak * Math.exp(-(((r - 11) / w) ** 2 + ((c - 11) / w) ** 2));
    if (v >= 6) a[r][c] = Math.min(255, Math.round(v));
  }
  return a;
}
function rotate(m: M, q: number): M {
  let a = m;
  for (let i = 0; i < ((q % 4) + 4) % 4; i++) {
    const R = a.length, C = a[0].length;
    const b: M = Array.from({ length: C }, () => new Array<number>(R));
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) b[c][R - 1 - r] = a[r][c];
    a = b;
  }
  return a;
}
const close = (a: number, b: number, tol = 1e-9) => Math.abs(a - b) <= tol;
const r2 = (v: number) => Math.round(v * 100) / 100;

interface Check { name: string; ok: boolean; detail?: unknown }
const checks: Check[] = [];
const add = (name: string, ok: boolean, detail?: unknown) => checks.push({ name, ok, detail });

/**
 * V2.7.104 逐帧同步核对：按主页同样的口径，比较“平均压强”卡片文字与热力图压强格子（非零格）平均值文字。
 * 卡片 = formatPressureNcm2(contactPressure.averagePressureKPa 取 2 位)；格子 = 每格 kPaToNcm2 后 3 位小数，按 0.001 单位求平均。
 */
const sync = { frames: 0, contactFrames: 0, humanFrames: 0, transitionFrames: 0, overFrames: 0, bad: [] as unknown[] };
/** V2.7.110 S9：真人区最大压强 ×1.5 逐帧统计。 */
const peak = {
  frames: 0, humanRegionFrames: 0, fullGainFrames: 0, transitionGainFrames: 0, realHumanFrames: 0,
  gainMismatch: 0, meanMismatch: 0, capped: 0, nonMonotonic: 0, nonHumanSharpened: 0,
  maxErrUnits: 0, ratioMin: Infinity, ratioMax: 0, gammaMin: Infinity, gammaMax: 0, bad: [] as unknown[], switchStartFrames: 0 as number | undefined,
  sample: null as unknown,
};
function checkPeak(tag: string, k: number, got: ContinuousForceFrame, pp: ReturnType<typeof attachEndiPointPressure>, heat: M) {
  if (!pp) return;
  peak.frames++;
  const regs = got.endiCushion?.regions ?? [];
  pp.summary.regions.forEach((r, j) => {
    const d = regs[j];
    if (!d || r.pointCount === 0) return;
    const P = got.contactPressure?.regions[j]?.estimatedPressureKPa ?? null;
    if (r.meanPressureKPa !== P) { peak.meanMismatch++; peak.bad.push({ tag, k, j, why: "区内格子平均≠区压强", mean: r.meanPressureKPa, P }); }
    if (Math.abs(r.peakGain - d.peakPressureGain) > 1e-12) { peak.gainMismatch++; peak.bad.push({ tag, k, j, why: "倍数与适配层不一致", a: r.peakGain, b: d.peakPressureGain }); }
    if (d.peakPressureGain > 1 + 1e-12) {
      peak.humanRegionFrames++;
      if (tag === "R0") peak.realHumanFrames++;
      const full = Math.abs(d.peakPressureGain - PEAK_GAIN) < 1e-12;
      if (full) peak.fullGainFrames++; else peak.transitionGainFrames++;
      // 倍数与系数同一 120 ms 过渡：倍数为 1.5 时系数必须仍是真人系数（切换首帧过渡起点允许类别已变）。
      const humanFactors = Math.abs(d.forceFactor - KF) < 1e-9 && Math.abs(d.areaFactor - KS) < 1e-9;
      if (full && !humanFactors) peak.bad.push({ tag, k, j, why: "倍数 1.5 但系数不是真人系数", kind: d.factorKind, fF: d.forceFactor, fS: d.areaFactor });
      if (full && d.factorKind !== "human") peak.switchStartFrames = (peak.switchStartFrames ?? 0) + 1;
      if (r.peakGainApplied < d.peakPressureGain - 1e-9) peak.capped++;
      const expMax = r.baseMaxPressureKPa! * d.peakPressureGain;
      const errUnits = Math.abs(r.maxPressureKPa! - expMax) * 100;
      if (errUnits > peak.maxErrUnits) peak.maxErrUnits = errUnits;
      if (errUnits > 2.0001) peak.bad.push({ tag, k, j, why: "最大格≠原比例最大格×倍数", max: r.maxPressureKPa, expMax, gain: d.peakPressureGain });
      if (full) {
        const ratio = r.maxPressureKPa! / r.baseMaxPressureKPa!;
        peak.ratioMin = Math.min(peak.ratioMin, ratio); peak.ratioMax = Math.max(peak.ratioMax, ratio);
        peak.gammaMin = Math.min(peak.gammaMin, r.peakExponent); peak.gammaMax = Math.max(peak.gammaMax, r.peakExponent);
        if (!peak.sample) peak.sample = { tag, k, region: j, cells: r.pointCount, P_Ncm2: P! / 10, baseMax_Ncm2: r.baseMaxPressureKPa! / 10, max_Ncm2: r.maxPressureKPa! / 10, ratio, gamma: r.peakExponent };
      }
      // 单调：ADC 升序时压强不下降（允许 1 个 0.001 N/cm² 取整单位）
      const cells: [number, number][] = [];
      pp.regionIndexMatrix.forEach((row, R) => row.forEach((v, C) => { if (v === j) cells.push([heat[R][C], pp.matrixKPa[R][C]]); }));
      cells.sort((a, b) => a[0] - b[0]);
      let prevGroupMax = -Infinity, curAdc = NaN, curMax = -Infinity, bad = 0;
      for (const [a, pk] of cells) {
        if (a !== curAdc) { prevGroupMax = Math.max(prevGroupMax, curMax); curAdc = a; curMax = -Infinity; }
        if (pk < prevGroupMax - 0.01 - 1e-9) bad++;
        curMax = Math.max(curMax, pk);
      }
      if (bad) { peak.nonMonotonic++; peak.bad.push({ tag, k, j, why: "ADC 大的格子压强反而小", bad }); }
    } else if (r.peakExponent !== 1 || r.peakGainApplied !== 1) {
      peak.nonHumanSharpened++; peak.bad.push({ tag, k, j, why: "非真人区被改分配", gamma: r.peakExponent });
    }
  });
}
function checkAvgSync(tag: string, k: number, got: ContinuousForceFrame, native: M) {
  const heat = lineInterp2x2(native, 23, 23);
  const pp = attachEndiPointPressure(got, "endi-23x23", native, heat);
  checkPeak(tag, k, got, pp, heat);
  const mat = endiPointPressureMatrix(got);
  let units = 0, n = 0;
  for (const row of mat ?? []) for (const v of row) if (v > 0) { units += Math.round(kPaToNcm2(v) * 1000); n++; }
  const cellMeanText = n > 0 ? (Math.round(units / n) / 1000).toFixed(3) : "--";
  const avg = got.contactPressure?.averagePressureKPa;
  const cardText = formatPressureNcm2(avg == null ? null : Number(avg.toFixed(2)));
  const regs = got.endiCushion?.regions ?? [];
  sync.frames++;
  if (regs.length) sync.contactFrames++;
  if (regs.some(r => r.factorKind === "human")) sync.humanFrames++;
  if (regs.some(r => r.factorKind === "over_range")) sync.overFrames++;
  if (regs.some(r => ![1, 2, KF].includes(+r.forceFactor.toFixed(6)) || ![1, KS].includes(+r.areaFactor.toFixed(6)))) sync.transitionFrames++;
  if (cellMeanText !== cardText) sync.bad.push({ tag, k, cellMeanText, cardText, cells: n, kinds: regs.map(r => r.factorKind) });
}
const report: Record<string, unknown> = {
  rules: { overRangeForceN: F_OVER, overRangeGain: GAIN, humanAreaCm2: S_HUMAN, humanForceN: F_HUMAN, humanForceFactor: KF, humanAreaFactor: KS,
    exitHoldMs: HOLD, smoothMs: SMOOTH, backrestOverRangeForceN: B_OVER, backrestOverRangeGain: B_GAIN, backrestOverRangeAreaGain: B_AGAIN },
};

type Kind = "standard" | "over_range" | "human";
const kindFactors = (k: Kind): [number, number] => (k === "human" ? [KF, KS] : k === "over_range" ? [GAIN, 1] : [1, 1]);

/**
 * 独立期望模型（不调用适配层）：
 *   超量程 —— 用核心输出的基准力逐帧复算“> 90 N 立即启动、≤ 90 N 连续 500 ms 取消”；
 *   真人 —— 全帧 ΣS > 600 且 ΣF > 300 立即启动，连续不满足 500 ms 退出，无接触立即退出；
 *   类别 —— 真人优先（仅非标准档区），否则超量程，否则标准；类别稳定 ≥ 120 ms 时系数必须严格等于目标值。
 */
class Expect {
  private over = new Map<number, { on: boolean; offSince: number | null }>();
  private kind = new Map<number, { k: Kind; since: number }>();
  private human = { on: false, offSince: null as number | null };
  private modeSince = new Map<number, { mode: string; since: number }>();
  overMismatch = 0;
  step(exp: any, t: number) {
    const regs = exp.regions as any[];
    let sumS = 0, sumF = 0;
    for (const r of regs) { sumS += r.S; sumF += r.F; }
    const humanRaw = sumS > S_HUMAN && sumF > F_HUMAN;
    if (regs.length === 0) this.human = { on: false, offSince: null };
    else if (humanRaw) this.human = { on: true, offSince: null };
    else if (this.human.on) {
      if (this.human.offSince === null) this.human.offSince = t;
      if (t - this.human.offSince >= HOLD) this.human = { on: false, offSince: null };
    }
    const seen = new Set<number>();
    const out = regs.map(r => {
      seen.add(r.track);
      let o = this.over.get(r.track);
      if (!o) { o = { on: false, offSince: null }; this.over.set(r.track, o); }
      if (r.F > F_OVER && 9.8 * r.mfit > F_OVER) { o.on = true; o.offSince = null; }
      else if (o.on) {
        if (o.offSince === null) o.offSince = t;
        if (t - o.offSince >= HOLD) { o.on = false; o.offSince = null; }
      }
      // 核心按“平滑前”的基准力判定；换模式后 120 ms 内输出力处于平滑过渡，此窗口内的差异不计
      let ms = this.modeSince.get(r.track);
      if (!ms) { ms = { mode: r.mode, since: -Infinity }; this.modeSince.set(r.track, ms); }
      else if (ms.mode !== r.mode) { ms.mode = r.mode; ms.since = t; }
      if (o.on !== r.over) {
        if (t - ms.since >= SMOOTH) this.overMismatch++;
        o.on = r.over; o.offSince = null;
      }
      const k: Kind = this.human.on && r.mode !== "标准档" ? "human" : r.over ? "over_range" : "standard";
      let st = this.kind.get(r.track);
      if (!st) { st = { k, since: -Infinity }; this.kind.set(r.track, st); }
      else if (st.k !== k) { st.k = k; st.since = t; }
      return { kind: k, stable: t - st.since >= SMOOTH };
    });
    for (const id of Array.from(this.over.keys())) if (!seen.has(id)) { this.over.delete(id); this.kind.delete(id); this.modeSince.delete(id); }
    return { humanRaw, humanOn: this.human.on, regions: out };
  }
}

/** 坐垫逐帧核对：适配层各区 = 核心基准值 × 系数，取整、总量与类别一致。 */
function verifySeatFrame(got: ContinuousForceFrame, exp: any, e: ReturnType<Expect["step"]>): string[] {
  const d = got.endiCushion!;
  const errs: string[] = [];
  if (d.regions.length !== exp.regions.length) return [`区数 ${d.regions.length}≠${exp.regions.length}`];
  if (d.humanConditionMet !== e.humanRaw) errs.push(`真人条件 ${d.humanConditionMet}≠${e.humanRaw}`);
  let sumF = 0, sumS = 0;
  d.regions.forEach((r, i) => {
    const c = exp.regions[i];
    const ek = e.regions[i];
    if (!close(r.coreForceN, c.F) || !close(r.coreAreaCm2, c.S) || !close(r.coreMassKg, c.m)) errs.push(`区${i} 核心基准值不一致`);
    if (r.factorKind !== ek.kind) errs.push(`区${i} 类别 ${r.factorKind}≠${ek.kind}`);
    if (r.humanEstimate !== (ek.kind === "human") || r.overRangeEstimate !== (ek.kind === "over_range")) errs.push(`区${i} 标记不一致`);
    const [eF, eS] = kindFactors(ek.kind);
    if (ek.stable) {
      if (r.forceFactor !== eF || r.areaFactor !== eS) errs.push(`区${i} 稳定帧系数 ${r.forceFactor}/${r.areaFactor} 应为 ${eF}/${eS}`);
    } else if (!(r.forceFactor >= KF - 1e-12 && r.forceFactor <= GAIN + 1e-12 && r.areaFactor >= KS - 1e-12 && r.areaFactor <= 1 + 1e-12)) {
      errs.push(`区${i} 过渡系数越界 ${r.forceFactor}/${r.areaFactor}`);
    }
    if (!close(r.forceN, c.F * r.forceFactor) || !close(r.areaCm2, c.S * r.areaFactor) || !close(r.massKg, c.m * r.forceFactor)) errs.push(`区${i} 乘系数后不一致`);
    const F = roundForceN(c.F * r.forceFactor), S = roundAreaCm2(c.S * r.areaFactor);
    if (got.regionForcesN![i] !== F) errs.push(`区${i} 压力 ${got.regionForcesN![i]}≠${F}`);
    const cp = got.contactPressure!.regions[i];
    if (cp.areaCm2 !== S) errs.push(`区${i} 面积 ${cp.areaCm2}≠${S}`);
    const P = c.P === null ? null : pressureKPaFromForceArea(F, S);
    if (cp.estimatedPressureKPa !== P) errs.push(`区${i} 压强 ${cp.estimatedPressureKPa}≠${P}`);
    sumF += F; sumS += c.S * r.areaFactor;
  });
  if (got.forceN !== roundForceN(sumF)) errs.push(`总力 ${got.forceN}≠${roundForceN(sumF)}`);
  if (got.areaCm2 !== roundAreaCm2(sumS)) errs.push(`总面积 ${got.areaCm2}≠${roundAreaCm2(sumS)}`);
  return errs;
}

/** 逐格压强与框选面积核对（坐垫显示方向 = 原生顺时针 3 次）。 */
function verifySeatPointAndSelection(got: ContinuousForceFrame, native: M, rot = 3) {
  const src = lineInterp2x2(native, 23, 23);
  const pp = attachEndiPointPressure(got, "endi-23x23", native, src);
  const errs: string[] = [];
  if (!pp) return { errs: ["无逐格压强"], info: null };
  const mat = endiPointPressureMatrix(got)!;
  let n = 0, sum = 0, mx = 0;
  for (const row of mat) for (const v of row) if (v > 0) { n++; sum += v; mx = Math.max(mx, v); }
  const mean = n ? Math.round((sum / n) * 100) / 100 : null;
  if (mean !== got.averagePressureKPa) errs.push(`格子平均 ${mean}≠平均压强 ${got.averagePressureKPa}`);
  if (pp.summary.maxPressureKPa !== mx) errs.push(`最大压强 ${pp.summary.maxPressureKPa}≠${mx}`);
  pp.summary.regions.forEach((r, k) => {
    const P = got.contactPressure!.regions[k]?.estimatedPressureKPa ?? null;
    if (r.pointCount > 0 && r.meanPressureKPa !== P) errs.push(`区${k} 格子平均 ${r.meanPressureKPa}≠区压强 ${P}`);
  });
  const disp = rotate(src, rot);
  const sel = { startRow: 0, startCol: 0, endRow: disp.length - 1, endCol: disp[0].length - 1 };
  const area = calculateDisplayedArea(disp, null, sel, { sensorType: "endi-23x23", sourceMatrix: disp, sourceRotation: rot });
  const owner = rotate(endiContourOwnerMatrix(got)!, rot);
  const factors = got.endiCushion!.regions.map(r => r.areaFactor);
  const ded = endiSeatSelectionHumanAreaDeduction(owner, factors, sel);
  const selArea = area ? Math.max(0, Math.round((area.areaCm2 - ded) * 100) / 100) : null;
  const expected = roundAreaCm2(got.endiCushion!.regions.reduce((s, r) => s + r.contourCells * r.areaFactor, 0));
  if (selArea !== expected) errs.push(`框选面积 ${selArea}≠${expected}`);
  return {
    errs,
    info: { pointCount: n, averagePressureNcm2: mean === null ? null : mean / 10, maxPressureNcm2: mx / 10, selectionAreaCm2: selArea },
  };
}

/** 坐垫场景运行器：逐帧调用实时适配层，并与独立的核心实例 + 期望模型对照。 */
function runSeat(name: string, seq: M[], t0 = 0) {
  resetLiveSeatForce();
  const ref = new EndiAlgorithm();
  const ex = new Expect();
  let errs: string[] = [];
  const trace: any[] = [];
  let lastGot: ContinuousForceFrame | null = null, lastNative: M | null = null;
  seq.forEach((alg, k) => {
    const t = t0 + k * DT;
    const native = algToNative(alg);
    const got = calculateLiveSensorForce("endi-23x23", [[0]], native, undefined, undefined, "fixed_load_recognition", { timestampMs: 100000 + t, streamId: name })!;
    const exp = ref.process(k * DT, alg);
    const e = ex.step(exp, k * DT);
    errs = errs.concat(verifySeatFrame(got, exp, e).map(x => `帧${k} ${x}`));
    checkAvgSync(name, k, got, native);
    const d = got.endiCushion!;
    trace.push({
      k, t: k * DT, baseF: r2(d.baseForceTotalN), fitF: d.regions.map(r => r2(9.8 * r.fitMassKg)), baseS: r2(d.baseAreaTotalCm2), humanCond: d.humanConditionMet, human: d.humanEstimateActive,
      over: d.overRangeActive, kinds: d.regions.map(r => r.factorKind), fF: d.regions.map(r => +r.forceFactor.toFixed(4)),
      fS: d.regions.map(r => +r.areaFactor.toFixed(4)), modes: d.regions.map(r => r.mode), forceN: got.forceN, areaCm2: got.areaCm2,
      avgNcm2: got.averagePressureKPa === null ? null : got.averagePressureKPa / 10,
    });
    lastGot = got; lastNative = native;
  });
  if (ex.overMismatch) errs.push(`核心超量程标记与独立复算不一致 ${ex.overMismatch} 帧`);
  return { errs, trace, lastGot: lastGot as ContinuousForceFrame | null, lastNative: lastNative as M | null, overMismatch: ex.overMismatch };
}

const seatFiles = fs.readdirSync(seatDir).filter(f => f.endsWith(".csv")).sort();
const backFiles = fs.readdirSync(backDir).filter(f => f.endsWith(".csv")).sort();

// ---------- R0 真实标定数据：不得出现超量程 / 真人 ----------
{
  let frames = 0, overFrames = 0, humanFrames = 0, maxBaseF = 0, maxBaseS = 0;
  const overByFile: Record<string, { frames: number[]; maxBaseForceN: number }> = {};
  let overOutside5 = 0;
  for (const f of seatFiles) {
    resetLiveSeatForce();
    const fr = parsePhys(fs.readFileSync(path.join(seatDir, f), "utf8"), 23, 23);
    for (const [k, x] of fr.entries()) {
      const nativeR0 = algToNative(x.phys);
      const got = calculateLiveSensorForce("endi-23x23", [[0]], nativeR0, undefined, undefined, "fixed_load_recognition", { timestampMs: x.t, streamId: "R0-" + f })!;
      checkAvgSync("R0-" + f, k, got, nativeR0);
      const d = got.endiCushion!;
      frames++;
      if (d.overRangeActive || d.regions.some(r => r.overRange)) {
        overFrames++;
        const e = (overByFile[f] ??= { frames: [], maxBaseForceN: 0 });
        e.frames.push(k);
        e.maxBaseForceN = Math.max(e.maxBaseForceN, ...d.regions.map(r => r2(r.coreForceN)));
        if (k % 100 < 80) overOutside5++;                     // 每 100 帧一轮，第 80–99 帧为 5 块段
      }
      if (d.humanEstimateActive || d.humanConditionMet) humanFrames++;
      for (const r of d.regions) maxBaseF = Math.max(maxBaseF, r.coreForceN);
      maxBaseS = Math.max(maxBaseS, d.baseAreaTotalCm2);
    }
  }
  let bFrames = 0, bOver = 0, bMaxF = 0;
  for (const f of backFiles) {
    resetLiveBackrestForce();
    const fr = parsePhys(fs.readFileSync(path.join(backDir, f), "utf8"), 25, 32);
    for (const x of fr) {
      const got = calculateLiveSensorForce("new-backrest-32x25", [[0]], transpose(x.phys), undefined, undefined, "fixed_load_recognition", { timestampMs: x.t, streamId: "R0B-" + f })!;
      bFrames++;
      const regs = got.endiBackrest!.regions;
      if (regs.some(r => r.overRange || r.mode === "超量程估算")) bOver++;
      for (const r of regs) bMaxF = Math.max(bMaxF, r.forceN);
    }
  }
  const overSummary = Object.fromEntries(Object.entries(overByFile).map(([f, e]) => [f, { count: e.frames.length, first: e.frames[0], last: e.frames[e.frames.length - 1], maxBaseForceN: e.maxBaseForceN }]));
  report.R0 = { seat: { files: seatFiles.length, frames, overFrames, overOutside5BlockSteps: overOutside5, overByFile: overSummary, humanFrames,
    maxRegionBaseForceN: r2(maxBaseF), maxFrameBaseAreaCm2: r2(maxBaseS) },
    backrest: { files: backFiles.length, frames: bFrames, overFrames: bOver, maxRegionForceN: r2(bMaxF) },
    note: "仅按状态机基准估算力 > 90 N 判定时，坐垫 2 个文件的第 2 轮 5 块段共 30 帧被状态机多估（91.95 / 104.78 N）而误触发；"
      + "加入连续拟合估算力 > 90 N 双重确认后为 0 帧。V2.7.102 旧判定在同一批数据中有 36 帧（4 个文件）超量程。" };
  add("R0 真实标定数据（1–5 块，坐垫 6200 帧 + 靠背 8800 帧）：均不出现超量程与真人估算",
    humanFrames === 0 && bOver === 0 && overFrames === 0 && frames === 6200 && bFrames === 8800 && overOutside5 === 0, report.R0);
}

// ---------- S1 坐垫砝码超量程 ----------
{
  const fr = parsePhys(fs.readFileSync(path.join(seatDir, seatFiles[0]), "utf8"), 23, 23);
  const seq: M[] = [];
  for (let k = 0; k < 100; k++) seq.push(fr[k].phys);                                         // 真实 1–5 块
  const hold5 = (k: number) => fr[80 + (k % 20)].phys;
  for (let k = 0; k < 8; k++) seq.push(scaleAdc(hold5(k), 1 + 0.15 * (k + 1) / 8));             // 加重到 ×1.15
  for (let k = 0; k < 40; k++) seq.push(scaleAdc(hold5(k), 1.15));                             // 保持 2 s
  for (let k = 0; k < 8; k++) seq.push(scaleAdc(hold5(k), 1.15 - 0.15 * (k + 1) / 8));          // 回到 5 块
  for (let k = 0; k < 40; k++) seq.push(hold5(k));                                            // 5 块保持 2 s
  for (let k = 0; k < 6; k++) seq.push(zeros());
  const res = runSeat("S1", seq);
  const tr = res.trace;
  const firstOver = tr.findIndex(x => x.kinds[0] === "over_range");
  const lastOver = tr.length - 1 - [...tr].reverse().findIndex(x => x.kinds[0] === "over_range");
  const before = tr[firstOver - 1], at = tr[firstOver], stable = tr[firstOver + 20];
  // 回落：最后一帧基准力 > 90 N 之后，超量程须再保持 ≥ 500 ms
  let lastAbove = -1;
  tr.forEach((x, i) => { if (x.kinds.length && x.baseF > F_OVER && x.fitF[0] > F_OVER) lastAbove = i; });
  const heldMs = (lastOver - lastAbove) * DT;
  const back = tr[lastOver + 1 + Math.ceil(SMOOTH / DT)];
  const pv = (() => {
    // 超量程保持段末帧的逐格压强核对
    resetLiveSeatForce();
    const sub = seq.slice(0, firstOver + 30);
    const r = runSeat("S1pp", sub);
    return verifySeatPointAndSelection(r.lastGot!, r.lastNative!);
  })();
  const firstFiveBlocks = tr.slice(80, 100).every(x => x.kinds[0] === "standard" && x.fF[0] === 1);
  report.S1 = {
    file: seatFiles[0], frames: seq.length, firstOverFrame: firstOver, lastOverFrame: lastOver, lastAbove90Frame: lastAbove, overHeldAfterDropMs: heldMs,
    beforeOver: before, firstOver: at, stableOver: stable, afterExit: back, final5: tr[tr.length - 8], pointPressure: pv.info,
    overMismatch: res.overMismatch, errors: res.errs.slice(0, 10), errorCount: res.errs.length,
  };
  add("S1 坐垫：真实 1–5 块不触发；基准力 > 90 N 立即超量程，压力 ×2、面积 = T29 轮廓；回落 ≤ 90 N 保持 500 ms 后取消",
    res.errs.length === 0 && pv.errs.length === 0 && firstFiveBlocks && firstOver > 100 && tr.slice(0, firstOver).every(x => !x.kinds.length || x.baseF <= F_OVER || x.fitF[0] <= F_OVER) &&
    tr.slice(firstOver, firstOver + Math.ceil(SMOOTH / DT) + 1).some(x => x.baseF > F_OVER && x.fitF[0] > F_OVER) &&
    stable.fF[0] === GAIN && stable.fS[0] === 1 && heldMs >= HOLD && heldMs < HOLD + 2 * DT && back.fF[0] === 1,
    { firstOver, heldMs, errs: res.errs.length, ppErrs: pv.errs });
}

// ---------- S2 坐垫纯真人（逐渐坐下） ----------
{
  const seq: M[] = [];
  for (let k = 0; k < 20; k++) seq.push(humanBlob(11, 11, 0.05 + 0.95 * (k + 1) / 20));
  for (let k = 0; k < 30; k++) seq.push(humanBlob(11, 11, 1 + 0.01 * Math.sin(k)));
  const res = runSeat("S2", seq);
  const tr = res.trace;
  const firstHuman = tr.findIndex(x => x.human);
  const overBefore = tr.slice(0, Math.max(0, firstHuman)).filter(x => x.kinds[0] === "over_range");
  const last = tr[tr.length - 1];
  const pv = verifySeatPointAndSelection(res.lastGot!, res.lastNative!);
  const r0 = res.lastGot!.endiCushion!.regions[0];
  const ratio = r0.corePressureKPa ? res.lastGot!.contactPressure!.regions[0].estimatedPressureKPa! / r0.corePressureKPa : null;
  report.S2 = {
    frames: seq.length, firstHumanFrame: firstHuman, overRangeFramesBeforeHuman: overBefore.length,
    lastOverBeforeHuman: overBefore[overBefore.length - 1] ?? null, firstHuman: tr[firstHuman], stableHuman: last,
    core: { forceN: r2(r0.coreForceN), areaCm2: r2(r0.coreAreaCm2), pressureNcm2: r0.corePressureKPa === null ? null : r0.corePressureKPa / 10, coreOverFlag: r0.overRange },
    pressureRatioToCore: ratio, pointPressure: pv.info, errors: res.errs.slice(0, 10), errorCount: res.errs.length,
  };
  add(`S2 坐垫真人：面积 ≤ 600 时按超量程 ×2；ΣS > 600 且 ΣF > 300 后压力 ×${KF}、面积 ×${KS}、不乘 ×2（压强 = 核心 ×${(KF / KS).toFixed(3)}）`,
    res.errs.length === 0 && pv.errs.length === 0 && firstHuman > 0 && overBefore.length > 0 && tr[firstHuman].baseS > S_HUMAN && tr[firstHuman].baseF > F_HUMAN &&
    last.kinds[0] === "human" && last.fF[0] === KF && last.fS[0] === KS && r0.overRange === true && ratio !== null && Math.abs(ratio - KF / KS) < 0.002,
    { firstHuman, overBefore: overBefore.length, ratio, errs: res.errs.length, ppErrs: pv.errs });
}

// ---------- S3 大面积轻载 / S4 小面积重载 ----------
for (const [key, label, frame] of [
  ["S3", "大面积轻载（面积 > 600 cm²、力 ≤ 300 N）", plateau(5, 17, 5, 17, 32)],
  ["S4", "小面积重载（力 > 300 N、面积 ≤ 600 cm²）", heavySmall(255, 3)],
] as [string, string, M][]) {
  const seq: M[] = Array.from({ length: 30 }, () => frame);
  const res = runSeat(key, seq);
  const last = res.trace[res.trace.length - 1];
  const pv = verifySeatPointAndSelection(res.lastGot!, res.lastNative!);
  report[key] = { last, pointPressure: pv.info, humanFrames: res.trace.filter(x => x.human).length, errors: res.errs.slice(0, 10), errorCount: res.errs.length };
  const cond = key === "S3" ? last.baseS > S_HUMAN && last.baseF <= F_HUMAN : last.baseF > F_HUMAN && last.baseS <= S_HUMAN;
  add(`${key} 坐垫${label}：不启动真人，按超量程 ×2`,
    res.errs.length === 0 && pv.errs.length === 0 && cond && res.trace.every(x => !x.human) && last.kinds[0] === "over_range" && last.fF[0] === GAIN && last.fS[0] === 1,
    { baseF: last.baseF, baseS: last.baseS, kinds: last.kinds, errs: res.errs.length });
}

// ---------- S5 坐垫砝码 + 真人 ----------
{
  const fr = parsePhys(fs.readFileSync(path.join(seatDir, seatFiles[0]), "utf8"), 23, 23);
  let chosen: { file: string; frames: M[] } | null = null;
  for (const f of seatFiles) {
    const x = parsePhys(fs.readFileSync(path.join(seatDir, f), "utf8"), 23, 23);
    const hold = x.slice(10, 20).map(y => y.phys);
    let w = 0, sr = 0, sc = 0;
    for (let r = 0; r < 23; r++) for (let c = 0; c < 23; c++) { const v = hold[0][r][c]; w += v; sr += v * r; sc += v * c; }
    const wr = sr / w, wc = sc / w;
    if (wr < 5 && (wc < 5 || wc > 17)) { chosen = { file: f, frames: hold }; break; }   // 角落砝码，真人放中心偏远侧
  }
  if (!chosen) chosen = { file: seatFiles[0], frames: fr.slice(10, 20).map(y => y.phys) };
  // 真人轮廓放在离砝码最远的一侧，确保两区不相连
  let w = 0, sr = 0, sc = 0;
  const h0 = chosen.frames[0];
  for (let r = 0; r < 23; r++) for (let c = 0; c < 23; c++) { const v = h0[r][c]; w += v; sr += v * r; sc += v * c; }
  const wr = sr / w, wc = sc / w;
  const hr = wr < 11 ? 15.5 : 7.5, hc = wc < 11 ? 14 : 8;
  const seq: M[] = [];
  for (let k = 0; k < 20; k++) seq.push(chosen.frames[k % 10]);
  for (let k = 0; k < 40; k++) seq.push(humanBlob(hr, hc, Math.min(1, (k + 1) / 8), chosen.frames[k % 10]));
  const res = runSeat("S5", seq);
  const tr = res.trace;
  const mixed = tr.filter(x => x.human && x.kinds.length === 2 && x.kinds.includes("human") && x.kinds.includes("standard"));
  const g = res.lastGot!.endiCushion!.regions;
  const weightOk = g.filter(r => r.mode === "标准档").every(r => r.forceFactor === 1 && r.areaFactor === 1);
  const pv = verifySeatPointAndSelection(res.lastGot!, res.lastNative!);
  report.S5 = {
    file: chosen.file, weightCenter: [r2(wr), r2(wc)], humanCenter: [hr, hc], mixedHumanFrames: mixed.length, last: tr[tr.length - 1],
    regions: g.map((r, i) => ({ mode: r.mode, level: r.level, kind: r.factorKind, forceFactor: r.forceFactor, areaFactor: r.areaFactor,
      coreForceN: r2(r.coreForceN), forceN: res.lastGot!.regionForcesN![i], areaCm2: res.lastGot!.contactPressure!.regions[i].areaCm2 })),
    pointPressure: pv.info, errors: res.errs.slice(0, 10), errorCount: res.errs.length,
  };
  add(`S5 坐垫砝码 + 真人：标准档砝码区系数 1，真人区 ${KF}/${KS}`, res.errs.length === 0 && pv.errs.length === 0 && mixed.length > 0 && weightOk &&
    g.some(r => r.factorKind === "human" && r.forceFactor === KF && r.areaFactor === KS), { mixed: mixed.length, weightOk, errs: res.errs.length, ppErrs: pv.errs });
}

// ---------- S6 坐垫真人退出防抖 ----------
{
  const seq: M[] = [];
  for (let k = 0; k < 20; k++) seq.push(humanBlob(11, 11, 1));
  for (let k = 0; k < 30; k++) seq.push(humanBlob(11, 11, 0.7));       // 面积 ≈ 500 cm² < 600，力仍 > 90 N
  for (let k = 0; k < 4; k++) seq.push(zeros());
  for (let k = 0; k < 10; k++) seq.push(humanBlob(11, 11, 1));
  for (let k = 0; k < 2; k++) seq.push(humanBlob(11, 11, 0.7));        // 短暂不满足（100 ms）
  for (let k = 0; k < 10; k++) seq.push(humanBlob(11, 11, 1));
  const res = runSeat("S6", seq);
  const tr = res.trace;
  const firstFalse = 20;
  const exitIdx = tr.findIndex((x, i) => i >= firstFalse && !x.human);
  const exitMs = (exitIdx - firstFalse) * DT;
  const afterExit = tr[exitIdx + Math.ceil(SMOOTH / DT)];
  const flickerHeld = tr.slice(64, 66).every(x => x.human);
  const zeroExit = tr.slice(50, 54).every(x => !x.human);
  report.S6 = { exitFrame: exitIdx, exitAfterMs: exitMs, beforeExit: tr[exitIdx - 1], atExit: tr[exitIdx], afterExit, flickerHeld, zeroExit,
    errors: res.errs.slice(0, 10), errorCount: res.errs.length };
  add("S6 坐垫真人防抖：条件不满足保持 500 ms 后退出（随后按超量程 ×2）；100 ms 短暂不满足不退出；无接触立即退出",
    res.errs.length === 0 && exitMs >= HOLD && exitMs < HOLD + 2 * DT && afterExit.kinds[0] === "over_range" && afterExit.fF[0] === GAIN && flickerHeld && zeroExit,
    { exitMs, flickerHeld, zeroExit, errs: res.errs.length });
}

// ---------- S7 坐垫静态单帧 ----------
{
  const h = calculateEndiSeatForce(algToNative(humanBlob(11, 11, 1)))!;
  const o = calculateEndiSeatForce(algToNative(heavySmall(255, 3)))!;
  const hr = h.endiCushion!.regions, orr = o.endiCushion!.regions;
  report.S7 = { human: hr.map(r => ({ kind: r.factorKind, fF: r.forceFactor, fS: r.areaFactor, coreF: r2(r.coreForceN), coreS: r.coreAreaCm2 })),
    overRange: orr.map(r => ({ kind: r.factorKind, fF: r.forceFactor, fS: r.areaFactor, coreF: r2(r.coreForceN), coreS: r.coreAreaCm2 })),
    humanForceN: h.forceN, humanAreaCm2: h.areaCm2, overForceN: o.forceN, overAreaCm2: o.areaCm2 };
  add(`S7 坐垫静态单帧：真人直接 ${KF}/${KS}，超量程直接 ×2`,
    hr.length === 1 && hr[0].factorKind === "human" && hr[0].forceFactor === KF && hr[0].areaFactor === KS && h.forceN === roundForceN(hr[0].coreForceN * KF) &&
    orr.length === 1 && orr[0].factorKind === "over_range" && orr[0].forceFactor === GAIN && orr[0].areaFactor === 1 && o.forceN === roundForceN(orr[0].coreForceN * GAIN));
}

// ---------- B1 靠背砝码超量程 ----------
/**
 * V2.7.108 靠背逐帧核对：适配层各区面积 = round2(核心 S)，区压强 = 10·F/S（F、S 先取 2 位），总面积 = round2(ΣS)；
 * 逐格压强格子平均 = 平均压强、区内格子平均 = 区压强；框选（全图，显示旋转 0 与 1 次）面积 = Σ 轮廓格 × 1.30 × 区面积系数。
 */
const b1 = { overFrames: 0, stableOverFrames: 0 };
function verifyBackrestFrame(got: ContinuousForceFrame, exp: any, k: number) {
  const errs: string[] = [];
  const d = got.endiBackrest!;
  if (d.regions.length !== exp.regions.length) return { errs: [`帧${k} 区数`], over: false, selArea: null as number | null };
  let sumS = 0;
  exp.regions.forEach((c: any, i: number) => {
    const F = roundForceN(c.forceN), S = roundAreaCm2(c.areaCm2);
    const cp = got.contactPressure!.regions[i];
    if (cp.areaCm2 !== S) errs.push(`帧${k} 区${i} 面积 ${cp.areaCm2}≠${S}`);
    if (got.regionForcesN && got.regionForcesN[i] !== undefined && got.regionForcesN[i] !== F) errs.push(`帧${k} 区${i} 压力 ${got.regionForcesN[i]}≠${F}`);
    const P = c.pressureKPa === null ? null : pressureKPaFromForceArea(F, S);
    if (cp.estimatedPressureKPa !== P) errs.push(`帧${k} 区${i} 压强 ${cp.estimatedPressureKPa}≠${P}`);
    sumS += c.areaCm2;
  });
  if (got.areaCm2 !== roundAreaCm2(sumS)) errs.push(`帧${k} 总面积 ${got.areaCm2}≠${roundAreaCm2(sumS)}`);
  const src = lineInterp2x2(transpose(exp._alg), 32, 25);
  const pp = attachEndiPointPressure(got, "new-backrest-32x25", transpose(exp._alg), src);
  let selArea: number | null = null;
  if (d.regions.length) {
    if (!pp) errs.push(`帧${k} 无逐格压强`);
    else {
      const mat = endiPointPressureMatrix(got)!;
      let n = 0, sum = 0, mx = 0;
      for (const row of mat) for (const v of row) if (v > 0) { n++; sum += v; mx = Math.max(mx, v); }
      const mean = n ? Math.round((sum / n) * 100) / 100 : null;
      if (mean !== got.averagePressureKPa) errs.push(`帧${k} 格子平均 ${mean}≠平均压强 ${got.averagePressureKPa}`);
      if (pp.summary.maxPressureKPa !== mx) errs.push(`帧${k} 最大压强 ${pp.summary.maxPressureKPa}≠${mx}`);
      pp.summary.regions.forEach((r, j) => {
        const P = got.contactPressure!.regions[j]?.estimatedPressureKPa ?? null;
        if (r.pointCount > 0 && r.meanPressureKPa !== P) errs.push(`帧${k} 区${j} 格子平均 ${r.meanPressureKPa}≠区压强 ${P}`);
      });
      const factors = d.regions.map(r => (r.overRange ? B_AGAIN : 1));
      const expected = roundAreaCm2(d.regions.reduce((s, r, j) => s + Math.round(r.contourAreaCm2 / B_CELL) * B_CELL * factors[j], 0));
      for (const rot of [0, 1]) {
        const disp = rotate(src, rot);
        const sel = { startRow: 0, startCol: 0, endRow: disp.length - 1, endCol: disp[0].length - 1 };
        const area = calculateDisplayedArea(disp, null, sel, { sensorType: "new-backrest-32x25", sourceMatrix: disp, sourceRotation: rot });
        const owner = rotate(endiContourOwnerMatrix(got)!, rot);
        const add2 = endiSelectionAreaFactorAdjustment(owner, factors, sel, B_CELL);
        const v = area ? Math.max(0, Math.round((area.areaCm2 + add2) * 100) / 100) : null;
        if (v !== expected) errs.push(`帧${k} 框选面积(旋转${rot}) ${v}≠${expected}`);
        if (rot === 0) selArea = v;
      }
    }
  }
  return { errs, over: d.regions.some(r => r.overRange), selArea };
}
{
  const fr = parsePhys(fs.readFileSync(path.join(backDir, backFiles[0]), "utf8"), 25, 32);
  const seq: M[] = [];
  for (let k = 0; k < 100; k++) seq.push(fr[k].phys);
  const hold5 = (k: number) => fr[80 + (k % 20)].phys;
  for (let k = 0; k < 8; k++) seq.push(scaleAdc(hold5(k), 1 + 0.15 * (k + 1) / 8));
  for (let k = 0; k < 40; k++) seq.push(scaleAdc(hold5(k), 1.15));
  for (let k = 0; k < 8; k++) seq.push(scaleAdc(hold5(k), 1.15 - 0.15 * (k + 1) / 8));
  for (let k = 0; k < 40; k++) seq.push(hold5(k));
  for (let k = 0; k < 6; k++) seq.push(Array.from({ length: 25 }, () => new Array<number>(32).fill(0)));
  resetLiveBackrestForce();
  const ref = new EndiBackrestAlgorithm();
  const errs: string[] = [];
  const trace: any[] = [];
  let lastMode: string | null = null, modeSince = -Infinity;
  const latch = { on: false, offSince: null as number | null };
  let latchMismatch = 0, stableFrames = 0;
  seq.forEach((alg, k) => {
    const t = k * DT;
    const native = transpose(alg);
    const got = calculateLiveSensorForce("new-backrest-32x25", [[0]], native, undefined, undefined, "fixed_load_recognition", { timestampMs: 500000 + t, streamId: "B1" })!;
    const exp: any = ref.process(alg, t);
    exp._alg = alg;
    // V2.7.108：区面积 / 区压强 / 总面积（适配层取整口径），逐格压强同步与框选面积
    const bv = verifyBackrestFrame(got, exp, k);
    errs.push(...bv.errs);
    if (bv.over) b1.overFrames++;
    if (Math.abs(got.forceN - exp.totalForceN) > 0.0051 * Math.max(1, exp.regions.length)) errs.push(`帧${k} 总力 ${got.forceN}≠${exp.totalForceN}`);
    const regs = got.endiBackrest!.regions;
    if (regs.length !== exp.regions.length) { errs.push(`帧${k} 区数`); return; }
    const r = exp.regions[0];
    if (r) {
      if (regs[0].mode !== (r.mode === "overrange" ? "超量程估算" : r.mode === "standard" ? "标准档" : "估算")) errs.push(`帧${k} 模式不一致`);
      if (r.mode !== lastMode) { lastMode = r.mode; modeSince = t; }
      // 核心平滑结束后的稳定帧：基准力 = F / 2（超量程）或 F，复算“> 90 N 立即启动、≤ 90 N 连续 500 ms 取消”
      const base = r.mode === "overrange" ? r.forceN / B_GAIN : r.forceN;
      const fitF = 9.8 * r.massFitKg;
      if (t - modeSince >= SMOOTH) {
        stableFrames++;
        const eS = r.mode === "overrange" ? r.contourAreaCm2 * B_AGAIN : r.mode === "standard" ? B_BASE : r.contourAreaCm2;
        if (!close(r.areaCm2, eS, 1e-9)) errs.push(`帧${k} 稳定帧面积 ${r.areaCm2}≠${eS}（${r.mode}）`);
        if (r.mode === "overrange") {
          b1.stableOverFrames++;
          // 超量程稳定帧：区压强 = 2F/2S = 基准力 / T39 轮廓面积
          const pBase = 10 * (r.forceN / B_GAIN) / r.contourAreaCm2;
          if (!close(r.pressureKPa, pBase, 1e-9)) errs.push(`帧${k} 超量程压强 ${r.pressureKPa}≠基准 ${pBase}`);
        }
        if (base > B_OVER && fitF > B_OVER) { latch.on = true; latch.offSince = null; }
        else if (latch.on) { if (latch.offSince === null) latch.offSince = t; if (t - latch.offSince >= HOLD) { latch.on = false; latch.offSince = null; } }
        if (latch.on !== (r.mode === "overrange")) latchMismatch++;
      }
      trace.push({ k, t, mode: r.mode, state: r.state, blocks: r.blocks, forceN: r2(r.forceN), baseForceN: r2(base), fitForceN: r2(fitF), areaCm2: r2(r.areaCm2),
        contourAreaCm2: r2(r.contourAreaCm2), pressureNcm2: r.pressureKPa === null ? null : Math.round(r.pressureKPa * 100) / 1000,
        shown: got.forceN, shownAreaCm2: got.areaCm2, shownPressureNcm2: got.contactPressure?.regions[0]?.estimatedPressureKPa == null ? null : got.contactPressure.regions[0].estimatedPressureKPa! / 10,
        avgNcm2: got.averagePressureKPa === null ? null : got.averagePressureKPa / 10, selAreaCm2: bv.selArea, stable: t - modeSince >= SMOOTH });
    } else trace.push({ k, t, mode: null });
  });
  const firstOver = trace.findIndex(x => x.mode === "overrange");
  const lastOver = trace.length - 1 - [...trace].reverse().findIndex(x => x.mode === "overrange");
  let lastAbove = -1;
  trace.forEach((x, i) => { if (x.mode && x.stable && x.baseForceN > B_OVER && x.fitForceN > B_OVER) lastAbove = i; });
  const heldMs = (lastOver - lastAbove) * DT;
  const real5 = trace.slice(80, 100).every(x => x.mode === "standard");
  const stable = trace[firstOver + 20];
  report.B1 = { file: backFiles[0], frames: seq.length, overAreaGain: B_AGAIN, overFrames: b1.overFrames, stableOverFrames: b1.stableOverFrames,
    firstOverFrame: firstOver, beforeOver: trace[firstOver - 1], firstOver: trace[firstOver], stableOver: stable,
    lastAbove90Frame: lastAbove, lastOverFrame: lastOver, overHeldAfterDropMs: heldMs, afterExit: trace[lastOver + 4], final5: trace[trace.length - 8],
    stableFrames, latchMismatch, errors: errs.slice(0, 10), errorCount: errs.length };
  const areaRatio = stable.areaCm2 / stable.contourAreaCm2;
  add(`B1 靠背：真实 1–5 块不触发；基准力 > 90 N 立即超量程（压力 ×${B_GAIN}、面积 = T39 轮廓 ×${B_AGAIN}，区压强 = F/S 不变），回落 ≤ 90 N 保持 500 ms 后取消；无真人系数；`
    + "逐帧区面积/区压强/格子平均=平均压强/框选面积一致",
    errs.length === 0 && real5 && firstOver > 100 && latchMismatch === 0 && Math.abs(stable.forceN / stable.baseForceN - B_GAIN) < 1e-9 &&
    Math.abs(areaRatio - B_AGAIN) < 1e-6 && b1.stableOverFrames > 20 && b1.overFrames > 0 &&
    heldMs >= HOLD && heldMs < HOLD + 2 * DT + SMOOTH, { firstOver, heldMs, latchMismatch, areaRatio, stableOverFrames: b1.stableOverFrames, errs: errs.length });
}

// ---------- S8 平均压强与格子同步（V2.7.104）：R0 真实数据 + S1–S7 全部坐垫帧（含 120 ms 系数过渡帧）----------
report.S8 = { ...sync, bad: sync.bad.slice(0, 20), badCount: sync.bad.length };
add("S8 坐垫每一帧：平均压强卡片 = 热力图压强格子平均（N/cm² 3 位小数，含真人、超量程与 120 ms 过渡帧）",
  sync.bad.length === 0 && sync.frames > 6500 && sync.humanFrames >= 40 && sync.transitionFrames > 0 && sync.overFrames > 0,
  { frames: sync.frames, contactFrames: sync.contactFrames, humanFrames: sync.humanFrames, overFrames: sync.overFrames, transitionFrames: sync.transitionFrames, bad: sync.bad.length });
// ---------- S9 真人估算区最大压强 ×1.5（V2.7.110）：与 S8 同一批坐垫帧 ----------
report.S9 = { ...peak, bad: peak.bad.slice(0, 20), badCount: peak.bad.length };
add(`S9 坐垫真人估算区：最大格 = 原比例分配最大格 × ${PEAK_GAIN}（过渡帧按 1–${PEAK_GAIN}），区内格子平均 = 区压强，ADC 大压强大；非真人区不变；真实砝码数据不触发`,
  peak.bad.length === 0 && peak.fullGainFrames >= 40 && peak.transitionGainFrames > 0 && peak.realHumanFrames === 0 && peak.capped === 0 &&
  peak.ratioMin > PEAK_GAIN - 0.02 && peak.ratioMax < PEAK_GAIN + 0.02,
  { frames: peak.frames, humanRegionFrames: peak.humanRegionFrames, fullGainFrames: peak.fullGainFrames, transitionGainFrames: peak.transitionGainFrames,
    ratioMin: peak.ratioMin, ratioMax: peak.ratioMax, gammaMin: peak.gammaMin, gammaMax: peak.gammaMax, maxErrUnits: peak.maxErrUnits, capped: peak.capped, bad: peak.bad.length });
resetLiveSeatForce();
resetLiveBackrestForce();
const passed = checks.every(c => c.ok);
report.checks = checks;
report.passed = passed;
const text = JSON.stringify(report, null, 1);
if (outPath) fs.writeFileSync(outPath, text);
console.log(checks.map(c => `${c.ok ? "PASS" : "FAIL"}  ${c.name}  ${JSON.stringify(c.detail ?? "")}`).join("\n"));
console.log(passed ? "ALL PASS" : "SOME FAILED");
process.exit(passed ? 0 : 1);
