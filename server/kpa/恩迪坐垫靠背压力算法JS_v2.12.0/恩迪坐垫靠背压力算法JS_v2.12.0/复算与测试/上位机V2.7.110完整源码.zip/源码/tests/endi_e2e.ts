/**
 * 端到端核对：采集 CSV 的原始 1024 字节 → 上位机 wireMap 解码（原生方向）→ calculateLiveSensorForce（坐垫新算法）
 * 对照：直接用 CSV“插值前原始物理矩阵”调用算法核心（与 Python 参考实现逐帧一致的版本）。
 * 用法：npx tsx tests/endi_e2e.ts <CSV 目录>
 */
import fs from "node:fs";
import path from "node:path";
import { getSensorConfig } from "../client/src/lib/sensorConfig";
import { calculateLiveSensorForce, resetLiveSeatForce } from "../client/src/lib/sensorForce";
import { calculateDisplayedArea } from "../client/src/lib/displayArea";
import { lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { EndiAlgorithm } from "../client/src/lib/endiCushion/endiCushionCore.js";

const dir = process.argv[2];
const cfg = getSensorConfig("endi-23x23");
const files = fs.readdirSync(dir).filter(f => f.endsWith(".csv")).sort();

interface Frame { t: number; raw: number[]; phys: number[][] }

function parse(text: string): Frame[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const ts: number[] = [];
  let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) { ts.push(Number(lines[i].split(",")[4])); i++; }
  const frames: Frame[] = [];
  let k = -1; let raw: number[] = [];
  while (i < lines.length) {
    const l = lines[i];
    if (/^--- 帧序号 #\d+ ---/.test(l)) { k++; raw = []; i++; continue; }
    if (l.startsWith("原始字节")) {
      for (let r = 0; r < 32; r++) raw.push(...lines[i + 2 + r].split(",").slice(1, 33).map(Number));
      i += 34; continue;
    }
    if (l.startsWith("插值前原始物理矩阵") && k >= 0) {
      const phys: number[][] = [];
      for (let r = 0; r < 23; r++) phys.push(lines[i + 2 + r].split(",").slice(1, 24).map(Number));
      frames.push({ t: ts[k], raw, phys });
      i += 25; continue;
    }
    i++;
  }
  return frames;
}

function decodeNative(raw: number[]): number[][] {
  const out: number[][] = [];
  for (let r = 0; r < cfg.physicalRows; r++) {
    const row: number[] = [];
    for (let c = 0; c < cfg.physicalCols; c++) { const idx = cfg.wireMap[r * cfg.physicalCols + c]; row.push(idx < raw.length ? raw[idx] : 0); }
    out.push(row);
  }
  return out;
}

let nFrames = 0, orientOk = 0, maxDF = 0, maxDS = 0, maxDP = 0, pNullMismatch = 0, modeMismatch = 0;
let areaChecks = 0, areaMismatch = 0;
const holdErr: number[] = [];
const perLevel: Record<number, { n: number; ok: number }> = {};
for (const f of files) {
  const frames = parse(fs.readFileSync(path.join(dir, f), "utf8"));
  for (let s = 0, g = 0; s + 100 <= frames.length; s += 100, g++) {
    const ref = new EndiAlgorithm();
    const t0 = frames[s].t;
    const streamId = `${f}|${g}`;
    for (let k = 0; k < 100; k++) {
      const fr = frames[s + k];
      const native = decodeNative(fr.raw);
      // 方向核对：顺时针 90° 后应等于 CSV 物理矩阵
      let same = true;
      for (let r = 0; r < 23 && same; r++) for (let c = 0; c < 23; c++) if (native[22 - c][r] !== fr.phys[r][c]) { same = false; break; }
      if (same) orientOk++;
      const got = calculateLiveSensorForce("endi-23x23", [[0]], native, undefined, undefined, "fixed_load_recognition", { timestampMs: fr.t, streamId });
      const exp = ref.process(fr.t - t0, fr.phys);
      nFrames++;
      if (!got) { pNullMismatch++; continue; }
      maxDF = Math.max(maxDF, Math.abs(got.forceN - exp.F));
      maxDS = Math.max(maxDS, Math.abs(got.areaCm2 - exp.S));
      if ((got.averagePressureKPa === null) !== (exp.P === null)) pNullMismatch++;
      else if (exp.P !== null) maxDP = Math.max(maxDP, Math.abs(got.averagePressureKPa! - exp.P));
      const gm = got.endiCushion!.regions.map(r => r.mode + r.level).join(",");
      const em = exp.regions.map(r => r.mode + r.level).join(",");
      if (gm !== em) modeMismatch++;
      // 框选面积（全图）：设备插值 + 显示旋转 3 后的 T29 计数应等于算法 46×46 轮廓总格数
      if (k % 10 === 9) {
        const src = lineInterp2x2(native, 23, 23);
        const rot = rotate(src, 3);
        const area = calculateDisplayedArea(rot, null, null, { sensorType: "endi-23x23", sourceMatrix: rot, sourceRotation: 3 });
        const nt = exp.regions.reduce((a, r) => a + r.NT, 0);
        areaChecks++;
        if (!area || area.areaCm2 !== nt) areaMismatch++;
      }
      // 保持帧（每档后 10 帧）读数误差
      const step = Math.floor(k / 20) + 1;
      if (k % 20 >= 10) {
        const truth = 1.625 * step;
        const e = got.forceN / 9.8 - truth;
        holdErr.push(Math.abs(e));
        perLevel[step] ??= { n: 0, ok: 0 };
        perLevel[step].n++;
        if (Math.abs(e) <= 0.01) perLevel[step].ok++;
      }
    }
  }
}
resetLiveSeatForce();

function rotate(m: number[][], q: number): number[][] {
  let a = m;
  for (let i = 0; i < ((q % 4) + 4) % 4; i++) {
    const R = a.length, C = a[0].length;
    const b: number[][] = Array.from({ length: C }, () => new Array<number>(R));
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) b[c][R - 1 - r] = a[r][c];
    a = b;
  }
  return a;
}

holdErr.sort((a, b) => a - b);
const q = (p: number) => holdErr[Math.min(holdErr.length - 1, Math.floor(p * holdErr.length))];
console.log(JSON.stringify({
  files: files.length, frames: nFrames, orientationMatches: orientOk,
  maxAbsDiff: { forceN: maxDF, areaCm2: maxDS, pressureKPa: maxDP }, nullMismatch: pNullMismatch, modeLevelMismatch: modeMismatch,
  selectionAreaChecks: areaChecks, selectionAreaMismatch: areaMismatch,
  holdFrames: holdErr.length, holdMassAbsErrKg: { p50: q(0.5), p95: q(0.95), max: holdErr[holdErr.length - 1] },
  holdWithin10g: Object.fromEntries(Object.entries(perLevel).map(([k, v]) => [k + "块", `${v.ok}/${v.n}`])),
}, null, 1));
