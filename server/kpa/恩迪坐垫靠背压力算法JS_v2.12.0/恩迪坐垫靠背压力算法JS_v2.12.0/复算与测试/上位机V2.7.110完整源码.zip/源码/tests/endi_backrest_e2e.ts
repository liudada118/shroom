/**
 * 靠背端到端核对：采集 CSV 的原始 1024 字节 → 上位机 wireMap 解码（原生 32×25）→ calculateLiveSensorForce（靠背新算法）
 * 对照：直接用 CSV“插值前原始物理矩阵（25×32）”与“采集时间戳（ms）”调用算法核心（与交付的 replay_csv.js 相同的连续回放方式）。
 * 另统计按标定口径（每 100 帧一组、每 20 帧一档 1.625 kg 起）的识别结果。
 * 用法：npx tsx tests/endi_backrest_e2e.ts <CSV 目录> [输出 JSON]
 */
import fs from "node:fs";
import path from "node:path";
import { getSensorConfig, lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { calculateLiveSensorForce, resetLiveBackrestForce } from "../client/src/lib/sensorForce";
import { calculateDisplayedArea } from "../client/src/lib/displayArea";
import { EndiBackrestAlgorithm, interpolate } from "../client/src/lib/endiBackrest/endiBackrestCore.js";

const dir = process.argv[2];
const outPath = process.argv[3];
const SENSOR = "new-backrest-32x25" as const;
const cfg = getSensorConfig(SENSOR);
const files = fs.readdirSync(dir).filter(f => f.endsWith(".csv")).sort();
interface Frame { t: number; raw: number[]; phys: number[][] }

function parse(text: string): Frame[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const header = lines[h].split(",");
  const tsCol = header.indexOf("采集时间戳（ms）");
  const ts = new Map<number, number>();
  let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) {
    const p = lines[i].split(","); ts.set(Number(p[0]), Number(p[tsCol])); i++;
  }
  const frames: Frame[] = [];
  let id = -1; let raw: number[] = [];
  while (i < lines.length) {
    const l = lines[i];
    const m = /^--- 帧序号 #(\d+) ---/.exec(l);
    if (m) { id = Number(m[1]); raw = []; i++; continue; }
    if (l.startsWith("原始字节")) {
      for (let r = 0; r < 32; r++) raw.push(...lines[i + 2 + r].split(",").slice(1, 33).map(Number));
      i += 34; continue;
    }
    if (l.startsWith("插值前原始物理矩阵") && id >= 0) {
      const phys: number[][] = [];
      for (let r = 0; r < 25; r++) phys.push(lines[i + 2 + r].split(",").slice(1, 33).map(Number));
      frames.push({ t: ts.get(id)!, raw, phys });
      i += 27; continue;
    }
    i++;
  }
  return frames;
}

function decodeNative(raw: number[]): number[][] {
  const out: number[][] = [];
  for (let r = 0; r < cfg.physicalRows; r++) {
    const row: number[] = [];
    for (let c = 0; c < cfg.physicalCols; c++) { const idx = cfg.wireMap[r * cfg.physicalCols + c]; row.push(idx < raw.length ? raw[idx] : 0); }
    out.push(row);
  }
  return out;
}

function rotate(m: number[][], q: number): number[][] {
  let a = m;
  for (let i = 0; i < ((q % 4) + 4) % 4; i++) {
    const R = a.length, C = a[0].length;
    const b: number[][] = Array.from({ length: C }, () => new Array<number>(R));
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) b[c][R - 1 - r] = a[r][c];
    a = b;
  }
  return a;
}

let nFrames = 0, orientOk = 0, maxDF = 0, maxDS = 0, maxDP = 0, maxDM = 0, nullMismatch = 0, stateMismatch = 0, gotNull = 0;
let areaChecks = 0, areaMismatch = 0;
let stepEnds = 0, stepEndOk = 0;
const holdErr: number[] = [];
const perLevel: Record<string, { n: number; ok50: number; ok10: number; endOk: number; endN: number }> = {};
const perFile: { file: string; frames: number; stepEndOk: number; stepEnds: number; holdWithin50g: string }[] = [];
const t0 = Date.now();
for (const f of files) {
  const frames = parse(fs.readFileSync(path.join(dir, f), "utf8"));
  const ref = new EndiBackrestAlgorithm();
  const streamId = `${SENSOR}|${f}`;
  let fEnds = 0, fEndOk = 0, fHold = 0, fHoldOk = 0;
  frames.forEach((fr, idx) => {
    const native = decodeNative(fr.raw);
    // 方向核对：转置后应等于 CSV 物理矩阵（25×32）
    let same = true;
    for (let r = 0; r < 25 && same; r++) for (let c = 0; c < 32; c++) if (native[c][r] !== fr.phys[r][c]) { same = false; break; }
    if (same) orientOk++;
    const got = calculateLiveSensorForce(SENSOR, [[0]], native, undefined, undefined, "fixed_load_recognition",
      { timestampMs: fr.t, streamId, method: "fixed_load_recognition" });
    const exp = ref.process(fr.phys, fr.t);
    nFrames++;
    if (!got) { gotNull++; return; }
    maxDF = Math.max(maxDF, Math.abs(got.forceN - exp.totalForceN));
    maxDS = Math.max(maxDS, Math.abs(got.areaCm2 - exp.totalAreaCm2));
    maxDM = Math.max(maxDM, Math.abs(got.endiBackrest!.massKg - exp.totalMassKg));
    if ((got.averagePressureKPa === null) !== (exp.avgPressureKPa === null)) nullMismatch++;
    else if (exp.avgPressureKPa !== null) maxDP = Math.max(maxDP, Math.abs(got.averagePressureKPa! - exp.avgPressureKPa));
    const gs = got.endiBackrest!.regions.map(r => `${r.mode}${r.level}`).join(",");
    const es = exp.regions.map(r => `${({ standard: "标准档", estimate: "估算", overrange: "超量程估算" } as const)[r.mode]}${r.blocks}`).join(",");
    if (gs !== es) stateMismatch++;
    // 框选面积（全图）：设备插值（原生 64×50）+ 显示旋转 3 后的 T39 计数 × 1.30 应等于核心插值的 T39 计数 × 1.30
    if (idx % 10 === 9) {
      const src = lineInterp2x2(native, 32, 25);
      const rot = rotate(src, 3);
      const area = calculateDisplayedArea(rot, null, null, { sensorType: SENSOR, sourceMatrix: rot, sourceRotation: 3 });
      const flat = fr.phys.flat();
      const it = interpolate(flat, 25, 32);
      let n = 0; for (let k = 0; k < it.length; k++) if (it[k] >= 39) n++;
      areaChecks++;
      if (!area || Math.abs(area.areaCm2 - Math.round(n * 1.3 * 1e6) / 1e6) > 1e-9) areaMismatch++;
    }
    // 标定口径：每 100 帧一组，每 20 帧一档（1.625 kg × 档位）
    const k = idx % 100;
    const step = Math.floor(k / 20) + 1;
    const truth = 1.625 * step;
    const m = got.endiBackrest!.massKg;
    const key = `${step}块`;
    perLevel[key] ??= { n: 0, ok50: 0, ok10: 0, endOk: 0, endN: 0 };
    if (k % 20 >= 10) {
      const e = Math.abs(m - truth);
      holdErr.push(e);
      perLevel[key].n++;
      if (e <= 0.05) { perLevel[key].ok50++; fHoldOk++; }
      if (e <= 0.01) perLevel[key].ok10++;
      fHold++;
    }
    if (k % 20 === 19) {
      const ok = Math.round(m / 1.625) === step;
      stepEnds++; fEnds++; perLevel[key].endN++;
      if (ok) { stepEndOk++; fEndOk++; perLevel[key].endOk++; }
    }
  });
  perFile.push({ file: f, frames: frames.length, stepEndOk: fEndOk, stepEnds: fEnds, holdWithin50g: `${fHoldOk}/${fHold}` });
}
resetLiveBackrestForce();
holdErr.sort((a, b) => a - b);
const q = (p: number) => holdErr[Math.min(holdErr.length - 1, Math.floor(p * holdErr.length))];
const result = {
  files: files.length, frames: nFrames, elapsedMs: Date.now() - t0, orientationMatches: orientOk, adapterNull: gotNull,
  maxAbsDiff: { forceN: maxDF, massKg: maxDM, areaCm2: maxDS, pressureKPa: maxDP }, nullMismatch, modeLevelMismatch: stateMismatch,
  selectionAreaChecks: areaChecks, selectionAreaMismatch: areaMismatch,
  stepEndLevel: `${stepEndOk}/${stepEnds}`,
  holdFrames: holdErr.length, holdMassAbsErrKg: { p50: q(0.5), p95: q(0.95), p99: q(0.99), max: holdErr[holdErr.length - 1] },
  holdWithin50g: holdErr.filter(e => e <= 0.05).length, holdWithin10g: holdErr.filter(e => e <= 0.01).length,
  perLevel, perFile,
};
if (outPath) fs.writeFileSync(outPath, JSON.stringify(result, null, 1));
const { perFile: _pf, ...summary } = result;
console.log(JSON.stringify(summary, null, 1));
console.log("步末档位未全对的文件：", perFile.filter(p => p.stepEndOk !== p.stepEnds).map(p => `${p.file} ${p.stepEndOk}/${p.stepEnds} 保持${p.holdWithin50g}`).join("；") || "无");
