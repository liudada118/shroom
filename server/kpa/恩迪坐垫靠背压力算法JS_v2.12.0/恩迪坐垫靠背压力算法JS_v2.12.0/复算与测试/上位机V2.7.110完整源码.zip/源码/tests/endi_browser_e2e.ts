/**
 * 浏览器端到端验证（V2.7.110：最大压强在热力图上红框标注——标注格 = 画布上最大压强格、标签 = “最大压强”卡片，逐帧位置与同一链路一致，
 *   “最大标注”开关可关闭；真人估算区最大压强 ×1.5、明细“识别”列含“最大压强×1.5”；V2.7.109：热力图放大镜扫读——放大窗口逐格数值 = 画布格内文字，放大镜读出的非零格平均值 = 平均压强卡片；V2.7.108：靠背超量程面积 = T39 轮廓 ×2；V2.7.107：坐垫/靠背算法回归 + 超量程（> 90 N，×2）与坐垫真人估算（ΣS > 600 cm² 且 ΣF > 300 N，压力×0.4 面积×0.9）+ 压强 N/cm² 3 位小数 + 压力 2 位小数 + 格子压强平均 = 平均压强 + “格子显示：ADC | 压强”切换）
 *   - 无头 Chromium + CDP；注入模拟 navigator.serial，逐帧推送“1024 原始字节 + AA 55 03 99”；Date.now 受控。
 *   - 坐垫：真实采集 CSV 原始字节，界面显示的 面积 / 压力 / 平均压强 与 坐垫算法核心（CSV 物理矩阵直算）逐帧比对。
 *   - 靠背：真实采集 CSV 原始字节，界面显示与 靠背算法核心（CSV 25×32 物理矩阵直算）逐帧比对。
 *   - 最大压强卡片：与上位机同一链路（原始字节→wireMap→lineInterp2x2→默认ADC补偿→适配层→attachEndiPointPressure）逐帧比对。
 *   - 卡片文字与同一链路逐帧精确比对：压力 2 位小数（N）、平均压强/最大压强 3 位小数（N/cm²）；并与算法核心直算值在取整容差内一致。
 *   - 切到“压强 N/cm²”后拦截画布 fillText 逐格核对格内文字（3 位小数），格内文字的平均值 = 平均压强卡片 = “格子平均”标签；悬停抽样核对。
 *   - 打开 计算设置 / 各接触区压强明细（面积列，与 V2.7.98 相同）/ 压强热图 并截图。
 *   - V2.7.103 超量程 + 坐垫真人：真实 5 块砝码帧 ADC ×1.15（超过 5 块）、合成臀部双峰轮廓（纯真人、1 块砝码 + 真人）经同一串口链路推送；
 *     界面 压力/面积/平均压强/最大压强 与同一链路逐帧一致，且类别稳定 ≥120 ms 的帧与“算法核心直算 × 系数”一致：
 *     超量程区 F×2、S 为 T29 轮廓；真人（全帧 ΣS > 600 且 ΣF > 300，条件连续不满足 500 ms 退出）非标准档区 F×0.4 / S×0.8；砝码标准档区不变；
 *     明细表“识别”列超量程区为“超量程估算 · 压力×2”，真人区为“真人估算 · 压力×0.4 面积×0.9”、砝码区为“标准档 1 块”；压强格子平均 = 平均压强。
 *   - V2.7.108 靠背超量程：真实靠背 1→5 块后 5 块保持帧 ADC ×1.15（超过 5 块）经同一串口链路推送；界面与同一链路逐帧一致，
 *     稳定超量程帧 压力 = 核心 F（×2）、面积 = T39 轮廓 ×2；明细“识别”列为“超量程估算 · 压力×2 面积×2”；压强格子平均 = 平均压强。
 * 用法：npx tsx tests/endi_browser_e2e.ts <坐垫CSV目录> <靠背CSV目录> <输出目录> [坐垫文件序号] [靠背文件序号]
 * 前提：standalone-server.mjs 已在 http://127.0.0.1:3000/（或环境变量 E2E_URL）运行新版站点。
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { EndiAlgorithm } from "../client/src/lib/endiCushion/endiCushionCore.js";
import { EndiBackrestAlgorithm } from "../client/src/lib/endiBackrest/endiBackrestCore.js";
import { APP_VERSION } from "../client/src/lib/version";
import { getSensorConfig, lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { calculateLiveSensorForce } from "../client/src/lib/sensorForce";
import { compensateAndFilterAdcMatrix, DEFAULT_ADC_COMPENSATION_SETTINGS } from "../client/src/lib/adcCompensation";
import { attachEndiPointPressure, maxPressureCellInSelection } from "../client/src/lib/endiPointPressure";
import { heatmapCellIndex } from "../client/src/lib/captureOrientation";
import { ENDI_BACKREST_OVER_RANGE_GAIN as B_GAIN, ENDI_BACKREST_OVER_RANGE_AREA_GAIN as B_AGAIN } from "../client/src/lib/endiBackrestForce";
import {
  endiNativeToAlgorithm, ENDI_SEAT_HUMAN_FORCE_FACTOR as KF, ENDI_SEAT_HUMAN_AREA_FACTOR as KS, ENDI_SEAT_OVER_RANGE_GAIN as GAIN,
  ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN as PEAK,
  ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2 as S_HUMAN, ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N as F_HUMAN, ENDI_SEAT_HUMAN_EXIT_HOLD_MS as HOLD,
} from "../client/src/lib/endiSeatForce";
import { formatForceN, formatPressureNcm2, kPaToNcm2 } from "../client/src/lib/pressureUnits";

const [seatDir, backDir, outDir, pickSeat = "0,15,30", pickBack = "0,21,43"] = process.argv.slice(2);
fs.mkdirSync(outDir, { recursive: true });
const FOOTER = [0xAA, 0x55, 0x03, 0x99];

interface CsvFrame { t: number; raw: number[]; phys: number[][] }
function parseCsv(text: string, rows: number, cols: number): CsvFrame[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const tsCol = lines[h].split(",").indexOf("采集时间戳（ms）");
  const ts: number[] = [];
  let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) { ts.push(Number(lines[i].split(",")[tsCol])); i++; }
  const frames: CsvFrame[] = [];
  let k = -1; let raw: number[] = [];
  while (i < lines.length) {
    const l = lines[i];
    if (/^--- 帧序号 #\d+ ---/.test(l)) { k++; raw = []; i++; continue; }
    if (l.startsWith("原始字节")) { for (let r = 0; r < 32; r++) raw.push(...lines[i + 2 + r].split(",").slice(1, 33).map(Number)); i += 34; continue; }
    if (l.startsWith("插值前原始物理矩阵") && k >= 0) {
      const phys: number[][] = [];
      for (let r = 0; r < rows; r++) phys.push(lines[i + 2 + r].split(",").slice(1, cols + 1).map(Number));
      frames.push({ t: ts[k], raw, phys }); i += rows + 2; continue;
    }
    i++;
  }
  return frames;
}

interface Step { t: number; raw: number[]; phys: number[][]; label: string }
let T = 1_800_000_000_000;
/** 每个文件取第 1 组 100 帧（1→5 块），文件之间插入 5 帧空载。 */
function buildSteps(dir: string, pick: string, rows: number, cols: number) {
  const files = fs.readdirSync(dir).filter(f => f.endsWith(".csv")).sort();
  const chosen = pick.split(",").map(Number).filter(n => n >= 0 && n < files.length);
  const zeros = Array.from({ length: rows }, () => new Array<number>(cols).fill(0));
  const steps: Step[] = [];
  for (const fi of chosen) {
    const fr = parseCsv(fs.readFileSync(path.join(dir, files[fi]), "utf8"), rows, cols).slice(0, 100);
    for (let k = 0; k < fr.length; k++) {
      if (k > 0) T += Math.max(1, fr[k].t - fr[k - 1].t);
      steps.push({ t: T, raw: fr[k].raw, phys: fr[k].phys, label: `${files[fi]}#${k}` });
    }
    for (let z = 0; z < 5; z++) { T += 100; steps.push({ t: T, raw: new Array(1024).fill(0), phys: zeros, label: `gap${z}` }); }
    T += 100;
  }
  return { files: chosen.map(i => files[i]), steps };
}

// ---------- 期望值（算法核心直算） ----------
const seat = buildSteps(seatDir, pickSeat, 23, 23);
const seatRef = new EndiAlgorithm();
const seatExpected = seat.steps.map(s => { const o = seatRef.process(s.t, s.phys); return { F: o.F, S: o.S, P: o.P, regions: o.regions }; });

// ---------- V2.7.103 坐垫超量程 + 真人估算场景（紧接坐垫回归、同一串口连接） ----------
type M = number[][];
const zeros23 = (): M => Array.from({ length: 23 }, () => new Array<number>(23).fill(0));
/** 算法方向 → 原生方向（endiNativeToAlgorithm 的逆）。 */
function algToNative(a: M): M {
  const n = a.length; const out = zeros23();
  for (let R = 0; R < n; R++) for (let C = 0; C < n; C++) out[R][C] = a[C][n - 1 - R];
  return out;
}
/** 双峰椭圆（臀部）合成轮廓（算法方向）。 */
function humanBlob(cr: number, cc: number, scale: number, base: M = zeros23()): M {
  const a = base.map(r => r.slice());
  for (let r = 0; r < 23; r++) for (let c = 0; c < 23; c++) {
    let v = 0;
    for (const [lr, lc] of [[cr, cc - 3.2], [cr, cc + 3.2]]) v = Math.max(v, 150 * Math.exp(-(((r - lr) / 3.6) ** 2 + ((c - lc) / 2.8) ** 2) / 1.6));
    v *= scale;
    if (v >= 6) a[r][c] = Math.max(a[r][c], Math.min(255, Math.round(v)));
  }
  return a;
}
const seatCfg = getSensorConfig("endi-23x23");
function nativeToRaw(native: M): number[] {
  const raw = new Array<number>(1024).fill(0);
  for (let r = 0; r < seatCfg.physicalRows; r++) for (let c = 0; c < seatCfg.physicalCols; c++) raw[seatCfg.wireMap[r * seatCfg.physicalCols + c]] = native[r][c];
  return raw;
}
function buildHumanSteps() {
  const steps: Step[] = []; const marks: Record<string, number> = {};
  const push = (alg: M, label: string) => {
    const native = algToNative(alg);
    if (JSON.stringify(endiNativeToAlgorithm(native)) !== JSON.stringify(alg)) throw new Error("方向换算不一致");
    T += 50; steps.push({ t: T, raw: nativeToRaw(native), phys: alg, label });
  };
  for (let z = 0; z < 3; z++) push(zeros23(), `hgap${z}`);
  const files = fs.readdirSync(seatDir).filter(f => f.endsWith(".csv")).sort();
  // O 超量程：真实采集 1→5 块（第 1 组 100 帧）后，5 块保持帧 ADC ×1.15（超过 5 块，基准力 ≈ 115 N）保持 2 s，再回到 5 块
  const f0 = parseCsv(fs.readFileSync(path.join(seatDir, files[0]), "utf8"), 23, 23);
  const sc = (a: M, k: number) => a.map(r => r.map(v => (v > 0 ? Math.min(255, Math.max(1, Math.round(v * k))) : 0)));
  for (let k = 0; k < 100; k++) push(f0[k].phys, `over-base#${k}`);
  for (let k = 0; k < 8; k++) push(sc(f0[80 + (k % 20)].phys, 1 + 0.15 * (k + 1) / 8), `over-up#${k}`);
  for (let k = 0; k < 40; k++) push(sc(f0[80 + (k % 20)].phys, 1.15), `over#${k}`);
  marks.over = steps.length - 1;
  for (let k = 0; k < 20; k++) push(f0[80 + (k % 20)].phys, `over-back5#${k}`);
  for (let z = 0; z < 5; z++) push(zeros23(), `hgap${z + 100}`);
  // A 纯真人：6 帧坐下 + 24 帧保持
  for (let k = 0; k < 6; k++) push(humanBlob(11, 11, (k + 1) / 6), `human#${k}`);
  for (let k = 0; k < 24; k++) push(humanBlob(11, 11, 1 + 0.01 * Math.sin(k)), `human#${k + 6}`);
  marks.pure = steps.length - 1;
  for (let z = 0; z < 5; z++) push(zeros23(), `hgap${z + 3}`);
  // B 1 块砝码（角落位置真实采集第 1 档保持帧）+ 对侧真人轮廓（全帧 ΣS > 600 cm² 且 ΣF > 300 N）
  const wFile = files.find(f => f.includes("03-02-03")) ?? files[0];
  const w = parseCsv(fs.readFileSync(path.join(seatDir, wFile), "utf8"), 23, 23).slice(10, 20).map(f => f.phys);
  for (let k = 0; k < 20; k++) push(w[k % 10], `weight1#${k}`);
  for (let k = 0; k < 24; k++) push(humanBlob(15.5, 14, Math.min(1, (k + 1) / 6), w[k % 10]), `weight1+human#${k}`);
  marks.mixed = steps.length - 1;
  for (let z = 0; z < 5; z++) push(zeros23(), `hgap${z + 8}`);
  T += 100;
  return { steps, marks, file: files[0], weightFile: wFile };
}
const human = buildHumanSteps();
const humanCore = human.steps.map(s => { const o = seatRef.process(s.t, s.phys); return { F: o.F, S: o.S, P: o.P, regions: o.regions }; });
/**
 * 核心直算 × 系数（独立期望模型）：真人 = 全帧基准 ΣS > 600 且 ΣF > 300（立即启动，连续不满足 500 ms 退出，无接触立即退出），
 * 非标准档区 ×0.4/×0.8；否则核心 over 标记的区 ×2；其余 ×1。仅类别稳定 ≥120 ms 的帧给出期望，过渡帧返回 null。
 */
const humanCoreExpected = (() => {
  const since = new Map<number, { cls: number; t: number }>();
  const hum = { on: false, offSince: null as number | null };
  return humanCore.map((o, i) => {
    const t = human.steps[i].t; let stable = true; let F = 0, S = 0; let nHuman = 0, nOver = 0; const seen = new Set<number>();
    const regs = o.regions as any[];
    const sumS = regs.reduce((a, r) => a + r.S, 0), sumF = regs.reduce((a, r) => a + r.F, 0);
    if (regs.length === 0) { hum.on = false; hum.offSince = null; }
    else if (sumS > S_HUMAN && sumF > F_HUMAN) { hum.on = true; hum.offSince = null; }
    else if (hum.on) { if (hum.offSince === null) hum.offSince = t; if (t - hum.offSince >= HOLD) { hum.on = false; hum.offSince = null; } }
    for (const r of regs) {
      const cls = hum.on && r.mode !== "标准档" ? 2 : r.over ? 1 : 0; seen.add(r.track);
      const st = since.get(r.track);
      if (!st) since.set(r.track, { cls, t: -Infinity });
      else if (st.cls !== cls) { st.cls = cls; st.t = t; }
      if (t - (since.get(r.track)!.t) < 120) stable = false;
      if (cls === 2) nHuman++; if (cls === 1) nOver++;
      const [kf, ks] = cls === 2 ? [KF, KS] : cls === 1 ? [GAIN, 1] : [1, 1];
      F += Math.round(r.F * kf * 100) / 100; S += r.S * ks;
    }
    for (const k of Array.from(since.keys())) if (!seen.has(k)) since.delete(k);
    return stable ? { F: Math.round(F * 100) / 100, S: Math.round(S * 100) / 100, nHuman, nOver, nRegions: o.regions.length } : null;
  });
})();
T += 60_000;
const back = buildSteps(backDir, pickBack, 25, 32);
const backRef = new EndiBackrestAlgorithm();
const backExpected = back.steps.map(s => { const o = backRef.process(s.phys, s.t); return { F: o.totalForceN, S: o.totalAreaCm2, P: o.avgPressureKPa, regions: o.regions }; });

// ---------- V2.7.108 靠背超量程场景（紧接靠背回归、同一串口连接） ----------
const backCfg = getSensorConfig("new-backrest-32x25");
/** 靠背算法方向 25×32 → 原生 32×25（转置）→ 按 wireMap 写入 1024 原始字节。 */
function backPhysToRaw(phys: M): number[] {
  const raw = new Array<number>(1024).fill(0);
  for (let r = 0; r < backCfg.physicalRows; r++) for (let c = 0; c < backCfg.physicalCols; c++) raw[backCfg.wireMap[r * backCfg.physicalCols + c]] = phys[c][r];
  return raw;
}
function buildBackOverSteps() {
  const files = fs.readdirSync(backDir).filter(f => f.endsWith(".csv")).sort();
  const f0 = parseCsv(fs.readFileSync(path.join(backDir, files[0]), "utf8"), 25, 32);
  const sc = (a: M, k: number) => a.map(r => r.map(v => (v > 0 ? Math.min(255, Math.max(1, Math.round(v * k))) : 0)));
  const steps: Step[] = []; const marks: Record<string, number> = {};
  const push = (phys: M, label: string) => {
    const raw = backPhysToRaw(phys);
    T += 50; steps.push({ t: T, raw, phys, label });
  };
  // 方向/字节映射自检：未缩放帧按 wireMap 重建的原始字节与 CSV 原始字节在映射位上一致
  for (let k = 0; k < 100; k++) {
    const rebuilt = backPhysToRaw(f0[k].phys);
    for (const idx of backCfg.wireMap) if (rebuilt[idx] !== f0[k].raw[idx]) throw new Error("靠背字节映射不一致");
  }
  // 真实采集 1→5 块（第 1 组 100 帧）后，5 块保持帧 ADC ×1.15（超过 5 块，基准力 > 90 N）保持 2 s，再回到 5 块
  for (let k = 0; k < 100; k++) push(f0[k].phys, `bover-base#${k}`);
  for (let k = 0; k < 8; k++) push(sc(f0[80 + (k % 20)].phys, 1 + 0.15 * (k + 1) / 8), `bover-up#${k}`);
  for (let k = 0; k < 40; k++) push(sc(f0[80 + (k % 20)].phys, 1.15), `bover#${k}`);
  marks.over = steps.length - 1;
  for (let k = 0; k < 20; k++) push(f0[80 + (k % 20)].phys, `bover-back5#${k}`);
  const z = Array.from({ length: 25 }, () => new Array<number>(32).fill(0));
  for (let k = 0; k < 5; k++) push(z, `bgap${k + 100}`);
  T += 100;
  return { steps, marks, file: files[0] };
}
const backOver = buildBackOverSteps();
/** 靠背核心直算（同一实例继续一条流）：模式稳定 ≥ 120 ms 的超量程帧给出 F / S / T39 轮廓面积期望。 */
const backOverCoreExpected = (() => {
  let lastMode: string | null = null, since = -Infinity;
  return backOver.steps.map(s => {
    const o = backRef.process(s.phys, s.t);
    const r = o.regions[0] as any;
    if (!r) { lastMode = null; return null; }
    if (r.mode !== lastMode) { lastMode = r.mode; since = s.t; }
    const stable = s.t - since >= 120;
    return { mode: r.mode, stable, F: Math.round(o.regions.reduce((a: number, x: any) => a + Math.round(x.forceN * 100) / 100, 0) * 100) / 100,
      S: Math.round(o.totalAreaCm2 * 100) / 100, contour: Math.round(o.regions.reduce((a: number, x: any) => a + x.contourAreaCm2, 0) * 100) / 100,
      baseF: Math.round((r.mode === "overrange" ? r.forceN / B_GAIN : r.forceN) * 100) / 100, nRegions: o.regions.length };
  });
})();

/** 逐格压强期望值：与上位机相同的链路（连续一条流，与浏览器一次连接相同）。 */
/** 与上位机 rotateMatrix(matrix, 3) 相同：顺时针 90° 旋转 3 次。 */
function rotate3(matrix: number[][]): number[][] {
  let result = matrix;
  for (let i = 0; i < 3; i++) {
    const rows = result.length, cols = result[0].length;
    const rotated: number[][] = Array.from({ length: cols }, () => new Array(rows));
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) rotated[c][rows - 1 - r] = result[r][c];
    result = rotated;
  }
  return result;
}
function pointExpected(sensor: "endi-23x23" | "new-backrest-32x25", steps: Step[]) {
  const cfg = getSensorConfig(sensor);
  const streamId = `point-expected|${sensor}`;
  return steps.map(s => {
    const native: number[][] = [];
    for (let r = 0; r < cfg.physicalRows; r++) {
      const row: number[] = [];
      for (let c = 0; c < cfg.physicalCols; c++) { const idx = cfg.wireMap[r * cfg.physicalCols + c]; row.push(idx < s.raw.length ? s.raw[idx] : 0); }
      native.push(row);
    }
    const src = lineInterp2x2(native, cfg.physicalRows, cfg.physicalCols);
    const heat = compensateAndFilterAdcMatrix(src, sensor, DEFAULT_ADC_COMPENSATION_SETTINGS);
    const force = calculateLiveSensorForce(sensor, src, native, undefined, undefined, "fixed_load_recognition", { timestampMs: s.t, streamId });
    const res = attachEndiPointPressure(force, sensor, native, heat);
    const mx = res?.summary.maxPressureKPa ?? null;
    const m = res?.matrixKPa ?? null;
    // V2.7.101：格子显示值为 N/cm²（0.001 N/cm² 取整）
    const nonZero = m ? m.flat().filter(v => v > 0).map(v => kPaToNcm2(v)).sort((a, b) => a - b) : [] as number[];
    const units = nonZero.reduce((a, v) => a + Math.round(v * 1000), 0);
    const cp = force?.contactPressure;
    const avgKPa = cp?.averagePressureKPa == null ? null : Number(cp.averagePressureKPa.toFixed(2));
    // V2.7.110：热力图最大压强标注格（与上位机相同：逐格压强矩阵旋转到显示方向后取首个最大格）
    const mCell = m ? maxPressureCellInSelection(rotate3(m), null) : null;
    return { max: mx === null ? null : kPaToNcm2(mx), maxKPa: mx, maxMarker: mCell ? `${mCell.row},${mCell.col}` : null, regions: res?.summary.regions ?? [], membership: res?.summary.membershipMatchesCore ?? true,
      rows: m?.length ?? src.length, cols: m?.[0]?.length ?? (src[0]?.length ?? 0),
      nonZero, nonZeroRaw: nonZero,
      cellMeanText: nonZero.length ? (Math.round(units / nonZero.length) / 1000).toFixed(3) : null,
      ui: { force: force ? formatForceN(force.forceN) : "--", pressure: formatPressureNcm2(avgKPa), max: formatPressureNcm2(mx === null ? null : Number(mx.toFixed(2))) },
      areaCm2: force?.areaCm2 ?? null, humanRegions: force?.endiCushion?.regions.filter(r => r.humanEstimate).length ?? 0,
      backOverRegions: force?.endiBackrest?.regions.filter(r => r.overRange).length ?? 0,
      overRegions: force?.endiCushion?.regions.filter(r => r.overRangeEstimate).length ?? 0,
      factors: force?.endiCushion?.regions.map(r => [r.forceFactor, r.areaFactor]) ?? [],
      regionsUi: (cp?.regions ?? []).map(r => ({ F: r.estimatedForceN.toFixed(2), S: r.areaCm2.toFixed(2), P: formatPressureNcm2(r.estimatedPressureKPa) })),
      nRegions: cp?.regions.length ?? 0 };
  });
}
// 坐垫回归与真人场景在浏览器中是同一条串口流，期望值也按一条流计算
const seatAllPoint = pointExpected("endi-23x23", [...seat.steps, ...human.steps]);
const seatPoint = seatAllPoint.slice(0, seat.steps.length);
const humanPoint = seatAllPoint.slice(seat.steps.length);
// 靠背回归与靠背超量程场景在浏览器中是同一条串口流
const backAllPoint = pointExpected("new-backrest-32x25", [...back.steps, ...backOver.steps]);
const backPoint = backAllPoint.slice(0, back.steps.length);
const backOverPoint = backAllPoint.slice(back.steps.length);

// ---------- 浏览器 ----------
const profile = fs.mkdtempSync(path.join(os.tmpdir(), "endi-v27109-"));
const chrome = spawn("/usr/bin/chromium", ["--headless=new", "--no-sandbox", "--disable-gpu", "--no-first-run", "--window-size=1600,1000",
  "--remote-debugging-port=9495", `--user-data-dir=${profile}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
const errors: unknown[] = [];          // 页面 JS 未捕获异常
const resourceErrors: unknown[] = [];  // 资源加载失败（V2.7.96 原有：未配置的统计脚本占位地址、离线 logo）
let socket: WebSocket | undefined;
const report: Record<string, any> = {};
try {
  let page: { type: string; webSocketDebuggerUrl: string } | undefined;
  for (let i = 0; i < 100 && !page; i++) {
    try { page = (await fetch("http://127.0.0.1:9495/json/list").then(r => r.json())).find((p: { type: string }) => p.type === "page"); } catch { /* starting */ }
    if (!page) await sleep(100);
  }
  if (!page) throw new Error("Chromium 未就绪");
  socket = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((a, b) => { socket!.addEventListener("open", a, { once: true }); socket!.addEventListener("error", b, { once: true }); });
  let serial = 0;
  const pending = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> }>();
  socket.addEventListener("message", e => {
    const v = JSON.parse(String(e.data));
    if (v.method === "Runtime.exceptionThrown") errors.push(v.params.exceptionDetails?.exception?.description ?? v.params);
    if (v.method === "Log.entryAdded" && v.params.entry.level === "error") (v.params.entry.source === "network" ? resourceErrors : errors).push(v.params.entry.url ? `${v.params.entry.text} ${v.params.entry.url}` : v.params.entry.text);
    const p = pending.get(v.id);
    if (p) { pending.delete(v.id); clearTimeout(p.timer); v.error ? p.reject(new Error(JSON.stringify(v.error))) : p.resolve(v.result); }
  });
  const send = (method: string, params: object = {}, timeoutMs = 30000) => new Promise<any>((resolve, reject) => {
    const id = ++serial; const timer = setTimeout(() => reject(new Error("CDP timeout " + method)), timeoutMs);
    pending.set(id, { resolve, reject, timer }); socket!.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async (expression: string, timeoutMs = 30000) => {
    const r = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true }, timeoutMs);
    if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
    return r.result.value;
  };
  const clickText = (t: string) => evaluate(`(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent.trim()===${JSON.stringify(t)});if(!b)throw Error('缺少按钮 '+${JSON.stringify(t)});b.click();return true;})()`);
  const shot = async (name: string) => {
    const r = await send("Page.captureScreenshot", { format: "png" });
    fs.writeFileSync(path.join(outDir, name), Buffer.from(r.data, "base64"));
  };
  const escape = async () => {
    await send("Input.dispatchKeyEvent", { type: "keyDown", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 });
    await send("Input.dispatchKeyEvent", { type: "keyUp", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 }); await sleep(200);
  };
  await send("Page.enable"); await send("Runtime.enable"); await send("Log.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: 1600, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send("Page.addScriptToEvaluateOnNewDocument", { source:
    `window.__audit={now:${seat.steps[0].t},controller:null};Date.now=()=>window.__audit.now;` +
    `const mk=()=>new ReadableStream({start(c){window.__audit.controller=c;}});` +
    `const port={open:async()=>{port.readable=mk();},close:async()=>{},getInfo:()=>({}),readable:mk()};` +
    `Object.defineProperty(navigator,'serial',{configurable:true,value:{requestPort:async()=>port,getPorts:async()=>[]}});` });
  await send("Page.navigate", { url: process.env.E2E_URL ?? "http://127.0.0.1:3000/" });
  for (let i = 0; i < 150; i++) { if (await evaluate(`!!document.querySelector('[data-testid="force-calculation-settings-toggle"]')`)) break; await sleep(100); }
  const title = await evaluate("document.title");
  report.title = title;
  if (!String(title).includes(APP_VERSION)) throw new Error("版本不符：" + title);

  const readUi = () => evaluate(`({force:document.querySelector('[data-testid="force-value"]')?.textContent.trim(),area:document.querySelector('[data-testid="area-value"]')?.textContent.trim(),pressure:document.querySelector('[data-testid="region-average-pressure-value"]')?.textContent.trim(),maxPressure:document.querySelector('[data-testid="max-pressure-value"]')?.textContent.trim(),maxLabel:document.querySelector('[data-testid="max-pressure-display"]')?.textContent.trim()})`);
  const fmt = (v: number | null) => v === null ? "--" : v.toFixed(2);
  const close = (a: string, b: string) => a === b || (a !== "--" && b !== "--" && Math.abs(Number(a) - Number(b)) <= 0.0051);
  /** 逐帧推送并比对；在 detailAt 帧打开接触区明细并截图。 */
  const sameNum = (a: string | undefined, b: number | null) => b === null ? (a === "--" || a === "" || a === undefined) : (a !== undefined && a !== "--" && Math.abs(Number(a) - b) <= 0.0051);
  const replay = async (steps: Step[], expected: { F: number; S: number; P: number | null; regions: any[] }[], tag: string, detailAt: number, mapRegion: (r: any) => object,
    point: ReturnType<typeof pointExpected>) => {
    let ok = 0; const bad: unknown[] = [];
    let maxOk = 0, maxWithValue = 0; const maxBad: unknown[] = [];
    // V2.7.101：卡片文字精确比对（同一链路）+ 与算法核心直算的取整容差比对 + 小数位格式
    let textOk = 0; const textBad: unknown[] = [];
    let coreForceChecks = 0, corePressureChecks = 0; const coreBad: unknown[] = [];
    let formatBad = 0;
    for (let i = 0; i < steps.length; i++) {
      const s = steps[i];
      await evaluate(`window.__audit.now=${s.t};window.__audit.controller.enqueue(new Uint8Array(${JSON.stringify([...s.raw, ...FOOTER])}))`);
      await sleep(90);
      const ui = await readUi();
      const e = expected[i];
      const pe = point[i];
      const exp = { force: fmt(e.F), area: fmt(e.S), pressure: e.P === null ? "--" : (e.P / 10).toFixed(3) };
      // 面积与算法核心一致；压力在 2 位小数取整容差内与核心一致；平均压强在单接触区时与核心 P/10 一致（≤0.0011 N/cm²）
      const forceCoreOk = close(ui.force, exp.force);
      const areaOk = close(ui.area, exp.area);
      let pressureCoreOk = true;
      if (e.P !== null && pe.nRegions === 1) {
        corePressureChecks++;
        pressureCoreOk = ui.pressure !== "--" && Math.abs(Number(ui.pressure) - e.P / 10) <= 0.0011;
      } else if (e.P === null) pressureCoreOk = ui.pressure === "--";
      if (e.F > 0) coreForceChecks++;
      if (forceCoreOk && areaOk && pressureCoreOk) ok++;
      else bad.push({ i, label: s.label, ui, exp });
      if (!pressureCoreOk || !forceCoreOk) coreBad.push({ i, label: s.label, ui, exp, nRegions: pe.nRegions });
      // 同一链路精确文字
      if (ui.force === pe.ui.force && ui.pressure === pe.ui.pressure && ui.maxPressure === pe.ui.max) textOk++;
      else textBad.push({ i, label: s.label, ui, exp: pe.ui });
      // 小数位：压力 2 位；压强 3 位
      if (!(/^\d+\.\d{2}$/.test(ui.force ?? "") || ui.force === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.pressure ?? "") || ui.pressure === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.maxPressure ?? "") || ui.maxPressure === "--")) formatBad++;
      if (pe.max !== null) maxWithValue++;
      if (ui.maxPressure === pe.ui.max) maxOk++;
      else maxBad.push({ i, label: s.label, ui: ui.maxPressure, exp: pe.ui.max });
      if (i === detailAt) {
        await evaluate(`document.querySelector('[data-testid="region-pressure-details-toggle"]').click()`); await sleep(400);
        report[tag + "RegionDetails"] = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-row"]')].map(r=>[...r.children].map(c=>c.textContent.trim()))`);
        report[tag + "RegionDetailsHeader"] = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-details"] thead th')].map(c=>c.textContent.trim())`);
        report[tag + "RegionDetailsExpected"] = e.regions.map(mapRegion);
        report[tag + "RegionDetailsExpectedUi"] = pe.regionsUi;
        report[tag + "DetailFrame"] = { label: s.label, ui, exp, expUi: pe.ui, nRegions: pe.nRegions };
        report[tag + "CardTexts"] = await evaluate(`({avg:document.querySelector('[data-testid="region-average-pressure-display"]')?.textContent.trim(),max:document.querySelector('[data-testid="max-pressure-display"]')?.textContent.trim(),force:document.querySelector('[data-testid="force-display"]')?.textContent.trim()})`);
        await shot(tag === "seat" ? "02_坐垫5块_接触区明细.png" : "05_靠背5块_接触区明细.png");
        await escape();
        await shot(tag === "seat" ? "03_坐垫5块_主界面.png" : "06_靠背5块_主界面.png");
        // 格子显示切到“压强 N/cm²”：先关掉“数值”，验证切换后自动打开格内数值
        await evaluate(`(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='数值');if(b&&b.className.includes('text-primary'))b.click();})()`); await sleep(200);
        await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(400);
        report[tag + "PressureHeatmap"] = await evaluate(`({adcPressed:document.querySelector('[data-testid="heatmap-mode-adc"]')?.getAttribute('aria-pressed'),pressurePressed:document.querySelector('[data-testid="heatmap-mode-pressure"]')?.getAttribute('aria-pressed'),valuesOn:[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='数值')?.className.includes('text-primary'),toggleText:document.querySelector('[data-testid="heatmap-value-toggle"]')?.textContent.trim(),maxPressure:document.querySelector('[data-testid="max-pressure-value"]')?.textContent.trim(),avgPressure:document.querySelector('[data-testid="region-average-pressure-value"]')?.textContent.trim(),cellMean:document.querySelector('[data-testid="pressure-cell-mean"]')?.textContent.trim(),pressureButton:document.querySelector('[data-testid="heatmap-mode-pressure"]')?.textContent.trim()})`);
        await shot(tag === "seat" ? "07_坐垫5块_逐格压强热图.png" : "08_靠背5块_逐格压强热图.png");
        // 画布逐格核对：拦截 canvas fillText，按文字中心换算格子——每个格子画出的文字应为该格逐格压强（格内格式：区外 "0"，非零 N/cm² 3 位小数，窄格省略整数位 0，如 ".854"）。
        const pt = point[i];
        const cap = await evaluate(`(async()=>{
          const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas'); const ctx=cv.getContext('2d');
          const wait=ms=>new Promise(ok=>setTimeout(ok,ms));
          const btn=()=>[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='数值');
          cv.dispatchEvent(new MouseEvent('mouseleave',{bubbles:true})); await wait(200);
          if(btn().className.includes('text-primary')){btn().click(); await wait(300);}
          const rec=[]; const of=ctx.fillText;
          ctx.fillText=function(t,x,y){const m=this.getTransform();rec.push([String(t),m.a*x+m.c*y+m.e,m.b*x+m.d*y+m.f]);return of.apply(this,arguments);};
          btn().click(); await wait(600);
          ctx.fillText=of;
          return {w:cv.width,h:cv.height,valuesOn:btn().className.includes('text-primary'),rec};
        })()`, 120000);
        const fmtCell = (v: number) => (v > 0 ? v.toFixed(3) : "0");
        const fmtCompact = (v: number) => (v > 0 ? v.toFixed(3).replace(/^0\./, ".") : "0");
        const dispCols = Math.round(Math.sqrt(pt.rows * pt.cols * cap.w / cap.h));
        const dispRows = Math.round(pt.rows * pt.cols / dispCols);
        const cw = cap.w / dispCols, chh = cap.h / dispRows;
        const drawn = new Map<string, { texts: Set<string>; x: number; y: number }>();
        let outside = 0;
        const markerLabels: string[] = [];
        for (const [t, x, y] of cap.rec as [string, number, number][]) {
          if (t.startsWith("最大 ")) { markerLabels.push(t); continue; }   // V2.7.110 最大压强标注标签（不属于格内文字）
          const c = Math.floor(x / cw), r = Math.floor(y / chh);
          if (r < 0 || c < 0 || r >= dispRows || c >= dispCols) { outside++; continue; }
          const k = r + "," + c;
          if (!drawn.has(k)) drawn.set(k, { texts: new Set(), x, y });
          drawn.get(k)!.texts.add(t);
        }
        const consistent = [...drawn.values()].every(d => d.texts.size === 1);
        const cellsDrawn = [...drawn.entries()].map(([k, d]) => ({ k, t: [...d.texts][0], x: d.x, y: d.y }));
        const nz = cellsDrawn.filter(d => d.t !== "0").sort((a, b) => Number(a.t) - Number(b.t));
        const expNZ = pt.nonZeroRaw;
        const textBad: { drawn: string; expected: number }[] = [];
        if (nz.length === expNZ.length) nz.forEach((d, k) => { if (d.t !== fmtCell(expNZ[k]) && d.t !== fmtCompact(expNZ[k])) textBad.push({ drawn: d.t, expected: expNZ[k] }); });
        const zerosOk = cellsDrawn.filter(d => d.t === "0").length === cellsDrawn.length - nz.length;
        const allCellsDrawn = tag === "seat" ? cellsDrawn.length === dispRows * dispCols : cellsDrawn.length > 0 && cellsDrawn.length <= dispRows * dispCols;
        // 格内文字（非零格）的平均值 = 平均压强卡片 = “格子平均”标签（均为 3 位小数）
        const drawnUnits = nz.reduce((a, d) => a + Math.round(Number(d.t) * 1000), 0);
        const drawnMeanText = nz.length ? (Math.round(drawnUnits / nz.length) / 1000).toFixed(3) : null;
        const ph = report[tag + "PressureHeatmap"];
        const cellMeanLabel = /格子平均 (\d+\.\d{3}) N\/cm²（(\d+) 格）/.exec(ph?.cellMean ?? "");
        report[tag + "CellMeanCheck"] = { drawnMeanText, expectedCellMean: pt.cellMeanText, avgCard: ph?.avgPressure, avgCardAtDetail: ui.pressure, label: ph?.cellMean, labelCount: cellMeanLabel ? Number(cellMeanLabel[2]) : null, cells: nz.length,
          ok: drawnMeanText !== null && drawnMeanText === pt.cellMeanText && drawnMeanText === ph?.avgPressure && drawnMeanText === ui.pressure
            && !!cellMeanLabel && cellMeanLabel[1] === drawnMeanText && Number(cellMeanLabel[2]) === nz.length };
        report[tag + "CanvasCellsOk"] = cap.valuesOn === true && consistent && outside === 0 && allCellsDrawn && zerosOk
          && nz.length === expNZ.length && textBad.length === 0 && nz.every(d => /^\d*\.\d{3}$/.test(d.t));
        report[tag + "CanvasCellsSummary"] = { grid: [dispRows, dispCols], canvas: [cap.w, cap.h], textsRecorded: cap.rec.length, cellsDrawn: cellsDrawn.length,
          cellsExpectedDrawn: tag === "seat" ? dispRows * dispCols : "未遮罩格", consistent, outside, nonZeroDrawn: nz.length, nonZeroExpected: expNZ.length,
          compactUsed: nz.some(d => d.t.startsWith(".")), maxDrawn: nz.length ? nz[nz.length - 1].t : null, maxExpected: pt.max, textMismatches: textBad.slice(0, 20), ok: report[tag + "CanvasCellsOk"] };
        // V2.7.110 最大压强标注：标注格（matrix 坐标 → 屏幕格）上画的文字 = 画布上最大压强 = “最大压强”卡片；标签 = “最大 x.xxx N/cm²”
        {
          const sensorName = tag === "seat" ? "endi-23x23" : "new-backrest-32x25";
          const mk = await evaluate(`(()=>{const v=document.querySelector('[data-testid="heatmap-viewport"]');return {marker:v?.dataset.maxMarker??null,label:v?.dataset.maxLabel??null,pressed:document.querySelector('[data-testid="heatmap-max-marker-toggle"]')?.getAttribute('aria-pressed')??null};})()`) as { marker: string | null; label: string | null; pressed: string | null };
          const [mr, mc] = mk.marker ? mk.marker.split(",").map(Number) : [-1, -1];
          const scr = mk.marker ? heatmapCellIndex(mr, mc, dispRows, dispCols, sensorName) : null;
          const markerCellText = scr ? (drawn.get(scr.row + "," + scr.col) ? [...drawn.get(scr.row + "," + scr.col)!.texts][0] : null) : null;
          const maxDrawnText = nz.length ? nz[nz.length - 1].t : null;
          const expectedLabel = ph?.maxPressure && ph.maxPressure !== "--" ? `最大 ${ph.maxPressure} N/cm²` : null;
          const tog = await evaluate(`(async()=>{const w=ms=>new Promise(o=>setTimeout(o,ms));const b=document.querySelector('[data-testid="heatmap-max-marker-toggle"]');const v=()=>document.querySelector('[data-testid="heatmap-viewport"]');
            if(!b) return null; b.click(); await w(350); const off={pressed:b.getAttribute('aria-pressed'),marker:v().dataset.maxMarker??null};
            b.click(); await w(350); const on={pressed:b.getAttribute('aria-pressed'),marker:v().dataset.maxMarker??null}; return {off,on};})()`) as { off: { pressed: string; marker: string | null }; on: { pressed: string; marker: string | null } } | null;
          const ok = mk.pressed === "true" && !!scr && markerCellText !== null && maxDrawnText !== null
            && Number(markerCellText) === Number(maxDrawnText) && Number(markerCellText) === Number(ph?.maxPressure)
            && mk.marker === pt.maxMarker && mk.label === expectedLabel && markerLabels.length > 0 && markerLabels.every(t => t === expectedLabel)
            && !!tog && tog.off.pressed === "false" && tog.off.marker === null && tog.on.pressed === "true" && tog.on.marker === mk.marker;
          report[tag + "MaxMarker"] = { marker: mk.marker, expectedMarker: pt.maxMarker, screenCell: scr, markerCellText, maxDrawnText, maxCard: ph?.maxPressure,
            label: mk.label, expectedLabel, labelsDrawn: [...new Set(markerLabels)], toggle: tog, ok };
          await shot(tag === "seat" ? "24_坐垫5块_最大压强标注.png" : "25_靠背5块_最大压强标注.png");
        }
        // 悬停抽样：在画出非零压强的格子（取最大的 12 个与最小的 4 个）上悬停，读数（3 位小数，N/cm²）须为该格逐格压强且与格内文字一致
        const picks = [...nz.slice(-12), ...nz.slice(0, 4)];
        const hov = await evaluate(`(async()=>{
          const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas');
          const wait=ms=>new Promise(ok=>setTimeout(ok,ms)); const out=[];
          // 首次悬停会在热力图下方出现坐标读数行并引起画布尺寸变化，因此每次移动前重新读取画布位置
          const toClient=(x,y)=>{const rect=cv.getBoundingClientRect(); const ca=cv.width/cv.height; let rw,rh,ox,oy;
            if(ca>rect.width/rect.height){rw=rect.width;rh=rect.width/ca;ox=0;oy=(rect.height-rh)/2;}else{rh=rect.height;rw=rect.height*ca;ox=(rect.width-rw)/2;oy=0;}
            return {clientX:rect.left+ox+x*rw/cv.width,clientY:rect.top+oy+y*rh/cv.height};};
          for(const [x,y,want] of ${JSON.stringify(picks.map(d => [d.x, d.y, d.k]))}){
            let el=null, label=null, tries=0;
            for(;tries<6;tries++){
              cv.dispatchEvent(new MouseEvent('mousemove',{...toClient(x,y),bubbles:true})); await wait(150);
              el=document.querySelector('[data-testid="heatmap-hover-value"]');
              const m=el&&/R(\\d+) C(\\d+) =/.exec(el.parentElement.textContent); label=m?m[1]+','+m[2]:null; if(label===want) break;
            }
            out.push(el?{v:el.textContent.trim(),unit:el.parentElement.textContent.trim().split(' ').pop(),label,want,tries}:null);
          }
          cv.dispatchEvent(new MouseEvent('mouseleave',{bubbles:true}));
          return out;
        })()`, 120000);
        const hovBad: any[] = [];
        picks.forEach((d, k) => {
          const h = hov[k]; const hv = h ? Number(h.v) : NaN;
          const okVal = !!h && h.label === h.want && h.unit === "N/cm²" && /^\d+\.\d{3}$/.test(h.v) && pt.nonZero.some(v => Math.abs(v - hv) <= 1e-9)
            && Math.abs(hv - Number(d.t)) <= 1e-9;
          if (!okVal) hovBad.push({ cellText: d.t, hover: h });
        });
        report[tag + "HoverSampleOk"] = picks.length > 0 && hovBad.length === 0;
        report[tag + "HoverSampleSummary"] = { samples: picks.length, bad: hovBad, maxHover: hov[picks.length - 5]?.v ?? null, ok: report[tag + "HoverSampleOk"] };
        // 热区局部放大截图（2 倍），便于查看格内压强数字
        const clip = await evaluate(`(()=>{const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas');const r=cv.getBoundingClientRect();return {x:r.left,y:r.top,w:r.width,h:r.height};})()`);
        const zoom = await send("Page.captureScreenshot", { format: "png", clip: { x: clip.x, y: clip.y, width: clip.w, height: clip.h, scale: 2 } });
        fs.writeFileSync(path.join(outDir, tag === "seat" ? "09_坐垫5块_压强格子_放大.png" : "10_靠背5块_压强格子_放大.png"), Buffer.from(zoom.data, "base64"));
        // V2.7.109 放大镜扫读：打开放大镜并选 11×11，按网格移动鼠标让放大窗口覆盖整幅热力图，逐格读取放大窗口中的完整数值。
        // 核对：①放大镜每格数值 = 画布格内文字（同一格，完整 3 位小数，不省略整数位）；②覆盖全部画出的格子；
        // ③放大镜读出的非零格平均值 = 平均压强卡片 = “格子平均”标签；④中心格标题 R/C 与读数 = 悬停读数；
        // ⑤窗口为 11×11=121 格且完全在视口内；⑥滚轮向上一格 → 9×9；⑦ADC 模式下中心格显示 ADC；⑧关闭后放大窗口消失。
        {
          await evaluate(`document.querySelector('[data-testid="heatmap-magnifier-toggle"]').click()`); await sleep(250);
          await evaluate(`document.querySelector('[data-testid="heatmap-magnifier-size-11"]').click()`); await sleep(250);
          const mag = await evaluate(`(async()=>{
            const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas');
            const wait=ms=>new Promise(ok=>setTimeout(ok,ms));
            const R=${dispRows}, C=${dispCols}, n=11, h=5;
            const centers=L=>{const o=[];for(let c=h;;c+=n){o.push(Math.min(c,L-1));if(c+h>=L-1)break;}return o;};
            const toClient=(r,c)=>{const rect=cv.getBoundingClientRect(); const ca=cv.width/cv.height; let rw,rh,ox,oy;
              if(ca>rect.width/rect.height){rw=rect.width;rh=rect.width/ca;ox=0;oy=(rect.height-rh)/2;}else{rh=rect.height;rw=rect.height*ca;ox=(rect.width-rw)/2;oy=0;}
              return {clientX:rect.left+ox+(c+0.5)*rw/C,clientY:rect.top+oy+(r+0.5)*rh/R};};
            const cells={}; const centersOut=[]; const maxTagged={}; let lensMiss=0, sizeBad=0, posBad=0, conflicts=0, textDiff=0;
            for(const r of centers(R)) for(const c of centers(C)){
              let lens=null, ctr=null;
              for(let t=0;t<6;t++){
                cv.dispatchEvent(new MouseEvent('mousemove',{...toClient(r,c),bubbles:true})); await wait(120);
                lens=document.querySelector('[data-testid="heatmap-magnifier"]'); ctr=lens&&lens.querySelector('[data-testid="magnifier-center"]');
                if(ctr&&+ctr.dataset.r===r&&+ctr.dataset.c===c) break;
              }
              if(!lens||!ctr||+ctr.dataset.r!==r||+ctr.dataset.c!==c){lensMiss++;continue;}
              if(lens.dataset.size!=='11'||lens.querySelectorAll('[data-testid="magnifier-cell"]').length!==121) sizeBad++;
              const b=lens.getBoundingClientRect(); if(b.left<0||b.top<0||b.right>innerWidth+0.5||b.bottom>innerHeight+0.5) posBad++;
              const hov=document.querySelector('[data-testid="heatmap-hover-value"]');
              centersOut.push({r,c,center:ctr.textContent.trim(),hover:hov?hov.parentElement.textContent.trim():null});
              for(const el of lens.querySelectorAll('[data-testid="magnifier-cell"]')){
                if(el.dataset.empty) continue;
                const k=el.dataset.r+','+el.dataset.c, v=el.dataset.v;
                // V2.7.110：最大压强格左上角有“最大”角标，去掉角标后比对数值
                const txt=el.textContent.trim(); const bare=el.dataset.max==='1'?txt.replace(/^最大/,''):txt;
                if(el.dataset.max==='1'){maxTagged[k]=v;} else if(txt.startsWith('最大')) textDiff++;
                if(bare!==v) textDiff++;
                if(cells[k]!==undefined&&cells[k]!==v) conflicts++;
                cells[k]=v;
              }
            }
            // 滚轮向上一格：11×11 → 9×9
            const p=toClient(Math.floor(R/2),Math.floor(C/2));
            cv.dispatchEvent(new MouseEvent('mousemove',{...p,bubbles:true})); await wait(150);
            cv.dispatchEvent(new WheelEvent('wheel',{...p,deltaY:-100,bubbles:true,cancelable:true})); await wait(300);
            cv.dispatchEvent(new MouseEvent('mousemove',{...p,bubbles:true})); await wait(150);
            const lens9=document.querySelector('[data-testid="heatmap-magnifier"]');
            const afterWheel=lens9?.dataset.size??null;
            const afterWheelCells=lens9?lens9.querySelectorAll('[data-testid="magnifier-cell"]').length:0;
            const btn9=document.querySelector('[data-testid="heatmap-magnifier-size-9"]')?.getAttribute('aria-pressed');
            const nzEl=lens9?[...lens9.querySelectorAll('[data-testid="magnifier-cell"][data-v]')].find(e=>e.dataset.v!=='0'):null;
            const fontPx=nzEl?parseFloat(getComputedStyle(nzEl).fontSize):null;
            return {cells,centers:centersOut,maxTagged,lensMiss,sizeBad,posBad,conflicts,textDiff,afterWheel,afterWheelCells,btn9,fontPx};
          })()`, 240000);
          const maxCell = nz[nz.length - 1]?.k.split(",").map(Number) ?? null;
          await evaluate(`document.querySelector('[data-testid="heatmap-magnifier-size-7"]').click()`); await sleep(250);
          const demo = maxCell ? await evaluate(`(async()=>{
            const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas'); const wait=ms=>new Promise(ok=>setTimeout(ok,ms));
            const R=${dispRows}, C=${dispCols}, r=${maxCell[0]}, c=${maxCell[1]};
            const rect=cv.getBoundingClientRect(); const ca=cv.width/cv.height; let rw,rh,ox,oy;
            if(ca>rect.width/rect.height){rw=rect.width;rh=rect.width/ca;ox=0;oy=(rect.height-rh)/2;}else{rh=rect.height;rw=rect.height*ca;ox=(rect.width-rw)/2;oy=0;}
            const p={clientX:rect.left+ox+(c+0.5)*rw/C,clientY:rect.top+oy+(r+0.5)*rh/R};
            cv.dispatchEvent(new MouseEvent('mousemove',{...p,bubbles:true})); await wait(200);
            cv.dispatchEvent(new MouseEvent('mousemove',{...p,bubbles:true})); await wait(250);
            const lens=document.querySelector('[data-testid="heatmap-magnifier"]');
            const ctr=lens&&lens.querySelector('[data-testid="magnifier-center"]');
            const nzEl=lens?[...lens.querySelectorAll('[data-testid="magnifier-cell"][data-v]')].find(e=>e.dataset.v!=='0'):null;
            const mx=lens?lens.querySelector('[data-testid="magnifier-cell"][data-max="1"]'):null;
            return {size:lens?.dataset.size??null,center:ctr?.textContent.trim()??null,fontPx:nzEl?parseFloat(getComputedStyle(nzEl).fontSize):null,maxTag:mx?mx.textContent.trim():null,maxCells:lens?lens.querySelectorAll('[data-max="1"]').length:0};
          })()`) : null;
          await shot(tag === "seat" ? "20_坐垫5块_放大镜.png" : "21_靠背5块_放大镜.png");
          // ADC 模式：放大镜中心格显示 ADC（整数），与悬停读数一致；随后切回压强
          await evaluate(`document.querySelector('[data-testid="heatmap-mode-adc"]').click()`); await sleep(400);
          const adc = await evaluate(`(async()=>{
            const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas'); const wait=ms=>new Promise(ok=>setTimeout(ok,ms));
            const rect=cv.getBoundingClientRect(); const R=${dispRows}, C=${dispCols}, mr=${maxCell ? maxCell[0] : -1}, mc=${maxCell ? maxCell[1] : -1};
            const ca=cv.width/cv.height; let rw,rh,ox,oy;
            if(ca>rect.width/rect.height){rw=rect.width;rh=rect.width/ca;ox=0;oy=(rect.height-rh)/2;}else{rh=rect.height;rw=rect.height*ca;ox=(rect.width-rw)/2;oy=0;}
            const p=mr>=0?{clientX:rect.left+ox+(mc+0.5)*rw/C,clientY:rect.top+oy+(mr+0.5)*rh/R}:{clientX:rect.left+rect.width/2,clientY:rect.top+rect.height/2};
            cv.dispatchEvent(new MouseEvent('mousemove',{...p,bubbles:true})); await wait(200);
            cv.dispatchEvent(new MouseEvent('mousemove',{clientX:p.clientX+0.5,clientY:p.clientY,bubbles:true})); await wait(200);
            const ctr=document.querySelector('[data-testid="heatmap-magnifier"] [data-testid="magnifier-center"]');
            const hov=document.querySelector('[data-testid="heatmap-hover-value"]');
            const vals=[...document.querySelectorAll('[data-testid="heatmap-magnifier"] [data-testid="magnifier-cell"][data-v]')].map(e=>e.dataset.v);
            return {center:ctr?.textContent.trim()??null,hover:hov?hov.parentElement.textContent.trim():null,allInt:vals.length>0&&vals.every(v=>/^[0-9]+$/.test(v)),sample:vals.slice(0,5)};
          })()`);
          await shot(tag === "seat" ? "22_坐垫5块_放大镜_ADC.png" : "23_靠背5块_放大镜_ADC.png");
          await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(400);
          // 关闭放大镜：窗口消失
          await evaluate(`document.querySelector('[data-testid="heatmap-magnifier-toggle"]').click()`); await sleep(250);
          const closed = await evaluate(`(async()=>{const cv=document.querySelector('[data-testid="heatmap-viewport"] canvas');const r=cv.getBoundingClientRect();
            cv.dispatchEvent(new MouseEvent('mousemove',{clientX:r.left+r.width/2,clientY:r.top+r.height/2,bubbles:true}));await new Promise(ok=>setTimeout(ok,200));
            const gone=!document.querySelector('[data-testid="heatmap-magnifier"]'); cv.dispatchEvent(new MouseEvent('mouseleave',{bubbles:true})); return gone;})()`);
          // Node 端比对
          const drawnMap = new Map(cellsDrawn.map(d => [d.k, d.t]));
          const magCells = mag.cells as Record<string, string>;
          let covered = 0, valueBad = 0, fullFormatBad = 0; const magBadSamples: unknown[] = [];
          for (const [k, t] of drawnMap) {
            const v = magCells[k];
            if (v === undefined) continue;
            covered++;
            if (!(v === "0" || /^\d+\.\d{3}$/.test(v))) fullFormatBad++;
            if (Number(v) !== Number(t)) { valueBad++; if (magBadSamples.length < 10) magBadSamples.push({ k, magnifier: v, canvas: t }); }
          }
          const magNZ = Object.values(magCells).filter(v => v !== "0");
          const magUnits = magNZ.reduce((a, v) => a + Math.round(Number(v) * 1000), 0);
          const magMeanText = magNZ.length ? (Math.round(magUnits / magNZ.length) / 1000).toFixed(3) : null;
          const ph2 = report[tag + "PressureHeatmap"];
          const lab = (x: string | null) => { const m = /R(\d+) C(\d+) = ([\d.]+|--)/.exec(x ?? ""); return m ? `${m[1]},${m[2]}=${m[3]}` : null; };
          const centersAll = mag.centers as { r: number; c: number; center: string; hover: string | null }[];
          // 中心落在无效格（靠背屏蔽位置）时标题显示 “--”，画布不画该格、悬停读数不更新（原有行为），这类位置只核对坐标
          const maskedCenters = centersAll.filter(c => / = -- /.test(c.center));
          const maskedBad = maskedCenters.filter(c => !c.center.startsWith(`R${c.r} C${c.c} = --`) || drawnMap.has(`${c.r},${c.c}`));
          const centerBad = centersAll.filter(c => !/ = -- /.test(c.center)).filter(c => !lab(c.center) || lab(c.center) !== lab(c.hover) || !lab(c.center)!.startsWith(`${c.r},${c.c}=`));
          const adcOk = !!adc.center && lab(adc.center) === lab(adc.hover) && /= \d+ ADC$/.test(adc.center) && adc.allInt;
          const maxTaggedKeys = Object.keys(mag.maxTagged ?? {});
          const maxTagOk = maxTaggedKeys.length === 1 && Number((mag.maxTagged as Record<string, string>)[maxTaggedKeys[0]]) === Number(nz[nz.length - 1]?.t)
            && Number(drawnMap.get(maxTaggedKeys[0])) === Number(nz[nz.length - 1]?.t);
          report[tag + "MagnifierOk"] = mag.lensMiss === 0 && mag.sizeBad === 0 && mag.posBad === 0 && mag.conflicts === 0 && mag.textDiff === 0 && maxTagOk
            && covered === drawnMap.size && valueBad === 0 && fullFormatBad === 0 && magNZ.length === nz.length
            && magMeanText === drawnMeanText && magMeanText === ph2?.avgPressure && centerBad.length === 0 && maskedBad.length === 0
            && mag.afterWheel === "9" && mag.afterWheelCells === 81 && mag.btn9 === "true" && adcOk && closed === true
            && !!demo && demo.size === "7" && !!demo.center && demo.center.includes(`= ${nz[nz.length - 1]?.t} `);
          report[tag + "MagnifierSummary"] = { positions: mag.centers.length, lensMiss: mag.lensMiss, sizeBad: mag.sizeBad, posBad: mag.posBad, conflicts: mag.conflicts, textDiff: mag.textDiff,
            cellsRead: Object.keys(magCells).length, canvasCells: drawnMap.size, covered, valueBad, fullFormatBad, badSamples: magBadSamples,
            nonZeroRead: magNZ.length, nonZeroCanvas: nz.length, sumRead: (magUnits / 1000).toFixed(3), magnifierMean: magMeanText, canvasMean: drawnMeanText, avgCard: ph2?.avgPressure, cellMeanLabel: ph2?.cellMean,
            centerSample: mag.centers.slice(0, 3), centerBad: centerBad.slice(0, 5), maskedCenters: maskedCenters.length, maskedBad: maskedBad.slice(0, 5), afterWheel: mag.afterWheel, afterWheelCells: mag.afterWheelCells, btn9: mag.btn9, fontPx9: mag.fontPx,
            maxTagged: mag.maxTagged, maxTagOk,
            demo, demoOk: !!demo && demo.size === "7" && !!demo.center && demo.center.includes(`= ${nz[nz.length - 1]?.t} `)
              && demo.maxCells === 1 && !!demo.maxTag && demo.maxTag.startsWith("最大") && Number(demo.maxTag.slice(2)) === Number(nz[nz.length - 1]?.t), adc, adcOk, closed, ok: report[tag + "MagnifierOk"] };
        }
        // 采集一帧（压强热图模式），从 IndexedDB 读回核对最大压强与压强热图
        if (!(await evaluate(`[...document.querySelectorAll('button')].some(b=>b.textContent.trim()==='采集当前帧')`))) { await clickText("采集"); await sleep(400); }
        await clickText("采集当前帧"); await sleep(1200);
        report[tag + "Capture"] = await evaluate(`new Promise((ok,no)=>{const q=indexedDB.open('SensorCaptureDB');q.onerror=()=>no(q.error);q.onsuccess=()=>{const db=q.result;const g=db.transaction('capturedFrames','readonly').objectStore('capturedFrames').getAll();g.onsuccess=()=>{const all=g.result.filter(f=>f.sensorType===${JSON.stringify(tag === "seat" ? "endi-23x23" : "new-backrest-32x25")});all.sort((a,b)=>new Date(a.capturedAt)-new Date(b.capturedAt));const f=all[all.length-1];if(!f){ok(null);return;}let hm=0;for(const row of (f.data.heatmapMatrix||[]))for(const v of row)if(v>hm)hm=v;ok({n:all.length,maxPressureKPa:f.maxPressureKPa,unit:f.captureConfig?.heatmapValueUnit,heatmapMax:hm,pointMax:f.forceMetrics?.pointPressure?.maxPressureKPa??null,pointCount:f.pointPressureCount,summaryPoints:f.forceMetrics?.pointPressure?.pointCount??null,version:f.forceMetrics?.pointPressure?.version??null});};g.onerror=()=>no(g.error);};})`);
        report[tag + "CaptureExpectedMax"] = point[i].maxKPa;
      }
    }
    // 回放末尾为 5 帧空载：切到压强后应保持压强显示（全 0），最大压强显示 --
    report[tag + "AfterUnload"] = await evaluate(`({pressurePressed:document.querySelector('[data-testid="heatmap-mode-pressure"]')?.getAttribute('aria-pressed'),pressureDisabled:document.querySelector('[data-testid="heatmap-mode-pressure"]')?.disabled,maxPressure:document.querySelector('[data-testid="max-pressure-value"]')?.textContent.trim()})`);
    await shot(tag === "seat" ? "11_坐垫空载_压强格子.png" : "12_靠背空载_压强格子.png");
    await evaluate(`document.querySelector('[data-testid="heatmap-mode-adc"]').click()`); await sleep(300);
    report[tag + "BackToAdc"] = await evaluate(`document.querySelector('[data-testid="heatmap-mode-adc"]')?.getAttribute('aria-pressed')`);
    return { ok, bad, maxOk, maxWithValue, maxBad, textOk, textBad, coreForceChecks, corePressureChecks, coreBad, formatBad };
  };

  // ---------- 坐垫（回归） ----------
  await evaluate(`document.querySelector('[data-testid="force-calculation-settings-toggle"]').click()`); await sleep(300);
  report.seatSettings = await evaluate(`({info:document.querySelector('[data-testid="seat-algorithm-info"]')?.innerText ?? null, oldSelect:!!document.querySelector('[data-testid="seat-force-method"]'), oldStable:!!document.querySelector('[data-testid="seat-stable-display"]')})`);
  await shot("01_计算设置_坐垫.png");
  await escape();
  await clickText("连接串口"); await sleep(200);
  const seatRes = await replay(seat.steps, seatExpected, "seat", seat.steps.length - 7,
    r => ({ mode: r.mode, level: r.level, state: r.state, massKg: +r.m.toFixed(3), F: +r.F.toFixed(2), S: +r.S.toFixed(2), P: r.P === null ? null : +r.P.toFixed(2) }), seatPoint);
  report.seat = { files: seat.files, frames: seat.steps.length, matched: seatRes.ok, mismatchCount: seatRes.bad.length, mismatches: seatRes.bad.slice(0, 20),
    textMatched: seatRes.textOk, textMismatches: seatRes.textBad.slice(0, 20), textMismatchCount: seatRes.textBad.length,
    corePressureChecks: seatRes.corePressureChecks, coreForceChecks: seatRes.coreForceChecks, coreMismatchCount: seatRes.coreBad.length, formatBad: seatRes.formatBad,
    maxPressureMatched: seatRes.maxOk, maxPressureFramesWithValue: seatRes.maxWithValue, maxPressureMismatches: seatRes.maxBad.slice(0, 20), membershipAll: seatPoint.every(p => p.membership) };

  // ---------- 坐垫超量程 + 真人估算（V2.7.103，同一连接继续推送） ----------
  {
    let textOk = 0, areaOk = 0, coreChecks = 0, coreOk = 0, humanFrames = 0, overFrames = 0, overCoreChecks = 0, formatBad = 0;
    const textBad: unknown[] = [], areaBad: unknown[] = [], coreBad: unknown[] = [];
    // V2.7.104：真人阶段全程切到压强热图，逐帧核对“格子平均”标签 = 平均压强卡片（含真人、超量程与系数过渡帧）。
    let syncOk = 0, syncHuman = 0;
    const syncBad: unknown[] = [];
    // V2.7.110：逐帧核对热力图最大压强标注（位置 = 同一链路期望的最大格，标签 = 最大压强卡片）
    let markerOk = 0, markerHuman = 0;
    const markerBad: unknown[] = [];
    await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(300);
    for (let i = 0; i < human.steps.length; i++) {
      const s = human.steps[i];
      await evaluate(`window.__audit.now=${s.t};window.__audit.controller.enqueue(new Uint8Array(${JSON.stringify([...s.raw, ...FOOTER])}))`);
      await sleep(90);
      const ui = await readUi();
      const pe = humanPoint[i];
      {
        const cmText = await evaluate(`document.querySelector('[data-testid="pressure-cell-mean"]')?.textContent.trim() ?? null`) as string | null;
        const mm = /格子平均 (\d+\.\d{3}) N\/cm²/.exec(cmText ?? "");
        const cellMean = mm ? mm[1] : (cmText === "格子平均 --" ? "--" : null);
        if (cellMean !== null && cellMean === ui.pressure && cellMean === (pe.cellMeanText ?? "--")) { syncOk++; if (pe.humanRegions > 0) syncHuman++; }
        else syncBad.push({ i, label: s.label, cellMean: cmText, card: ui.pressure, exp: pe.cellMeanText });
      }
      {
        const mk = await evaluate(`(()=>{const v=document.querySelector('[data-testid="heatmap-viewport"]');return {marker:v?.dataset.maxMarker??null,label:v?.dataset.maxLabel??null};})()`) as { marker: string | null; label: string | null };
        const expLabel = pe.ui.max === "--" ? null : `最大 ${pe.ui.max} N/cm²`;
        if (mk.marker === pe.maxMarker && mk.label === expLabel && (expLabel === null) === (mk.marker === null)) { markerOk++; if (pe.humanRegions > 0) markerHuman++; }
        else markerBad.push({ i, label: s.label, marker: mk.marker, expMarker: pe.maxMarker, uiLabel: mk.label, expLabel });
      }
      if (pe.humanRegions > 0) humanFrames++;
      if (pe.overRegions > 0) overFrames++;
      if (ui.force === pe.ui.force && ui.pressure === pe.ui.pressure && ui.maxPressure === pe.ui.max) textOk++;
      else textBad.push({ i, label: s.label, ui, exp: pe.ui });
      if (sameNum(ui.area, pe.areaCm2 === null || pe.areaCm2 === 0 ? (pe.areaCm2 === 0 ? 0 : null) : Math.round(pe.areaCm2 * 100) / 100)) areaOk++;
      else areaBad.push({ i, label: s.label, ui: ui.area, exp: pe.areaCm2 });
      if (!(/^\d+\.\d{2}$/.test(ui.force ?? "") || ui.force === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.pressure ?? "") || ui.pressure === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.maxPressure ?? "") || ui.maxPressure === "--")) formatBad++;
      const ce = humanCoreExpected[i];
      if (ce && (ce.nHuman > 0 || ce.nOver > 0)) {
        coreChecks++;
        if (ce.nOver > 0) overCoreChecks++;
        if (sameNum(ui.force, ce.F) && Math.abs(Number(ui.area) - ce.S) <= 0.0051 * Math.max(1, ce.nRegions)) coreOk++;
        else coreBad.push({ i, label: s.label, ui, exp: ce });
      }
      const mark = i === human.marks.pure ? "pure" : i === human.marks.mixed ? "mixed" : i === human.marks.over ? "over" : null;
      if (mark) {
        await evaluate(`document.querySelector('[data-testid="region-pressure-details-toggle"]').click()`); await sleep(400);
        const header = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-details"] thead th')].map(c=>c.textContent.trim())`) as string[];
        const rows = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-row"]')].map(r=>[...r.children].map(c=>c.textContent.trim()))`) as string[][];
        const cards = await evaluate(`({avg:document.querySelector('[data-testid="region-average-pressure-display"]')?.textContent.trim(),max:document.querySelector('[data-testid="max-pressure-display"]')?.textContent.trim(),force:document.querySelector('[data-testid="force-display"]')?.textContent.trim()})`);
        await shot(mark === "pure" ? "13_坐垫真人_接触区明细.png" : mark === "mixed" ? "15_坐垫砝码加真人_接触区明细.png" : "17_坐垫超量程_接触区明细.png");
        await escape();
        await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(400);
        const cellMean = await evaluate(`document.querySelector('[data-testid="pressure-cell-mean"]')?.textContent.trim() ?? null`);
        await shot(mark === "pure" ? "14_坐垫真人_逐格压强热图.png" : mark === "mixed" ? "16_坐垫砝码加真人_逐格压强热图.png" : "18_坐垫超量程_逐格压强热图.png");
        const kId = header.findIndex(x => x.includes("识别")), kF = header.indexOf("力 N"), kP = header.indexOf("压强 N/cm²"), kS = header.findIndex(x => x.includes("面积"));
        const humanRows = rows.filter(r => kId >= 0 && r[kId].includes("真人估算") && r[kId].includes(`压力×${KF}`) && r[kId].includes(`面积×${KS}`) && r[kId].includes(`最大压强×${PEAK}`));
        // V2.7.110：真人区最大格 = 原比例分配最大格 × 1.5（同一链路逐格压强摘要）
        const peakRegs = (pe.regions as any[]).filter(r => r.peakGain > 1).map(r => ({ gain: r.peakGain, applied: r.peakGainApplied, gamma: r.peakExponent,
          maxNcm2: r.maxPressureKPa / 10, baseMaxNcm2: r.baseMaxPressureKPa / 10, ratio: r.maxPressureKPa / r.baseMaxPressureKPa, meanNcm2: r.meanPressureKPa / 10, P_Ncm2: r.regionPressureKPa / 10 }));
        const peakOk = mark === "over" ? peakRegs.length === 0 : peakRegs.length === 1 && Math.abs(peakRegs[0].ratio - PEAK) < 0.02 && Math.abs(peakRegs[0].gain - PEAK) < 1e-9;
        const mkNow = await evaluate(`(()=>{const v=document.querySelector('[data-testid="heatmap-viewport"]');return {marker:v?.dataset.maxMarker??null,label:v?.dataset.maxLabel??null};})()`);
        const weightRows = rows.filter(r => kId >= 0 && /标准档 1 块/.test(r[kId]));
        const overRows = rows.filter(r => kId >= 0 && r[kId].includes("超量程估算") && r[kId].includes(`压力×${GAIN}`));
        const m = /格子平均 (\d+\.\d{3}) N\/cm²/.exec(cellMean ?? "");
        const rowsMatch = rows.length === pe.regionsUi.length && rows.every((r, j) => r[kF] === pe.regionsUi[j].F && r[kS] === pe.regionsUi[j].S && r[kP] === pe.regionsUi[j].P);
        report["human_" + mark] = { label: s.label, ui, expUi: pe.ui, areaExp: pe.areaCm2, factors: pe.factors, core: ce, header, rows, regionsUi: pe.regionsUi, cards, cellMean,
          peakRegions: peakRegs, peakOk, maxMarker: mkNow, expMaxMarker: pe.maxMarker,
          ok: peakOk && (mkNow as any)?.marker === pe.maxMarker && (mark === "over"
            ? rowsMatch && overRows.length === 1 && humanRows.length === 0 && rows.length === 1 && !!m && m[1] === pe.cellMeanText && m[1] === ui.pressure && !!ce && ce.nOver === 1 && ce.nHuman === 0
            : rowsMatch && humanRows.length === 1 && overRows.length === 0 && weightRows.length === (mark === "mixed" ? 1 : 0) && rows.length === (mark === "mixed" ? 2 : 1)
              && !!m && m[1] === pe.cellMeanText && m[1] === ui.pressure && !!ce && ce.nHuman === 1) };
      }
    }
    await evaluate(`document.querySelector('[data-testid="heatmap-mode-adc"]').click()`); await sleep(300);
    report.humanAvgSync = { frames: human.steps.length, matched: syncOk, humanMatched: syncHuman, mismatchCount: syncBad.length, mismatches: syncBad.slice(0, 10) };
    report.humanMaxMarker = { frames: human.steps.length, matched: markerOk, humanMatched: markerHuman, mismatchCount: markerBad.length, mismatches: markerBad.slice(0, 10) };
    report.human = { file: human.file, weightFile: human.weightFile, frames: human.steps.length, humanFrames, overFrames, overCoreChecks, textMatched: textOk, textMismatchCount: textBad.length, textMismatches: textBad.slice(0, 10),
      areaMatched: areaOk, areaMismatchCount: areaBad.length, areaMismatches: areaBad.slice(0, 10), coreChecks, coreMatched: coreOk, coreMismatches: coreBad.slice(0, 10), formatBad };
    const info = report.seatSettings?.info ?? "";
    report.humanSettingsOk = new RegExp(`压力\\s*×\\s*${String(KF).replace(".", "\\.")}(?![.\\d])`).test(info) && new RegExp(`面积\\s*×\\s*${String(KS).replace(".", "\\.")}(?![.\\d])`).test(info) && /真人/.test(info) && /600\s*cm²/.test(info) && /300\s*N/.test(info)
      && /超量程/.test(info) && /90\s*N/.test(info) && /×\s*2/.test(info) && !/131/.test(info);
    report.humanOk = textBad.length === 0 && areaBad.length === 0 && coreBad.length === 0 && coreChecks >= 60 && humanFrames >= 40 && overFrames >= 30 && overCoreChecks >= 30
      && formatBad === 0 && report.human_pure?.ok === true && report.human_mixed?.ok === true && report.human_over?.ok === true && report.humanSettingsOk
      && syncBad.length === 0 && syncOk === human.steps.length && syncHuman >= 40
      && markerBad.length === 0 && markerOk === human.steps.length && markerHuman >= 40;
  }

  // ---------- 靠背（新算法） ----------
  await clickText("断开连接"); await sleep(200);
  await evaluate(`document.querySelector('button[role="combobox"]').click()`); await sleep(200);
  await evaluate(`[...document.querySelectorAll('[role="option"]')].find(e=>e.textContent.includes('新靠背')).click()`); await sleep(300);
  await evaluate(`document.querySelector('[data-testid="force-calculation-settings-toggle"]').click()`); await sleep(300);
  report.backrestSettings = await evaluate(`({info:document.querySelector('[data-testid="backrest-algorithm-info"]')?.innerText ?? null, oldSelect:!!document.querySelector('[data-testid="backrest-force-method"]')})`);
  await shot("04_计算设置_靠背.png");
  await escape();
  await evaluate(`window.__audit.now=${back.steps[0].t}`);
  await clickText("连接串口"); await sleep(200);
  const backRes = await replay(back.steps, backExpected, "backrest", back.steps.length - 7,
    r => ({ mode: r.mode, blocks: r.blocks, state: r.state, massKg: +r.massKg.toFixed(3), F: +r.forceN.toFixed(2), S: +r.areaCm2.toFixed(2), P: r.pressureKPa === null ? null : +r.pressureKPa.toFixed(2) }), backPoint);
  report.backrest = { files: back.files, frames: back.steps.length, matched: backRes.ok, mismatchCount: backRes.bad.length, mismatches: backRes.bad.slice(0, 20),
    textMatched: backRes.textOk, textMismatches: backRes.textBad.slice(0, 20), textMismatchCount: backRes.textBad.length,
    corePressureChecks: backRes.corePressureChecks, coreForceChecks: backRes.coreForceChecks, coreMismatchCount: backRes.coreBad.length, formatBad: backRes.formatBad,
    framesWithContact: backExpected.filter(e => e.regions.length > 0).length, framesWithPressure: backExpected.filter(e => e.P !== null).length,
    maxPressureMatched: backRes.maxOk, maxPressureFramesWithValue: backRes.maxWithValue, maxPressureMismatches: backRes.maxBad.slice(0, 20), membershipAll: backPoint.every(p => p.membership) };
  // ---------- 靠背超量程（V2.7.108，同一连接继续推送） ----------
  {
    let textOk = 0, areaOk = 0, overFrames = 0, coreChecks = 0, coreOk = 0, syncOk = 0, formatBad = 0;
    const textBad: unknown[] = [], areaBad: unknown[] = [], coreBad: unknown[] = [], syncBad: unknown[] = [];
    await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(300);
    for (let i = 0; i < backOver.steps.length; i++) {
      const s = backOver.steps[i];
      await evaluate(`window.__audit.now=${s.t};window.__audit.controller.enqueue(new Uint8Array(${JSON.stringify([...s.raw, ...FOOTER])}))`);
      await sleep(90);
      const ui = await readUi();
      const pe = backOverPoint[i];
      const ce = backOverCoreExpected[i];
      {
        const cmText = await evaluate(`document.querySelector('[data-testid="pressure-cell-mean"]')?.textContent.trim() ?? null`) as string | null;
        const mm = /格子平均 (\d+\.\d{3}) N\/cm²/.exec(cmText ?? "");
        const cellMean = mm ? mm[1] : (cmText === "格子平均 --" ? "--" : null);
        if (cellMean !== null && cellMean === ui.pressure && cellMean === (pe.cellMeanText ?? "--")) syncOk++;
        else syncBad.push({ i, label: s.label, cellMean: cmText, card: ui.pressure, exp: pe.cellMeanText });
      }
      if (pe.backOverRegions > 0) overFrames++;
      if (ui.force === pe.ui.force && ui.pressure === pe.ui.pressure && ui.maxPressure === pe.ui.max) textOk++;
      else textBad.push({ i, label: s.label, ui, exp: pe.ui });
      if (sameNum(ui.area, pe.areaCm2 === null ? null : Math.round(pe.areaCm2 * 100) / 100)) areaOk++;
      else areaBad.push({ i, label: s.label, ui: ui.area, exp: pe.areaCm2 });
      if (!(/^\d+\.\d{2}$/.test(ui.force ?? "") || ui.force === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.pressure ?? "") || ui.pressure === "--")) formatBad++;
      if (!(/^\d+\.\d{3}$/.test(ui.maxPressure ?? "") || ui.maxPressure === "--")) formatBad++;
      if (ce && ce.mode === "overrange" && ce.stable) {
        coreChecks++;
        if (sameNum(ui.force, ce.F) && sameNum(ui.area, ce.S) && Math.abs(ce.S - ce.contour * B_AGAIN) <= 0.0051) coreOk++;
        else coreBad.push({ i, label: s.label, ui, exp: ce });
      }
      if (i === backOver.marks.over) {
        await evaluate(`document.querySelector('[data-testid="region-pressure-details-toggle"]').click()`); await sleep(400);
        const header = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-details"] thead th')].map(c=>c.textContent.trim())`) as string[];
        const rows = await evaluate(`[...document.querySelectorAll('[data-testid="region-pressure-row"]')].map(r=>[...r.children].map(c=>c.textContent.trim()))`) as string[][];
        await shot("19_靠背超量程_接触区明细.png");
        await escape();
        await evaluate(`document.querySelector('[data-testid="heatmap-mode-pressure"]').click()`); await sleep(400);
        const cellMean = await evaluate(`document.querySelector('[data-testid="pressure-cell-mean"]')?.textContent.trim() ?? null`);
        await shot("20_靠背超量程_逐格压强热图.png");
        const kId = header.findIndex(x => x.includes("识别")), kF = header.indexOf("力 N"), kP = header.indexOf("压强 N/cm²"), kS = header.findIndex(x => x.includes("面积"));
        const overRows = rows.filter(r => kId >= 0 && r[kId].includes("超量程估算") && r[kId].includes(`压力×${B_GAIN}`) && r[kId].includes(`面积×${B_AGAIN}`));
        const m = /格子平均 (\d+\.\d{3}) N\/cm²/.exec(cellMean ?? "");
        const rowsMatch = rows.length === pe.regionsUi.length && rows.every((r, j) => r[kF] === pe.regionsUi[j].F && r[kS] === pe.regionsUi[j].S && r[kP] === pe.regionsUi[j].P);
        const rowAreaIsDouble = !!ce && rows.length === 1 && Math.abs(Number(rows[0][kS]) - ce.contour * B_AGAIN) <= 0.0051;
        report.backOverDetail = { label: s.label, ui, expUi: pe.ui, core: ce, header, rows, regionsUi: pe.regionsUi, cellMean,
          ok: rowsMatch && overRows.length === 1 && rows.length === 1 && rowAreaIsDouble && !!m && m[1] === pe.cellMeanText && m[1] === ui.pressure && !!ce && ce.mode === "overrange" && ce.stable };
      }
    }
    report.backOverAfterUnload = await evaluate(`({maxPressure:document.querySelector('[data-testid="max-pressure-value"]')?.textContent.trim(),force:document.querySelector('[data-testid="force-value"]')?.textContent.trim()})`);
    await evaluate(`document.querySelector('[data-testid="heatmap-mode-adc"]').click()`); await sleep(300);
    const binfo = report.backrestSettings?.info ?? "";
    report.backOverSettingsOk = /超量程/.test(binfo) && /90\s*N/.test(binfo) && new RegExp(`T39\\s*轮廓\\s*×\\s*${B_AGAIN}(?![.\\d])`).test(binfo) && !/真人估算：/.test(binfo);
    report.backOver = { file: backOver.file, frames: backOver.steps.length, overFrames, coreChecks, coreMatched: coreOk, coreMismatches: coreBad.slice(0, 10),
      textMatched: textOk, textMismatchCount: textBad.length, textMismatches: textBad.slice(0, 10), areaMatched: areaOk, areaMismatchCount: areaBad.length, areaMismatches: areaBad.slice(0, 10),
      syncMatched: syncOk, syncMismatchCount: syncBad.length, syncMismatches: syncBad.slice(0, 10), formatBad };
    report.backOverOk = textBad.length === 0 && areaBad.length === 0 && coreBad.length === 0 && coreChecks >= 30 && overFrames >= 40 && formatBad === 0
      && syncBad.length === 0 && syncOk === backOver.steps.length && report.backOverDetail?.ok === true && report.backOverSettingsOk === true
      && report.backOverAfterUnload?.maxPressure === "--";
  }
  /** 明细表面积列（恢复 V2.7.98）：表头含“面积 cm²”、不含“压强点位”，每行面积 = 算法区域面积。 */
  const areaColumnOk = (tag: string) => {
    const h = report[tag + "RegionDetailsHeader"] as string[]; const rows = report[tag + "RegionDetails"] as string[][]; const ex = report[tag + "RegionDetailsExpected"] as { S: number }[];
    if (!Array.isArray(h) || !Array.isArray(rows) || !Array.isArray(ex)) return false;
    const k = h.findIndex(x => x.includes("面积"));
    return k >= 0 && !h.some(x => x.includes("压强点位") || x.includes("ADC中位数")) && rows.length === ex.length
      && rows.every((r, j) => Math.abs(Number(r[k]) - ex[j].S) <= 0.0051);
  };
  report.seatAreaColumnOk = areaColumnOk("seat");
  /** V2.7.101 明细表：表头“力 N”“压强 N/cm²”；每行 力 2 位小数、压强 3 位小数，且与同一链路的接触区数值一致。 */
  const unitColumnsOk = (tag: string) => {
    const h = report[tag + "RegionDetailsHeader"] as string[]; const rows = report[tag + "RegionDetails"] as string[][]; const ex = report[tag + "RegionDetailsExpectedUi"] as { F: string; S: string; P: string }[];
    if (!Array.isArray(h) || !Array.isArray(rows) || !Array.isArray(ex)) return false;
    const kF = h.indexOf("力 N"), kP = h.indexOf("压强 N/cm²");
    return kF >= 0 && kP >= 0 && !h.some(x => x.includes("kPa")) && rows.length === ex.length && rows.length > 0
      && rows.every((r, j) => r[kF] === ex[j].F && /^\d+\.\d{2}$/.test(r[kF]) && r[kP] === ex[j].P && /^\d+\.\d{3}$/.test(r[kP]));
  };
  report.seatUnitColumnsOk = unitColumnsOk("seat");
  report.backrestUnitColumnsOk = unitColumnsOk("backrest");
  const cardUnitOk = (tag: string) => { const c = report[tag + "CardTexts"]; return !!c && /N\/cm²/.test(c.avg ?? "") && /N\/cm²/.test(c.max ?? "") && !/kPa|KPa/.test((c.avg ?? "") + (c.max ?? "")); };
  report.seatCardUnitOk = cardUnitOk("seat");
  report.backrestCardUnitOk = cardUnitOk("backrest");
  report.backrestAreaColumnOk = areaColumnOk("backrest");
  const toggleOk = (tag: string) => {
    const t = report[tag + "PressureHeatmap"]; const u = report[tag + "AfterUnload"];
    return !!t && t.pressurePressed === "true" && t.adcPressed === "false" && t.valuesOn === true && t.pressureButton === "压强 N/cm²"
      && !!u && u.pressurePressed === "true" && u.pressureDisabled === false && u.maxPressure === "--" && report[tag + "BackToAdc"] === "true";
  };
  report.seatToggleOk = toggleOk("seat");
  report.backrestToggleOk = toggleOk("backrest");
  const captureOk = (tag: string) => {
    const c = report[tag + "Capture"]; const ex = report[tag + "CaptureExpectedMax"];
    return !!c && c.unit === "kPa" && ex !== null && Math.abs(c.maxPressureKPa - ex) <= 1e-9 && c.pointMax === c.maxPressureKPa
      && Math.abs(c.heatmapMax - c.maxPressureKPa) <= 1e-9 && c.pointCount === c.summaryPoints && c.pointCount > 0;
  };
  report.seatCaptureOk = captureOk("seat");
  report.backrestCaptureOk = captureOk("backrest");
  report.uncaughtErrors = errors;
  report.resourceErrors = resourceErrors;
  report.passed = seatRes.bad.length === 0 && backRes.bad.length === 0 && errors.length === 0
    && seatRes.maxBad.length === 0 && backRes.maxBad.length === 0 && report.seat.membershipAll && report.backrest.membershipAll
    && report.seatAreaColumnOk && report.backrestAreaColumnOk && report.seatCaptureOk && report.backrestCaptureOk
    && report.seatToggleOk && report.backrestToggleOk && report.seatCanvasCellsOk && report.backrestCanvasCellsOk
    && report.seatHoverSampleOk && report.backrestHoverSampleOk
    && report.seatMagnifierOk === true && report.backrestMagnifierOk === true
    && report.seatMaxMarker?.ok === true && report.backrestMaxMarker?.ok === true
    && seatRes.textBad.length === 0 && backRes.textBad.length === 0 && seatRes.formatBad === 0 && backRes.formatBad === 0
    && report.seatCellMeanCheck?.ok === true && report.backrestCellMeanCheck?.ok === true
    && report.seatUnitColumnsOk && report.backrestUnitColumnsOk && report.seatCardUnitOk && report.backrestCardUnitOk
    && report.humanOk === true && report.backOverOk === true
    && !!report.seatSettings.info && !report.seatSettings.oldSelect && !report.seatSettings.oldStable
    && !!report.backrestSettings.info && !report.backrestSettings.oldSelect;
} finally {
  try { socket?.close(); } catch { /* ignore */ }
  chrome.kill("SIGKILL");
  fs.writeFileSync(path.join(outDir, "浏览器端到端验证.json"), JSON.stringify(report, null, 1));
  console.log(JSON.stringify({ passed: report.passed, title: report.title,
    seat: { frames: report.seat?.frames, matched: report.seat?.matched, mismatchCount: report.seat?.mismatchCount, maxMatched: report.seat?.maxPressureMatched, maxWithValue: report.seat?.maxPressureFramesWithValue },
    backrest: { frames: report.backrest?.frames, matched: report.backrest?.matched, mismatchCount: report.backrest?.mismatchCount, withContact: report.backrest?.framesWithContact, withPressure: report.backrest?.framesWithPressure, maxMatched: report.backrest?.maxPressureMatched, maxWithValue: report.backrest?.maxPressureFramesWithValue },
    areaColumn: [report.seatAreaColumnOk, report.backrestAreaColumnOk], toggle: [report.seatToggleOk, report.backrestToggleOk],
    text: [report.seat?.textMatched, report.seat?.textMismatchCount, report.backrest?.textMatched, report.backrest?.textMismatchCount],
    core: [report.seat?.corePressureChecks, report.seat?.coreMismatchCount, report.backrest?.corePressureChecks, report.backrest?.coreMismatchCount],
    formatBad: [report.seat?.formatBad, report.backrest?.formatBad], unitColumns: [report.seatUnitColumnsOk, report.backrestUnitColumnsOk], cardUnit: [report.seatCardUnitOk, report.backrestCardUnitOk],
    cellMean: [report.seatCellMeanCheck, report.backrestCellMeanCheck], cardTexts: [report.seatCardTexts, report.backrestCardTexts],
    canvasCells: [report.seatCanvasCellsSummary, report.backrestCanvasCellsSummary], hoverSample: [report.seatHoverSampleSummary, report.backrestHoverSampleSummary], magnifier: [report.seatMagnifierSummary && { ...report.seatMagnifierSummary, centerSample: undefined }, report.backrestMagnifierSummary && { ...report.backrestMagnifierSummary, centerSample: undefined }], afterUnload: [report.seatAfterUnload, report.backrestAfterUnload],
    capture: [report.seatCaptureOk, report.backrestCaptureOk], seatCapture: report.seatCapture, backrestCapture: report.backrestCapture,
    human: { ok: report.humanOk, settings: report.humanSettingsOk, ...report.human, textMismatches: undefined, areaMismatches: undefined,
      pure: report.human_pure && { ok: report.human_pure.ok, ui: report.human_pure.ui, rows: report.human_pure.rows, cellMean: report.human_pure.cellMean },
      mixed: report.human_mixed && { ok: report.human_mixed.ok, ui: report.human_mixed.ui, rows: report.human_mixed.rows, cellMean: report.human_mixed.cellMean },
      over: report.human_over && { ok: report.human_over.ok, ui: report.human_over.ui, rows: report.human_over.rows, cellMean: report.human_over.cellMean } },
    backOver: { ok: report.backOverOk, settings: report.backOverSettingsOk, ...report.backOver, textMismatches: undefined, areaMismatches: undefined,
      detail: report.backOverDetail && { ok: report.backOverDetail.ok, ui: report.backOverDetail.ui, rows: report.backOverDetail.rows, cellMean: report.backOverDetail.cellMean, core: report.backOverDetail.core } },
    backrestSettingsInfo: !!report.backrestSettings?.info, backrestOldSelect: report.backrestSettings?.oldSelect,
    errors: errors.length, resourceErrors }, null, 1));
}
