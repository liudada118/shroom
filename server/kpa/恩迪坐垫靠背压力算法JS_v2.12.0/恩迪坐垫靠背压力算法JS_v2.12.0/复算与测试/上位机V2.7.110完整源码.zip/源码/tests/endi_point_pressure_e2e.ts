/**
 * 逐格压强端到端核对（V2.7.99）：采集 CSV 原始 1024 字节 → 上位机 wireMap 解码（原生方向）
 * → lineInterp2x2（上位机插值）→ 默认 ADC 补偿与固定过滤（热力图显示矩阵）
 * → calculateLiveSensorForce（恩迪算法）→ attachEndiPointPressure（V2.7.101：Pᵢ = P_区 × ADCᵢ / mean(ADC_区)，按 0.001 N/cm² 保和取整）。
 * 核对：
 *  1) 区域归属：各区轮廓格数与算法核心输出一致（membershipMatchesCore）；
 *  2) 方向：算法核心插值映回原生方向后与上位机 lineInterp2x2 逐格相等；
 *  3) 中位数守恒：每区逐格压强的中位数 = 该区平均压强 P_区；
 *  4) 最大压强 = 逐格矩阵最大值，且只出现在接触区内。
 * 用法：npx tsx tests/endi_point_pressure_e2e.ts seat|backrest <CSV 目录> [输出 JSON]
 */
import fs from "node:fs";
import path from "node:path";
import { getSensorConfig, lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { calculateLiveSensorForce } from "../client/src/lib/sensorForce";
import { compensateAndFilterAdcMatrix, DEFAULT_ADC_COMPENSATION_SETTINGS } from "../client/src/lib/adcCompensation";
import { attachEndiPointPressure, endiPointPressureMatrix } from "../client/src/lib/endiPointPressure";
import { interpolate as seatInterp } from "../client/src/lib/endiCushion/endiCushionCore.js";
import { interpolate as backInterp } from "../client/src/lib/endiBackrest/endiBackrestCore.js";
import { endiNativeToAlgorithm } from "../client/src/lib/endiSeatForce";
import { endiBackrestNativeToAlgorithm } from "../client/src/lib/endiBackrestForce";

const which = process.argv[2];
const dir = process.argv[3];
const outPath = process.argv[4];
const SEAT = which === "seat";
const SENSOR = SEAT ? "endi-23x23" : "new-backrest-32x25";
const cfg = getSensorConfig(SENSOR);
const PR = SEAT ? 23 : 25, PC = SEAT ? 23 : 32;    // CSV 物理矩阵行列（算法方向）
const NR = SEAT ? 23 : 32, NC = SEAT ? 23 : 25;    // 原生物理行列
const files = fs.readdirSync(dir).filter(f => f.endsWith(".csv")).sort();

interface Frame { t: number; raw: number[] }
function parse(text: string): Frame[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const header = lines[h].split(",");
  const tsCol = header.indexOf("采集时间戳（ms）") >= 0 ? header.indexOf("采集时间戳（ms）") : 4;
  const ts: number[] = [];
  let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) { ts.push(Number(lines[i].split(",")[tsCol])); i++; }
  const frames: Frame[] = [];
  let k = -1; let raw: number[] = [];
  while (i < lines.length) {
    const l = lines[i];
    if (/^--- 帧序号 #\d+ ---/.test(l)) { k++; raw = []; i++; continue; }
    if (l.startsWith("原始字节")) {
      for (let r = 0; r < 32; r++) raw.push(...lines[i + 2 + r].split(",").slice(1, 33).map(Number));
      frames.push({ t: ts[k], raw });
      i += 34; continue;
    }
    i++;
  }
  return frames;
}
function decodeNative(raw: number[]): number[][] {
  const out: number[][] = [];
  for (let r = 0; r < cfg.physicalRows; r++) {
    const row: number[] = [];
    for (let c = 0; c < cfg.physicalCols; c++) { const idx = cfg.wireMap[r * cfg.physicalCols + c]; row.push(idx < raw.length ? raw[idx] : 0); }
    out.push(row);
  }
  return out;
}
const flat = (m: number[][]) => m.flat();
function median(v: number[]): number { const s = [...v].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
const pct = (v: number[], q: number) => { if (!v.length) return null; const s = [...v].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(q * (s.length - 1) + 0.5))]; };

let nFrames = 0, withRegions = 0, membershipOk = 0, orientOk = 0, maxBad = 0, outsideBad = 0, srcHeatmap = 0;
// V2.7.101 核对项
let regionChecks = 0, regionMeanBad = 0, unitBad = 0, minUnitBad = 0, apportionBad = 0, frameMeanBad = 0, cardBad = 0;
let regionForceRoundBad = 0, totalForceBad = 0, regionPressureBad = 0, singleRegionFrames = 0, singleRegionCardBad = 0;
let maxApportionErrUnits = 0, maxCellCountMismatch = 0;
const units = (kPa: number) => Math.round(kPa * 100);
const isUnit = (kPa: number) => Math.abs(kPa * 100 - Math.round(kPa * 100)) < 1e-6;
const isCent = (v: number) => Math.abs(v * 100 - Math.round(v * 100)) < 1e-6;
const perLevel: Record<number, { maxP: number[]; regionP: number[]; ratio: number[]; points: number[]; medAdc: number[]; meanRatio: number[] }> = {};
const t0 = Date.now();
for (const f of files) {
  const frames = parse(fs.readFileSync(path.join(dir, f), "utf8"));
  for (let s = 0, g = 0; s + 100 <= frames.length; s += 100, g++) {
    const streamId = `${f}|${g}`;
    for (let k = 0; k < 100; k++) {
      const fr = frames[s + k];
      const native = decodeNative(fr.raw);
      const src = lineInterp2x2(native, NR, NC);
      const heat = compensateAndFilterAdcMatrix(src, SENSOR, DEFAULT_ADC_COMPENSATION_SETTINGS);
      const force = calculateLiveSensorForce(SENSOR, src, native, undefined, undefined, "fixed_load_recognition", { timestampMs: fr.t, streamId });
      const res = attachEndiPointPressure(force, SENSOR, native, heat);
      nFrames++;
      // 方向：核心插值映回原生方向 = 上位机插值
      const b = SEAT ? seatInterp(flat(endiNativeToAlgorithm(native))) : backInterp(flat(endiBackrestNativeToAlgorithm(native)), PR, PC);
      let same = true;
      for (let R = 0; R < src.length && same; R++) for (let C = 0; C < src[0].length; C++) {
        const v = SEAT ? b[C * 46 + (45 - R)] : b[C * 64 + R];
        if (v !== src[R][C]) { same = false; break; }
      }
      if (same) orientOk++;
      if (!res || !force) continue;
      const sm = res.summary;
      if (sm.adcSource === "heatmap") srcHeatmap++;
      if (sm.regions.length) withRegions++;
      if (sm.membershipMatchesCore) membershipOk++;
      const M = endiPointPressureMatrix(force)!;
      const O = res.regionIndexMatrix;
      const cp = force.contactPressure!;
      // 压力 2 位小数、总力 = Σ 各区压力、各区压强 = round(10F/S, 0.01 kPa)
      let fSum = 0;
      cp.regions.forEach(r => {
        fSum += r.estimatedForceN;
        if (!isCent(r.estimatedForceN) || !isCent(r.areaCm2)) regionForceRoundBad++;
        if (r.estimatedPressureKPa !== null && r.estimatedPressureKPa !== Math.round(1000 * r.estimatedForceN / r.areaCm2) / 100) regionPressureBad++;
      });
      if (!isCent(force.forceN) || Math.abs(force.forceN - Math.round(fSum * 100) / 100) > 1e-9) totalForceBad++;
      // 最大值、区外为 0、取整单位
      let mx = 0, total = 0, nPts = 0;
      const perK = new Map<number, { u: number[]; adc: number[] }>();
      for (let R = 0; R < M.length; R++) for (let C = 0; C < M[0].length; C++) {
        const v = M[R][C], k = O[R][C];
        if (v > mx) mx = v;
        if (k < 0) { if (v !== 0) outsideBad++; continue; }
        if (!isUnit(v)) unitBad++;
        if (units(v) < 1) minUnitBad++;
        total += units(v); nPts++;
        const e = perK.get(k) ?? { u: [], adc: [] }; e.u.push(units(v)); e.adc.push(heat[R][C] > 0 ? heat[R][C] : 0); perK.set(k, e);
      }
      if ((sm.maxPressureKPa ?? 0) !== mx) maxBad++;
      // 各区：格子数一致、区内格子平均 = P区（单位整数严格相等）、与精确比例分配相差 < 1 单位（+每格最少 1 单位的抬高）
      for (const rg of sm.regions) {
        if (!rg.pointCount || rg.regionPressureKPa === null) continue;
        regionChecks++;
        const e = perK.get(rg.index);
        if (!e || e.u.length !== rg.pointCount) { regionMeanBad++; maxCellCountMismatch = Math.max(maxCellCountMismatch, Math.abs((e?.u.length ?? 0) - rg.pointCount)); continue; }
        const Pu = units(rg.regionPressureKPa);
        const sumU = e.u.reduce((a, v) => a + v, 0);
        if (sumU !== Pu * e.u.length) regionMeanBad++;
        if (rg.meanPressureKPa !== Pu / 100) regionMeanBad++;
        if (rg.adcSource === "heatmap") {
          const meanAdc = e.adc.reduce((a, v) => a + v, 0) / e.adc.length;
          for (let i = 0; i < e.u.length; i++) {
            const exact = Pu * e.adc[i] / meanAdc;
            const err = Math.abs(e.u[i] - exact);
            if (exact >= 1 && err > maxApportionErrUnits) maxApportionErrUnits = err;
            if (exact >= 1 && err >= 1 + 1e-9) apportionBad++;
          }
        }
      }
      // 全帧：格子平均 = 平均压强卡片（contactPressure.averagePressureKPa = force.averagePressureKPa）
      if (nPts > 0) {
        const meanKPa = Math.round(total / nPts) / 100;
        if (sm.meanPressureKPa !== meanKPa) frameMeanBad++;
        if (cp.status === "estimated" && (cp.averagePressureKPa !== meanKPa || force.averagePressureKPa !== meanKPa)) cardBad++;
        // 显示核对：格子显示值（N/cm² 3 位小数）的平均值，按 3 位小数显示后与卡片显示文字一致
        const shownMean = M.flat().filter(v => v > 0).map(v => Number((v / 10).toFixed(3))).reduce((a, v) => a + v, 0) / nPts;
        if (cp.status === "estimated" && shownMean.toFixed(3) !== (cp.averagePressureKPa! / 10).toFixed(3)) cardBad++;
        if (sm.regions.length === 1 && cp.status === "estimated") {
          singleRegionFrames++;
          if (cp.averagePressureKPa !== cp.regions[0].estimatedPressureKPa) singleRegionCardBad++;
        }
      }
      // 每档末帧统计（每 100 帧一组，每 20 帧一档）
      if (k % 20 === 19 && sm.regions.length === 1 && sm.maxPressureKPa !== null) {
        const L = (k / 20 | 0) + 1;
        const rg = sm.regions[0];
        const vals: number[] = [];
        for (const row of M) for (const v of row) if (v > 0) vals.push(v);
        const meanP = vals.reduce((a, v) => a + v, 0) / vals.length;
        (perLevel[L] ??= { maxP: [], regionP: [], ratio: [], points: [], medAdc: [], meanRatio: [] });
        perLevel[L].maxP.push(sm.maxPressureKPa);
        perLevel[L].regionP.push(rg.regionPressureKPa!);
        perLevel[L].ratio.push(sm.maxPressureKPa / rg.regionPressureKPa!);
        perLevel[L].points.push(rg.pointCount);
        perLevel[L].medAdc.push(rg.meanAdc!);
        perLevel[L].meanRatio.push(meanP / rg.regionPressureKPa!);
      }
    }
  }
}
const round = (v: number | null, d = 3) => v === null ? null : Number(v.toFixed(d));
const levels = Object.fromEntries(Object.entries(perLevel).map(([L, d]) => [L, {
  n: d.maxP.length,
  regionPressureKPa_median: round(pct(d.regionP, 0.5)),
  maxPressureKPa_median: round(pct(d.maxP, 0.5)), maxPressureKPa_p10: round(pct(d.maxP, 0.1)), maxPressureKPa_p90: round(pct(d.maxP, 0.9)),
  maxOverRegion_median: round(pct(d.ratio, 0.5)), maxOverRegion_p90: round(pct(d.ratio, 0.9)),
  meanOverRegion_median: round(pct(d.meanRatio, 0.5)),
  points_median: pct(d.points, 0.5), meanAdc_median: round(pct(d.medAdc, 0.5), 1),
}]));
const result = {
  sensor: SENSOR, files: files.length, frames: nFrames, framesWithRegions: withRegions,
  heatmapAdcSourceFrames: srcHeatmap, orientationEqualFrames: orientOk, membershipMatchesCoreFrames: membershipOk,
  regionChecks, regionMeanBad, maxCellCountMismatch, unitBad, minUnitBad, apportionBad, maxApportionErrUnits: Number(maxApportionErrUnits.toFixed(4)),
  frameMeanBad, cardBad, singleRegionFrames, singleRegionCardBad, regionForceRoundBad, totalForceBad, regionPressureBad,
  maxMismatchFrames: maxBad, outsideRegionCells: outsideBad,
  perLevelStepEnd: levels, ms: Date.now() - t0,
};
console.log(JSON.stringify(result, null, 1));
if (outPath) fs.writeFileSync(outPath, JSON.stringify(result, null, 1));
const ok = orientOk === nFrames && membershipOk === nFrames && maxBad === 0 && outsideBad === 0 && srcHeatmap === nFrames
  && regionMeanBad === 0 && unitBad === 0 && minUnitBad === 0 && apportionBad === 0 && frameMeanBad === 0 && cardBad === 0
  && singleRegionCardBad === 0 && regionForceRoundBad === 0 && totalForceBad === 0 && regionPressureBad === 0;
console.log(ok ? "PASS" : "FAIL");
process.exit(ok ? 0 : 1);
