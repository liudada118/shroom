/**
 * V2.7.109 平均压强审计：热力图压强格子（显示文字）之和 ÷ 格子数 是否等于上位机“平均压强”卡片。
 *
 * 链路与主页完全相同：原生 ADC → lineInterp2x2（上位机插值）→ 默认 ADC 补偿与固定过滤（热力图显示矩阵）
 *   → calculateLiveSensorForce（恩迪坐垫 / 靠背拟合算法）→ attachEndiPointPressure（逐格压强）
 *   → 格子文字 = 主页 formatHeatmapPressureCell(kPaToNcm2(v))（区外 "0"，非零 3 位小数）
 *   → 卡片文字 = formatPressureNcm2(Number(averagePressureKPa.toFixed(2)))
 *
 * 对每一帧统计：
 *   A. 显示文字平均值（Σ 非零格文字 ÷ 非零格数，四舍五入到 0.001）与卡片文字是否逐字相同；
 *   B. 显示文字的精确平均值（不取整）与卡片的差（应 ≤ 0.0005 N/cm²，即只差最后一位的四舍五入）；
 *   C. 非零格数 = 轮廓格数（区外格为 0、区内格均 > 0，即“格子数”就是接触面积格数）；
 *   D. 对照口径：总压力 ÷ 总面积（F/S）与卡片的差——多接触区时两者不是同一个量，仅供说明。
 *   E. 全图平均（含 0 格，Σ ÷ 全部格数）与卡片的差——仅供说明“为什么不除以全部格子”。
 *
 * 用法：npx tsx tests/endi_avg_audit.ts <坐垫CSV目录> <靠背CSV目录> <输出JSON>
 */
import { APP_VERSION } from "../client/src/lib/version";
import fs from "node:fs";
import path from "node:path";
import { getSensorConfig, lineInterp2x2 } from "../client/src/lib/sensorConfig";
import { calculateLiveSensorForce } from "../client/src/lib/sensorForce";
import { compensateAndFilterAdcMatrix, DEFAULT_ADC_COMPENSATION_SETTINGS } from "../client/src/lib/adcCompensation";
import { attachEndiPointPressure, endiPointPressureMatrix } from "../client/src/lib/endiPointPressure";
import { formatPressureNcm2, kPaToNcm2 } from "../client/src/lib/pressureUnits";

const [seatDir, backDir, outPath] = process.argv.slice(2);
// 与主页 Home.tsx 中的格内格式化函数逐字相同
const formatHeatmapPressureCell = (value: number) => (value > 0 ? value.toFixed(3) : "0");

interface Frame { t: number; raw: number[] }
function parse(text: string): Frame[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  const h = lines.findIndex(l => l.startsWith("帧序号,采集类型"));
  const header = lines[h].split(",");
  const tsCol = header.indexOf("采集时间戳（ms）") >= 0 ? header.indexOf("采集时间戳（ms）") : 4;
  const ts: number[] = [];
  let i = h + 1;
  while (i < lines.length && lines[i].trim() && !lines[i].startsWith("---")) { ts.push(Number(lines[i].split(",")[tsCol])); i++; }
  const frames: Frame[] = [];
  let k = -1; let raw: number[] = [];
  while (i < lines.length) {
    const l = lines[i];
    if (/^--- 帧序号 #\d+ ---/.test(l)) { k++; raw = []; i++; continue; }
    if (l.startsWith("原始字节")) {
      for (let r = 0; r < 32; r++) raw.push(...lines[i + 2 + r].split(",").slice(1, 33).map(Number));
      frames.push({ t: ts[k], raw });
      i += 34; continue;
    }
    i++;
  }
  return frames;
}

type Sensor = "endi-23x23" | "new-backrest-32x25";
function audit(sensor: Sensor, dir: string) {
  const cfg = getSensorConfig(sensor);
  const NR = cfg.physicalRows, NC = cfg.physicalCols;
  const decode = (raw: number[]) => {
    const out: number[][] = [];
    for (let r = 0; r < NR; r++) {
      const row: number[] = [];
      for (let c = 0; c < NC; c++) { const idx = cfg.wireMap[r * NC + c]; row.push(idx < raw.length ? raw[idx] : 0); }
      out.push(row);
    }
    return out;
  };
  const files = fs.readdirSync(dir).filter(f => f.endsWith(".csv")).sort();
  const st = {
    sensor, files: files.length, frames: 0, contactFrames: 0, multiRegionFrames: 0,
    textEqual: 0, textBad: [] as unknown[],
    maxExactDiff: 0, exactDiffBad: 0,
    countEqualsContour: 0, countBad: [] as unknown[],
    noContactCardDash: 0, noContactBad: 0,
    // 对照口径（不要求相等）
    fsDiffMax: 0, fsDiffMaxSingle: 0, fsDiffMaxMulti: 0, fsDiffMulti: [] as number[],
    allCellsMeanRatioMin: Infinity, allCellsMeanRatioMax: 0,
    examples: [] as unknown[],
  };
  for (const f of files) {
    const frames = parse(fs.readFileSync(path.join(dir, f), "utf8"));
    for (let s = 0, g = 0; s + 100 <= frames.length; s += 100, g++) {
      const streamId = `audit|${f}|${g}`;
      for (let k = 0; k < 100; k++) {
        const fr = frames[s + k];
        const native = decode(fr.raw);
        const src = lineInterp2x2(native, NR, NC);
        const heat = compensateAndFilterAdcMatrix(src, sensor, DEFAULT_ADC_COMPENSATION_SETTINGS);
        const force = calculateLiveSensorForce(sensor, src, native, undefined, undefined, "fixed_load_recognition", { timestampMs: fr.t, streamId });
        attachEndiPointPressure(force, sensor, native, heat);
        st.frames++;
        const avg = force?.contactPressure?.averagePressureKPa ?? null;
        const cardText = formatPressureNcm2(avg == null ? null : Number(avg.toFixed(2)));
        const M = force ? endiPointPressureMatrix(force) : null;
        // 主页压强热图：每格 kPaToNcm2 后按格内格式显示
        const texts: string[] = [];
        let all = 0;
        for (const row of M ?? []) for (const v of row) { all++; texts.push(formatHeatmapPressureCell(Number.isFinite(v) && v > 0 ? kPaToNcm2(v) : 0)); }
        const nz = texts.filter(t => t !== "0");
        if (!nz.length) {
          if (cardText === "--") st.noContactCardDash++; else st.noContactBad++;
          continue;
        }
        st.contactFrames++;
        const units = nz.reduce((a, t) => a + Math.round(Number(t) * 1000), 0);
        const meanText = (Math.round(units / nz.length) / 1000).toFixed(3);
        const exactMean = units / nz.length / 1000;
        if (meanText === cardText) st.textEqual++;
        else if (st.textBad.length < 20) st.textBad.push({ f, g, k, meanText, cardText, cells: nz.length });
        const d = Math.abs(exactMean - Number(cardText));
        st.maxExactDiff = Math.max(st.maxExactDiff, d);
        if (d > 0.0005 + 1e-9) st.exactDiffBad++;
        // 非零格数 = 各区轮廓格数之和
        const regs = (sensor === "endi-23x23" ? force?.endiCushion?.regions : force?.endiBackrest?.regions) ?? [];
        // 坐垫诊断区给出 T29 轮廓格数 contourCells（1 cm²/格）；靠背诊断区给出 T39 轮廓面积 contourAreaCm2（1.3 cm²/格）
        const contour = regs.reduce((a, r: any) => a + (sensor === "endi-23x23" ? r.contourCells : Math.round(r.contourAreaCm2 / 1.3)), 0);
        if (contour === nz.length) st.countEqualsContour++;
        else if (st.countBad.length < 20) st.countBad.push({ f, g, k, nonZero: nz.length, contour });
        // 对照口径 D：总压力 / 总面积
        const F = force?.forceN ?? 0, S = force?.areaCm2 ?? 0;
        if (S > 0) {
          const fs_ = F / S;
          const dd = Math.abs(fs_ - Number(cardText));
          st.fsDiffMax = Math.max(st.fsDiffMax, dd);
          if (regs.length > 1) { st.multiRegionFrames++; st.fsDiffMaxMulti = Math.max(st.fsDiffMaxMulti, dd); st.fsDiffMulti.push(dd); }
          else st.fsDiffMaxSingle = Math.max(st.fsDiffMaxSingle, dd);
        }
        // 对照口径 E：除以全部格子（含 0）
        const allMean = units / all / 1000;
        const ratio = allMean / Number(cardText);
        st.allCellsMeanRatioMin = Math.min(st.allCellsMeanRatioMin, ratio);
        st.allCellsMeanRatioMax = Math.max(st.allCellsMeanRatioMax, ratio);
        if (k === 99 && st.examples.length < 6) {
          st.examples.push({ file: f, group: g, cells: nz.length, contourCells: contour, regions: regs.length, sumText: (units / 1000).toFixed(3),
            meanText, exactMean: +exactMean.toFixed(6), cardText, forceN: F, areaCm2: S, forceOverArea: +(S > 0 ? F / S : 0).toFixed(4),
            allCellsMean: +allMean.toFixed(4), totalCells: all });
        }
      }
    }
  }
  const sorted = st.fsDiffMulti.sort((a, b) => a - b);
  return {
    ...st, fsDiffMulti: undefined,
    fsDiffMultiP50: sorted.length ? sorted[Math.floor(sorted.length / 2)] : null,
    ok: st.textEqual === st.contactFrames && st.exactDiffBad === 0 && st.countEqualsContour === st.contactFrames && st.noContactBad === 0,
  };
}

const t0 = Date.now();
const seat = audit("endi-23x23", seatDir);
const back = audit("new-backrest-32x25", backDir);
const out = { version: APP_VERSION, seat, back, ok: seat.ok && back.ok, elapsedS: Math.round((Date.now() - t0) / 1000) };
fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
for (const r of [seat, back]) {
  console.log(`${r.sensor}: 帧 ${r.frames}，有接触 ${r.contactFrames}（多区 ${r.multiRegionFrames}），格子文字平均=卡片 ${r.textEqual}/${r.contactFrames}，` +
    `精确平均与卡片最大差 ${r.maxExactDiff.toFixed(6)} N/cm²，非零格数=轮廓格数 ${r.countEqualsContour}/${r.contactFrames}，无接触卡片“--” ${r.noContactCardDash}（异常 ${r.noContactBad}）；` +
    `对照 F/S 与卡片最大差：单区 ${r.fsDiffMaxSingle.toFixed(4)}，多区 ${r.fsDiffMaxMulti.toFixed(4)}；全图含0格平均/卡片 ${r.allCellsMeanRatioMin.toFixed(3)}–${r.allCellsMeanRatioMax.toFixed(3)}；ok=${r.ok}`);
}
console.log("ALL OK =", out.ok, "用时", out.elapsedS, "s");
