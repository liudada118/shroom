import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {analyzeSeatArea,SEAT_AREA_VERSION} from '../client/src/lib/seatArea';
import {calculateDisplayedArea} from '../client/src/lib/displayArea';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {predictSeatTotalForce,seatTotalForceModelVersion} from '../client/src/lib/seatTotalForce';
import {calculateSeatRegionPressure} from '../client/src/lib/seatRegionPressure';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';

const out=process.argv[2];assert.ok(out);
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(out,name),'utf8'));
const data=read('坐垫面积原始ADC与接触数标签.json'),refs=read('坐垫面积逐帧对比.json');
const hash=(value:unknown)=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const close=(a:number,b:number,t=1e-7)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const rotate=<T>(m:T[][],turns:number)=>{for(let i=0;i<turns;i++)m=m[0].map((_,c)=>m.map(row=>row[c]).reverse());return m;};
const config=getSensorConfig('endi-23x23');
let maxAreaDifferenceCm2=0,contacts=0,rotationChecks=0;
const start=performance.now();
for(let i=0;i<data.length;i++){
 const r=data[i],ref=refs[i],before=hash(r),area=analyzeSeatArea(r.source);
 assert.equal(area.seedCount,r.expectedContacts,`${r.file} frame ${r.index}`);
 assert.equal(ref.file,r.file);assert.equal(ref.index,r.index);
 maxAreaDifferenceCm2=Math.max(maxAreaDifferenceCm2,Math.abs(area.areaCm2-ref.areaCm2));close(area.areaCm2,ref.areaCm2);
 area.regions.forEach((local,k)=>{
  close(local.areaCm2,ref.regions[k].areaCm2);close(local.thresholdAdc,ref.regions[k].thresholdAdc);
  assert.ok(local.areaCm2>=59&&local.areaCm2<=66,JSON.stringify({file:r.file,index:r.index,local}));contacts++;
 });
 close(area.areaMatrixCm2.flat().reduce((s,v)=>s+v,0),area.areaCm2);
 const decoded=Array.from({length:23},(_,row)=>Array.from({length:23},(_,col)=>r.raw[config.wireMap[row*23+col]]));
 assert.deepEqual(decoded,r.physical);assert.deepEqual(lineInterp2x2(decoded,23,23),r.source);
 const forceN=predictSeatTotalForce(r.physical);
 for(let rotation=0;rotation<4;rotation++){
  const matrix=rotate(r.source,rotation),rotated=analyzeSeatArea(matrix,{rotation});rotationChecks++;
  close(rotated.areaCm2,area.areaCm2);assert.deepEqual(rotated.areaMatrixCm2,rotate(area.areaMatrixCm2,rotation));
  assert.deepEqual(rotated.regions.map(v=>v.areaCm2),area.regions.map(v=>v.areaCm2));
  const pressure=calculateSeatRegionPressure(r.physical,forceN,{area:rotated,rotation});
  close(pressure.regions.reduce((s,v)=>s+v.estimatedForceN,0),forceN);
  close(pressure.averagePressureKPa!,pressure.regions.reduce((s,v)=>s+10*v.estimatedForceN/v.areaCm2,0)/pressure.regions.length);
  if(rotation===3){
   // Display filtering/ADC gain cannot change this source-only area fit.
   const display=calculateDisplayedArea(matrix.map(row=>row.map(()=>0)),null,null,{sensorType:config.type,sourceMatrix:matrix,sourceRotation:rotation})!;
   close(display.areaCm2,area.areaCm2);
   const live=calculateLiveSensorForce(config.type,r.source,r.physical,area.areaCm2,{area:rotated,rotation})!;
   close(live.forceN,forceN,0);close(live.averagePressureKPa!,pressure.averagePressureKPa!);
   assert.equal(live.modelVersion,seatTotalForceModelVersion);
   const selection={startRow:8,startCol:12,endRow:32,endCol:35};
   const cropped=analyzeSeatArea(matrix,{rotation,selection});
   const expected=rotated.areaMatrixCm2.flatMap((row,r)=>row.map((v,c)=>r>=8&&r<=32&&c>=12&&c<=35?v:0)).reduce((s,v)=>s+v,0);
   close(cropped.areaCm2,expected);assert.deepEqual(cropped.regionThresholds,rotated.regionThresholds);assert.deepEqual(cropped.seeds,rotated.seeds);
  }
 }
 assert.equal(hash(r),before,'Original data must be unchanged');
}
const zero=Array.from({length:46},()=>Array(46).fill(0));
assert.equal(analyzeSeatArea(zero).areaCm2,0);assert.equal(analyzeSeatArea(zero).seedCount,0);
assert.equal(calculateDisplayedArea(zero,null,null,{sensorType:config.type}),null,'Missing raw source must not silently use display ADC');
assert.equal(analyzeSeatArea(data[0].source,{validMask:zero.map(row=>row.map(()=>false))}).areaCm2,0);
assert.throws(()=>analyzeSeatArea([[1]]));assert.throws(()=>analyzeSeatArea(zero.map(row=>row.map(()=>NaN))));
assert.throws(()=>analyzeSeatArea(zero,{rotation:NaN}));
const chosen=[data.find((r:any)=>r.expectedContacts===1),...Array.from({length:4},(_,i)=>data.find((r:any)=>r.expectedContacts===i+2))];
// Distinct loading levels are also needed for the preserved short-pulse audit.
chosen.push(data.find((r:any)=>r.expectedContacts===1&&predictSeatTotalForce(r.physical)>100));
const fixtures=chosen.map((r:any)=>{
 const area=analyzeSeatArea(rotate(r.source,3),{rotation:3}),forceN=predictSeatTotalForce(r.physical);
 return {file:r.file,index:r.index,sensorType:config.type,forceN,expectedAreaCm2:area.areaCm2,
  packet:[...r.raw,170,85,3,153],contactPressure:calculateSeatRegionPressure(r.physical,forceN,{area,rotation:3})};
});
// Verify all genuinely new five-stack raw frames in the production page.
fixtures.push(...data.filter((r:any)=>r.originallyUnseenByV75).map((r:any)=>{
 const area=analyzeSeatArea(rotate(r.source,3),{rotation:3}),forceN=predictSeatTotalForce(r.physical);
 return {file:r.file,index:r.index,sensorType:config.type,forceN,expectedAreaCm2:area.areaCm2,
  packet:[...r.raw,170,85,3,153],contactPressure:calculateSeatRegionPressure(r.physical,forceN,{area,rotation:3})};
}));
const previous=JSON.parse(fs.readFileSync(path.join(out,'..','坐垫面积重新拟合','坐垫面积逐帧对比.json'),'utf8'));
const multis=data.map((r:any,i:number)=>[r,i]).filter(([r]:any)=>r.expectedContacts>1);
multis.forEach(([r,i]:any)=>{
 const current=analyzeSeatArea(r.source),old=previous[i];
 close(current.areaCm2,old.areaCm2);
 current.regions.forEach((v:any,k:number)=>{close(v.areaCm2,old.regions[k].areaCm2);close(v.thresholdAdc,old.regions[k].thresholdAdc);});
});
assert.equal(multis.length,64);
const browser=path.join(out,'坐垫页面');fs.mkdirSync(browser,{recursive:true});fs.writeFileSync(path.join(browser,'browser-wire-fixtures.json'),JSON.stringify(fixtures));
const result={areaVersion:SEAT_AREA_VERSION,forceModelVersion:seatTotalForceModelVersion,frames:data.length,contacts,correctCountFrames:data.length,
 passedContacts:contacts,maxPythonAreaDifferenceCm2:maxAreaDifferenceCm2,rotationChecks,selectionCropsFinalMask:true,sourceOnlyAreaPassed:true,
 forceModelUpdated:true,areaValuesUnchanged:true,regionMeanFormulaPassed:true,originalAdcPreserved:true,emptyAndInvalidPassed:true,
 multiContactFramesUnchanged:64,newFileExcludedFromAreaFit:true,newFiveStackFrames:10,browserFixtures:fixtures.length,totalTestMs:performance.now()-start,independentAcceptancePassed:false};
fs.writeFileSync(path.join(out,'seat-area-integration-result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
