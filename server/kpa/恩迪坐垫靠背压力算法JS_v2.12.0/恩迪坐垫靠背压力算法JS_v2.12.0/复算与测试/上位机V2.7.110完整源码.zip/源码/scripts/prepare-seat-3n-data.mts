import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {applyFilter} from '../client/src/lib/dataFilter';
const root=process.argv[2];assert.ok(root);
const file=path.join(root,'坐垫原始ADC与标签.json'),frames=JSON.parse(fs.readFileSync(file,'utf8'));
const ctx:any={};vm.runInNewContext(fs.readFileSync('client/public/dummyArea_v2.10.36.js','utf8'),ctx);
let checked=0;
for(const f of frames){
 if(f.kind!=='本次3至5块连续实测')continue;
 f.areaInput=applyFilter(f.areaInput,{threshold:30,calibrationMode:'none',resultScale:1}).filteredMatrix;
 f.baselineArea=ctx.DummyAreaV21036.calculateDummyDisplayedAreaFrame(f.areaInput,null);
 assert.equal(f.baselineArea.areaCm2,f.savedAreaCm2,'Existing exported area must match unchanged area code');
 checked++;
}
assert.equal(checked,19);fs.writeFileSync(file,JSON.stringify(frames));
fs.mkdirSync(path.join(root,'上位机接入验证'),{recursive:true});
console.log(JSON.stringify({newFrames:checked,originalSavedAreasMatch:true}));

