import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { analyzeBackrestArea } from "../client/src/lib/backrestArea";
import { calculateDisplayedArea } from "../client/src/lib/displayArea";

// External fixtures include original ADC and independent Python reference outputs.
const audit = process.argv[2];
const output = process.argv[3] && !process.argv[3].startsWith("--") ? process.argv[3] : audit;
assert.ok(audit, "Usage: tsx scripts/verify-backrest-total-force.mts <audit folder> [--baseline]");
const read = (name: string) => JSON.parse(fs.readFileSync(path.join(audit, name), "utf8"));
const write = (name: string, data: unknown) => fs.writeFileSync(path.join(output, name), JSON.stringify(data, null, 2));
const hash = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const transpose = (m: number[][]) => m[0].map((_, c) => m.map(row => row[c]));
type Fixture = { file: string; index: number; matrix: number[][]; source: number[][];
  mass_kg: number | null; referenceFeatures: number[]; referenceForceN: number };
const fixtures: Fixture[] = read("integration-fixtures.json");
const areaSnapshots = fixtures.map(f => ({
  canonical: hash(analyzeBackrestArea(f.source)),
  native: hash(analyzeBackrestArea(transpose(f.source))),
  selection: hash(calculateDisplayedArea(f.source, null,
    { startRow: 10, endRow: 39, startCol: 8, endCol: 55 },
    { sensorType: "new-backrest-32x25", sourceMatrix: f.source })),
}));
if (process.argv.includes("--baseline")) {
  write("area-before.json", areaSnapshots);
  console.log(JSON.stringify({ baselineAreaFrames: fixtures.length, comparisonsPerFrame: 3 }));
  process.exit(0);
}
assert.deepEqual(areaSnapshots, read("area-before.json"), "Every area result, threshold and retained mask must remain identical");

const { extractBackrestForceFeatures, predictBackrestTotalForce } = await import("../client/src/lib/backrestTotalForce");
const { analyzeBackrestForce } = await import("../client/src/lib/backrestForce");
const { calculateLiveSensorForce } = await import("../client/src/lib/sensorForce");
const { ForceReadout, captureForceReadout, forceReadoutExportValues, FORCE_READOUT_EXPORT_HEADERS, FORCE_READOUT_INTERVAL_MS } = await import("../client/src/lib/forceReadout");
const close = (a: number, b: number, tolerance = 1e-9) => assert.ok(Math.abs(a - b) <= tolerance, `${a} != ${b}`);
let maxFeatureDifference = 0, maxPredictionDifference = 0;
const comparisons = fixtures.map(f => {
  const features = extractBackrestForceFeatures(f.matrix);
  features.forEach((v, i) => { maxFeatureDifference = Math.max(maxFeatureDifference, Math.abs(v-f.referenceFeatures[i])); close(v, f.referenceFeatures[i]); });
  const inputBefore = hash(f);
  const nativeSource = transpose(f.source), nativePhysical = transpose(f.matrix);
  const existingArea = analyzeBackrestArea(nativeSource).areaCm2;
  const prediction = calculateLiveSensorForce("new-backrest-32x25", nativeSource, nativePhysical, existingArea)!;
  assert.ok(prediction);
  close(prediction.forceN, f.referenceForceN);
  close(analyzeBackrestForce(f.source, f.matrix).forceN, prediction.forceN);
  close(predictBackrestTotalForce(f.matrix), prediction.forceN);
  maxPredictionDifference = Math.max(maxPredictionDifference, Math.abs(prediction.forceN - f.referenceForceN));
  assert.equal(prediction.areaCm2, existingArea);
  const pressure = prediction.contactPressure!;
  assert.equal(prediction.averagePressureKPa, pressure.averagePressureKPa);
  assert.equal(pressure.areaCm2, existingArea);
  if (pressure.status === "estimated") {
    close(pressure.regions.reduce((s, r) => s+r.estimatedForceN, 0), prediction.forceN);
    close(pressure.averagePressureKPa!, pressure.regions.reduce((s, r) => s+10*r.estimatedForceN/r.areaCm2, 0)/pressure.regions.length);
  }
  assert.equal(prediction.forceAggregation, "total_only");
  assert.deepEqual(prediction.regionForcesN, [], "The model has no independently calibrated contact forces");
  assert.equal(prediction.accepted, false);
  assert.equal(prediction.independentlyValidated, false);
  assert.equal(prediction.forceEstimateComplete, true);
  assert.equal(hash(f), inputBefore, "Original ADC must not be modified");
  const readout = new ForceReadout();
  for (const enabled of [false, true]) {
    readout.reset();
    const shown = readout.update("fixture", nativePhysical, prediction, 100, 100, enabled)!;
    close(shown.forceN, prediction.forceN);
    assert.deepEqual(shown.regionForcesN, []);
    assert.equal(forceReadoutExportValues(captureForceReadout(shown)).length, FORCE_READOUT_EXPORT_HEADERS.length);
  }
  return { file: f.file, index: f.index, mass_kg: f.mass_kg, referenceForceN: f.referenceForceN,
    integratedForceN: prediction.forceN, areaCm2: existingArea,
    errorN: f.mass_kg === null ? null : prediction.forceN-f.mass_kg*9.80665 };
});

const zeroP = Array.from({length:32}, () => Array(25).fill(0));
const zeroS = Array.from({length:64}, () => Array(50).fill(0));
const empty = calculateLiveSensorForce("new-backrest-32x25", zeroS, zeroP, 0)!;
assert.equal(empty.forceN, 0);
assert.equal(empty.averagePressureKPa, null);
assert.equal(calculateLiveSensorForce("new-backrest-32x25", [[0]], zeroP), null);
assert.equal(calculateLiveSensorForce("other", zeroS, zeroP), null);
assert.equal(calculateLiveSensorForce("new-backrest-32x25", null, zeroP), null);
const bad = structuredClone(zeroP); bad[0][0] = NaN;
assert.equal(calculateLiveSensorForce("new-backrest-32x25", zeroS, bad), null);
assert.throws(() => predictBackrestTotalForce([[1]]));
const sample = fixtures[0];
const independent = calculateLiveSensorForce("new-backrest-32x25", zeroS, transpose(sample.matrix), 123)!;
close(independent.forceN, sample.referenceForceN);
assert.equal(independent.areaCm2, 123, "Area is supplied independently of the force model");

// A stream tests global smoothing, deadlines, final-sample publication and zero unload.
const filter = new ForceReadout();
const base = { ...independent, forceN: 100 };
assert.equal(filter.update("live", {}, base, 0, 0)!.forceN, 100);
assert.equal(filter.update("live", {}, { ...base, forceN: 120 }, 5, 5), null);
assert.equal(filter.pendingPublishAt(), FORCE_READOUT_INTERVAL_MS);
close(filter.flush(FORCE_READOUT_INTERVAL_MS)!.forceN, 120, 1e-9);
// Loading passes through immediately; no median rejection of short force pulses.
assert.ok(filter.update("live", {}, { ...base, forceN: 120 }, 100, 100)!.forceN > 118);
assert.equal(filter.update("live", {}, empty, 110, 110), null);
assert.equal(filter.flush(120)!.forceN, 0);
assert.equal(filter.update("live", {}, base, 125, 125)!.forceN, 100);
assert.equal(filter.update("live", {}, { ...base, forceN: 125 }, 130, 130, false)!.forceN, 125);
// The original per-region seat path must still sum and drop removed contacts.
filter.reset();
const regional = { ...base, forceAggregation: "regional_sum" as const, regionForcesN: [30,70], regionCenters: [[1,1],[20,20]] as [number,number][] };
assert.equal(filter.update("seat", {}, regional, 0, 0)!.forceN, 100);
const removed = filter.update("seat", {}, { ...regional, forceN: 30, regionForcesN: [30], regionCenters: [[1,1]] }, 50, 50)!;
assert.equal(removed.forceN, 30);
assert.deepEqual(removed.regionForcesN, [30]);

const labelled = comparisons.filter(f => f.errorN !== null);
const errors = labelled.map(f => f.errorN!);
assert.equal(fixtures.length, 676);
assert.equal(errors.length, 675);
assert.ok(errors.every(e => Math.abs(e) <= 5), "All known-weight calibration frames must pass ±5 N");
const summary = { frames: fixtures.length, labelled: errors.length, excludedUnknownWeight: fixtures.length-errors.length,
  minErrorN: Math.min(...errors), maxErrorN: Math.max(...errors), maxAbsErrorN: Math.max(...errors.map(Math.abs)),
  meanAbsErrorN: errors.reduce((s,e) => s+Math.abs(e),0)/errors.length, within5N: errors.length,
  maxFeatureDifference, maxPredictionDifference, areaFramesUnchanged: areaSnapshots.length,
  areaSnapshotsUnchanged: areaSnapshots.length*3,
  totalReadoutAndRegionalCompatibility: "passed", independentAccuracyAccepted: false };
write("integration-comparison.json", comparisons);
write("integration-result.json", summary);
console.log(JSON.stringify(summary, null, 2));
