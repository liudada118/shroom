import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';

const audit=process.argv[2];
assert.ok(audit,'Pass the integration audit directory');
const fixtures=JSON.parse(fs.readFileSync(path.join(audit,'browser-wire-fixtures.json'),'utf8'));
const expectedVersion=process.argv[3]??'V2.7.70';
const expectedModel=process.argv[4]??'2026-10-28-field-compensated-985frames-12features';
const sensorType=fixtures[0]?.sensorType??'new-backrest-32x25';
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'region-pressure-runtime-'));
const browser=spawn('C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',[
 '--headless=new','--disable-gpu','--no-first-run','--window-size=1800,1200',
 '--remote-debugging-port=9336',`--user-data-dir=${profile}`,'about:blank',
],{stdio:'ignore',windowsHide:true});
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let socket;
const errors=[];
try {
 let target;
 for(let i=0;i<60;i++){
  try{const list=await fetch('http://127.0.0.1:9336/json/list').then(r=>r.json());target=list.find(t=>t.type==='page');if(target)break;}catch{}
  await sleep(100);
 }
 assert.ok(target,'Browser debugger must become available');
 socket=new WebSocket(target.webSocketDebuggerUrl);
 let sequence=0;
 const pending=new Map();
 socket.addEventListener('message',event=>{
  const value=JSON.parse(event.data);
  if(value.method==='Runtime.exceptionThrown')errors.push(value.params.exceptionDetails);
  const request=pending.get(value.id);if(!request)return;
  pending.delete(value.id);clearTimeout(request.timer);
  value.error?request.reject(new Error(value.error.message)):request.resolve(value.result);
 });
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 const send=(method,params={})=>new Promise((resolve,reject)=>{
  const id=++sequence;
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`Timeout: ${method}`));},15000);
  pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));
 });
 const evaluate=async expression=>{
  const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value;
 };
 const click=async expression=>{
  const pos=await evaluate(`(()=>{const e=${expression};if(!e)throw Error('Element not found');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
  await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...pos});
  await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...pos});
 };
 const button=text=>`[...document.querySelectorAll('button')].find(e=>e.textContent?.trim()===${JSON.stringify(text)})`;
 await send('Page.enable');await send('Runtime.enable');
 await send('Page.addScriptToEvaluateOnNewDocument',{source:`
  window.__serialAudit={controller:null};
  window.__auditBlobs=[];
  const originalCreate=URL.createObjectURL.bind(URL);
  URL.createObjectURL=blob=>{window.__auditBlobs.push(blob);return originalCreate(blob);};
  HTMLAnchorElement.prototype.click=function(){};
  const port={
   open:async()=>{},close:async()=>{},getInfo:()=>({usbVendorId:0,usbProductId:0}),
   readable:new ReadableStream({start(c){window.__serialAudit.controller=c;}})
  };
  Object.defineProperty(navigator,'serial',{configurable:true,value:{requestPort:async()=>port,getPorts:async()=>[]}});
 `});
 await send('Page.navigate',{url:'http://127.0.0.1:3000/'});
 for(let i=0;i<80;i++){
  if(await evaluate(`!!document.querySelector('button[role="combobox"]')`))break;
  await sleep(100);
 }
 assert.ok((await evaluate('document.title')).includes(expectedVersion));
 if(sensorType==='new-backrest-32x25'){
  await click(`document.querySelector('button[role="combobox"]')`);await sleep(100);
  await click(`[...document.querySelectorAll('[role="option"]')].find(e=>e.textContent?.includes('新靠背'))`);
 }
 await sleep(200);
 await click(button('连接串口'));await sleep(300);
 assert.ok(await evaluate(`document.body.innerText.includes('已连接')`));

 const low=fixtures.reduce((a,b)=>a.forceN<b.forceN?a:b);
 const high=fixtures.reduce((a,b)=>a.forceN>b.forceN?a:b);
 const force=()=>evaluate(`Number(document.querySelector('[data-testid="force-value"]').textContent)`);
 const sendPackets=async packets=>{
  return evaluate(`(()=>{const at=performance.now();window.__serialAudit.controller.enqueue(new Uint8Array(${JSON.stringify(packets.flat())}));return at;})()`);
 };
 const watch=()=>evaluate(`(()=>{window.__followChanges=[];window.__followObserver?.disconnect();window.__followObserver=new MutationObserver(()=>window.__followChanges.push({at:performance.now(),forceN:Number(document.querySelector('[data-testid="force-value"]').textContent)}));window.__followObserver.observe(document.querySelector('[data-testid="force-value"]'),{childList:true,subtree:true,characterData:true});})()`);
 const changes=()=>evaluate('window.__followChanges');
 await sendPackets([low.packet]);await sleep(180);
 await watch();
 const at=await sendPackets([...Array(23).fill(low.packet),high.packet]);
 await sleep(350);
 const observed=await force(),trace=await changes();
 const reached=trace.find(p=>Math.abs(p.forceN-high.forceN)<=.0051);
 const result={version:expectedVersion,sensorType,input:'Mock Web Serial original ADC packets; software latency only',
  burstFrames:24,chunkCount:1,noFurtherPackets:true,expectedForceN:high.forceN,observedForceN:observed,
  latestFrameReached:Math.abs(observed-high.forceN)<=.0051,responseMs:reached?reached.at-at:null,
  changes:trace.map(p=>({...p,elapsedMs:p.at-at})),uncaughtRuntimeErrors:errors.length};
 fs.writeFileSync(path.join(audit,'following-burst-result.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));
 if(!process.argv.includes('--baseline'))assert.ok(result.latestFrameReached,'A 24-frame chunk must drain to the latest force without another serial read');
 if(!process.argv.includes('--baseline')){
  await sendPackets([low.packet]);await sleep(180);await watch();
  const zero=[...Array(1024).fill(0),170,85,3,153];
  const peakAt=await sendPackets([...Array(12).fill(low.packet),high.packet,...Array(11).fill(low.packet)]);
  await sleep(220);const peak=await changes();
  assert.ok(peak.some(p=>Math.abs(p.forceN-high.forceN)<=.0051),JSON.stringify(peak));
  assert.ok(Math.abs((await force())-low.forceN)<=.0051);
  const unloadAt=await sendPackets([...Array(19).fill(high.packet),zero]);
  await sleep(220);assert.equal(await force(),0);
  // Delimiter and payload split across reads, including a >10-frame first read.
  const bytes=[...Array(12).fill(low.packet).flat(),...high.packet];
  await sendPackets([bytes.slice(0,-2)]);await sleep(80);
  await sendPackets([bytes.slice(-2)]);await sleep(180);
  assert.ok(Math.abs((await force())-high.forceN)<=.0051);
  // Long buffered burst exercises paint yielding without discarding valid frames.
  await watch();const longAt=await sendPackets([...Array(159).fill(low.packet),high.packet]);
  await sleep(80);let longTrace=await changes();
  for(let i=0;i<80&&!longTrace.some(p=>Math.abs(p.forceN-high.forceN)<=.0051);i++){
    await sleep(25);longTrace=await changes();
  }
  assert.ok(longTrace.some(p=>Math.abs(p.forceN-high.forceN)<=.0051),JSON.stringify(longTrace));
  assert.ok(Math.abs((await force())-high.forceN)<=.0051);
  const last=longTrace.find(p=>Math.abs(p.forceN-high.forceN)<=.0051);
  result.shortPeakPreserved=true;result.latestLowRestored=true;result.unloadPassed=true;
  result.splitFramePassed=true;result.longBurstFrames=160;result.longBurstLatestReached=true;
  result.longBurstResponseMs=last?last.at-longAt:null;
  result.shortPeakResponseMs=peak.find(p=>Math.abs(p.forceN-high.forceN)<=.0051).at-peakAt;
  // Normal 80 Hz traffic: verify live rising/falling steps while bytes continue.
  await sendPackets([low.packet]);await sleep(160);await watch();
  const stream=await evaluate(`(async()=>{
    const low=${JSON.stringify(low.packet)},high=${JSON.stringify(high.packet)},marks=[];
    for(let i=0;i<30;i++){
      if(i===10||i===20)marks.push({at:performance.now(),forceN:i===10?${high.forceN}:${low.forceN}});
      window.__serialAudit.controller.enqueue(new Uint8Array(i>=10&&i<20?high:low));
      await new Promise(r=>setTimeout(r,12.5));
    }
    await new Promise(r=>setTimeout(r,80));
    return {marks,changes:window.__followChanges};
  })()`);
  result.normalStreamSteps=stream.marks.map(mark=>{
    const seen=stream.changes.find(p=>p.at>=mark.at&&Math.abs(p.forceN-mark.forceN)<=.0051);
    assert.ok(seen,JSON.stringify(stream));
    return {targetForceN:mark.forceN,responseMs:seen.at-mark.at};
  });
  assert.ok(result.normalStreamSteps.every(s=>s.responseMs<150));
  assert.ok(Math.abs((await force())-low.forceN)<=.0051);
  // The captured display sequence proves every valid frame participated, even
  // in the 160-frame burst; reaching only the final value would not prove that.
  const manual=await evaluate(`[...document.querySelectorAll('button')].find(e=>['采集当前帧','手动采集','采集一帧'].includes(e.textContent?.trim()))?.textContent.trim()`);
  assert.ok(manual);await click(button(manual));await sleep(100);
  const sequence=await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('SensorCaptureDB',3);r.onerror=()=>reject(r.error);r.onsuccess=()=>{const d=r.result,q=d.transaction('capturedFrames').objectStore('capturedFrames').getAll();q.onsuccess=()=>{d.close();resolve(q.result[0]?.forceDisplayMetrics?.sampleSequence);};q.onerror=()=>reject(q.error);};})`);
  assert.equal(sequence,274,'All 274 complete frames must reach the force calculation');
  result.expectedInputFrames=274;result.forceSampleSequence=sequence;result.allValidFramesParticipated=true;
  result.uncaughtRuntimeErrors=errors.length;
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(audit,'following-burst-result.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify({additionalChecks:result},null,2));
 }
 await click(button('断开连接'));
}catch(error){
 fs.writeFileSync(path.join(audit,'following-burst-failure.json'),JSON.stringify({message:String(error),errors},null,2));
 throw error;
}finally{
 socket?.close();browser.kill();
}
