import fs from 'node:fs';
import path from 'node:path';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {analyzeSeatArea} from '../client/src/lib/seatArea';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
const out=process.argv[2],input=JSON.parse(fs.readFileSync(path.join(out,'wire-fixture-input.json'),'utf8'));
const config=getSensorConfig('endi-23x23');
const rotate=(m:number[][])=>{for(let i=0;i<3;i++)m=m[0].map((_,c)=>m.map(row=>row[c]).reverse());return m;};
function fixture(raw:number[],f:any){
 const physical=Array.from({length:23},(_,r)=>Array.from({length:23},(_,c)=>raw[config.wireMap[r*23+c]]));
 const source=lineInterp2x2(physical,23,23),area=analyzeSeatArea(rotate(source),{rotation:3});
 const live=calculateLiveSensorForce(config.type,source,physical,area.areaCm2,{area,rotation:3})!;
 const v80=calculateLiveSensorForce(config.type,source,physical,area.areaCm2,{area,rotation:3},'spatial_response_spline')!;
 return {file:f.file,index:f.index,blocks:f.blocks,sensorType:config.type,forceN:live.forceN,v80ForceN:v80.forceN,
 expectedAreaCm2:area.areaCm2,packet:[...raw,170,85,3,153],contactPressure:live.contactPressure};
}
fs.writeFileSync(path.join(out,'browser-wire-fixtures.json'),JSON.stringify(input.old.map((f:any)=>fixture(f.packet.slice(0,1024),f))));
fs.writeFileSync(path.join(out,'browser-current-wire.json'),JSON.stringify(input.current.map((f:any)=>fixture(f.raw,f))));
console.log('Prepared '+input.old.length+' representative and '+input.current.length+' current recorded ADC fixtures');
