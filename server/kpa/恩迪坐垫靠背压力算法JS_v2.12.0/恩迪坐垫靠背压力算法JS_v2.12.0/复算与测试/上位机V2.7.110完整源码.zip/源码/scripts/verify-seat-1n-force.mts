import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {predictSeatForceDetails,predictSeatTotalForce,extractSeatForceFeatures,seatTotalForceModelVersion} from '../client/src/lib/seatTotalForce';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {analyzeSeatArea} from '../client/src/lib/seatArea';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {ForceReadout} from '../client/src/lib/forceReadout';

const out=process.argv[2];assert.ok(out);
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(out,name),'utf8'));
const records=read('坐垫一牛顿全部原始ADC与标签.json');
const refs=read('坐垫一牛顿逐帧对比.json'),python=read('python-portable-predictions.json');
const close=(a:number,b:number,t=1e-7)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const config=getSensorConfig('endi-23x23');
let maxPythonDifferenceN=0,maxFeatureDifference=0,negative=0,positive=0,unknown=0,totalMs=0;
const comparisons:any[]=[];
for(let i=0;i<records.length;i++){
 const r=records[i],before=hash(r),start=performance.now(),p=predictSeatForceDetails(r.physical);
 totalMs+=performance.now()-start;
 maxPythonDifferenceN=Math.max(maxPythonDifferenceN,Math.abs(p.forceN-python[i].forceN));
 for(const key of ['baseForceN','correctionN','forceN'] as const)close(p[key],python[i][key]);
 assert.equal(seatTotalForceModelVersion,python[i].modelVersion);
 const decoded=Array.from({length:23},(_,row)=>Array.from({length:23},(_,col)=>r.raw[config.wireMap[row*23+col]]));
 assert.deepEqual(decoded,r.physical);
 const source=lineInterp2x2(decoded,23,23);
 if(r.source)assert.deepEqual(source,r.source);
 const area=analyzeSeatArea(source),live=calculateLiveSensorForce(config.type,source,r.physical,area.areaCm2,{area,rotation:0})!;
 close(live.forceN,p.forceN,0);assert.equal(live.modelVersion,seatTotalForceModelVersion);
 assert.equal(live.accepted,false);assert.equal(live.independentlyValidated,false);
 assert.equal(live.forceAggregation,'total_only');assert.deepEqual(live.regionForcesN,[]);
 const pressure=live.contactPressure!;
 close(pressure.regions.reduce((s,v)=>s+v.estimatedForceN,0),p.forceN);
 close(pressure.averagePressureKPa!,pressure.regions.reduce((s,v)=>s+10*v.estimatedForceN/v.areaCm2,0)/pressure.regions.length);
 const filter=new ForceReadout(),shown=filter.update('fixture',r.physical,live,100,100,true)!;
 close(shown.forceN,p.forceN,0);close(shown.contactPressure!.averagePressureKPa!,pressure.averagePressureKPa!);
 if(i<752){
  const ref=refs[i],error=p.forceN-r.mass_kg*9.80665;
  assert.equal(r.file,ref.file);assert.equal(r.index,ref.index);
  close(p.forceN,ref.forceN);assert.ok(Math.abs(error)<=1,JSON.stringify({file:r.file,index:r.index,error}));
  extractSeatForceFeatures(r.physical).forEach((v,k)=>{maxFeatureDifference=Math.max(maxFeatureDifference,Math.abs(v-ref.features[k]));close(v,ref.features[k]);});
  if(p.correctionN>0)positive++;else if(p.correctionN<0)negative++;
  comparisons.push({file:r.file,index:r.index,phase:ref.phase,massKg:r.mass_kg,referenceForceN:r.mass_kg*9.80665,...p,errorN:error,areaCm2:area.areaCm2,averagePressureKPa:pressure.averagePressureKPa});
 }else{assert.equal(r.mass_kg,null);unknown++;}
 assert.equal(hash(r),before,'Original ADC and labels remain unchanged');
}
assert.equal(records.length,753);assert.equal(unknown,1);assert.equal(negative,406);assert.equal(positive,346);
const zero=Array.from({length:23},()=>Array(23).fill(0));
assert.deepEqual(predictSeatForceDetails(zero),{baseForceN:0,correctionN:0,forceN:0});
assert.equal(predictSeatTotalForce(zero),0);
assert.throws(()=>predictSeatTotalForce([[0]]));
assert.throws(()=>predictSeatTotalForce(zero.map(row=>row.map(()=>NaN))));
const stats=(a:any[])=>({frames:a.length,within1N:a.filter(r=>Math.abs(r.errorN)<=1).length,maxAbsErrorN:Math.max(...a.map(r=>Math.abs(r.errorN))),minErrorN:Math.min(...a.map(r=>r.errorN)),maxErrorN:Math.max(...a.map(r=>r.errorN))});
assert.equal(comparisons.filter(r=>r.phase==='calibration').length,745);
assert.equal(comparisons.filter(r=>r.phase==='later_check').length,7);
const current=comparisons.filter(r=>r.file.includes('13-48-05'));
assert.equal(current.length,10);
const result={modelVersion:seatTotalForceModelVersion,rawFrames:753,knownWeightFrames:752,unknownWeightExcluded:1,
 calibration:stats(comparisons.filter(r=>r.phase==='calibration')),laterCheck:stats(comparisons.filter(r=>r.phase==='later_check')),allKnown:stats(comparisons),
 positiveCorrectionFrames:positive,negativeCorrectionFrames:negative,maxPythonDifferenceN,maxFeatureDifference,meanInferenceMs:totalMs/records.length,
 rawMappingPassed:true,regionPressureMeanPassed:true,zeroAndInvalidPassed:true,forceReadoutPassed:true,originalAdcPreserved:true,
 currentFiveStack:{frames:current.length,referenceForceN:79.67903125,baseRangeN:[Math.min(...current.map(r=>r.baseForceN)),Math.max(...current.map(r=>r.baseForceN))],
 correctedRangeN:[Math.min(...current.map(r=>r.forceN)),Math.max(...current.map(r=>r.forceN))]},independentPlacementAcceptancePassed:false};
fs.writeFileSync(path.join(out,'force-integration-result.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(out,'上位机逐帧压力补偿对比.json'),JSON.stringify(comparisons));
console.log(JSON.stringify(result,null,2));
