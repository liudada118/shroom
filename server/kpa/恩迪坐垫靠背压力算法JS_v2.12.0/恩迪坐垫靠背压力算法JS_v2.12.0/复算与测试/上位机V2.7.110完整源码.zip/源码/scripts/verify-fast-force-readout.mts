import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {build} from 'esbuild';
import {ForceReadout,captureForceReadout,forceReadoutExportValues,FORCE_READOUT_EXPORT_HEADERS,FORCE_READOUT_VERSION} from '../client/src/lib/forceReadout';
import type {ContinuousForceFrame} from '../client/src/lib/sensorForce';

const audit=process.argv[2];assert.ok(audit,'Pass the fast-filter audit directory');
const state=JSON.parse(fs.readFileSync(path.join(audit,'paths.json'),'utf8'));
const oldPath=path.join(state.backup,'source/client/src/lib/forceReadout.ts');
const previous=await build({stdin:{contents:fs.readFileSync(oldPath,'utf8'),loader:'ts',
 resolveDir:path.resolve('client/src/lib')},bundle:true,format:'esm',platform:'node',write:false});
const {ForceReadout:PreviousReadout}=await import('data:text/javascript;base64,'+Buffer.from(previous.outputFiles[0].contents).toString('base64'));
function raw(forceN:number):ContinuousForceFrame {
 const share=[.25,.75],area=[6.25,12.5];
 return {algorithmId:'synthetic-dynamics',algorithmLabel:'synthetic',modelVersion:'frozen-test-model',
 status:'candidate_requires_validation',forceN,regionForcesN:[],forceAggregation:'total_only',
 areaCm2:18.75,averagePressureKPa:forceN*.5,seedCount:2,inputMode:'synthetic-force',
 accepted:false,independentlyValidated:false,forceEstimateComplete:true,
 forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',scopeNote:'Synthetic filter dynamics, not sensor force accuracy',
 contactPressure:{version:'seat-raw-adc-share-region-pressure-mean-20261028',
 method:'raw_adc_share_then_region_arithmetic_mean',status:'estimated',scope:'complete_frame',independentlyValidated:false,
 totalForceN:forceN,areaCm2:18.75,rawAdcSum:40,assignedRawAdcSum:40,
 regions:share.map((s,i)=>({index:i,center:[i,i] as [number,number],rawAdcSum:40*s,forceShare:s,
 estimatedForceN:forceN*s,areaCm2:area[i],estimatedPressureKPa:10*forceN*s/area[i]})),
 averagePressureKPa:forceN*.5,globalAreaMeanPressureKPa:10*forceN/18.75}};
}
type Point={timeMs:number;forceN:number};
function stream(Ctor:any,samples:Point[]) {
 const filter=new Ctor(),shown:Point[]=[];
 for(const s of samples){
  const r=raw(s.forceN),before=JSON.stringify(r);
  const v=filter.update('test',{},r,s.timeMs,s.timeMs);
  assert.equal(JSON.stringify(r),before,'Display filtering must not mutate captured/raw force');
  if(v){
   shown.push({timeMs:s.timeMs,forceN:v.forceN});
   assert.ok(Math.abs(v.contactPressure.averagePressureKPa-v.forceN*.5)<1e-9);
   assert.ok(Math.abs(v.contactPressure.regions.reduce((n:number,r:any)=>n+r.estimatedForceN,0)-v.forceN)<1e-9);
  }
 }
 const deadline=filter.pendingPublishAt();
 if(deadline!==null){const v=filter.flush(deadline);shown.push({timeMs:deadline,forceN:v.forceN});}
 return shown;
}
const stepTests=[];
const traces:any={};
for(const period of [12.5,50,100]){
 for(const [initial,target] of [[100,150],[150,100],[15,31]]){
  const onset=1000;
  const samples=Array.from({length:Math.ceil(2500/period)+1},(_,i)=>({timeMs:i*period,forceN:i*period<onset?initial:target}));
  const old=stream(PreviousReadout,samples),current=stream(ForceReadout,samples);
  const response=(points:Point[])=>points.find(p=>p.timeMs>=onset&&Math.abs(p.forceN-target)<=Math.abs(target-initial)*.1)!.timeMs-onset;
  const oldT=response(old),newT=response(current);
  assert.ok(newT<oldT,JSON.stringify({period,initial,target,oldT,newT}));
  assert.ok(newT<=150,'Sustained step should reach 90% within 150 ms at 10–80 Hz');
  stepTests.push({periodMs:period,initialN:initial,targetN:target,old90PercentMs:oldT,new90PercentMs:newT});
  if(period===50&&target===150)traces.step={raw:samples,old,current};
 }
}
const noise=Array.from({length:501},(_,i)=>({timeMs:i*20,forceN:100+1.2*Math.sin(i*20*2*Math.PI*3/1000)+.6*Math.sin(i*1.718)}));
const oldNoise=stream(PreviousReadout,noise),newNoise=stream(ForceReadout,noise);
function std(values:number[]){const m=values.reduce((s,v)=>s+v,0)/values.length;return Math.sqrt(values.reduce((s,v)=>s+(v-m)**2,0)/values.length);}
const rawStd=std(noise.filter(p=>p.timeMs>1000).map(p=>p.forceN));
const oldStd=std(oldNoise.filter(p=>p.timeMs>1000).map(p=>p.forceN));
const newStd=std(newNoise.filter(p=>p.timeMs>1000).map(p=>p.forceN));
assert.ok(newStd<rawStd*.6,'Steady-state noise must still be attenuated');
assert.ok(newStd<=oldStd,'Steady-state smoothing should retain or improve noise suppression');
traces.noise={raw:noise,old:oldNoise,current:newNoise};
const spike=Array.from({length:41},(_,i)=>({timeMs:i*50,forceN:i===21?250:100}));
const spikeOut=stream(ForceReadout,spike);assert.ok(spikeOut.every(p=>p.forceN===100),'Isolated spike must be rejected');

const ramp=Array.from({length:61},(_,i)=>({timeMs:i*50,forceN:100+Math.max(0,Math.min(i*50-1000,1000))*.05}));
const oldRamp=stream(PreviousReadout,ramp),newRamp=stream(ForceReadout,ramp);
const rampLag=(shown:Point[])=>{const points=shown.filter(p=>p.timeMs>=1200&&p.timeMs<=2000);return points.reduce((s,p)=>s+100+(p.timeMs-1000)*.05-p.forceN,0)/points.length;};
assert.ok(rampLag(newRamp)<rampLag(oldRamp));
traces.ramp={raw:ramp,old:oldRamp,current:newRamp};

const filter=new ForceReadout(),identity={},r=raw(100);
const first=filter.update('live',identity,r,0,0)!;
assert.equal(first.forceN,100);assert.equal(filter.update('live',identity,r,10,10),null);
assert.equal(filter.update('live',{},raw(150),25,25),null);assert.equal(filter.pendingPublishAt(),50);
assert.equal(filter.flush(49),null);assert.equal(filter.flush(50)!.forceN,100);
assert.ok(filter.update('live',{},raw(150),100,100)!.forceN>147);
const zero={...raw(0),status:'no_contact'};
assert.equal(filter.update('live',{},zero,110,110)!.forceN,0);
assert.equal(filter.update('live',{},raw(80),120,120)!.forceN,80);
assert.equal(filter.update('live',{},raw(65),130,130,false)!.forceN,65);
assert.equal(filter.update('other-source',{},raw(42),140,140)!.forceN,42);
assert.equal(filter.update('other-source',{},raw(60),1800,1800)!.forceN,60);
filter.reset();
const regional={...raw(100),contactPressure:undefined,forceAggregation:'regional_sum' as const,
 regionForcesN:[30,70],regionCenters:[[1,1],[20,20]] as [number,number][]};
filter.update('regional',{},regional,0,0);
const reordered=filter.update('regional',{},{...regional,regionForcesN:[70,30],regionCenters:[[20,20],[1,1]]},50,50)!;
assert.deepEqual(reordered.regionForcesN,[70,30]);
const removed=filter.update('regional',{},{...regional,forceN:30,regionForcesN:[30],regionCenters:[[1,1]]},60,60)!;
assert.deepEqual(removed.regionForcesN,[30]);assert.equal(removed.forceN,30);
const meta=captureForceReadout(removed)!;assert.equal(meta.filterVersion,FORCE_READOUT_VERSION);
assert.equal(meta.mode,'median3-adaptive-ema');assert.equal(meta.publishIntervalMs,50);
assert.equal(forceReadoutExportValues(meta).length,FORCE_READOUT_EXPORT_HEADERS.length);
assert.equal(r.forceN,100);
const result={filterVersion:FORCE_READOUT_VERSION,stepTests,
 steadyNoise:{rawStdN:rawStd,oldStdN:oldStd,newStdN:newStd},
 rampMeanLagN:{old:rampLag(oldRamp),current:rampLag(newRamp)},
 singleSpikeRejected:true,zeroUnloadImmediate:true,sourceAndGapReset:true,regionalTrackingPassed:true,
 pressureAndForceStayAligned:true,rawFrameUnchanged:true,exportMetadataPassed:true,
 scope:'Synthetic dynamics validation; not a hardware response or calibration accuracy acceptance'};
fs.writeFileSync(path.join(audit,'filter-dynamics-result.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(audit,'filter-dynamics-traces.json'),JSON.stringify(traces));
console.log(JSON.stringify(result,null,2));

