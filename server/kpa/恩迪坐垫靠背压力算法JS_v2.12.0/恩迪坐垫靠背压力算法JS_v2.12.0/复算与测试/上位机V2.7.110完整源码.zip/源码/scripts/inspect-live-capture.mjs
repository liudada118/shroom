import fs from 'node:fs';
import path from 'node:path';
import XLSX from 'xlsx-js-style';
const dir=process.argv[2];
for(const file of fs.readdirSync(dir).filter(f=>f.endsWith('.xlsx'))){
 const w=XLSX.readFile(path.join(dir,file));
 console.log(file,JSON.stringify(w.SheetNames.map(name=>{
  const s=w.Sheets[name],r=XLSX.utils.sheet_to_json(s,{header:1,raw:true,defval:''});
  return {name,range:s['!ref'],start:r.slice(0,5).map(v=>v.slice(0,12)),
   detailSections:r.map((row,i)=>({i,label:row[0]})).filter(v=>typeof v.label==='string'&&
    /原始字节|插值前原始物理矩阵|补偿前插值|连续采集帧|采集时间/.test(v.label)).slice(0,15)};
 })));
}
