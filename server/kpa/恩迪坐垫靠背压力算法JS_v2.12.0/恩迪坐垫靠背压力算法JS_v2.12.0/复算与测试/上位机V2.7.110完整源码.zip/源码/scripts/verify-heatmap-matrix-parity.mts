import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {build} from 'esbuild';
import {heatmapCellIndex,heatmapCellValue,orientCaptureMatrix,physicalCellInRotatedMatrix,rotatedMatrixCellToPhysical,rotatedPhysicalSize} from '../client/src/lib/captureOrientation';
import {valueToColor} from '../client/src/lib/colorMap';

const out=process.argv[2];assert.ok(out,'Pass audit directory');
const source=path.resolve('client/src/components/Heatmap.tsx');
const shim=`
const h=()=>globalThis.__heatmapParity;
export const useCallback=f=>f;
export function useEffect(f){h().effects.push(f);}
export function useRef(initial){const g=h(),i=g.refIndex++;if(!g.refs[i])g.refs[i]={current:i===0?g.canvas:initial};return g.refs[i];}
export function useState(initial){const g=h(),i=g.stateIndex++;if(!(i in g.states))g.states[i]=typeof initial==='function'?initial():initial;return [g.states[i],v=>{g.states[i]=typeof v==='function'?v(g.states[i]):v;}];}
`;
const compiled=await build({entryPoints:[source],bundle:true,write:false,format:'esm',platform:'node',jsx:'automatic',plugins:[{
 name:'heatmap-harness',setup(b){
  b.onResolve({filter:/^react(?:\/jsx-runtime)?$/},args=>({path:args.path,namespace:'test-react'}));
  b.onLoad({filter:/.*/,namespace:'test-react'},args=>({contents:args.path==='react'?shim:`export const jsx=(type,props)=>({type,props});export const jsxs=jsx;export const Fragment='fragment';`,loader:'js'}));
  b.onResolve({filter:/^@\//},args=>({path:path.resolve('client/src',args.path.slice(2)+'.ts')}));
 }
}]});
const {default:Heatmap}=await import('data:text/javascript;base64,'+Buffer.from(compiled.outputFiles[0].contents).toString('base64'));

function harness(){
 const calls:any[]=[],ctx:any={fillStyle:'',strokeStyle:'',imageSmoothingEnabled:true};
 for(const method of ['fillRect','strokeRect','strokeText','fillText','beginPath','moveTo','lineTo','stroke','setLineDash','quadraticCurveTo','closePath','fill','save','restore']){
  ctx[method]=(...args:any[])=>calls.push({method,args,fillStyle:ctx.fillStyle});
 }
 ctx.measureText=(text:string)=>({width:text.length*6});
 const canvas={width:768,height:768,getContext:()=>ctx,getBoundingClientRect:()=>({left:0,top:0,width:canvas.width,height:canvas.height})};
 return {states:[] as any[],refs:[] as any[],stateIndex:0,refIndex:0,effects:[] as any[],canvas,ctx,calls};
}
function render(g:any,props:any){
 (globalThis as any).__heatmapParity=g;g.stateIndex=0;g.refIndex=0;g.effects=[];g.calls.length=0;
 const tree=Heatmap(props);g.effects.forEach((f:any)=>f());
 const child=Array.isArray(tree.props.children)?tree.props.children[0]:tree.props.children;
 assert.equal(child.type,'canvas');assert.equal(child.props.style.imageRendering,'pixelated');
 assert.equal(g.ctx.imageSmoothingEnabled,false);
 return child.props;
}
function pixelEvent(g:any,sr:number,sc:number,rows:number,cols:number){return {clientX:(sc+.5)*g.canvas.width/cols,clientY:(sr+.5)*g.canvas.height/rows};}
function frame(matrix:number[][]){return {matrix,raw:new Uint8Array(),timestamp:1,max:255,min:0,avg:0,nonZeroMin:0,sum:0,nonZeroCount:0};}

const matrix=[[0,25.125,100],[0.875,50.5,255]],mask=[[true,true,false],[true,true,true]];
const original=JSON.stringify(matrix),tests:any[]=[];
for(const sensorType of ['endi-23x23','new-backrest-32x25']){
 const g=harness(),hovers:any[]=[],p={data:frame(matrix),showValues:true,sensorType,validMask:mask,filterThreshold:30,matrixIsFiltered:true,onCellHover:(...args:any[])=>hovers.push(args)};
 const canvas=render(g,p);const captured=orientCaptureMatrix(matrix,sensorType);
 for(let sr=0;sr<matrix.length;sr++)for(let sc=0;sc<matrix[0].length;sc++){
  const cell=heatmapCellIndex(sr,sc,matrix.length,matrix[0].length,sensorType)!;
  const back=heatmapCellIndex(cell.row,cell.col,matrix.length,matrix[0].length,sensorType)!;
  assert.deepEqual(back,{row:sr,col:sc});
  const expected=heatmapCellValue(matrix,cell.row,cell.col,mask),event=pixelEvent(g,sr,sc,matrix.length,matrix[0].length);
  const count=hovers.length;canvas.onMouseMove(event);
  if(expected===null){assert.equal(hovers.length,count);continue;}
  assert.deepEqual(hovers.at(-1),[cell.row,cell.col,expected]);
  assert.equal(captured[sr][sc],expected,'Saved heatmap matrix uses exactly the visible value');
  const x=(sc+.5)*g.canvas.width/matrix[0].length,y=(sr+.5)*g.canvas.height/matrix.length;
  assert.ok(g.calls.some((c:any)=>c.method==='fillText'&&c.args[0]===String(expected)&&Math.abs(c.args[1]-x)<1e-8&&Math.abs(c.args[2]-y)<1e-8),'Displayed numbers are exact at their visible cell');
  const rgb=valueToColor(expected),color=`rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
  assert.ok(g.calls.some((c:any)=>c.method==='fillRect'&&c.fillStyle===color&&Math.abs(c.args[0]-sc*g.canvas.width/matrix[0].length)<1e-8&&Math.abs(c.args[1]-sr*g.canvas.height/matrix.length)<1e-8),'Cell color uses the same input value');
 }
 // Outside the actual canvas image cannot wrap into the opposite edge.
 const count=hovers.length;canvas.onMouseMove({clientX:-1,clientY:5});assert.equal(hovers.length,count);
 const stats=render(g,{...p,areaSelection:{startRow:0,startCol:0,endRow:1,endCol:2}});
 const texts=g.calls.filter((c:any)=>c.method==='fillText').map((c:any)=>c.args[0]);
 assert.ok(texts.some((text:string)=>text.includes('有效:4')&&text.includes('最大:255')),'Selection excludes masked cell consistently');
 const manual=harness(),selections:Set<string>[]=[];
 let events=render(manual,{...p,manualSelectMode:true,onManualSelect:(s:Set<string>)=>selections.push(s)});
 const startCol=sensorType==='endi-23x23'?0:2,endCol=sensorType==='endi-23x23'?2:0;
 events.onMouseDown(pixelEvent(manual,0,startCol,2,3));events.onMouseMove(pixelEvent(manual,1,endCol,2,3));
 events=render(manual,{...p,manualSelectMode:true,onManualSelect:(s:Set<string>)=>selections.push(s)});events.onMouseUp({});
 assert.equal(selections.length,1);assert.equal(selections[0].size,5);assert.equal(selections[0].has('0,2'),false);
 tests.push({sensorType,matrixCells:6,validCells:5,maskedCells:1,zeroVisible:true,belowLegacyThresholdVisible:true,hoverAndColorAndCaptureExact:true,manualMaskRespected:true});
}

const pressure=[[.025,.375],[1.125,2.875]],pg=harness(),ph:any[]=[];
const pp=render(pg,{data:frame(pressure),showValues:true,sensorType:'endi-23x23',colorMax:3,valueFormatter:(v:number)=>v.toFixed(3),valueUnit:'kPa',onCellHover:(...a:any[])=>ph.push(a)});
pp.onMouseMove(pixelEvent(pg,0,0,2,2));assert.deepEqual(ph.at(-1),[1,1,2.875]);
assert.ok(pg.calls.some((c:any)=>c.method==='fillText'&&c.args[0]==='2.875'));
const legacy=harness(),legacyHover:any[]=[];
const legacyCanvas=render(legacy,{data:frame([[25,31]]),showValues:true,filterThreshold:30,onCellHover:(...args:any[])=>legacyHover.push(args)});
legacyCanvas.onMouseMove(pixelEvent(legacy,0,0,1,2));assert.equal(legacyHover.length,0);
legacyCanvas.onMouseMove(pixelEvent(legacy,0,1,1,2));assert.deepEqual(legacyHover.at(-1),[0,1,31]);

function rotate(input:number[][],turns:number){let output=input.map(r=>[...r]);for(let i=0;i<turns;i++){const next=Array.from({length:output[0].length},()=>Array(output.length).fill(0));output.forEach((row,r)=>row.forEach((value,c)=>{next[c][output.length-1-r]=value;}));output=next;}return output;}
const rotationCases:any[]=[];
for(const [physicalRows,physicalCols] of [[3,4],[23,23],[25,32]])for(let rotation=0;rotation<4;rotation++){
 const native=Array.from({length:physicalRows},(_,r)=>Array.from({length:physicalCols},(_,c)=>1+r*physicalCols+c+.125));
 const expanded=Array.from({length:physicalRows*2},(_,r)=>Array.from({length:physicalCols*2},(_,c)=>r%2===0&&c%2===0?native[r/2][c/2]:.25));
 const physical=rotate(native,rotation),interpolated=rotate(expanded,rotation),size=rotatedPhysicalSize(physicalRows,physicalCols,rotation);
 assert.deepEqual(size,{rows:physical.length,cols:physical[0].length});
 for(let pr=0;pr<size.rows;pr++)for(let pc=0;pc<size.cols;pc++){
  const cell=physicalCellInRotatedMatrix(pr,pc,rotation);assert.equal(interpolated[cell.row][cell.col],physical[pr][pc]);
  assert.deepEqual(rotatedMatrixCellToPhysical(cell.row,cell.col,rotation),{pr,pc});
  assert.equal(rotatedMatrixCellToPhysical(cell.row+(cell.row%2===0?1:-1),cell.col,rotation),null);
 }
 for(const sensorType of ['endi-23x23','new-backrest-32x25']){
  const g=harness(),physicalHovers:any[]=[],props={data:frame(interpolated),showValues:false,sensorType,matrixIsFiltered:true,matrixRotation:rotation,physicalRows,physicalCols,showOriginalPoints:true,onPhysicalHover:(...args:any[])=>physicalHovers.push(args)};
  const events=render(g,props);
  for(const [pr,pc] of [[0,0],[size.rows-1,size.cols-1],[Math.floor(size.rows/2),Math.floor(size.cols/2)]]){
   const point=physicalCellInRotatedMatrix(pr,pc,rotation),screen=heatmapCellIndex(point.row,point.col,interpolated.length,interpolated[0].length,sensorType)!;
   events.onMouseMove(pixelEvent(g,screen.row,screen.col,interpolated.length,interpolated[0].length));
   assert.deepEqual(physicalHovers.at(-1),[pr,pc,physical[pr][pc]]);
   const x=screen.col*g.canvas.width/interpolated[0].length,y=screen.row*g.canvas.height/interpolated.length;
   assert.ok(g.calls.some((c:any)=>c.method==='strokeRect'&&Math.abs(c.args[0]-x-.75)<1e-8&&Math.abs(c.args[1]-y-.75)<1e-8),'Original point overlay is in the same displayed cell');
  }
 }
 rotationCases.push({physicalRows,physicalCols,rotation,physicalPanelMatchesInterpolatedSamples:true,forwardInverseExact:true,overlayAndHoverExact:true});
}
assert.equal(heatmapCellValue([[NaN,Infinity]],0,0),null);assert.equal(heatmapCellValue([[NaN,Infinity]],0,1),null);
assert.equal(heatmapCellValue(matrix,-1,0),null);assert.equal(heatmapCellIndex(2,0,2,3,'endi-23x23'),null);
assert.equal(JSON.stringify(matrix),original,'Drawing/hover/export orientation do not mutate source matrix');
const copied=orientCaptureMatrix(matrix,'endi-23x23');copied[0][0]=-999;assert.equal(JSON.stringify(matrix),original);
const result={tests,rotationCases,pressureDecimalsPreserved:true,nonfiniteCellsExcluded:true,sourceMatrixUnchanged:true,legacyThresholdCompatible:true,
 thresholdHandledUpstreamOnly:true,canvasImageSmoothingDisabled:true,cssPixelRendering:true,
 scope:'Component canvas/numbers/hover/selection/orientation software consistency, not sensor calibration precision'};
fs.writeFileSync(path.join(out,'heatmap-matrix-parity-result.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
