import assert from "node:assert/strict";
import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import XLSX from "xlsx-js-style";
import { exportToXlsx } from "../client/src/lib/xlsxExport";
import type { FittingExportFrame } from "../client/src/lib/fittingExportData";

type TestFrame = FittingExportFrame & Record<string, any>;
const outputDir = process.argv[2] ?? resolve(import.meta.dirname, "fitting-xlsx-verification");
mkdirSync(outputDir, { recursive: true });
const original = {
  document: globalThis.document,
  createObjectURL: URL.createObjectURL,
  revokeObjectURL: URL.revokeObjectURL,
};
let outputBlob: Blob | undefined;
let clicked = 0;
let revoked = 0;
const anchor = { href: "", download: "", click: () => { clicked += 1; } };
globalThis.document = {
  createElement: () => anchor,
  body: { appendChild() {}, removeChild() {} },
} as unknown as Document;
URL.createObjectURL = (blob: Blob) => { outputBlob = blob; return "blob:fitting-xlsx-test"; };
URL.revokeObjectURL = () => { revoked += 1; };

const expectedHeaders = [
  "帧序号", "采集类型", "连续帧序号", "采集时间（ISO）", "采集时间戳（ms）", "数据源帧时间戳（ms）",
  "传感器型号", "传感器名称", "矩阵旋转（四分之一圈）", "矩阵行序", "矩阵列序",
  "原始字节长度", "原始物理矩阵尺寸", "补偿前插值矩阵尺寸", "原始数据完整性",
  "实际总质量（kg）", "砝码数量", "单块砝码质量（kg）", "摆放方式（叠放/平铺）",
  "接触底面数量", "接触底面直径（cm）", "参考接触面积（cm²）", "放置位置",
  "操作阶段（加载/卸载/重新放置）", "采集状态（稳定/移动/异常）", "备注",
];
const baseSheetNames = ["帧信息与标注", "原始字节", "原始物理ADC", "原始插值ADC"];
const forbiddenValue = 978654321.125;
const forbiddenText = "DO_NOT_EXPORT_PREDICTION";
const config = { name: "测试坐垫", matrixSize: 46, totalPoints: 2116, filterThreshold: 12345, resultScale: 56789 };

function makeFrame(id: number, continuous = true, large = false): TestFrame {
  const physicalRows = large ? 23 : 3 + id % 2;
  const physicalCols = large ? 23 : 4;
  const matrix = (rows: number, columns: number, divisor: number) => Array.from({ length: rows }, (_, r) => (
    Array.from({ length: columns }, (_, c) => ((r * columns + c + id) % 251) / divisor)
  ));
  return {
    id,
    captureKind: continuous ? "continuous" : "standard",
    ...(continuous ? { continuousSequence: id } : {}),
    capturedAt: new Date(1793280000000 + id),
    sensorType: id % 2 ? "endi-23x23" : "new-backrest-32x25",
    data: {
      timestamp: 1793279999123, // The same millisecond must not merge distinct frames.
      raw: Array.from({ length: large ? 1024 : 300 }, (_, index) => (index + id) % 256),
      physical: matrix(physicalRows, physicalCols, 1),
      sourceMatrix: matrix(physicalRows * 2, physicalCols * 2, 16),
      matrix: [[forbiddenValue]], heatmapMatrix: [[forbiddenValue]],
      max: forbiddenValue, min: forbiddenValue, avg: forbiddenValue,
      sum: forbiddenValue, nonZeroCount: forbiddenValue, nonZeroMin: forbiddenValue,
    },
    captureConfig: {
      matrixRotation: id % 4,
      matrixRowOrder: "heatmap-top-to-bottom-v1",
      matrixColumnOrder: "heatmap-left-to-right-v2",
      filterThreshold: forbiddenValue, resultScale: forbiddenValue,
      heatmapValueMode: "pressure", heatmapValueUnit: "kPa",
      adcCompensation: { enabled: true, scale: forbiddenValue, offset: forbiddenValue, fingerprint: forbiddenText },
    },
    filteredStats: { filteredMatrix: [[forbiddenValue]], max: forbiddenValue },
    forceMetrics: { forceN: forbiddenValue, modelVersion: forbiddenText, accepted: true },
    areaMetrics: { areaCm2: forbiddenValue, algorithmLabel: forbiddenText },
    forceDisplayMetrics: { forceN: forbiddenValue },
    avgPressureKPa: forbiddenValue, humanCoefficient: forbiddenValue,
    groundTruth: { actualTotalMassKg: forbiddenValue, notes: forbiddenText },
  };
}

const rowsIn = (workbook: XLSX.WorkBook, name: string) => workbook.SheetNames
  .filter(sheet => sheet === name || sheet.startsWith(`${name}_`))
  .flatMap(sheet => (XLSX.utils.sheet_to_json(workbook.Sheets[sheet], {
    header: 1, raw: true, defval: "",
  }) as any[][]).slice(1));

function verifyWorkbook(workbook: XLSX.WorkBook, expected: TestFrame[], rowLimit?: number): void {
  if (rowLimit === undefined) assert.deepEqual(workbook.SheetNames, baseSheetNames);
  for (const name of workbook.SheetNames) {
    assert(baseSheetNames.some(base => name === base || name.startsWith(`${base}_`)), `Unexpected sheet ${name}`);
    const range = XLSX.utils.decode_range(workbook.Sheets[name]["!ref"]!);
    if (rowLimit !== undefined) assert(range.e.r + 1 <= rowLimit, `${name} exceeds row limit`);
    const cells = Object.entries(workbook.Sheets[name]).filter(([key]) => !key.startsWith("!"));
    for (const [key, value] of cells) {
      assert.notEqual(value.v, forbiddenValue, `${name}!${key}: derived number leaked`);
      assert(!String(value.v).includes(forbiddenText), `${name}!${key}: derived text leaked`);
      assert.equal(value.f, undefined, `${name}!${key}: unexpected formula`);
    }
  }
  const firstMetadata = XLSX.utils.sheet_to_json(workbook.Sheets["帧信息与标注"], {
    header: 1, raw: true, defval: "",
  }) as any[][];
  assert.deepEqual(firstMetadata[0], expectedHeaders);
  const metadata = rowsIn(workbook, "帧信息与标注");
  assert.deepEqual(metadata.map(row => row[0]), expected.map(frame => frame.id));
  const rawRows = rowsIn(workbook, "原始字节");
  const physicalRows = rowsIn(workbook, "原始物理ADC");
  const sourceRows = rowsIn(workbook, "原始插值ADC");
  expected.forEach((frame, index) => {
    const metadataRow = metadata[index];
    assert.equal(metadataRow.length, 26);
    assert.deepEqual(metadataRow.slice(15), Array(11).fill(""), "Labels must remain blank");
    assert.equal(metadataRow[1], frame.captureKind);
    assert.equal(metadataRow[2], frame.continuousSequence ?? "");
    assert.equal(metadataRow[3], frame.capturedAt.toISOString());
    assert.equal(metadataRow[4], frame.capturedAt.getTime());
    assert.equal(metadataRow[5], frame.data.timestamp);
    assert.equal(metadataRow[6], frame.sensorType);
    assert.equal(metadataRow[7], frame.sensorType === "endi-23x23" ? "坐垫（恩迪23×23）" : "靠背（32×25）");
    assert.equal(metadataRow[8], frame.captureConfig!.matrixRotation);
    assert.equal(metadataRow[9], "heatmap-top-to-bottom-v1");
    assert.equal(metadataRow[10], "heatmap-left-to-right-v2");
    assert.equal(metadataRow[11], frame.data.raw?.length ?? 0);
    for (const [field, values, sizeColumn] of [
      ["physical", physicalRows, 12], ["sourceMatrix", sourceRows, 13],
    ] as const) {
      const matrix = frame.data[field];
      const frameRows = values.filter(row => row[0] === frame.id);
      if (!matrix?.length) {
        assert.equal(metadataRow[sizeColumn], "未保存");
        assert.equal(frameRows.length, 1);
        assert.match(frameRows[0][1], /未保存/);
        assert(frameRows[0].slice(2).every(value => value === ""));
      } else {
        assert.equal(metadataRow[sizeColumn], `${matrix.length}×${matrix[0].length}`);
        assert.equal(frameRows.length, matrix.length);
        frameRows.forEach((row, r) => {
          assert.equal(row[1], `R${r}`);
          assert.deepEqual(row.slice(2, matrix[r].length + 2), matrix[r]);
          assert(row.slice(matrix[r].length + 2).every(value => value === ""));
        });
      }
    }
    const bytes = rawRows.filter(row => row[0] === frame.id);
    if (!frame.data.raw?.length) {
      assert.equal(bytes.length, 1);
      assert.match(bytes[0][1], /未保存/);
      assert.match(metadataRow[14], /未保存/);
    } else {
      const reconstructed: number[] = [];
      bytes.forEach((row, chunk) => {
        assert.equal(row[1], chunk * 32);
        reconstructed.push(...row.slice(2).filter(value => value !== ""));
      });
      assert.deepEqual(reconstructed, frame.data.raw);
    }
  });
}

async function runCase(name: string, standard: TestFrame[], continuous: TestFrame[], rowLimit?: number) {
  const before = JSON.stringify({ standard, continuous });
  outputBlob = undefined;
  const progress: number[] = [];
  await exportToXlsx(standard, config, ["max", "sum", "avgPressure"], value => progress.push(value), false, {
    continuousFrames: continuous, worksheetRowLimit: rowLimit,
  });
  assert(outputBlob, `${name}: no downloaded file`);
  const bytes = new Uint8Array(await outputBlob.arrayBuffer());
  assert.equal(bytes[0], 0x50);
  assert.equal(bytes[1], 0x4b);
  const zipFirstMethod = new DataView(bytes.buffer).getUint16(8, true);
  assert.equal(zipFirstMethod, 8, "ZIP must use lossless DEFLATE compression");
  const workbook = XLSX.read(bytes, { type: "array", cellFormula: true });
  const seen = new Set<number>();
  const expected = [...standard, ...continuous].sort((a, b) => a.id - b.id).filter(frame => {
    if (seen.has(frame.id)) return false;
    seen.add(frame.id);
    return true;
  });
  verifyWorkbook(workbook, expected, rowLimit);
  assert.equal(JSON.stringify({ standard, continuous }), before, `${name}: input mutated`);
  assert.deepEqual(progress, [20, 40, 60, 80, 100]);
  writeFileSync(resolve(outputDir, `xlsx-${name}.xlsx`), bytes);
  return { name, frames: expected.length, sheets: workbook.SheetNames, bytes: bytes.length, rowLimit: rowLimit ?? 1048576 };
}

try {
  const continuous = Array.from({ length: 10 }, (_, index) => makeFrame(10 - index, true, true));
  // Decimal interpolation is exported unchanged, including valid zero.
  continuous[0].data.sourceMatrix![0][0] = 0.12345678901234566;
  continuous[0].data.sourceMatrix![0][1] = 0;
  const ten = await runCase("10-continuous", [], continuous);
  const duplicate = makeFrame(5, true);
  duplicate.data.raw![0] = 222;
  const legacy = makeFrame(13, false);
  legacy.data = { matrix: [[forbiddenValue]], timestamp: 1793279999123 } as any;
  const mixed = await runCase("mixed-and-missing", [makeFrame(12, false), makeFrame(5, false), legacy], [...continuous, duplicate]);
  const split = await runCase("split-mid-frame", [makeFrame(21, false)], [makeFrame(22)], 8);
  assert(split.sheets.some(name => name.startsWith("原始字节_")));
  assert(split.sheets.some(name => name.startsWith("原始插值ADC_")));
  const splitMetadata = await runCase("split-metadata", [], Array.from({ length: 10 }, (_, index) => makeFrame(index + 30)), 8);
  assert(splitMetadata.sheets.includes("帧信息与标注_2"));
  await assert.rejects(exportToXlsx([makeFrame(1)], config, [], undefined, true, { worksheetRowLimit: 7 }), RangeError);
  outputBlob = undefined;
  await exportToXlsx([], config, []);
  assert.equal(outputBlob, undefined);
  assert.equal(clicked, 4);
  assert.equal(revoked, 4);
  const result = {
    passed: true, version: "V2.7.84", cases: [ten, mixed, split, splitMetadata],
    checks: ["four minimal worksheets", "10 continuous frames", "mixed sorted deduplicated frames", "same-ms frames retained", "blank ground truth", "all raw bytes and ADC values preserved", "no processed/model/display data or formulas", "missing raw data explicit without fallback", "lossless ZIP compression", "mid-frame splitting retains frame id and original offset/row", "metadata continuation headers", "no source mutation", "legacy argument compatibility", "download cleanup and progress"],
  };
  writeFileSync(resolve(outputDir, "xlsx-verification-result.json"), JSON.stringify(result, null, 2), "utf8");
  console.log(JSON.stringify(result));
} finally {
  globalThis.document = original.document;
  URL.createObjectURL = original.createObjectURL;
  URL.revokeObjectURL = original.revokeObjectURL;
}
