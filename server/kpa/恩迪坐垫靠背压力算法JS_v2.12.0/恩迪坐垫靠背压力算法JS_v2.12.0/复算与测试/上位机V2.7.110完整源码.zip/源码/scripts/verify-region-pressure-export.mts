import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import XLSX from "xlsx-js-style";
import { exportToXlsx } from "../client/src/lib/xlsxExport";

const audit=process.argv[2];assert.ok(audit);
const wire=JSON.parse(fs.readFileSync(path.join(audit,"browser-wire-fixtures.json"),"utf8"));
const browser=JSON.parse(fs.readFileSync(path.join(audit,"browser-runtime-result.json"),"utf8"));
function checkRows(rows:any[][],meanLabel:string){
  const start=rows.findIndex(r=>r.includes("各区压强算术平均（kPa）"));
  assert.ok(start>=0,"Region export headers exist");
  const header=rows[start];assert.equal(new Set(header).size,header.length,"Unique headers");
  for(let i=0;i<wire.length;i++){
    const row=rows[start+1+i],p=wire[i].contactPressure;
    const get=(label:string)=>{const col=header.indexOf(label);assert.ok(col>=0,label);return row[col];};
    const close=(a:number,b:number)=>assert.ok(Math.abs(Number(a)-b)<1e-9,`${a} != ${b}`);
    close(get("总压力候选（N）"),wire[i].forceN);
    close(get("接触面积（cm²）"),wire[i].expectedAreaCm2);
    close(get(meanLabel),Number(p.averagePressureKPa.toFixed(2)));
    close(get("各区压强算术平均（kPa）"),p.averagePressureKPa);
    close(get("显示接触区平均压强（kPa）"),p.averagePressureKPa);
    assert.equal(String(get("各区估算力（N）")),p.regions.map((r:any)=>r.estimatedForceN).join(";"));
    assert.equal(String(get("各区原面积（cm²）")),p.regions.map((r:any)=>r.areaCm2).join(";"));
    assert.equal(String(get("各区原始ADC总和")),p.regions.map((r:any)=>r.rawAdcSum).join(";"));
    assert.equal(String(get("各区估算压强（kPa）")),p.regions.map((r:any)=>r.estimatedPressureKPa).join(";"));
    assert.equal(get("接触区压强算法版本"),p.version);
    assert.equal(get("区域力分配方法"),"原始物理ADC总和占比");
    assert.equal(get("区域压强独立验收"),"未通过独立标定验收（ADC比例估算）");
  }
}
const rows=(book:any,name:string)=>XLSX.utils.sheet_to_json(book.Sheets[name],{header:1,raw:true,defval:""}) as any[][];
const csv=XLSX.read(fs.readFileSync(path.join(audit,"浏览器实际导出.csv"),"utf8"),{type:"string",raw:true});
checkRows(rows(csv,csv.SheetNames[0]),"平均压强（KPa）");
const actual=XLSX.read(fs.readFileSync(path.join(audit,"浏览器实际导出.xlsx")),{type:"buffer"});
checkRows(rows(actual,"统计摘要"),"平均压强（KPa）");

// Exercise the same export implementation with complete captured standard/continuous frames.
let blob:Blob|null=null;
const anchor={href:"",download:"",click:()=>{}};
globalThis.document={createElement:()=>anchor,body:{appendChild:()=>anchor,removeChild:()=>anchor}} as unknown as Document;
URL.createObjectURL=(value:Blob)=>{blob=value;return "blob:audit";}; URL.revokeObjectURL=()=>{};
const captures=browser.captured.map((r:any)=>({...r.capture,capturedAt:new Date(r.capture.capturedAt)}));
await exportToXlsx(captures,{name:"区域压强接入验证",matrixSize:64,totalPoints:3200,filterThreshold:30,resultScale:1},
  ["avgPressure","maxPressure","max","avg","sum","nonZeroCount"],undefined,false,
  {continuousFrames:captures.map((f:any,i:number)=>({...f,id:f.id+100,continuousSequence:i+1,captureKind:"continuous"}))});
assert.ok(blob);
const bytes=new Uint8Array(await (blob as Blob).arrayBuffer());
const book=XLSX.read(bytes,{type:"array"});
checkRows(rows(book,"统计摘要"),"平均压强（KPa）");
checkRows(rows(book,"连续采集数据"),"采集平均压强（kPa）");
fs.writeFileSync(path.join(audit,"标准与连续采集区域压强验证.xlsx"),bytes);
const result={actualBrowserCsvFrames:wire.length,actualBrowserXlsxFrames:wire.length,standardFrames:wire.length,continuousFrames:wire.length,
  areaForceAndRegionMeanMatch:true,regionBreakdownAndDisplaySnapshotsMatch:true,rawCaptureMetadataRetained:true};
fs.writeFileSync(path.join(audit,"export-verification.json"),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
