import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import XLSX from 'xlsx-js-style';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {analyzeSeatForce} from '../client/src/lib/seatForce';
import {applyFilter} from '../client/src/lib/dataFilter';

const [root,out]=process.argv.slice(2);assert.ok(root&&out);fs.mkdirSync(out,{recursive:true});
const context:any={};vm.runInNewContext(fs.readFileSync('client/public/dummyArea_v2.10.36.js','utf8'),context);
const areaApi=context.DummyAreaV21036;
const config=getSensorConfig('endi-23x23');
const counts:any={'一':1,'两':2,'二':2,'三':3,'四':4,'五':5,'六':6};
const list=(dir:string):string[]=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?list(path.join(dir,e.name)):/\.(csv|xlsx)$/i.test(e.name)?[path.join(dir,e.name)]:[]);
const rotate=(m:number[][])=>m[0].map((_,c)=>m.map(row=>row[c]).reverse());
const orientations=(m:number[][])=>{const a:any[]=[];let r=m;for(let k=0;k<4;k++){a.push({name:`rotate${90*k}`,matrix:r});a.push({name:`rotate${90*k}-mirrorColumns`,matrix:r.map(row=>[...row].reverse())});r=rotate(r);}return a;};
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const hash=(v:any)=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
function csvRows(text:string):any[][]{
 return text.replace(/^\uFEFF/,'').split(/\r?\n/).map(line=>{
  line=line.replace(/(?<=,)\((\d+),\s*(\d+)\)(?=,)/g,'"($1, $2)"');
  const values:string[]=[];let current='',quoted=false;
  for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(quoted&&line[i+1]==='"'){current+='"';i++;}else quoted=!quoted;}else if(c===','&&!quoted){values.push(current);current='';}else current+=c;}
  values.push(current);return values;
 });
}
function matrixAt(rows:any[][],prefix:string,size:number,start:number,end:number){
 const n=rows.findIndex((r,i)=>i>=start&&i<end&&typeof r[0]==='string'&&r[0].startsWith(prefix));
 if(n<0)return null;
 const matrix=rows.slice(n+2,n+2+size).map(row=>row.slice(1,size+1).map(Number));
 assert.ok(matrix.length===size&&matrix.every(r=>r.length===size&&r.every(Number.isFinite)),prefix);
 return matrix;
}
const frames:any[]=[],files:any[]=[];
for(const full of list(root).sort()){
 const relative=path.relative(root,full);let rows:any[][],headerIndex:number;
 if(full.endsWith('.xlsx')){
  const book=XLSX.readFile(full,{cellDates:false});
  const sheet=book.Sheets['连续采集数据']??book.Sheets['统计摘要'];assert.ok(sheet,relative);
  rows=XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:''}) as any[][];
  headerIndex=rows.findIndex(r=>r.includes('采集时间')&&(r.includes('内部帧序号')||r.includes('帧序号')));
 }else{rows=csvRows(fs.readFileSync(full,'utf8'));headerIndex=rows.findIndex(r=>r[0]==='采集时间');}
 assert.ok(headerIndex>=0,relative);
 const h=rows[headerIndex],summaries:any[]=[];
 for(let i=headerIndex+1;i<rows.length&&rows[i][0]&&String(rows[i][0]).match(/^\d{4}\//);i++){
  assert.equal(rows[i].length,h.length,`${relative} summary columns`);
  summaries.push(Object.fromEntries(h.map((k,j)=>[k,rows[i][j]])));
 }
 const begins=rows.flatMap((r,i)=>typeof r[0]==='string'&&/^(?:--- )?(?:标准采集帧|连续采集帧|连续帧) #/.test(r[0])?[i]:[]);
 assert.equal(begins.length,summaries.length,`${relative} detail count`);
 const variable=relative.includes('从1.625kg到16.5kg');
 if(variable)assert.ok(summaries.length===7||(relative.endsWith('sensor_capture_2026-10-27T14-07-20.csv')&&summaries.length===8),`${relative} confirmed seven loads plus unresolved extra frame`);
 const countMatch=relative.match(/([一二两三四五六1-6])个砝码/);
 const count=countMatch?(counts[countMatch[1]]??Number(countMatch[1])):null;
 assert.ok(variable||relative.includes('重16.5kg')||count,`Missing weight ${relative}`);
 for(let i=0;i<summaries.length;i++){
  const meta=summaries[i],start=begins[i],end=begins[i+1]??rows.length;
  const rawStart=rows.findIndex((r,j)=>j>=start&&j<end&&String(r[0]).startsWith('原始字节（'));
  assert.ok(rawStart>=0,`${relative} original bytes`);
  const raw=Array(1024).fill(-1);
  for(let j=rawStart+2;j<rawStart+34;j++){const offset=Number(rows[j][0]);assert.ok(Number.isInteger(offset));for(let k=0;k<32;k++)raw[offset+k]=Number(rows[j][k+1]);}
  assert.ok(raw.every(v=>Number.isInteger(v)&&v>=0&&v<=255),`${relative} ADC bytes`);
  const physical=Array.from({length:23},(_,r)=>Array.from({length:23},(_,c)=>raw[config.wireMap[r*23+c]]));
  const source=lineInterp2x2(physical,23,23);
  const savedPhysical=matrixAt(rows,'插值前原始物理矩阵',23,start,end);assert.ok(savedPhysical);
  const orientation=orientations(physical).find(o=>same(o.matrix,savedPhysical));assert.ok(orientation,`${relative} physical/wire mapping`);
  const savedSource=matrixAt(rows,'ADC补偿前插值矩阵',46,start,end);
  if(savedSource)assert.ok(orientations(source).some(o=>same(o.matrix,savedSource)),`${relative} source/wire mapping`);
  const savedDisplay=matrixAt(rows,'补偿后显示矩阵',46,start,end);
  assert.equal(physical.flat().reduce((s,v)=>s+v,0),Number(meta['原始物理ADC总和']));
  const areaInput=savedDisplay??savedSource??source;
  const filtered=applyFilter(areaInput,{threshold:30,calibrationMode:'none',resultScale:1}).filteredMatrix;
  const area=areaApi.calculateDummyDisplayedAreaFrame(filtered,null);
  const old=analyzeSeatForce(source,physical);
  const mass=variable?([1.625,3.25,4.875,6.5,8.125,9.75,16.5][i]??null):relative.includes('重16.5kg')?16.5:count*1.625;
  frames.push({file:relative,index:i+1,time:meta['采集时间'],sourceFrame:Number(meta['内部帧序号']??meta['帧序号']),
   mass_kg:mass,referenceForceN:mass===null?null:mass*9.80665,labelBasis:mass===null?'用户确认额外第8帧重量未知，保留但不参与拟合和误差验收':variable?'用户确认7帧依次1至6块1.625kg及16.5kg':'目录块数×1.625kg或明确16.5kg',
   kind:relative.startsWith('多帧采集')?'新增连续实测':variable?'七级加载':relative.includes('平铺')?'平铺':'叠放',
   physical,source,raw,savedPhysicalOrientation:orientation.name,sourceMatchesWire:!!savedSource,
   previousForceN:old.forceN,previousRegionForcesN:old.regionForcesN,previousSeeds:old.regionCenters,
   previousForceErrorN:mass===null?null:old.forceN-mass*9.80665,previousMeanPressureKPa:Number(meta['平均压强（KPa）']),
   savedForceN:typeof meta['总压力候选（N）']==='number'?meta['总压力候选（N）']:null,
   savedAreaCm2:meta['接触面积（cm²）']?Number(meta['接触面积（cm²）']):null,
   areaInput:filtered,baselineArea:area,areaInputHash:hash(filtered),originalMetadata:meta});
 }
 const bytes=fs.readFileSync(full);files.push({file:relative,sha256:createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,frames:summaries.length});
 if(files.length%10===0)console.log(JSON.stringify({processedFiles:files.length,frames:frames.length}));
}
fs.writeFileSync(path.join(out,'坐垫原始ADC与标签.json'),JSON.stringify(frames));
fs.writeFileSync(path.join(out,'原文件校验清单.json'),JSON.stringify({root,files},null,2));
const labelled=frames.filter(r=>r.mass_kg!==null);
const summary={files:files.length,frames:frames.length,labelledFrames:labelled.length,unknownWeightFrames:frames.length-labelled.length,physicalShape:[23,23],rawBytesPerFrame:1024,
 allRawPhysicalSumsMatch:true,wireMappingVerified:true,sourceMatricesVerified:frames.filter(r=>r.sourceMatchesWire).length,
 previousModel:{within5N:labelled.filter(r=>Math.abs(r.previousForceErrorN)<=5).length,maxAbsErrorN:Math.max(...labelled.map(r=>Math.abs(r.previousForceErrorN))),maeN:labelled.reduce((s,r)=>s+Math.abs(r.previousForceErrorN),0)/labelled.length},
 byKind:[...new Set(frames.map(r=>r.kind))].map(kind=>({kind,frames:frames.filter(r=>r.kind===kind).length})),
 byMass:[...new Set(frames.map(r=>r.mass_kg))].sort((a,b)=>a-b).map(mass=>({massKg:mass,frames:frames.filter(r=>r.mass_kg===mass).length})),
 savedPhysicalOrientations:[...new Set(frames.map(r=>r.savedPhysicalOrientation))]};
fs.writeFileSync(path.join(out,'数据核对结果.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
