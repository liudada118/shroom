import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { calculateLiveSensorForce } from "../client/src/lib/sensorForce";
import { analyzeBackrestArea } from "../client/src/lib/backrestArea";
import { extractBackrestForceFeatures, backrestTotalForceModelVersion } from "../client/src/lib/backrestTotalForce";
import { getSensorConfig, lineInterp2x2 } from "../client/src/lib/sensorConfig";

const directory=process.argv[2], output=process.argv[3];
assert.ok(directory&&output,"Pass field data directory and output audit directory");
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(directory,name),"utf8"));
const records=read("新增多重量原始ADC与标签.json");
const references=read("字段补偿候选逐帧对比.json");
const lookup=new Map(references.map((r:any)=>[`${r.file}:${r.index}`,r]));
const hash=(v:unknown)=>createHash("sha256").update(JSON.stringify(v)).digest("hex");
const transpose=(m:number[][])=>m[0].map((_,c)=>m.map(row=>row[c]));
const close=(a:number,b:number,t=1e-8)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const config=getSensorConfig("new-backrest-32x25");
let maxPythonDifferenceN=0;
const results=records.map((f:any)=>{
  const before=hash(f), native=transpose(f.matrix);
  assert.equal(f.raw.length,1024);
  const decoded=Array.from({length:32},(_,r)=>Array.from({length:25},(_,c)=>f.raw[config.wireMap[r*25+c]]));
  assert.deepEqual(decoded,native,"Original serial bytes must decode to the labelled physical ADC");
  assert.deepEqual(lineInterp2x2(native,32,25),f.nativeSource);
  assert.deepEqual(transpose(f.nativeSource),f.source);
  const existingArea=analyzeBackrestArea(f.nativeSource);
  assert.equal(existingArea.areaCm2,f.areaCm2,"Area must match the original capture");
  const predicted=calculateLiveSensorForce("new-backrest-32x25",f.nativeSource,native,existingArea.areaCm2)!;
  const ref:any=lookup.get(`${f.file}:${f.index}`);
  assert.ok(ref);
  close(predicted.forceN,ref.candidateForceN);
  maxPythonDifferenceN=Math.max(maxPythonDifferenceN,Math.abs(predicted.forceN-ref.candidateForceN));
  extractBackrestForceFeatures(f.matrix).forEach((v,i)=>close(v,f.features[i]));
  const errorN=predicted.forceN-f.mass_kg*9.80665;
  assert.ok(Math.abs(errorN)<=5,`${f.file}:${f.index}: ${errorN} N`);
  assert.equal(predicted.modelVersion,backrestTotalForceModelVersion);
  assert.equal(predicted.forceAggregation,"total_only");
  assert.equal(predicted.independentlyValidated,false);
  assert.equal(predicted.accepted,false);
  assert.deepEqual(predicted.regionForcesN,[]);
  const p=predicted.contactPressure!;
  assert.equal(p.areaCm2,f.areaCm2);
  assert.equal(p.rawAdcSum,f.matrix.flat().reduce((s:number,v:number)=>s+v,0));
  close(p.regions.reduce((s,r)=>s+r.estimatedForceN,0),predicted.forceN);
  if(p.status==="estimated")close(p.averagePressureKPa!,p.regions.reduce((s,r)=>s+10*r.estimatedForceN/r.areaCm2,0)/p.regions.length);
  assert.equal(hash(f),before,"Retain original ADC and capture data");
  return {file:f.file,index:f.index,blocks:f.mass_kg/1.625,referenceForceN:f.mass_kg*9.80665,
    previousForceN:f.savedForceN,forceN:predicted.forceN,errorN,areaCm2:f.areaCm2,
    averagePressureKPa:p.averagePressureKPa,contactPressure:p};
});
const byBlocks=[1,2,3,4,5,6].map(blocks=>{
  const rows=results.filter((r:any)=>r.blocks===blocks);
  return {blocks,frames:rows.length,referenceForceN:blocks*1.625*9.80665,within5N:rows.filter((r:any)=>Math.abs(r.errorN)<=5).length,
    forceRangeN:[Math.min(...rows.map((r:any)=>r.forceN)),Math.max(...rows.map((r:any)=>r.forceN))],
    maxAbsErrorN:Math.max(...rows.map((r:any)=>Math.abs(r.errorN)))};
});
assert.equal(results.length,310);
// Include all six field loads in the production serial-stream/browser audit.
const wirePath=path.join(output,"browser-wire-fixtures.json");
const wire=JSON.parse(fs.readFileSync(wirePath,"utf8")).filter((r:any)=>!r.fieldCompensation);
for(const blocks of [1,2,3,4,5,6]){
  const result=results.filter((r:any)=>r.blocks===blocks).sort((a:any,b:any)=>Math.abs(b.previousForceN-b.referenceForceN)-Math.abs(a.previousForceN-a.referenceForceN))[0];
  const f=records.find((f:any)=>f.file===result.file&&f.index===result.index);
  wire.push({file:f.file,index:f.index,massKg:f.mass_kg,forceN:result.forceN,
    expectedAreaCm2:f.areaCm2,packet:[...f.raw,170,85,3,153],contactPressure:result.contactPressure,fieldCompensation:true});
}
fs.writeFileSync(wirePath,JSON.stringify(wire));
const summary={modelVersion:backrestTotalForceModelVersion,frames:results.length,within5N:results.length,
  maxAbsErrorN:Math.max(...results.map((r:any)=>Math.abs(r.errorN))),maxPythonDifferenceN,byBlocks,
  originalSerialBytesDecoded:true,originalAreaResultsUnchanged:true,originalAdcPreserved:true,
  calibrationOnly:true,independentAcceptancePassed:false,browserFixtureFrames:wire.length};
fs.writeFileSync(path.join(output,"field-integration-result.json"),JSON.stringify(summary,null,2));
fs.writeFileSync(path.join(output,"field-integration-comparison.json"),JSON.stringify(results,null,2));
console.log(JSON.stringify(summary,null,2));
