import XLSX from "xlsx-js-style";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { exportToXlsx, type ExportOptions } from "../client/src/lib/xlsxExport";

let exportedBlob: Blob | null = null;
const fakeAnchor = { href: "", download: "", click: () => {} };
(globalThis as typeof globalThis & { document: Document }).document = {
  createElement: () => fakeAnchor,
  body: { appendChild: () => fakeAnchor, removeChild: () => fakeAnchor },
} as unknown as Document;
URL.createObjectURL = ((blob: Blob) => { exportedBlob = blob; return "blob:continuous-test"; }) as typeof URL.createObjectURL;
URL.revokeObjectURL = (() => {}) as typeof URL.revokeObjectURL;

const frame = (id: number, capturedAt: Date, sequence?: number) => ({
  id,
  ...(sequence === undefined ? {} : { continuousSequence: sequence, captureKind: "continuous" as const }),
  data: {
    matrix: [[120, 110], [100, 0]],
    raw: [11, 22, 33, 44],
    physical: [[11, 22], [33, 44]],
    sourceMatrix: [[118, 108], [98, 0]],
    max: 120,
    min: 0,
    avg: 82.5,
    sum: 330,
    nonZeroCount: 3,
    nonZeroMin: 100,
    timestamp: capturedAt.getTime(),
  },
  capturedAt,
  sensorType: "endi-23x23",
  captureConfig: {
    filterThreshold: 30,
    resultScale: 1,
    visibleFields: ["max", "maxCoord", "avg", "avgPressure", "maxPressure", "sum", "nonZeroCount"],
    adcCompensation: {
      sensor: "seat" as const,
      enabled: true,
      scale: 1.0069947916666666,
      offset: 6.018421875000001,
      fingerprint: "test-seat-compensation",
    },
  },
  maxCoordStr: "(1,2)",
});

const visibleFields = ["max", "maxCoord", "avg", "avgPressure", "maxPressure", "sum", "nonZeroCount"];
const config = { name: "测试坐垫", matrixSize: 2, totalPoints: 4, filterThreshold: 30, resultScale: 1 };
const baseOptions: ExportOptions = {};

async function exportWorkbook(options: ExportOptions, frames = [frame(1, new Date("2026-08-27T10:00:00Z"))]) {
  exportedBlob = null;
  await exportToXlsx(frames, config, visibleFields, undefined, false, options);
  if (!exportedBlob) throw new Error("未生成XLSX文件");
  return XLSX.read(new Uint8Array(await exportedBlob.arrayBuffer()), { type: "array" });
}

function normalizeVolatileMetadata(rows: unknown[][]): unknown[][] {
  return rows.map((row) => row.map((value) => typeof value === "string"
    ? value.replace(/导出时间:\s*[^|]+/g, "导出时间:<normalized>")
    : value));
}

const baseline = await exportWorkbook(baseOptions);
const withContinuous = await exportWorkbook({
  continuousFrames: [frame(2, new Date("2026-08-27T10:00:01Z"), 1)],
});
const continuousOnly = await exportWorkbook({
  continuousFrames: [frame(2, new Date("2026-08-27T10:00:01Z"), 1)],
}, []);

if (JSON.stringify(baseline.SheetNames) !== JSON.stringify(["统计摘要", "原始数据"])) {
  throw new Error(`标准采集应输出统计摘要和原始数据：${baseline.SheetNames.join("、")}`);
}
const expectedNames = ["统计摘要", "原始数据", "连续采集数据"];
for (const [label, workbook] of [["混合帧", withContinuous], ["仅连续帧", continuousOnly]] as const) {
  if (JSON.stringify(workbook.SheetNames) !== JSON.stringify(expectedNames)) {
    throw new Error(`${label}工作表结构错误：${workbook.SheetNames.join("、")}`);
  }
}

const originalSummary = normalizeVolatileMetadata(XLSX.utils.sheet_to_json(baseline.Sheets["统计摘要"], { header: 1, raw: true }) as unknown[][]);
const expandedSummary = normalizeVolatileMetadata(XLSX.utils.sheet_to_json(withContinuous.Sheets["统计摘要"], { header: 1, raw: true }) as unknown[][]);
if (JSON.stringify(originalSummary) !== JSON.stringify(expandedSummary)) {
  throw new Error("追加连续采集统计后，标准采集统计摘要发生变化");
}

const continuousRows = XLSX.utils.sheet_to_json(withContinuous.Sheets["连续采集数据"], { header: 1, raw: true }) as unknown[][];
const header = continuousRows[2].map(String);
for (const required of [
  "采集时间",
  "连续帧序号",
  "原始字节长度",
  "原始字节最大值",
  "原始字节平均值",
  "原始字节总和",
  "原始物理矩阵尺寸",
  "原始物理ADC最大值",
  "原始物理ADC平均值",
  "原始物理ADC总和",
  "原始物理有效点数",
  "补偿前插值矩阵尺寸",
  "补偿后ADC最大值",
  "补偿后ADC平均值",
  "ADC补偿启用",
  "ADC补偿倍率a",
  "ADC补偿偏移b",
  "ADC补偿配置指纹",
  "砝码归一化系数",
  "AVG(Pi)-Pbar（kPa）",
  "采集平均压强（kPa）",
  "有效点数",
  "ADC总和",
]) {
  if (!header.includes(required)) throw new Error(`连续采集统计缺少列：${required}`);
}
const allText = continuousRows.flat().map(String).join("\n");
for (const required of ["原始字节（4字节）", "插值前原始物理矩阵（2×2）", "ADC补偿前插值矩阵（2×2）", "连续帧 #1"]) {
  if (!allText.includes(required)) throw new Error(`连续采集原始数据明细缺失：${required}`);
}

const summaryHeader = originalSummary[2].map(String);
for (const required of ["原始字节长度", "原始字节最大值", "原始物理矩阵尺寸", "原始物理ADC平均值", "补偿前插值矩阵尺寸"]) {
  if (!summaryHeader.includes(required)) throw new Error(`统计摘要缺少原始数据审计列：${required}`);
}

const rawRows = XLSX.utils.sheet_to_json(baseline.Sheets["原始数据"], { header: 1, raw: true }) as unknown[][];
const rawText = rawRows.flat().map(String).join("\n");
for (const required of ["原始字节（4字节）", "插值前原始物理矩阵（2×2）", "ADC补偿前插值矩阵（2×2）", "11", "118"]) {
  if (!rawText.includes(required)) throw new Error(`标准采集原始数据工作表缺失：${required}`);
}

const homeSource = readFileSync(resolve(import.meta.dirname, "../client/src/pages/Home.tsx"), "utf8");
const xlsxSource = readFileSync(resolve(import.meta.dirname, "../client/src/lib/xlsxExport.ts"), "utf8");
for (const expected of [
  "setInterval(captureNext, 1000)",
  "captureFrameRef.current?.(\"continuous\", nextSequence)",
  "const [continuousFrames, setContinuousFrames]",
  "数据源已停止，连续采集已自动结束",
  "continuousFrames: continuousFrames",
  "const hasExportableFrames = capturedFrames.length > 0 || continuousFrames.length > 0",
  "{hasExportableFrames && (",
  "CSV仅导出标准采集帧",
]) {
  if (!homeSource.includes(expected)) throw new Error(`连续采集主页面调用链缺失：${expected}`);
}
for (const expected of ["raw: Array.from(frame.raw)"]) {
  if (!homeSource.includes(expected)) throw new Error(`采集原始数据接线缺失：${expected}`);
}
for (const expected of ['book_append_sheet(wb, rawWs, "原始数据")', "appendRawFrameDetails", "frame.data.raw", "frame.data.physical", "frame.data.sourceMatrix"]) {
  if (!xlsxSource.includes(expected)) throw new Error(`XLSX原始数据导出接线缺失：${expected}`);
}
if (!xlsxSource.includes('book_append_sheet(wb, continuousWs, "连续采集数据")')) {
  throw new Error("XLSX导出未追加连续采集统计工作表");
}
console.log("PASS V2.7.67标准/连续采集均导出原始字节与矩阵，同时保留补偿后统计、压强和归一化审计。");
