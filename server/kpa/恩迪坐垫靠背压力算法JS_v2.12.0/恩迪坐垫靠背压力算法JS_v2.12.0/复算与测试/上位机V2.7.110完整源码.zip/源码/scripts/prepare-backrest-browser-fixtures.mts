import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {getSensorConfig, lineInterp2x2} from '../client/src/lib/sensorConfig';
import {analyzeBackrestArea} from '../client/src/lib/backrestArea';
const audit=process.argv[2];
const frames=JSON.parse(fs.readFileSync(path.join(audit,'integration-fixtures.json'),'utf8'));
const counts=new Map<string,number>();
for(const f of frames) if(f.kind==='新方法') counts.set(f.file,(counts.get(f.file)??0)+1);
const file=[...counts].find(([,count])=>count===14)?.[0];
// Fall back to the first complete 14-frame capture if its descriptive kind differs.
const allCounts=new Map<string,number>();
for(const f of frames) allCounts.set(f.file,(allCounts.get(f.file)??0)+1);
const selected=file??[...allCounts].find(([,count])=>count===14)?.[0];
assert.ok(selected);
const config=getSensorConfig('new-backrest-32x25');
const rotate=(m:number[][])=>m[0].map((_,c)=>m.map(row=>row[c]).reverse());
const output=frames.filter((f:any)=>f.file===selected).map((f:any)=>{
 const native=f.matrix[0].map((_:number,c:number)=>f.matrix.map((row:number[])=>row[c]));
 const bytes=Array(1024).fill(0);
 for(let r=0;r<32;r++)for(let c=0;c<25;c++)bytes[config.wireMap[r*25+c]]=native[r][c];
 const source=lineInterp2x2(native,32,25);
 const displayed=rotate(rotate(rotate(source)));
 return {file:f.file,index:f.index,forceN:f.referenceForceN,massKg:f.mass_kg,
  expectedAreaCm2:analyzeBackrestArea(displayed).areaCm2,packet:[...bytes,170,85,3,153]};
});
fs.writeFileSync(path.join(audit,'browser-wire-fixtures.json'),JSON.stringify(output));
console.log(JSON.stringify({file:selected,frames:output.length}));
