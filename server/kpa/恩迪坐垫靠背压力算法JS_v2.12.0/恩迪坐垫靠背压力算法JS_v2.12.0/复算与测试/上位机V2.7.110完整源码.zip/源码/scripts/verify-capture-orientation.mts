import assert from "node:assert/strict";
import XLSX from "xlsx-js-style";
import { CAPTURE_MATRIX_ROW_ORDER, flipCaptureMatrixRows } from "../client/src/lib/captureOrientation";
import { calculatePressureMetricsFromMatrix } from "../client/src/lib/pressureFit";
import { exportToXlsx } from "../client/src/lib/xlsxExport";

const live = [[40, 60], [90, 120], [150, 180]];
const original = structuredClone(live);
const captured = flipCaptureMatrixRows(live);
assert.deepEqual(captured, [[150, 180], [90, 120], [40, 60]]);
assert.deepEqual(live, original);
assert.notEqual(captured[0], live[2]);
const separate = flipCaptureMatrixRows(live);
separate[0][0] = -1;
assert.deepEqual(live, original, "Changing a saved snapshot must not change the live frame");
assert.deepEqual(flipCaptureMatrixRows([]), []);

for (const sensor of ["endi-23x23", "new-backrest-32x25"]) {
  for (const rows of [3, 18]) {
    const matrix = Array.from({ length: rows }, (_, r) =>
      Array.from({ length: 19 }, (_, c) => 40 + ((r * 19 + c) % 170)),
    );
    const before = calculatePressureMetricsFromMatrix(matrix, sensor, 1.7);
    const after = calculatePressureMetricsFromMatrix(flipCaptureMatrixRows(matrix), sensor, 1.7);
    for (const key of ["avgPressureKPa", "maxPressureKPa", "topMean", "topCount", "pointPressureCount"] as const) {
      assert.equal(after[key], before[key], `${sensor} ${rows} rows: ${key}`);
    }
    assert.equal(after.calibrationBranch, before.calibrationBranch);
    for (let r = 0; r < matrix.length; r++) {
      const expected = before.pressureMatrixKPa?.[matrix.length - 1 - r];
      after.pressureMatrixKPa?.[r].forEach((value, c) => {
        assert.ok(Math.abs(value - expected![c]) < 1e-10, "Point pressure follows the same row reversal");
      });
    }
  }
}

let exportedBlob: Blob | null = null;
const fakeAnchor = { href: "", download: "", click: () => {} };
(globalThis as typeof globalThis & { document: Document }).document = {
  createElement: () => fakeAnchor,
  body: { appendChild: () => fakeAnchor, removeChild: () => fakeAnchor },
} as unknown as Document;
URL.createObjectURL = (blob: Blob) => { exportedBlob = blob; return "blob:orientation-test"; };
URL.revokeObjectURL = () => {};

const frame = {
  id: 1,
  capturedAt: new Date("2026-10-27T05:00:00Z"),
  sensorType: "endi-23x23",
  data: {
    matrix: captured,
    raw: [1, 2, 3, 4, 5, 6],
    physical: [[5, 6], [3, 4], [1, 2]],
    sourceMatrix: [[130, 160], [70, 100], [20, 40]],
    max: 180, min: 40, avg: 106.67, sum: 640, nonZeroCount: 6, nonZeroMin: 40,
  },
  captureConfig: {
    filterThreshold: 30, resultScale: 1, visibleFields: [],
    matrixRowOrder: CAPTURE_MATRIX_ROW_ORDER, matrixRotation: 0,
  },
};
const snapshot = JSON.stringify(frame);
await exportToXlsx([frame], {
  name: "方向验证", matrixSize: 3, totalPoints: 6, filterThreshold: 30, resultScale: 1,
}, [], undefined, false, { continuousFrames: [{ ...frame, id: 2, continuousSequence: 1 }] });
assert.ok(exportedBlob, "Export creates an XLSX file");
const workbook = XLSX.read(new Uint8Array(await (exportedBlob as Blob).arrayBuffer()), { type: "array" });
for (const name of ["原始数据", "连续采集数据"]) {
  const rows = XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, raw: true }) as unknown[][];
  for (const [label, expected] of [
    ["补偿后显示矩阵（3×2）", [[150, 180], [90, 120], [40, 60]]],
    ["插值前原始物理矩阵（3×2）", [[5, 6], [3, 4], [1, 2]]],
    ["ADC补偿前插值矩阵（3×2）", [[130, 160], [70, 100], [20, 40]]],
  ] as const) {
    const index = rows.findIndex(row => row[0] === label);
    assert.ok(index >= 0, `${name}: ${label} exists`);
    assert.deepEqual(rows.slice(index + 2, index + 5).map(row => row.slice(1)), expected,
      `${name}: ${label} preserves saved row order without flipping again`);
  }
  assert.ok(rows.some(row => row[0] === "矩阵行序：与采集时热力图从上到下一致"));
  const rawIndex = rows.findIndex(row => row[0] === "原始字节（6字节）");
  assert.deepEqual(rows[rawIndex + 2].slice(1), [1, 2, 3, 4, 5, 6]);
}
assert.equal(JSON.stringify(frame), snapshot, "Repeated export must not mutate captured frames");
console.log("PASS 采集翻转快照独立、双传感器砝码/真人段压力不变、标准/连续XLSX矩阵行序与原始字节往返。");
