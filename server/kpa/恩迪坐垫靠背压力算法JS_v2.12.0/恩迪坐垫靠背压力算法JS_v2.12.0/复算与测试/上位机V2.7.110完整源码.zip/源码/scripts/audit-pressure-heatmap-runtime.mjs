import { spawn } from "node:child_process";
import fs from "node:fs";

const previewUrl = process.env.PREVIEW_URL ?? "http://127.0.0.1:3000";
const debugPort = 9333;
const humanScreenshotPath = "/home/ubuntu/pressure-sensor-v2/.manus-logs/pressure-heatmap-human-runtime.png";
const weightScreenshotPath = "/home/ubuntu/pressure-sensor-v2/.manus-logs/pressure-heatmap-weight-runtime.png";
const chrome = spawn("/usr/bin/chromium", [
  "--headless=new",
  "--no-sandbox",
  "--disable-gpu",
  `--remote-debugging-port=${debugPort}`,
  `--user-data-dir=/tmp/pressure-heatmap-audit-${Date.now()}`,
  "about:blank",
], { stdio: "ignore" });

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitForTargets() {
  for (let attempt = 0; attempt < 50; attempt++) {
    try {
      const targets = await fetch(`http://127.0.0.1:${debugPort}/json/list`).then((response) => response.json());
      if (targets[0]?.webSocketDebuggerUrl) return targets[0].webSocketDebuggerUrl;
    } catch {
      // Chromium尚未完成启动。
    }
    await sleep(100);
  }
  throw new Error("无法连接Chromium调试端口");
}

const websocketUrl = await waitForTargets();
const socket = new WebSocket(websocketUrl);
const pending = new Map();
let commandId = 0;

socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  const request = pending.get(message.id);
  if (!request) return;
  pending.delete(message.id);
  if (message.error) request.reject(new Error(message.error.message));
  else request.resolve(message.result);
});

await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

function send(method, params = {}) {
  const id = ++commandId;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

async function evaluate(expression) {
  const result = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
  return result.result.value;
}

try {
  await send("Page.enable");
  await send("Runtime.enable");
  await send("Page.navigate", { url: previewUrl });
  await sleep(1500);

  const clickButton = (text) => evaluate(`(() => {
    const button = [...document.querySelectorAll('button')].find((node) => node.textContent?.includes(${JSON.stringify(text)}));
    if (!button) return { found: false };
    const disabled = button.disabled;
    button.click();
    return { found: true, disabled };
  })()`);

  const demoClick = await clickButton("演示模式");
  if (!demoClick.found || demoClick.disabled) throw new Error("演示模式按钮不可用");
  await sleep(1800);

  const before = await evaluate(`(() => {
    const button = [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'));
    return { text: button?.textContent ?? '', disabled: button?.disabled ?? true, canvasCount: document.querySelectorAll('canvas').length };
  })()`);
  if (!before.text.includes("ADC") || before.disabled) throw new Error(`ADC模式按钮状态异常: ${JSON.stringify(before)}`);

  const pressureClick = await clickButton("热图：ADC");
  if (!pressureClick.found || pressureClick.disabled) throw new Error("无法切换到压强热力图");
  await sleep(700);

  const pressureState = await evaluate(`(() => ({
    bodyText: document.body.innerText,
    modeText: [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'))?.textContent ?? '',
    canvasCount: document.querySelectorAll('canvas').length,
  }))()`);
  if (!pressureState.modeText.includes("压强 kPa")) {
    throw new Error(`按钮未切换为压强模式: ${JSON.stringify({ pressureClick, before, modeText: pressureState.modeText })}`);
  }
  if (!pressureState.bodyText.includes("色标 0—") || !pressureState.bodyText.includes("kPa")) {
    throw new Error(`压强色标或单位未显示: ${JSON.stringify({ modeText: pressureState.modeText, hasColorScale: pressureState.bodyText.includes("色标 0—") })}`);
  }
  if (!pressureState.bodyText.includes("真人段")) throw new Error("阈值0演示帧未进入真人段");

  const screenshot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
  fs.writeFileSync(humanScreenshotPath, Buffer.from(screenshot.data, "base64"));

  await clickButton("热图：压强 kPa");
  await sleep(300);
  const after = await evaluate(`([...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'))?.textContent ?? '')`);
  if (!after.includes("ADC")) throw new Error("无法切换回ADC模式");

  let selectedWeightThreshold = null;
  for (const threshold of [120, 140, 150, 160, 170]) {
    const thresholdState = await evaluate(`(() => {
      const label = [...document.querySelectorAll('span')].find((node) => node.textContent?.trim() === '过滤≤');
      const input = label?.parentElement?.querySelector('input[type="number"]');
      if (!input) return { changed: false };
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
      setter?.call(input, ${JSON.stringify(String(threshold))});
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return { changed: true };
    })()`);
    if (!thresholdState.changed) throw new Error("未找到过滤阈值输入框");
    await sleep(700);
    const branchState = await evaluate(`(() => {
      const button = [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'));
      return { bodyText: document.body.innerText, pressureAvailable: !(button?.disabled ?? true) };
    })()`);
    if (branchState.bodyText.includes("砝码段") && branchState.pressureAvailable) {
      selectedWeightThreshold = threshold;
      break;
    }
  }
  if (selectedWeightThreshold === null) throw new Error("未找到可稳定复现的砝码段演示阈值");
  const weightPressureClick = await clickButton("热图：ADC");
  if (!weightPressureClick.found || weightPressureClick.disabled) throw new Error("砝码段无法切换到压强热力图");
  await sleep(500);
  const weightPressureState = await evaluate(`(() => ({
    bodyText: document.body.innerText,
    modeText: [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'))?.textContent ?? '',
  }))()`);
  if (!weightPressureState.modeText.includes("压强 kPa")) throw new Error("砝码段按钮未切换为压强模式");
  if (!weightPressureState.bodyText.includes("色标 0—") || !weightPressureState.bodyText.includes("砝码段")) {
    throw new Error(`砝码段压强色标或分支说明未显示: ${JSON.stringify({
      modeText: weightPressureState.modeText,
      hasColorScale: weightPressureState.bodyText.includes("色标 0—"),
      hasWeightBranch: weightPressureState.bodyText.includes("砝码段"),
      bodyPreview: weightPressureState.bodyText.slice(0, 600),
    })}`);
  }
  const weightScreenshot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
  fs.writeFileSync(weightScreenshotPath, Buffer.from(weightScreenshot.data, "base64"));
  const stopDemoClick = await clickButton("停止演示");
  if (!stopDemoClick.found || stopDemoClick.disabled) throw new Error("无法停止演示数据源");
  await sleep(600);
  const stoppedMode = await evaluate(`(() => {
    const button = [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'));
    return { text: button?.textContent ?? '', disabled: button?.disabled ?? false };
  })()`);
  if (!stoppedMode.text.includes("压强 kPa") || stoppedMode.disabled) {
    throw new Error(`停止演示后最后一帧未保留压强模式: ${JSON.stringify(stoppedMode)}`);
  }
  await send("Page.navigate", { url: previewUrl });
  await sleep(1200);
  const refreshedMode = await evaluate(`(() => {
    const button = [...document.querySelectorAll('button')].find((node) => node.textContent?.includes('热图：'));
    return { text: button?.textContent ?? '', disabled: button?.disabled ?? false };
  })()`);
  if (!refreshedMode.text.includes("ADC") || !refreshedMode.disabled) {
    throw new Error(`页面重新加载无数据时未回到禁用的ADC状态: ${JSON.stringify(refreshedMode)}`);
  }

  console.log("PASS 演示模式产生有效数据");
  console.log("PASS ADC按钮由禁用变为可用");
  console.log("PASS 真人段实际切换到逐点压强热力图");
  console.log("PASS 真人段显示动态色标与kPa单位");
  console.log("PASS 实际点击切换回ADC热力图");
  console.log(`PASS 过滤阈值${selectedWeightThreshold}的演示帧进入砝码段`);
  console.log("PASS 砝码段实际切换到归一化Pi热力图");
  console.log("PASS 停止演示后保留最后一帧及压强模式");
  console.log("PASS 页面重新加载无数据时回到ADC并禁用压强切换");
  console.log(`PASS 真人段运行截图: ${humanScreenshotPath}`);
  console.log(`PASS 砝码段运行截图: ${weightScreenshotPath}`);
} finally {
  socket.close();
  chrome.kill("SIGTERM");
}
