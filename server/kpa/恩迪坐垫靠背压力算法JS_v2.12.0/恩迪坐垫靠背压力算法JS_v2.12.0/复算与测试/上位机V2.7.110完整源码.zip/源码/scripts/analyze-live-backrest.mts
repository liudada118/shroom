import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import XLSX from 'xlsx-js-style';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {extractBackrestForceFeatures} from '../client/src/lib/backrestTotalForce';

const [dir,out]=process.argv.slice(2);assert.ok(dir&&out);
const allLabeled=process.argv.includes('--all-labeled');
const config=getSensorConfig('new-backrest-32x25');
const all:any[]=[];
const originalTriples=new Set(['sensor_capture_2026-10-28T09-14-03.xlsx','sensor_capture_2026-10-28T09-14-25.xlsx',
 'sensor_capture_2026-10-28T09-14-56.xlsx','sensor_capture_2026-10-28T09-15-20.xlsx']);
function list(root:string):string[]{return fs.readdirSync(root,{withFileTypes:true}).flatMap(e=>e.isDirectory()&&allLabeled?
 list(path.join(root,e.name)):e.isFile()&&e.name.endsWith('.xlsx')?[path.join(root,e.name)]:[]);}
for(const fullPath of list(dir)){
 const file=path.relative(dir,fullPath);
 const countLabel=file.match(/(?:^|[\\/])(\d+)块(?:[\\/]|$)/);
 const count=countLabel?Number(countLabel[1]):originalTriples.has(path.basename(file))?3:null;
 if(count===null){console.log('SKIP missing weight label',file);continue;}
 const mass=count*1.625;
 const w=XLSX.readFile(fullPath);
 const sheet=w.Sheets['连续采集数据'];assert.ok(sheet);
 const rows=XLSX.utils.sheet_to_json(sheet,{header:1,raw:true,defval:''}) as any[][];
 const h=rows[2];
 const summaries=[];
 for(let i=3;rows[i]?.[0]&&typeof rows[i][1]==='number';i++)summaries.push(Object.fromEntries(h.map((k,j)=>[k,rows[i][j]])));
 const raws=rows.flatMap((r,i)=>typeof r[0]==='string'&&r[0].startsWith('原始字节（')?[i]:[]);
 const physicals=rows.flatMap((r,i)=>typeof r[0]==='string'&&r[0].startsWith('插值前原始物理矩阵（')?[i]:[]);
 const sources=rows.flatMap((r,i)=>typeof r[0]==='string'&&r[0].startsWith('ADC补偿前插值矩阵（')?[i]:[]);
 assert.equal(raws.length,summaries.length);assert.equal(physicals.length,summaries.length);
 for(let i=0;i<summaries.length;i++){
  const s=summaries[i],raw=Array(1024).fill(0);
  for(let j=raws[i]+2;typeof rows[j]?.[0]==='number';j++){
   const offset=rows[j][0];for(let k=1;k<=32&&offset+k-1<1024;k++)raw[offset+k-1]=rows[j][k];
  }
  const nativeP=Array.from({length:32},(_,r)=>Array.from({length:25},(_,c)=>raw[config.wireMap[r*25+c]]));
  const nativeS=lineInterp2x2(nativeP,32,25);
  const canonicalP=Array.from({length:25},(_,c)=>nativeP.map(row=>row[c]));
  const savedP=rows.slice(physicals[i]+2,physicals[i]+27).map(row=>row.slice(1,33));
  assert.deepEqual(canonicalP,savedP,'True wire byte decoding must match saved calibration coordinates');
  const savedS=rows.slice(sources[i]+2,sources[i]+52).map(row=>row.slice(1,65));
  const force=calculateLiveSensorForce(config.type,nativeS,nativeP)!;assert.ok(force);
  assert.ok(Math.abs(force.forceN-s['总压力候选（N）'])<1e-9,'Saved force matches original-ADC model');
  const p=force.contactPressure!;
  assert.ok(Math.abs(p.averagePressureKPa!-s['各区压强算术平均（kPa）'])<1e-9);
  all.push({file,index:i+1,source_frame:s['内部帧序号'],time:s['采集时间'],mass_kg:mass,
   label_basis:countLabel?`用户重量目录${count}块×1.625kg`:'用户确认三个1.625kg砝码同一落点叠放，提供多帧采集复核',matrix:canonicalP,
   source:savedS,raw,nativeSource:nativeS,features:extractBackrestForceFeatures(canonicalP),
   savedForceN:s['总压力候选（N）'],displayForceN:s['平滑显示总力（N）'],referenceForceN:mass*9.80665,
   errorN:force.forceN-mass*9.80665,areaCm2:s['接触面积（cm²）'],regionPressure:p,
   referencePressureAtSameAreaKPa:10*mass*9.80665/s['接触面积（cm²）']});
 }
}
fs.writeFileSync(path.join(out,allLabeled?'新增多重量原始ADC与标签.json':'当前40帧原始ADC与标签.json'),JSON.stringify(all));
const summary=[...new Set(all.map(r=>r.file))].map(file=>{
 const subset=all.filter(r=>r.file===file);
 const range=(key:string)=>[Math.min(...subset.map(r=>r[key])),Math.max(...subset.map(r=>r[key]))];
 return {file,frames:subset.length,massKg:subset[0].mass_kg,forceRangeN:range('savedForceN'),errorRangeN:range('errorN'),
  areaRangeCm2:range('areaCm2'),meanForceN:subset.reduce((s,r)=>s+r.savedForceN,0)/subset.length,
  within5N:subset.filter(r=>Math.abs(r.errorN)<=5).length,
  regionCounts:[...new Set(subset.map(r=>r.regionPressure.regions.length))],
  rawCenters:subset[0].features.slice(3,5),pressureRangeKPa:[Math.min(...subset.map(r=>r.regionPressure.averagePressureKPa)),Math.max(...subset.map(r=>r.regionPressure.averagePressureKPa))]};
});
fs.writeFileSync(path.join(out,allLabeled?'新增多重量原模型偏差结果.json':'当前实测偏差结果.json'),JSON.stringify({frames:all.length,
 genuineByteMappingMatches:true,savedForceMatchesModel:true,savedPressureMatchesFormula:true,summary},null,2));
console.log(JSON.stringify(process.argv.includes('--quiet')?{frames:all.length,files:summary.length,
  groups:[...new Set(all.map(r=>r.mass_kg))].map(massKg=>{
   const subset=all.filter(r=>r.mass_kg===massKg);
   return {massKg,frames:subset.length,within5N:subset.filter(r=>Math.abs(r.errorN)<=5).length,
    maxAbsErrorN:Math.max(...subset.map(r=>Math.abs(r.errorN)))};
  })}:summary,null,2));
