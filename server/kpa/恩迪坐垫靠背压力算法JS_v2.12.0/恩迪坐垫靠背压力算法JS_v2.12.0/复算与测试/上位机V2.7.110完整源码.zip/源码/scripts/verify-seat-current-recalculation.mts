import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {predictSeatForceDetails,seatTotalForceModelVersion} from '../client/src/lib/seatTotalForce';
import {analyzeSeatArea,SEAT_AREA_VERSION} from '../client/src/lib/seatArea';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {calculateSeatRegionPressure} from '../client/src/lib/seatRegionPressure';
import {calculateDisplayedArea} from '../client/src/lib/displayArea';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {ForceReadout} from '../client/src/lib/forceReadout';

const out=process.argv[2];assert.ok(out);
const read=(n:string)=>JSON.parse(fs.readFileSync(path.join(out,n),'utf8'));
const forceData=read('重标定力值原始ADC与标签.json'),forcePython=read('python-force-predictions.json');
const areaData=read('重标定面积原始ADC与标签.json'),areaPython=read('python-area-predictions.json');
assert.equal(forceData.length,894);assert.equal(areaData.length,894);
assert.equal(forcePython.length,forceData.length);assert.equal(areaPython.length,areaData.length);
const close=(a:number,b:number,t=1e-7)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const rotate=<T>(m:T[][],turns:number)=>{for(let i=0;i<turns;i++)m=m[0].map((_,c)=>m.map(row=>row[c]).reverse());return m;};
const config=getSensorConfig('endi-23x23');
let maxForceDifferenceN=0,maxAreaDifferenceCm2=0,forceKnown=0,forceCal=0,forceDev=0,moving=0,unknown=0,contacts=0,rotations=0,multi=0;
const forceComparisons:any[]=[],areaComparisons:any[]=[];
const forcePhaseCounts:Record<string,number>={};
for(let i=0;i<forceData.length;i++){
 const r=forceData[i],before=hash(r),p=predictSeatForceDetails(r.physical),reference=forcePython[i];
 for(const k of ['baseForceN','correctionN','forceN'] as const)close(p[k],reference[k]);
 maxForceDifferenceN=Math.max(maxForceDifferenceN,Math.abs(p.forceN-reference.forceN));
 const decoded=Array.from({length:23},(_,row)=>Array.from({length:23},(_,col)=>r.raw[config.wireMap[row*23+col]]));assert.deepEqual(decoded,r.physical);
 if(r.phase==='unknown_weight')unknown++;
 else if(r.phase==='moving_candidate_excluded')moving++;
 else{
  const error=p.forceN-r.mass_kg*9.80665;assert.ok(Math.abs(error)<=1,JSON.stringify({file:r.file,index:r.index,error}));forceKnown++;
  // The frozen model determines which records are calibration versus checks.
  // Never silently assert a training split chosen by this verification script.
  forcePhaseCounts[r.phase]=(forcePhaseCounts[r.phase]??0)+1;
  if(/calibration|training/.test(r.phase))forceCal++;else forceDev++;
  forceComparisons.push({file:r.file,index:r.index,massKg:r.mass_kg,referenceForceN:r.mass_kg*9.80665,...p,errorN:error,phase:r.phase});
 }
 assert.equal(hash(r),before);
}
assert.equal(forceKnown,892);assert.equal(forceCal+forceDev,forceKnown);assert.equal(unknown,1);assert.equal(moving,1);
for(let i=0;i<areaData.length;i++){
 const r=areaData[i],before=hash(r),area=analyzeSeatArea(r.source),py=areaPython[i];
 assert.equal(area.seedCount,py.seedCount);assert.equal(area.seedCount,r.expectedContacts);
 close(area.areaCm2,py.areaCm2);maxAreaDifferenceCm2=Math.max(maxAreaDifferenceCm2,Math.abs(area.areaCm2-py.areaCm2));
 area.regions.forEach((v,k)=>{close(v.areaCm2,py.regions[k].areaCm2);close(v.thresholdAdc,py.regions[k].thresholdAdc);
  if(r.phase!=='moving_candidate_excluded'){assert.ok(v.areaCm2>=59&&v.areaCm2<=66,JSON.stringify({file:r.file,index:r.index,region:k,area:v.areaCm2}));contacts++;if(area.seedCount>1)multi++;}
 });
 area.areaMatrixCm2.forEach((row,rr)=>row.forEach((v,c)=>close(v,py.areaMatrixCm2[rr][c])));
 assert.deepEqual(lineInterp2x2(r.physical,23,23),r.source);
 const force=predictSeatForceDetails(r.physical).forceN;
 for(let rotation=0;rotation<4;rotation++){
  const source=rotate(r.source,rotation),current=analyzeSeatArea(source,{rotation});rotations++;
  close(current.areaCm2,area.areaCm2);assert.deepEqual(current.areaMatrixCm2,rotate(area.areaMatrixCm2,rotation));
  const pressure=calculateSeatRegionPressure(r.physical,force,{area:current,rotation});
  close(pressure.regions.reduce((s,v)=>s+v.estimatedForceN,0),force);
  close(pressure.averagePressureKPa!,pressure.regions.reduce((s,v)=>s+10*v.estimatedForceN/v.areaCm2,0)/pressure.regions.length);
  if(rotation===3){
   const live=calculateLiveSensorForce(config.type,r.source,r.physical,area.areaCm2,{area:current,rotation})!;
   close(live.forceN,force,0);close(live.contactPressure!.averagePressureKPa!,pressure.averagePressureKPa!);
   assert.equal(live.modelVersion,seatTotalForceModelVersion);assert.equal(live.accepted,false);assert.equal(live.independentlyValidated,false);
   assert.deepEqual(live.regionForcesN,[]);
   const display=calculateDisplayedArea(source.map(row=>row.map(()=>0)),null,null,{sensorType:config.type,sourceMatrix:source,sourceRotation:rotation})!;close(display.areaCm2,area.areaCm2);
   const selected=analyzeSeatArea(source,{rotation,selection:{startRow:5,startCol:7,endRow:34,endCol:31}});
   close(selected.areaCm2,current.areaMatrixCm2.flatMap((row,rr)=>row.map((v,c)=>rr>=5&&rr<=34&&c>=7&&c<=31?v:0)).reduce((s,v)=>s+v,0));
   const shown=new ForceReadout().update('fixture',r.physical,live,100,100,true)!;close(shown.forceN,force,0);
  }
 }
 assert.equal(hash(r),before);
 areaComparisons.push({file:r.file,index:r.index,phase:r.phase,contacts:area.seedCount,areaCm2:area.areaCm2,regions:area.regions.map(v=>({index:v.index,thresholdAdc:v.thresholdAdc,areaCm2:v.areaCm2}))});
}
assert.equal(contacts,1053);assert.equal(multi,224);assert.equal(rotations,3576);
const old=JSON.parse(fs.readFileSync(path.join(out,'..','坐垫叠放面积修正','坐垫面积逐帧对比.json'),'utf8'));
for(const r of areaComparisons.filter(r=>r.contacts>1)){
 const prior=old.find((v:any)=>v.file===r.file&&v.index===r.index);assert.ok(prior);close(r.areaCm2,prior.areaCm2,1e-10);
 r.regions.forEach((v:any,k:number)=>{close(v.areaCm2,prior.regions[k].areaCm2,1e-10);close(v.thresholdAdc,prior.regions[k].thresholdAdc,0);});
}
const zero=Array.from({length:23},()=>Array(23).fill(0));assert.equal(predictSeatForceDetails(zero).forceN,0);assert.equal(analyzeSeatArea(lineInterp2x2(zero,23,23)).areaCm2,0);
const chosen=[areaData.find((r:any)=>r.expectedContacts===1),...Array.from({length:4},(_,i)=>areaData.find((r:any)=>r.expectedContacts===i+2)),
 areaData.find((r:any)=>r.expectedContacts===1&&predictSeatForceDetails(r.physical).forceN>100),
 ...areaData.filter((r:any)=>r.file.startsWith('当前复测/')&&r.index===10),
 ...areaData.filter((r:any)=>r.file.startsWith('异常/')&&r.index===10),
 areaData.find((r:any)=>r.phase==='moving_candidate_excluded')];
assert.ok(chosen.every(Boolean));
assert.equal(chosen.length,21);
assert.equal(new Set(chosen.map((r:any)=>`${r.file}|${r.index}`)).size,21);
assert.equal(chosen.filter((r:any)=>r.file.startsWith('当前复测/')).length,5);
assert.equal(chosen.filter((r:any)=>r.file.startsWith('异常/')&&r.index===10).length,9);
const fixtures=chosen.map((r:any)=>{
 const area=analyzeSeatArea(rotate(r.source,3),{rotation:3}),forceN=predictSeatForceDetails(r.physical).forceN;
 return {file:r.file,index:r.index,sensorType:config.type,forceN,expectedAreaCm2:area.areaCm2,packet:[...r.raw,170,85,3,153],contactPressure:calculateSeatRegionPressure(r.physical,forceN,{area,rotation:3})};
});
for(const n of ['坐垫页面','坐垫跟随']){
 fs.mkdirSync(path.join(out,n),{recursive:true});
 fs.writeFileSync(path.join(out,n,'browser-wire-fixtures.json'),JSON.stringify(fixtures));
}
const result={version:'V2.7.80',forceModelVersion:seatTotalForceModelVersion,areaVersion:SEAT_AREA_VERSION,
 rawForceFrames:forceData.length,rawAreaFrames:areaData.length,knownStableForceFrames:forceKnown,calibrationForceFrames:forceCal,temporalForceDevelopmentFrames:forceDev,
 forcePhaseCounts,
 forceMaxAbsErrorN:Math.max(...forceComparisons.map(r=>Math.abs(r.errorN))),stableAreaContacts:contacts,multiContactsUnchanged:multi,
 excludedUnknownWeight:unknown,excludedMotionCandidates:moving,rotationChecks:rotations,maxForceDifferenceN,maxAreaDifferenceCm2,
 areaSingleMinCm2:Math.min(...areaComparisons.filter(r=>r.contacts===1&&r.phase!=='moving_candidate_excluded').map(r=>r.areaCm2)),
 areaSingleMaxCm2:Math.max(...areaComparisons.filter(r=>r.contacts===1&&r.phase!=='moving_candidate_excluded').map(r=>r.areaCm2)),
 rawMappingPassed:true,originalAdcPreserved:true,pressureFormulaPassed:true,selectionsPassed:true,forceReadoutPassed:true,browserFixtures:fixtures.length,
 forceTemporalDevelopmentUsedForMethodSelection:true,independentReloadAcceptancePassed:false,
 separateTwoBlockReloadIncludedInCalibration:false,
 verificationScope:'894 archived plus current same-placement frames only; separate two-block physical reload must be checked with the frozen model separately'};
fs.writeFileSync(path.join(out,'recalibration-integration-result.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(out,'上位机总力重标定逐帧对比.json'),JSON.stringify(forceComparisons));
fs.writeFileSync(path.join(out,'上位机面积重标定逐帧对比.json'),JSON.stringify(areaComparisons));
console.log(JSON.stringify(result,null,2));
