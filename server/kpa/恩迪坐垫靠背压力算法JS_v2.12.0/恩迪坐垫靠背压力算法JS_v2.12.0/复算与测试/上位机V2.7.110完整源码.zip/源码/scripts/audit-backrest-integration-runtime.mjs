import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';

const audit=process.argv[2];
assert.ok(audit,'Pass the integration audit directory');
const fixtures=JSON.parse(fs.readFileSync(path.join(audit,'browser-wire-fixtures.json'),'utf8'));
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'backrest-runtime-'));
const browser=spawn('C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',[
 '--headless=new','--disable-gpu','--no-first-run','--window-size=1800,1200',
 '--remote-debugging-port=9335',`--user-data-dir=${profile}`,'about:blank',
],{stdio:'ignore',windowsHide:true});
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let socket;
const errors=[];
try {
 let target;
 for(let i=0;i<60;i++){
  try{const list=await fetch('http://127.0.0.1:9335/json/list').then(r=>r.json());target=list.find(t=>t.type==='page');if(target)break;}catch{}
  await sleep(100);
 }
 assert.ok(target,'Browser debugger must become available');
 socket=new WebSocket(target.webSocketDebuggerUrl);
 let sequence=0;
 const pending=new Map();
 socket.addEventListener('message',event=>{
  const value=JSON.parse(event.data);
  if(value.method==='Runtime.exceptionThrown')errors.push(value.params.exceptionDetails);
  const request=pending.get(value.id);if(!request)return;
  pending.delete(value.id);clearTimeout(request.timer);
  value.error?request.reject(new Error(value.error.message)):request.resolve(value.result);
 });
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 const send=(method,params={})=>new Promise((resolve,reject)=>{
  const id=++sequence;
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`Timeout: ${method}`));},15000);
  pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));
 });
 const evaluate=async expression=>{
  const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value;
 };
 const click=async expression=>{
  const pos=await evaluate(`(()=>{const e=${expression};if(!e)throw Error('Element not found');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
  await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...pos});
  await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...pos});
 };
 const button=text=>`[...document.querySelectorAll('button')].find(e=>e.textContent?.trim()===${JSON.stringify(text)})`;
 await send('Page.enable');await send('Runtime.enable');
 await send('Page.addScriptToEvaluateOnNewDocument',{source:`
  window.__serialAudit={controller:null};
  const port={
   open:async()=>{},close:async()=>{},getInfo:()=>({usbVendorId:0,usbProductId:0}),
   readable:new ReadableStream({start(c){window.__serialAudit.controller=c;}})
  };
  Object.defineProperty(navigator,'serial',{configurable:true,value:{requestPort:async()=>port,getPorts:async()=>[]}});
 `});
 await send('Page.navigate',{url:'http://127.0.0.1:3000/'});
 for(let i=0;i<80;i++){
  if(await evaluate(`!!document.querySelector('button[role="combobox"]')`))break;
  await sleep(100);
 }
 assert.ok((await evaluate('document.title')).includes('V2.7.68'));
 await click(`document.querySelector('button[role="combobox"]')`);await sleep(100);
 await click(`[...document.querySelectorAll('[role="option"]')].find(e=>e.textContent?.includes('新靠背'))`);
 await sleep(200);
 await click(button('连接串口'));await sleep(300);
 assert.ok(await evaluate(`document.body.innerText.includes('已连接')`));
 const observations=[];
 for(const f of fixtures){
  // Preserve the display filter's existing reset after a gap between stable loads.
  if(observations.length)await sleep(1600);
  await evaluate(`window.__serialAudit.controller.enqueue(new Uint8Array(${JSON.stringify(f.packet)}))`);
  await sleep(130);
  const observed=await evaluate(`({force:Number(document.querySelector('[data-testid="force-value"]').textContent),area:Number(document.querySelector('[data-testid="area-value"]').textContent)})`);
  assert.ok(Math.abs(observed.force-f.forceN)<=0.0051,JSON.stringify({frame:f.index,...observed,expected:f.forceN}));
  assert.equal(observed.area,f.expectedAreaCm2,`Frame ${f.index} existing area`);
  const captureButton=await evaluate(`([...document.querySelectorAll('button')].filter(e=>e.textContent?.includes('采集')).map(e=>({text:e.textContent.trim(),title:e.title,disabled:e.disabled})))`);
  const manual=captureButton.find(e=>e.text==='采集当前帧'||e.text==='手动采集'||e.text==='采集一帧');
  assert.ok(manual,JSON.stringify(captureButton));
  await click(button(manual.text));
  observations.push({index:f.index,forceN:observed.force,referenceForceN:f.forceN,areaCm2:observed.area});
 }
 await sleep(300);
 const saved=await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('SensorCaptureDB',3);r.onerror=()=>reject(r.error);r.onsuccess=()=>{const d=r.result,q=d.transaction('capturedFrames').objectStore('capturedFrames').getAll();q.onsuccess=()=>{d.close();resolve(q.result.map(f=>({id:f.id,force:f.forceMetrics,display:f.forceDisplayMetrics,area:f.areaMetrics,rawLength:f.data.raw?.length,physicalShape:[f.data.physical?.length,f.data.physical?.[0]?.length]})));};q.onerror=()=>reject(q.error);};})`);
 assert.equal(saved.length,14);
 saved.forEach((row,i)=>{
  assert.ok(Math.abs(row.force.forceN-fixtures[i].forceN)<1e-9);
  assert.equal(row.force.modelVersion,'2026-10-28-all-data-12features');
  assert.equal(row.force.forceAggregation,'total_only');
  assert.deepEqual(row.force.regionForcesN,[]);
  assert.equal(row.area.areaCm2,fixtures[i].expectedAreaCm2);
  assert.equal(row.rawLength,1024);assert.deepEqual(row.physicalShape,[25,32]);
 });
 const screenshot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
 fs.writeFileSync(path.join(audit,'上位机靠背接入运行.png'),Buffer.from(screenshot.data,'base64'));
 await click(button('断开连接'));
 assert.deepEqual(errors,[],'No uncaught browser runtime errors');
 const result={version:'V2.7.68',productionUrl:'http://127.0.0.1:3000/',
  input:'Mock Web Serial byte stream using original ADC; no physical device connected',
  stableLoadFrames:observations.length,forceDisplayMatches:true,areaDisplayMatches:true,
  capturedFrames:saved.length,rawCaptureForceMatches:true,originalAdcPreserved:true,
  uncaughtRuntimeErrors:errors.length,observations,captured:saved};
 fs.writeFileSync(path.join(audit,'browser-runtime-result.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify({...result,observations:undefined,captured:undefined},null,2));
}catch(error){
 fs.writeFileSync(path.join(audit,'browser-failure.json'),JSON.stringify({message:String(error),errors},null,2));
 throw error;
}finally{
 socket?.close();browser.kill();
}
