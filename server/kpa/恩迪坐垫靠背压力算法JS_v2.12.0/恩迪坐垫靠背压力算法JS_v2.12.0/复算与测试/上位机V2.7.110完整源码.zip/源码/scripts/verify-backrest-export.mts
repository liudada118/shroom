import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import XLSX from 'xlsx-js-style';
import {exportToXlsx} from '../client/src/lib/xlsxExport';
import {backrestTotalForceModelVersion} from '../client/src/lib/backrestTotalForce';
const audit=process.argv[2];
const wire=JSON.parse(fs.readFileSync(path.join(audit,'browser-wire-fixtures.json'),'utf8'));
const browser=JSON.parse(fs.readFileSync(path.join(audit,'browser-runtime-result.json'),'utf8'));
const fixtures=JSON.parse(fs.readFileSync(path.join(audit,'integration-fixtures.json'),'utf8'));
let blob:Blob|null=null;
const anchor={href:'',download:'',click:()=>{}};
globalThis.document={createElement:()=>anchor,body:{appendChild:()=>anchor,removeChild:()=>anchor}} as unknown as Document;
URL.createObjectURL=(value:Blob)=>{blob=value;return 'blob:audit';};
URL.revokeObjectURL=()=>{};
const frames=browser.captured.map((saved:any,i:number)=>{
 const f=fixtures.find((f:any)=>f.file===wire[i].file&&f.index===wire[i].index);
 const matrix=f.source.map((row:number[])=>row.map(v=>v>30?v:0));
 const values=matrix.flat(),positive=values.filter((v:number)=>v>0),sum=values.reduce((a:number,b:number)=>a+b,0);
 return {id:saved.id,capturedAt:new Date(1700000000000+i*2000),sensorType:'new-backrest-32x25',
  data:{matrix,physical:f.matrix,sourceMatrix:f.source,raw:wire[i].packet.slice(0,1024),
   max:Math.max(...values),min:0,avg:sum/values.length,sum,nonZeroCount:positive.length,nonZeroMin:Math.min(...positive)},
  forceMetrics:saved.force,forceDisplayMetrics:saved.display,areaMetrics:saved.area,
  captureConfig:{filterThreshold:30,resultScale:1,visibleFields:[]}};
});
await exportToXlsx(frames,{name:'靠背接入验证',matrixSize:64,totalPoints:3200,filterThreshold:30,resultScale:1},[],undefined,false,
 {continuousFrames:frames.map((f:any,i:number)=>({...f,id:f.id+100,continuousSequence:i+1}))});
assert.ok(blob);
const bytes=new Uint8Array(await (blob as Blob).arrayBuffer());
const book=XLSX.read(bytes,{type:'array'});
for(const name of ['统计摘要','连续采集数据']){
 const rows=XLSX.utils.sheet_to_json(book.Sheets[name],{header:1,raw:true,defval:''}) as any[][];
 const header=rows[2];
 assert.equal(new Set(header).size,header.length,'No duplicate export headers');
 for(let i=0;i<14;i++){
  const row=rows[3+i];
  const get=(label:string)=>{const col=header.indexOf(label);assert.ok(col>=0,label);return row[col];};
  assert.ok(Math.abs(get('总压力候选（N）')-wire[i].forceN)<1e-9);
  assert.equal(get('接触面积（cm²）'),wire[i].expectedAreaCm2);
  assert.equal(get('总力汇总方式'),'total_only');
  assert.equal(get('显示力汇总方式'),'total_only');
  assert.equal(get('总力模型版本'),backrestTotalForceModelVersion);
  assert.equal(get('分区总力（N）'),'');
  assert.equal(get('原始字节长度'),1024);
 }
}
fs.writeFileSync(path.join(audit,'接入后标准与连续采集导出验证.xlsx'),bytes);
fs.writeFileSync(path.join(audit,'export-verification.json'),JSON.stringify({standardFrames:14,continuousFrames:14,
 forceAndAreaColumnsMatch:true,aggregationMetadataPreserved:true,rawAdcIncluded:true}));
console.log('PASS 14帧标准/连续XLSX导出：总力、面积、模型版本、总力汇总方式、原始ADC与采集记录一致。');
