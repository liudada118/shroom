import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  BACKREST_SEGMENTS,
  calculatePressureMetricsFromMatrix,
  calculateWeightPointPressuresFromMatrix,
  DEFAULT_HUMAN_COEFFICIENT,
  estimateAvgPressureAuto,
  getAvgFitInfoAuto,
  getMaxFitInfoAuto,
  getPressureInputFromMatrix,
  HUMAN_VALID_POINT_THRESHOLD,
  SEAT_SEGMENTS,
} from "../client/src/lib/pressureFit";
import { computeMatrixSummary } from "../client/src/lib/statistics";

type Sensor = "seat" | "backrest";

function assertEqual(name: string, actual: unknown, expected: unknown): void {
  if (actual !== expected) throw new Error(`${name}：期望 ${expected}，实际 ${actual}`);
  console.log(`PASS ${name}: ${String(actual)}`);
}

function assertClose(name: string, actual: number | null | undefined, expected: number, epsilon = 1e-9): void {
  if (actual === null || actual === undefined || Math.abs(actual - expected) > epsilon) {
    throw new Error(`${name}：期望 ${expected}，实际 ${actual}`);
  }
  console.log(`PASS ${name}: ${actual}`);
}

function assertContains(name: string, source: string, expected: string): void {
  if (!source.includes(expected)) throw new Error(`${name}：未找到 ${expected}`);
  console.log(`PASS ${name}: ${expected}`);
}

function assertNotContains(name: string, source: string, forbidden: string): void {
  if (source.includes(forbidden)) throw new Error(`${name}：仍包含 ${forbidden}`);
  console.log(`PASS ${name}: 未包含 ${forbidden}`);
}

function roundPressure(value: number): number {
  return Number(Math.max(0, value).toFixed(2));
}

const seatSegments = [
  { lo: 60.2350214583333, hi: 67.7811886783854, a: 2.2732, b: 0.059583227735165, c: 0, d: 0 },
  { lo: 67.7811886783854, hi: 75.3273558984375, a: 2.722825, b: 0.0633830683108733, c: 0, d: 0 },
  { lo: 75.3273558984375, hi: 82.8735231184896, a: 3.20112423239383, b: 0.0663622296976314, c: 0, d: 0 },
  { lo: 82.8735231184896, hi: 90.4196903385417, a: 3.70190471478767, b: 0.0693413910843896, c: 0, d: 0 },
  { lo: 90.4196903385417, hi: 97.9658575585938, a: 4.2251664471815, b: 0.0723205524711478, c: 0, d: 0 },
  { lo: 97.9658575585938, hi: 105.512024778646, a: 4.77090942957533, b: 0.075299713857906, c: 0, d: 0 },
  { lo: 105.512024778646, hi: 113.058191998698, a: 5.33913366196916, b: 0.0782788752446643, c: 0, d: 0 },
  { lo: 113.058191998698, hi: 120.60435921875, a: 5.929839144363, b: 0.125356717547255, c: 0, d: 0 },
  { lo: 120.60435921875, hi: 128.150526438802, a: 6.87580189713142, b: 0.128335878934012, c: 0, d: 0 },
  { lo: 128.150526438802, hi: 135.696693658854, a: 7.84424589989983, b: 0.155522523731217, c: 0, d: 0 },
  { lo: 135.696693658854, hi: 143.242860878906, a: 9.01784487046011, b: 0.158501685117975, c: 0, d: 0 },
  { lo: 143.242860878906, hi: 150.789028098958, a: 10.2139250910204, b: 0.336096346245174, c: 0, d: 0 },
  { lo: 150.789028098958, hi: 158.33519531901, a: 12.750164321835, b: 0.339075507631933, c: 0, d: 0 },
  { lo: 158.33519531901, hi: 165.881362539062, a: 15.3088848026496, b: 0.342054669018692, c: 0, d: 0 },
  { lo: 165.881362539062, hi: 173.427529759115, a: 17.8900865334642, b: 0.480599177497908, c: 0, d: 0 },
  { lo: 173.427529759115, hi: 180.973696979167, a: 21.5167682926829, b: 0.72662472847762, c: 0, d: 0 },
] as const;

const backSegments = [
  { lo: 64.93, hi: 77.99578947368421, a: 2.171199999999999, b: 0.04000000000000015 },
  { lo: 77.99578947368421, hi: 107.9942105263158, a: 2.693831578947369, b: 0.07152099258507517 },
  { lo: 107.9942105263158, hi: 116.5842105263158, a: 4.839348428616596, b: 0.07452099258507523 },
  { lo: 116.5842105263158, hi: 128.00263157894736, a: 5.479483754922392, b: 0.14953903662226653 },
  { lo: 128.00263157894736, hi: 135.86894736842106, a: 7.186983438880322, b: 0.1525390366222664 },
  { lo: 135.86894736842106, hi: 142.54315789473685, a: 8.386903671173163, b: 0.15553903662226615 },
  { lo: 142.54315789473685, hi: 148.77052631578945, a: 9.42500394665051, b: 0.15853903662226654 },
  { lo: 148.77052631578945, hi: 154.32736842105265, a: 10.412284936816114, b: 0.2465713823659119 },
  { lo: 154.32736842105265, hi: 159.07789473684213, a: 11.782443176299966, b: 0.2495713823659125 },
  { lo: 159.07789473684213, hi: 162.78105263157894, a: 12.96803859589719, b: 0.39822322147755757 },
  { lo: 162.78105263157894, hi: 165.38210526315788, a: 14.442722062379335, b: 0.4012232214775568 },
  { lo: 165.38210526315788, hi: 170.20105263157893, a: 15.486324778454113, b: 0.40422322147755524 },
  { lo: 170.20105263157893, hi: 173.70842105263156, a: 17.434255207848057, b: 0.44139613105542036 },
  { lo: 173.70842105263156, hi: 175.1836842105263, a: 18.982394059086648, b: 0.5020594652919378 },
  { lo: 175.1836842105263, hi: 178.69052631578947, a: 19.72306389130418, b: 0.5050594652919369 },
  { lo: 178.69052631578947, hi: 180.56894736842105, a: 21.49422768985164, b: 0.5080594652919352 },
  { lo: 180.56894736842105, hi: 181.79736842105265, a: 22.448577285444756, b: 0.5110594652919322 },
  { lo: 181.79736842105265, hi: 189.43, a: 23.076373491756016, b: 0.514059465291931 },
] as const;

function expectedBase(adc: number, sensor: Sensor): number | null {
  if (!Number.isFinite(adc) || adc <= 0) return null;
  if (sensor === "seat") {
    if (adc <= seatSegments[0].lo) return Math.max(0, 0.04192811827872 * (adc - 6.018421875000001));
    if (adc > seatSegments.at(-1)!.hi) return 27;
    const segment = seatSegments.find((item) => adc <= item.hi)!;
    const dx = adc - segment.lo;
    return Math.min(27, Math.max(0, segment.a + segment.b * dx + segment.c * dx ** 2 + segment.d * dx ** 3));
  }
  if (adc <= backSegments[0].lo) return Math.max(0, 0.033439088248883412 * adc);
  if (adc > backSegments.at(-1)!.hi) return 27;
  const segment = backSegments.find((item) => adc <= item.hi) ?? backSegments[0];
  const dx = adc - segment.lo;
  return Math.min(27, Math.max(0, segment.a + segment.b * dx));
}

for (const [adc, pressure] of [
  [60.2350214583333, 2.27],
  [67.7811886783854, 2.72],
  [75.3273558984375, 3.2],
  [82.8735231184896, 3.7],
  [90.4196903385417, 4.23],
  [97.9658575585938, 4.77],
  [105.512024778646, 5.34],
  [113.058191998698, 5.93],
  [120.60435921875, 6.88],
  [128.150526438802, 7.84],
  [135.696693658854, 9.02],
  [143.242860878906, 10.21],
  [150.789028098958, 12.75],
  [158.33519531901, 15.31],
  [165.881362539062, 17.89],
  [173.427529759115, 21.52],
  [180.973696979167, 27],
  [210, 27],
] as const) {
  assertEqual(`坐垫处理版E/G验收点 ADC=${adc}`, estimateAvgPressureAuto(adc, 40, "endi-23x23"), pressure);
}

for (const [adc, pressure] of [
  [64.93, 2.17],
  [77.99578947368421, 2.69],
  [107.9942105263158, 4.84],
  [116.5842105263158, 5.48],
  [128.00263157894736, 7.19],
  [135.86894736842106, 8.39],
  [142.54315789473685, 9.43],
  [148.77052631578945, 10.41],
  [154.32736842105265, 11.78],
  [159.07789473684213, 12.97],
  [162.78105263157894, 14.44],
  [165.38210526315788, 15.49],
  [170.20105263157893, 17.43],
  [173.70842105263156, 18.98],
  [175.1836842105263, 19.72],
  [178.69052631578947, 21.49],
  [180.56894736842105, 22.45],
  [181.79736842105265, 23.08],
  [189.43, 27],
  [220, 27],
] as const) {
  assertEqual(`靠背处理版E/G验收点 ADC=${adc}`, estimateAvgPressureAuto(adc, 40, "new-backrest-32x25"), pressure);
}

for (const [name, segments] of [["坐垫", SEAT_SEGMENTS], ["靠背", BACKREST_SEGMENTS]] as const) {
  const minimumSlopeIncrease = name === "坐垫" ? 0.002979 : 0.003;
  for (let index = 0; index < segments.length; index += 1) {
    const segment = segments[index];
    if (segment.b <= 0) throw new Error(`${name}第${index + 1}段斜率不是正斜率：${segment.b}`);
    if (index > 0 && segment.b - segments[index - 1].b < minimumSlopeIncrease - 1e-12) {
      throw new Error(`${name}第${index + 1}段补偿后斜率增量不足${minimumSlopeIncrease}：${segments[index - 1].b} → ${segment.b}`);
    }
  }
  console.log(`PASS ${name}全部${segments.length}段斜率逐段增加且满足ADC域对应最小增量`);
}

for (const [name, sensorType, startAdc, clampAdc] of [
  ["坐垫", "endi-23x23", 31, 180],
  ["靠背", "new-backrest-32x25", 31, 189],
] as const) {
  let previous = estimateAvgPressureAuto(startAdc, 40, sensorType)!;
  for (let adc = startAdc + 1; adc <= clampAdc; adc += 1) {
    const current = estimateAvgPressureAuto(adc, 40, sensorType)!;
    if (current <= previous) throw new Error(`${name}整数ADC=${adc}未严格上升：${previous} → ${current}`);
    previous = current;
  }
  console.log(`PASS ${name}整数ADC在27kPa钳位前逐级严格上升`);
}

const seatInput = getPressureInputFromMatrix([Array.from({ length: 80 }, (_, index) => index + 1)], "endi-23x23");
assertEqual("坐垫取第5—70位共66点", seatInput.topCount, 66);
assertClose("坐垫第5—70位均值", seatInput.topMean, 43.5);
const backInput = getPressureInputFromMatrix([Array.from({ length: 50 }, (_, index) => index + 1)], "new-backrest-32x25");
assertEqual("靠背取TOP46共46点", backInput.topCount, 46);
assertClose("靠背TOP46均值", backInput.topMean, 27.5);

function verifyWeightDistribution(name: string, matrix: number[][], sensorType: string, sensor: Sensor): void {
  const distribution = calculateWeightPointPressuresFromMatrix(matrix, sensorType);
  const input = getPressureInputFromMatrix(matrix, sensorType);
  const expectedAverage = expectedBase(input.topMean, sensor)!;
  const actualAverage = distribution.pointPressuresKPa.reduce((sum, value) => sum + value, 0) / distribution.pointPressuresKPa.length;
  const expectedResponses = matrix.flat().filter((value) => value > 0).map((value) => expectedBase(value, sensor)!);
  const expectedResponseMean = expectedResponses.reduce((sum, value) => sum + value, 0) / expectedResponses.length;
  const expectedScale = expectedAverage / expectedResponseMean;
  const expectedMax = Math.max(...expectedResponses) * expectedScale;
  assertClose(`${name}目标平均压强`, distribution.targetAveragePressureKPa, expectedAverage);
  assertClose(`${name}逐点平均严格守恒`, actualAverage, expectedAverage, 1e-12);
  assertClose(`${name}均值守恒误差`, distribution.meanConservationErrorKPa, 0, 1e-12);
  assertClose(`${name}归一化系数`, distribution.normalizationScale, expectedScale);
  assertClose(`${name}最大压强取MAX(Pi)`, distribution.maxPressureKPa, expectedMax);
  assertEqual(`${name}逐点数量覆盖全部有效点`, distribution.pointPressuresKPa.length, input.validCount);
  assertEqual(`${name}无异常回退`, distribution.fallbackMode, "none");

  const metrics = calculatePressureMetricsFromMatrix(matrix, sensorType);
  assertEqual(`${name}整帧平均压强`, metrics.avgPressureKPa, roundPressure(expectedAverage));
  assertEqual(`${name}整帧最大压强`, metrics.maxPressureKPa, roundPressure(expectedMax));
  assertEqual(`${name}砝码段返回逐点数量`, metrics.pointPressureCount, input.validCount);
}

verifyWeightDistribution(
  "坐垫砝码段",
  [[255, 254, 253, 252, ...Array(66).fill(150), ...Array(30).fill(60)]],
  "endi-23x23",
  "seat",
);
verifyWeightDistribution(
  "靠背砝码段",
  [[220, 219, 218, 217, ...Array(42).fill(170), ...Array(54).fill(80)]],
  "new-backrest-32x25",
  "backrest",
);

const seatEqualDistribution = calculateWeightPointPressuresFromMatrix([Array(20).fill(150)], "endi-23x23");
assertClose("等ADC坐垫逐点压强等于拟合平均", seatEqualDistribution.maxPressureKPa, seatEqualDistribution.targetAveragePressureKPa!);

const thresholdMatrix = [
  ...Array.from({ length: 70 }, () => [200]),
  ...Array.from({ length: HUMAN_VALID_POINT_THRESHOLD - 70 }, () => [1]),
];
const thresholdMetrics = calculatePressureMetricsFromMatrix(thresholdMatrix, "endi-23x23", 6);
assertEqual("有效点数300进入砝码段", thresholdMetrics.calibrationBranch, "weight");
assertEqual("砝码段300点全部获得Pi", thresholdMetrics.pointPressureCount, 300);
assertClose("砝码段300点AVG(Pi)=Pbar", thresholdMetrics.meanConservationErrorKPa, 0, 1e-12);

const humanMatrix = [...thresholdMatrix, [1]];
const humanMetrics = calculatePressureMetricsFromMatrix(humanMatrix, "endi-23x23");
const expectedHumanSum = humanMatrix.flat().reduce((sum, adc) => sum + expectedBase(adc, "seat")! * DEFAULT_HUMAN_COEFFICIENT, 0);
assertEqual("有效点数301进入真人段", humanMetrics.calibrationBranch, "human");
assertEqual("真人段保持逐点基础公式×k平均", humanMetrics.avgPressureKPa, roundPressure(expectedHumanSum / 301));
assertEqual("真人段保持逐点最大值", humanMetrics.maxPressureKPa, roundPressure(27 * DEFAULT_HUMAN_COEFFICIENT));
assertEqual("真人段不返回砝码归一化系数", humanMetrics.normalizationScale, undefined);
assertEqual("真人段返回全部逐点压强", humanMetrics.pointPressuresKPa?.length, 301);
assertEqual("真人段压强矩阵保持原行数", humanMetrics.pressureMatrixKPa?.length, humanMatrix.length);
assertClose("真人段压强矩阵逐点执行k×F(ADC)", humanMetrics.pressureMatrixKPa?.[0]?.[0], 27 * DEFAULT_HUMAN_COEFFICIENT);

const backrestHumanMatrix = Array.from({ length: HUMAN_VALID_POINT_THRESHOLD + 1 }, () => [220]);
const backrestHumanMetrics = calculatePressureMetricsFromMatrix(backrestHumanMatrix, "new-backrest-32x25", 3.1);
assertEqual("靠背301点进入真人段", backrestHumanMetrics.calibrationBranch, "human");
assertEqual("靠背真人段平均逐点执行k×F(ADC)", backrestHumanMetrics.avgPressureKPa, 83.7);
assertEqual("靠背真人段最大逐点执行k×F(ADC)", backrestHumanMetrics.maxPressureKPa, 83.7);
assertClose("靠背真人段压强矩阵使用27kPa基础钳位后乘k", backrestHumanMetrics.pressureMatrixKPa?.[0]?.[0], 83.7);

const seatSummary = computeMatrixSummary([[255, 254, 253, 252, ...Array(66).fill(150), ...Array(30).fill(60)]], "endi-23x23");
assertClose("矩阵摘要透传砝码归一化系数", seatSummary.normalizationScale, calculateWeightPointPressuresFromMatrix([[255, 254, 253, 252, ...Array(66).fill(150), ...Array(30).fill(60)]], "endi-23x23").normalizationScale!);
assertClose("矩阵摘要透传均值守恒误差", seatSummary.meanConservationErrorKPa, 0, 1e-12);

const weightAvgInfo = getAvgFitInfoAuto("endi-23x23", 100);
const weightMaxInfo = getMaxFitInfoAuto("endi-23x23", 100);
assertContains("砝码平均公式说明显示AVG(Pi)守恒", weightAvgInfo.formula, "AVG(Pᵢ)=P̄");
assertContains("砝码最大公式说明显示MAX(Pi)", weightMaxInfo.formula, "MAX(Pᵢ)");
assertContains("砝码最大公式说明不二次钳制", weightMaxInfo.note, "不再执行27.00 kPa二次钳制");
const humanInfo = getAvgFitInfoAuto("endi-23x23", 301, 4.2);
assertContains("真人段公式说明仍显示动态系数", humanInfo.formula, "4.2");

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const homeSource = readFileSync(resolve(projectRoot, "client/src/pages/Home.tsx"), "utf8");
const xlsxSource = readFileSync(resolve(projectRoot, "client/src/lib/xlsxExport.ts"), "utf8");
const pressureFitSource = readFileSync(resolve(projectRoot, "client/src/lib/pressureFit.ts"), "utf8");
const statisticsSource = readFileSync(resolve(projectRoot, "client/src/lib/statistics.ts"), "utf8");
const captureStorageSource = readFileSync(resolve(projectRoot, "client/src/lib/captureStorage.ts"), "utf8");
assertContains("采集缓存保存归一化系数", captureStorageSource, "pressureNormalizationScale");
assertContains("实时链路使用矩阵压强统一入口", homeSource, "calculatePressureMetricsFromMatrix");
assertContains("串口演示统一执行可配置补偿后过滤", homeSource, "compensateAndFilterAdcMatrix(processed.matrix, sensorType, adcCompensationSettings)");
assertContains("页面显示当前补偿配置说明", homeSource, "getAdcCompensationDisplayNote(sensorType, adcCompensationSettings)");
assertContains("CSV仍从矩阵重算压强", homeSource, "interpolationMetrics.calibrationBranch");
assertContains("XLSX仍从矩阵重算压强", xlsxSource, "metrics.maxPressureKPa");
const pressureChainSource = [homeSource, xlsxSource, pressureFitSource, statisticsSource, captureStorageSource].join("\n");
for (const forbidden of [
  "regionCalibration",
  "pressureRegionCoefficient",
  "detectRegionFromMatrix",
  "DEFAULT_SEAT_REGION_CALIBRATION",
  "DEFAULT_BACKREST_REGION_CALIBRATION",
  "区域标定",
]) {
  assertNotContains("区域标定链路已删除", pressureChainSource, forbidden);
}

console.log("V2.7.67：原始数据留档与补偿后标定隔离 + 可配置ADC补偿 + 砝码逐点归一化守恒 + 双传感器凸分段 + 27kPa钳位 + 双分支回归完成。");
