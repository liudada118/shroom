import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  DEFAULT_HUMAN_COEFFICIENT,
  calculatePressureMetricsFromMatrix,
} from "../client/src/lib/pressureFit";
import { valueToColor } from "../client/src/lib/colorMap";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const homeSource = fs.readFileSync(path.join(root, "client/src/pages/Home.tsx"), "utf8");
const heatmapSource = fs.readFileSync(path.join(root, "client/src/components/Heatmap.tsx"), "utf8");

function assert(condition: unknown, label: string): asserts condition {
  if (!condition) throw new Error(`FAIL ${label}`);
  console.log(`PASS ${label}`);
}
assert(valueToColor(0.1).every(Number.isFinite), "0—1低压色值可安全映射");
assert(valueToColor(Number.NaN).every(Number.isFinite), "NaN色值安全回退背景色");
assert(valueToColor(Number.POSITIVE_INFINITY).every(Number.isFinite), "无穷色值安全回退背景色");
const weightMatrix = Array.from({ length: 10 }, (_, row) =>
  Array.from({ length: 10 }, (_, column) => 80 + row * 8 + column),
);
const weightMetrics = calculatePressureMetricsFromMatrix(weightMatrix, "new-seat-23x23", DEFAULT_HUMAN_COEFFICIENT);
assert(weightMetrics.calibrationBranch === "weight", "100点进入砝码段");
assert(weightMetrics.pressureMatrixKPa?.length === 10, "砝码段返回逐点压强矩阵");
assert(weightMetrics.pressureMatrixKPa?.every((row) => row.length === 10), "砝码段压强矩阵保持列数");
assert(weightMetrics.pointPressureCount === 100, "砝码段压强矩阵覆盖全部有效点");

const humanMatrix = Array.from({ length: 7 }, (_, row) =>
  Array.from({ length: 43 }, (_, column) => 80 + ((row + column) % 110)),
);
const humanMetrics = calculatePressureMetricsFromMatrix(humanMatrix, "new-seat-23x23", DEFAULT_HUMAN_COEFFICIENT);
assert(humanMetrics.calibrationBranch === "human", "301点进入真人段");
assert(humanMetrics.pressureMatrixKPa?.length === 7, "真人段返回逐点压强矩阵");
assert(humanMetrics.pressureMatrixKPa?.every((row) => row.length === 43), "真人段压强矩阵保持列数");
assert(humanMetrics.pointPressureCount === 301, "真人段压强矩阵覆盖全部有效点");

for (const token of [
  'useState<"adc" | "pressure">("adc")',
  'heatmapValueMode === "pressure"',
  'matrix: activeHeatmapMatrix',
  'colorMax={activeHeatmapColorMax}',
  'valueUnit={showPressureHeatmap ? "kPa" : ""}',
  '热图：{heatmapValueMode === "pressure" ? "压强 kPa" : "ADC"}',
]) {
  assert(homeSource.includes(token), `主页热力图切换接线：${token}`);
}

for (const token of [
  "colorMax?: number",
  "valueFormatter?: (value: number) => string",
  "valueUnit?: string",
  "(val / colorMax) * 255",
  "valueFormatter(val)",
]) {
  assert(heatmapSource.includes(token), `热力图动态显示能力：${token}`);
}

console.log("V2.7.55：ADC/逐点压强热力图切换、低值色谱安全映射与双分支压力矩阵回归完成。");
