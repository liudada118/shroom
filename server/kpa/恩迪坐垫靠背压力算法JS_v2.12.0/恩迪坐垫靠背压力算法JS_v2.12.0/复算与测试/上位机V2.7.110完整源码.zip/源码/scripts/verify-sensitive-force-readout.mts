import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {build} from 'esbuild';
import {ForceReadout,captureForceReadout,forceReadoutExportValues,FORCE_READOUT_EXPORT_HEADERS,FORCE_READOUT_VERSION,FORCE_READOUT_INTERVAL_MS} from '../client/src/lib/forceReadout';
import type {ContinuousForceFrame} from '../client/src/lib/sensorForce';
const audit=process.argv[2];assert.ok(audit);
const state=JSON.parse(fs.readFileSync(path.join(audit,'paths.json'),'utf8'));
const prior=await build({stdin:{contents:fs.readFileSync(path.join(state.backup,'source/client/src/lib/forceReadout.ts'),'utf8'),loader:'ts',resolveDir:path.resolve('client/src/lib')},bundle:true,platform:'node',format:'esm',write:false});
const {ForceReadout:Previous}=await import('data:text/javascript;base64,'+Buffer.from(prior.outputFiles[0].contents).toString('base64'));
function raw(forceN:number):ContinuousForceFrame {
 return {algorithmId:'synthetic',algorithmLabel:'synthetic',modelVersion:'frozen-test-model',status:forceN>0?'candidate_requires_validation':'no_contact',
 forceN,regionForcesN:[],forceAggregation:'total_only',areaCm2:18.75,averagePressureKPa:forceN*.5,seedCount:2,
 inputMode:'synthetic',accepted:false,independentlyValidated:false,forceEstimateComplete:true,forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',scopeNote:'Synthetic display response, not force accuracy',
 contactPressure:{version:'test',method:'raw_adc_share_then_region_arithmetic_mean',status:'estimated',scope:'complete_frame',independentlyValidated:false,
 totalForceN:forceN,areaCm2:18.75,rawAdcSum:40,assignedRawAdcSum:40,
 regions:[.25,.75].map((s,i)=>({index:i,center:[i,i] as [number,number],rawAdcSum:40*s,forceShare:s,estimatedForceN:forceN*s,areaCm2:[6.25,12.5][i],estimatedPressureKPa:10*forceN*s/[6.25,12.5][i]})),averagePressureKPa:forceN*.5,globalAreaMeanPressureKPa:10*forceN/18.75}};
}
type Point={timeMs:number;forceN:number};
function stream(Ctor:any,samples:Point[]) {
 const filter=new Ctor(),shown:Point[]=[];
 const record=(v:any,t:number)=>{if(!v)return;shown.push({timeMs:t,forceN:v.forceN});
  assert.ok(Math.abs(v.contactPressure.averagePressureKPa-v.forceN*.5)<1e-9);
  assert.ok(Math.abs(v.contactPressure.regions.reduce((s:number,r:any)=>s+r.estimatedForceN,0)-v.forceN)<1e-9);};
 for(const s of samples){
  while(filter.pendingPublishAt()!==null&&filter.pendingPublishAt()<=s.timeMs){const t=filter.pendingPublishAt();record(filter.flush(t),t);}
  const r=raw(s.forceN),before=JSON.stringify(r);record(filter.update('live',{},r,s.timeMs,s.timeMs),s.timeMs);
  assert.equal(JSON.stringify(r),before);
 }
 for(let i=0;i<3&&filter.pendingPublishAt()!==null;i++){const t=filter.pendingPublishAt();record(filter.flush(t),t);}
 return shown;
}
const steps:any[]=[],traces:any={};
for(const period of [12.5,50,100])for(const [initial,target] of [[100,150],[150,100],[15,31],[100,100.1]]){
 const samples=Array.from({length:Math.ceil(2000/period)+1},(_,i)=>({timeMs:i*period,forceN:i*period<1000?initial:target}));
 const old=stream(Previous,samples),current=stream(ForceReadout,samples);
 const response=(s:Point[])=>s.find(p=>p.timeMs>=1000&&Math.abs(p.forceN-target)<=Math.abs(target-initial)*.1)!.timeMs-1000;
 const oldMs=response(old),newMs=response(current);assert.ok(newMs<=FORCE_READOUT_INTERVAL_MS);assert.ok(newMs<oldMs);
 const first=current.find(p=>p.timeMs>=1000&&p.forceN!==initial)!;assert.equal(first.forceN,target,'The first changed published step must retain its amplitude');
 steps.push({periodMs:period,initialN:initial,targetN:target,previous90PercentMs:oldMs,current90PercentMs:newMs});
 if(period===50&&target===150)traces.step={raw:samples,previous:old,current};
}
const filter=new ForceReadout();filter.update('test',{},raw(100),0,0);
assert.equal(filter.update('test',{},raw(150),5,5),null);
assert.equal(filter.update('test',{},raw(100),10,10),null);
assert.equal(filter.pendingPublishAt(),20);
const pulse=filter.flush(20)!;assert.equal(pulse.forceN,150);assert.equal(pulse.sourceFrameTimestamp,5);
assert.equal(filter.flush(40)!.forceN,100);assert.equal(filter.pendingPublishAt(),null);
// A peak immediately followed by zero is published once, then zero. No stale
// peak is resurrected after that; the hold is bounded by two publication slots.
filter.update('test',{},raw(160),45,45);assert.equal(filter.update('test',{},raw(0),46,46),null);
assert.equal(filter.flush(60)!.forceN,160);assert.equal(filter.flush(80)!.forceN,0);assert.equal(filter.pendingPublishAt(),null);
filter.reset();filter.update('zero-pulse',{},raw(0),0,0);
assert.equal(filter.update('zero-pulse',{},raw(150),5,5)!.forceN,150);
assert.equal(filter.update('zero-pulse',{},raw(0),5,5),null);
assert.equal(filter.flush(25)!.forceN,0);
const pulseSamples=Array.from({length:101},(_,i)=>({timeMs:i*10,forceN:i===51?150:100}));
const oldPulse=stream(Previous,pulseSamples),newPulse=stream(ForceReadout,pulseSamples);
assert.equal(Math.max(...oldPulse.map(p=>p.forceN)),100);assert.equal(Math.max(...newPulse.map(p=>p.forceN)),150);
traces.pulse={raw:pulseSamples,previous:oldPulse,current:newPulse};
const ramp=Array.from({length:201},(_,i)=>({timeMs:i*10,forceN:100+Math.min(50,Math.max(0,i*10-500)*.05)}));
const oldRamp=stream(Previous,ramp),newRamp=stream(ForceReadout,ramp);
const lag=(s:Point[])=>{const a=s.filter(p=>p.timeMs>=700&&p.timeMs<=1500);return a.reduce((v,p)=>v+100+(p.timeMs-500)*.05-p.forceN,0)/a.length;};
assert.ok(lag(newRamp)<=.6);assert.ok(lag(newRamp)<lag(oldRamp));traces.ramp={raw:ramp,previous:oldRamp,current:newRamp};
const noise=Array.from({length:1001},(_,i)=>({timeMs:i*10,forceN:100+.2*Math.sin(i*2*Math.PI/7)+.1*Math.sin(i*1.718)}));
const oldNoise=stream(Previous,noise),newNoise=stream(ForceReadout,noise);
const std=(a:number[])=>{const m=a.reduce((s,v)=>s+v,0)/a.length;return Math.sqrt(a.reduce((s,v)=>s+(v-m)**2,0)/a.length);};
const noiseRaw=noise.filter(p=>p.timeMs>1000).map(p=>p.forceN),noiseShown=newNoise.filter(p=>p.timeMs>1000).map(p=>p.forceN);
assert.ok(std(noiseShown)<std(noiseRaw));assert.ok(Math.abs(noiseShown.reduce((s,v)=>s+v,0)/noiseShown.length-100)<.3);
traces.noise={raw:noise,previous:oldNoise,current:newNoise};
const unchanged=raw(100),before=JSON.stringify(unchanged),identity={};filter.reset();
const first=filter.update('source',identity,unchanged,0,0)!;assert.equal(filter.update('source',identity,unchanged,10,10),null);
assert.equal(filter.update('other',{},raw(80),11,11)!.forceN,80);
assert.equal(filter.update('other',{},raw(55),1700,1700)!.forceN,55);
assert.equal(filter.update('other',{},raw(85),1701,1701,false)!.forceN,85);
assert.equal(JSON.stringify(unchanged),before);
filter.reset();const regional={...raw(100),contactPressure:undefined,forceAggregation:'regional_sum' as const,regionForcesN:[30,70],regionCenters:[[1,1],[20,20]] as [number,number][]};
filter.update('regions',{},regional,0,0);
assert.deepEqual(filter.update('regions',{},{...regional,regionForcesN:[70,30],regionCenters:[[20,20],[1,1]]},20,20)!.regionForcesN,[70,30]);
const removed=filter.update('regions',{},{...regional,forceN:30,regionForcesN:[30],regionCenters:[[1,1]]},21,21)!;assert.equal(removed.forceN,30);
const meta=captureForceReadout(removed)!;assert.equal(meta.mode,'fast-attack-light-release');assert.equal(meta.medianWindow,1);assert.equal(meta.publishIntervalMs,20);
assert.equal(forceReadoutExportValues(meta).length,FORCE_READOUT_EXPORT_HEADERS.length);
const result={filterVersion:FORCE_READOUT_VERSION,publishIntervalMs:20,stepTests:steps,
 singleFramePulse:{previousPeakN:Math.max(...oldPulse.map(p=>p.forceN)),currentPeakN:Math.max(...newPulse.map(p=>p.forceN)),inputPeakN:150},
 intervalPeakPreserved:true,latestValueAfterPeak:true,zeroUnloadMaximumSoftwareHoldMs:40,zeroToPeakToZeroPreserved:true,sourceAndGapReset:true,regionalTrackingPassed:true,
 pressureForceAligned:true,rawUnmodified:true,exportMetadataPassed:true,
 noise:{rawStdN:std(noiseRaw),currentStdN:std(noiseShown),meanDisplayN:noiseShown.reduce((s,v)=>s+v,0)/noiseShown.length},
 rampMeanLagN:{previous:lag(oldRamp),current:lag(newRamp)},
 scope:'Software display response; upward noise spikes are retained; not physical response or calibration accuracy acceptance'};
fs.writeFileSync(path.join(audit,'sensitive-dynamics-result.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(audit,'sensitive-dynamics-traces.json'),JSON.stringify(traces));
console.log(JSON.stringify(result,null,2));
