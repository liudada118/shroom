import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {predictSeatRegionalCompensatedForce,SEAT_REGIONAL_COMPENSATION_VERSION} from '../client/src/lib/seatRegionalCompensation';
import {predictSeatTotalForce} from '../client/src/lib/seatTotalForce';
import {analyzeSeatArea,SEAT_AREA_VERSION} from '../client/src/lib/seatArea';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {calculateSeatRegionPressure} from '../client/src/lib/seatRegionPressure';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {ForceReadout} from '../client/src/lib/forceReadout';

const root=process.argv[2],out=path.join(root,'上位机试用接入');
const read=(p:string)=>JSON.parse(fs.readFileSync(p,'utf8'));
const state=read(path.join(out,'integration-paths.json'));
const historical=path.join(root,'..','..','坐垫边界面积重标定');
const force=read(path.join(historical,'重标定力值原始ADC与标签.json'));
const oldArea=read(path.join(historical,'重标定面积原始ADC与标签.json'));
const referenceArea=read(path.join(historical,'python-area-predictions.json'));
const current=read(path.join(root,'..','当前复测原始ADC与标签.json'));
const reload=read(path.join(root,'..','独立2块重新放置原始ADC与对比.json'));
const close=(a:number,b:number,t=1e-7)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const rotate=<T>(m:T[][],turns:number)=>{for(let i=0;i<turns;i++)m=m[0].map((_,c)=>m.map(row=>row[c]).reverse());return m;};
const mirror=<T>(m:T[][])=>m.map(row=>row.slice().reverse());
const point=([r,c]:number[],turns:number,mirrored:boolean):[number,number]=>{
 for(let i=0;i<turns;i++){const next=c;c=45-r;r=next;}return [r,mirrored?45-c:c];
};
const config=getSensorConfig('endi-23x23');
const areaKey=(r:any)=>JSON.stringify([r.file,r.index]);
const areaByKey=new Map(oldArea.map((r:any,i:number)=>[areaKey(r),{...r,reference:referenceArea[i]}]));
const frames=[...force.map((v:any)=>({...v,source:areaByKey.get(areaKey(v))!.source,expectedContacts:areaByKey.get(areaKey(v))!.expectedContacts,group:'historical'})),
 ...current.map((v:any)=>({...v,group:'current'})),...reload.map((v:any)=>({...v,group:'reload_development'}))];
let maxAreaDifference=0,orientationChecks=0,stableCount=0,multi=0,selectionChecks=0;
const predictions:any[]=[],areas:any[]=[],durations:number[]=[];
for(let i=0;i<frames.length;i++){
 const r=frames[i],before=hash(r),area=analyzeSeatArea(r.source);
 const decoded=Array.from({length:23},(_,row)=>Array.from({length:23},(_,col)=>r.raw[config.wireMap[row*23+col]]));
 assert.ok(hash(decoded)===hash(r.physical),`raw mapping ${i} ${r.file}`);assert.ok(hash(lineInterp2x2(r.physical,23,23))===hash(r.source),`source interpolation ${i} ${r.file}`);
 if(i<oldArea.length){
  const prior=areaByKey.get(areaKey(r))!.reference;close(area.areaCm2,prior.areaCm2,1e-10);
  assert.equal(area.seedCount,prior.seedCount);assert.deepEqual(area.areaMatrixCm2,prior.areaMatrixCm2);
  maxAreaDifference=Math.max(maxAreaDifference,Math.abs(area.areaCm2-prior.areaCm2));
 }
 const native=predictSeatRegionalCompensatedForce(r.source,r.physical);
 const t=performance.now();
 const live=calculateLiveSensorForce(config.type,r.source,r.physical,area.areaCm2,{area,rotation:0})!;
 durations.push(performance.now()-t);close(live.forceN,native.forceN,0);
 assert.equal(live.modelVersion,SEAT_REGIONAL_COMPENSATION_VERSION);
 assert.equal(live.accepted,false);assert.equal(live.independentlyValidated,false);
 assert.equal(live.forceAggregation,'total_only');assert.deepEqual(live.regionForcesN,[]);
 if(area.seedCount>1)multi++;
 for(let rotation=0;rotation<4;rotation++)for(const mirrored of [false,true]){
  const rotated=analyzeSeatArea(rotate(r.source,rotation),{rotation});
  const contextArea=mirrored?{...rotated,seeds:rotated.seeds.map(p=>point(p,0,true)),
   areaMatrixCm2:mirror(rotated.areaMatrixCm2),retainedMask:mirror(rotated.retainedMask),
   regions:rotated.regions.map(region=>({...region,seedCol:45-region.seedCol}))}:rotated;
  const context={area:contextArea,rotation,mirrorColumns:mirrored};
  const prediction=predictSeatRegionalCompensatedForce(r.source,r.physical,context);
  close(prediction.forceN,native.forceN,1e-9);orientationChecks++;
  const pipeline=calculateLiveSensorForce(config.type,r.source,r.physical,area.areaCm2,context)!;
  close(pipeline.forceN,native.forceN,1e-9);
  const pressure=calculateSeatRegionPressure(r.physical,native.forceN,context);
  assert.deepEqual(pipeline.contactPressure,pressure);
  close(pressure.regions.reduce((s,v)=>s+v.estimatedForceN,0),native.forceN);
  close(pressure.averagePressureKPa!,pressure.regions.reduce((s,v)=>s+10*v.estimatedForceN/v.areaCm2,0)/pressure.regions.length);
 }
 const selection=analyzeSeatArea(r.source,{selection:{startRow:6,startCol:7,endRow:34,endCol:33}});
 const selected=calculateLiveSensorForce(config.type,r.source,r.physical,selection.areaCm2,{area:selection,rotation:0})!;
 close(selected.forceN,native.forceN,0);selectionChecks++;
 const shown=new ForceReadout().update('fixture',r.physical,live,100,100,true)!;
 close(shown.forceN,native.forceN,0);
 const known=r.mass_kg!==null&&r.mass_kg!==undefined&&!['unknown_weight','moving_candidate_excluded'].includes(r.phase);
 if(known)stableCount++;
 predictions.push({file:r.file,index:r.index,group:r.group,phase:r.phase,massKg:r.mass_kg,
  referenceForceN:known?r.mass_kg*9.80665:null,...native,errorN:known?native.forceN-r.mass_kg*9.80665:null});
 areas.push({file:r.file,index:r.index,group:r.group,areaCm2:area.areaCm2,regions:area.regions.map(v=>({areaCm2:v.areaCm2,thresholdAdc:v.thresholdAdc})),seedCount:area.seedCount});
 assert.equal(hash(r),before);
}
// A context changed on the same raw frame must not reuse its old cached result.
const r=frames[0],a=analyzeSeatArea(r.source),changed={...a,seeds:[[0,0]] as [number,number][]};
const changedExpected=predictSeatRegionalCompensatedForce(r.source,r.physical,{area:changed,rotation:0});
const changedLive=calculateLiveSensorForce(config.type,r.source,r.physical,a.areaCm2,{area:changed,rotation:0})!;
close(changedLive.forceN,changedExpected.forceN,0);
const zero=Array.from({length:23},()=>Array(23).fill(0)),zeroSource=lineInterp2x2(zero,23,23);
const empty=predictSeatRegionalCompensatedForce(zeroSource,zero);assert.equal(empty.forceN,0);assert.equal(empty.reason,'no_contact');
for(const level of [.01,255]){
 const physical=Array.from({length:23},()=>Array(23).fill(level)),source=lineInterp2x2(physical,23,23);
 const p=predictSeatRegionalCompensatedForce(source,physical,level===255?{area:{...analyzeSeatArea(source),seeds:[[22,22]]},rotation:0}:undefined);
 assert.equal(p.applied,false);assert.equal(p.correctionN,0);close(p.forceN,predictSeatTotalForce(physical),0);
 assert.ok(Number.isFinite(p.forceN)&&p.forceN>=0);
}
const bad=zero.map(row=>row.slice());bad[0][0]=NaN;
assert.throws(()=>predictSeatRegionalCompensatedForce(zeroSource,bad));
for(const [relative,digest] of Object.entries(state.protectedHashes))
 assert.equal(createHash('sha256').update(fs.readFileSync(path.join(state.source,relative))).digest('hex'),digest,relative);

const chosen=[...Array.from({length:5},(_,i)=>frames.find((r:any)=>r.group==='current'&&r.blocks===i+1)),
 frames.find((r:any)=>r.group==='reload_development'),
 ...Array.from({length:4},(_,i)=>frames.find((r:any)=>r.expectedContacts===i+2)),
 frames.find((r:any)=>r.mass_kg===16.5)];
assert.ok(chosen.every(Boolean));
const fixtures=chosen.map((r:any)=>{
 const area=analyzeSeatArea(rotate(r.source,3),{rotation:3});
 const live=calculateLiveSensorForce(config.type,r.source,r.physical,area.areaCm2,{area,rotation:3})!;
 return {file:r.file,index:r.index,sensorType:config.type,forceN:live.forceN,expectedAreaCm2:area.areaCm2,
  packet:[...r.raw,170,85,3,153],contactPressure:live.contactPressure};
});
fs.writeFileSync(path.join(out,'browser-wire-fixtures.json'),JSON.stringify(fixtures));
fs.writeFileSync(path.join(out,'上位机区域补偿逐帧对比.json'),JSON.stringify(predictions));
fs.writeFileSync(path.join(out,'上位机原面积逐帧检查.json'),JSON.stringify(areas));
const stats=(group:string)=>{const rows=predictions.filter(r=>r.group===group&&r.errorN!==null);return {frames:rows.length,within1N:rows.filter(r=>Math.abs(r.errorN)<=1).length,maxAbsErrorN:Math.max(...rows.map(r=>Math.abs(r.errorN)))};};
const result={version:'V2.7.80',forceModelVersion:SEAT_REGIONAL_COMPENSATION_VERSION,areaVersion:SEAT_AREA_VERSION,
 rawFrames:frames.length,stableKnownFrames:stableCount,orientationChecks,selectionChecks,multiContactFrames:multi,
 baselineAreaFramesCompared:oldArea.length,maxAreaDifferenceCm2:maxAreaDifference,protectedUnchanged:Object.keys(state.protectedHashes).length,
 originalAdcPreserved:true,rawMappingPassed:true,regionForceShareConserved:true,pressureFormulaUnchanged:true,
 contextCacheVerified:true,forceReadoutPassed:true,zeroAndFallbackPassed:true,areaAlgorithmUnchanged:true,
 browserFixtures:fixtures.length,accuracyAccepted:false,independentAcceptancePassed:false,
 accuracy:{historical:stats('historical'),current:stats('current'),reloadDevelopment:stats('reload_development')},
 liveCachedAreaComputationTimeMs:{median:durations.sort((a,b)=>a-b)[Math.floor(durations.length/2)],max:Math.max(...durations)}};
fs.writeFileSync(path.join(out,'integration-verification.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
