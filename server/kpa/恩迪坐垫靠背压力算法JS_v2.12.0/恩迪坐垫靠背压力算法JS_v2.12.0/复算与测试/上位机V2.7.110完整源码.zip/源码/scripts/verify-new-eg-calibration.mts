import XLSX from "xlsx-js-style";
import { compensateAdcValueWithoutFilter } from "../client/src/lib/adcCompensation";
import { estimateAvgPressureAuto } from "../client/src/lib/pressureFit";

interface SensorCase {
  name: string;
  path: string;
  sensorType: string;
  expectedCount: number;
  expectedCapAdc: number;
  maxAllowedError: number;
  expectedWithinTolerance: number;
  maxAllowedRmse: number;
}

const TOLERANCE_KPA = 2.5;

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(message);
  console.log(`PASS ${message}`);
}

function readEgRows(path: string): Array<{ adc: number; pressure: number }> {
  const workbook = XLSX.readFile(path);
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<unknown[]>(worksheet, { header: 1, raw: true });
  return rows.slice(3).flatMap((row) => {
    const adc = Number(row[4]);
    const pressure = Number(row[6]);
    return Number.isFinite(adc) && Number.isFinite(pressure) ? [{ adc, pressure }] : [];
  });
}

const cases: SensorCase[] = [
  {
    name: "坐垫",
    path: "/home/ubuntu/upload/坐垫处理版.xlsx",
    sensorType: "endi-23x23",
    expectedCount: 40,
    expectedCapAdc: 180.973696979167,
    maxAllowedError: 2.42,
    expectedWithinTolerance: 40,
    maxAllowedRmse: 0.79,
  },
  {
    name: "靠背",
    path: "/home/ubuntu/upload/靠背处理版.xlsx",
    sensorType: "new-backrest-32x25",
    expectedCount: 50,
    expectedCapAdc: 189.43,
    maxAllowedError: 2.5,
    expectedWithinTolerance: 50,
    maxAllowedRmse: 0.9,
  },
];

for (const item of cases) {
  const rows = readEgRows(item.path);
  assert(rows.length === item.expectedCount, `${item.name}第一张工作表E/G有效记录=${item.expectedCount}`);
  const predictions = rows.map((row) => {
    const correctedAdc = compensateAdcValueWithoutFilter(row.adc, item.sensorType);
    return estimateAvgPressureAuto(correctedAdc, 40, item.sensorType);
  });
  assert(predictions.every((value) => value !== null), `${item.name}全部E列均可计算压强`);
  const errors = predictions.map((value, index) => value! - rows[index].pressure);
  const absoluteErrors = errors.map(Math.abs);
  const rmse = Math.sqrt(errors.reduce((sum, value) => sum + value ** 2, 0) / errors.length);
  const maxError = Math.max(...absoluteErrors);
  const withinTolerance = absoluteErrors.filter((value) => value <= TOLERANCE_KPA + 1e-9).length;
  assert(maxError <= item.maxAllowedError, `${item.name}全样本最大绝对误差=${maxError.toFixed(3)}kPa`);
  assert(rmse <= item.maxAllowedRmse, `${item.name}全样本RMSE=${rmse.toFixed(3)}kPa`);
  assert(withinTolerance === item.expectedWithinTolerance, `${item.name}逐帧±2.50kPa达标=${withinTolerance}/${rows.length}`);
  assert(estimateAvgPressureAuto(item.expectedCapAdc, 40, item.sensorType) === 27, `${item.name}高端边界输出27.00kPa`);
  assert(estimateAvgPressureAuto(255, 40, item.sensorType) === 27, `${item.name}高ADC固定钳位27.00kPa`);
}

console.log("V2.7.65：实时统计补偿口径 + 逐帧ADC补偿后双传感器凸分段、27kPa钳位与±2.50kPa回归完成。");
