import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { analyzeBackrestArea } from "../client/src/lib/backrestArea";
import { calculateLiveSensorForce } from "../client/src/lib/sensorForce";
import { calculateBackrestRegionPressure, rescaleBackrestRegionPressure, capturedAveragePressureKPa,
  REGION_PRESSURE_EXPORT_HEADERS, regionPressureExportValues } from "../client/src/lib/backrestRegionPressure";
import { ForceReadout, captureForceReadout } from "../client/src/lib/forceReadout";

const [baseline, output] = process.argv.slice(2);
assert.ok(baseline && output, "Pass baseline fixture folder and new output folder");
const read = (name: string) => JSON.parse(fs.readFileSync(path.join(baseline,name),"utf8"));
const write = (name: string, value: unknown) => fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2));
const transpose = (m: number[][]) => m[0].map((_,c) => m.map(row => row[c]));
const close = (a: number,b: number,t=1e-9) => assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const zeros = (r: number,c: number) => Array.from({length:r},()=>Array(c).fill(0));

// Independently specified force shares/areas have an analytically known answer.
const physical = zeros(25,32), source = zeros(50,64);
physical[5][5]=10; physical[20][25]=30; // Below display threshold must still count.
const template = analyzeBackrestArea(source);
const area = {...template,seeds:[[10,10],[40,50]] as [number,number][],seedCount:2,areaCm2:75,
  regions:[25,50].map((retainedCellCount,index)=>({index,seedRow:index?40:10,seedCol:index?50:10,
    retainedCellCount,thresholdAdc:30,positiveCellCount:1,supportAbove5:1,countAbove30:0,features:null}))};
const two = calculateBackrestRegionPressure(source,physical,100,area);
assert.deepEqual(two.regions.map(r=>r.rawAdcSum),[10,30]);
assert.deepEqual(two.regions.map(r=>r.estimatedForceN),[25,75]);
assert.deepEqual(two.regions.map(r=>r.estimatedPressureKPa),[10,15]);
assert.equal(two.averagePressureKPa,12.5);
close(two.globalAreaMeanPressureKPa!,1000/75);
assert.notEqual(two.averagePressureKPa,two.globalAreaMeanPressureKPa,"Mean must be equal by contact, not area weighted");
assert.equal(rescaleBackrestRegionPressure(two,200).averagePressureKPa,25);
const equal = calculateBackrestRegionPressure(source,physical,100,{...area,areaCm2:100,
  regions:area.regions.map((r,i)=>({...r,retainedCellCount:i?75:25}))});
assert.equal(equal.averagePressureKPa,10);
const one = calculateBackrestRegionPressure(source,physical,100,{...area,seeds:[[10,10]],seedCount:1,
  regions:[{...area.regions[0],retainedCellCount:50}],areaCm2:50});
assert.equal(one.averagePressureKPa,20);
const incomplete=calculateBackrestRegionPressure(source,physical,100,{...area,
  regions:area.regions.map((r,i)=>({...r,retainedCellCount:i?0:25})),areaCm2:25});
assert.equal(incomplete.status,"incomplete"); assert.equal(incomplete.averagePressureKPa,null);
assert.equal(capturedAveragePressureKPa({forceMetrics:{contactPressure:incomplete},avgPressureKPa:99},99),null);
assert.equal(capturedAveragePressureKPa({avgPressureKPa:7},8),8,"Legacy capture interpretation retained");
assert.equal(capturedAveragePressureKPa({forceMetrics:{contactPressure:two}},99),12.5);
assert.equal(calculateBackrestRegionPressure(source,zeros(25,32),0).status,"no_contact");
assert.equal(regionPressureExportValues(two).length,REGION_PRESSURE_EXPORT_HEADERS.length);

const fixtures=read("integration-fixtures.json");
const comparisons=fixtures.map((f:any)=>{
  const nativeS=transpose(f.source), nativeP=transpose(f.matrix);
  const originalArea=analyzeBackrestArea(nativeS);
  const force=calculateLiveSensorForce("new-backrest-32x25",nativeS,nativeP,originalArea.areaCm2)!;
  const p=force.contactPressure!;
  assert.equal(force.forceN,f.referenceForceN,"Total-force regression is unchanged");
  assert.equal(p.areaCm2,originalArea.areaCm2);
  assert.equal(p.regions.reduce((s,r)=>s+r.areaCm2,0),originalArea.areaCm2);
  assert.equal(p.rawAdcSum,nativeP.flat().reduce((s,v)=>s+v,0));
  if(p.regions.length)assert.equal(p.assignedRawAdcSum,p.rawAdcSum);
  if(p.status==="estimated"){
    close(p.regions.reduce((s,r)=>s+r.estimatedForceN,0),force.forceN);
    // Compare against the direct equation using independently supplied areas and Qs.
    const mean = p.regions.reduce((s,r)=>s+10*f.referenceForceN*r.rawAdcSum/p.rawAdcSum/r.areaCm2,0)/p.regions.length;
    close(p.averagePressureKPa!,mean);
    const readout=new ForceReadout();
    const first=readout.update("test",{},force,0,0)!;
    const snapshot=captureForceReadout(first)!;
    close(snapshot.contactPressure!.averagePressureKPa!,mean);
    assert.notEqual(snapshot.contactPressure,first.frame.contactPressure,"Capture must be a separate snapshot");
    const doubled=readout.update("test",{},{...force,forceN:2*force.forceN},50,50,false)!;
    close(doubled.frame.averagePressureKPa!,2*mean);
  }else assert.equal(p.averagePressureKPa,null);
  return {file:f.file,index:f.index,massKg:f.mass_kg,forceN:force.forceN,areaCm2:originalArea.areaCm2,
    regionCount:p.regions.length,status:p.status,newAveragePressureKPa:p.averagePressureKPa,
    oldGlobalAreaMeanPressureKPa:p.globalAreaMeanPressureKPa,contactPressure:p};
});
const wire=read("browser-wire-fixtures.json");
const expected=wire.map((f:any)=>{
  const p=comparisons.find((r:any)=>r.file===f.file&&r.index===f.index);
  assert.ok(p); return {...f,contactPressure:p.contactPressure};
});
write("browser-wire-fixtures.json",expected);
write("region-pressure-comparison.json",comparisons);
const csv=(v:any)=>'"'+String(v??"").replaceAll('"','""')+'"';
const rows=[["源文件","帧序号","总力N","原面积cm²","区域数","状态","接触区等权平均kPa","旧总力除总面积kPa","各区原始ADC总和","各区分力N","各区原面积cm²","各区估算压强kPa"],
  ...comparisons.map((r:any)=>[r.file,r.index,r.forceN,r.areaCm2,r.regionCount,r.status,r.newAveragePressureKPa,
    r.oldGlobalAreaMeanPressureKPa,r.contactPressure.regions.map((v:any)=>v.rawAdcSum).join(";"),
    r.contactPressure.regions.map((v:any)=>v.estimatedForceN).join(";"),
    r.contactPressure.regions.map((v:any)=>v.areaCm2).join(";"),
    r.contactPressure.regions.map((v:any)=>v.estimatedPressureKPa??"--").join(";")])];
fs.writeFileSync(path.join(output,"全部676帧区域压强对比.csv"),"\ufeff"+rows.map(r=>r.map(csv).join(",")).join("\r\n"));
const summary={frames:comparisons.length,estimated:comparisons.filter((r:any)=>r.status==="estimated").length,
  incomplete:comparisons.filter((r:any)=>r.status==="incomplete").length,
  multiRegion:comparisons.filter((r:any)=>r.regionCount>1).length,
  formulaTests:"passed",rawAdcIncludesBelowDisplayThreshold:true,forcesAndAreasConserved:true,
  nullAndLegacyCaptureCompatibility:true,displaySnapshotSynchronized:true,independentRegionalAccuracyAccepted:false};
write("region-pressure-result.json",summary);
console.log(JSON.stringify(summary,null,2));
