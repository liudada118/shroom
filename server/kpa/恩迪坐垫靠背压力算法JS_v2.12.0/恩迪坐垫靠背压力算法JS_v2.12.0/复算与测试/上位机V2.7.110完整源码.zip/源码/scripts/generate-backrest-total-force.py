"""Export frozen inference parameters; never fit or modify the model here."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('model', type=Path)
args = parser.parse_args()
raw = args.model.read_bytes()
model = json.loads(raw)
assert model['input_shape'] == [25, 32]
assert len(model['feature_names']) == 12 and len(model['trees']) == 350
for tree in model['trees']:
    for feature, value, left, right in tree:
        assert feature < 12
        if feature >= 0:
            assert 0 <= left < len(tree) and 0 <= right < len(tree)
inference = {k: model[k] for k in ['version', 'row_budget', 'baseline_N', 'feature_names', 'trees']}
target = Path(__file__).resolve().parents[1] / 'client/src/lib/backrestTotalForce.generated.ts'
header = '''// Generated from 力值拟合参数.json; do not edit or refit here.
// SHA256: %s
// Leaf values include the learning rate. Calibration passes ±5N; grouped validation fails.
type Node = [feature: number, thresholdOrLeaf: number, left: number, right: number];
interface Parameters { version: string; row_budget: number; baseline_N: number; feature_names: string[]; trees: Node[][] }
export const backrestTotalForceModel: Parameters = ''' % hashlib.sha256(raw).hexdigest()
target.write_text(header + json.dumps(inference, ensure_ascii=False, separators=(',', ':')) + ';\n', encoding='utf-8')
print(str(target))
