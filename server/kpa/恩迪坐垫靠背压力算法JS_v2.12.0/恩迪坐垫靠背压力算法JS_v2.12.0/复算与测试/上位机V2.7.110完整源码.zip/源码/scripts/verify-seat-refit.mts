import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {extractSeatForceFeatures,predictSeatTotalForce,seatTotalForceModelVersion} from '../client/src/lib/seatTotalForce';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {calculateSeatRegionPressure} from '../client/src/lib/seatRegionPressure';
import {getSensorConfig,lineInterp2x2} from '../client/src/lib/sensorConfig';
import {compensateAndFilterAdcMatrix,createDefaultAdcCompensationSettings} from '../client/src/lib/adcCompensation';
import {ForceReadout} from '../client/src/lib/forceReadout';
import {applyFilter} from '../client/src/lib/dataFilter';

const out=process.argv[2];assert.ok(out);
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(out,name),'utf8'));
const frames=read('坐垫原始ADC与标签.json'),refs=read('坐垫逐帧拟合结果.json');
const config=getSensorConfig('endi-23x23'),context:any={};
vm.runInNewContext(fs.readFileSync('client/public/dummyArea_v2.10.36.js','utf8'),context);const api=context.DummyAreaV21036;
const hash=(value:unknown)=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const close=(a:number,b:number,t=1e-8)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const rotate=(m:number[][])=>m[0].map((_,c)=>m.map(row=>row[c]).reverse());
const zeros=(n:number)=>Array.from({length:n},()=>Array(n).fill(0));
// Actual original-area components with unequal areas and analytically known shares.
let sample=zeros(46);for(let r=10;r<12;r++)for(let c=10;c<12;c++)sample[r][c]=80;
for(let r=39;r<41;r++)for(let c=39;c<43;c++)sample[r][c]=100;
const physical=zeros(23);physical[5][5]=10;physical[20][20]=30;
let originalMean:number|null=null;
for(let rotation=0;rotation<4;rotation++){
 const area=api.calculateDummyDisplayedAreaFrame(sample,null),p=calculateSeatRegionPressure(physical,100,{area,rotation});
 assert.equal(p.regions.length,2);close(p.averagePressureKPa!,50);close(p.globalAreaMeanPressureKPa!,1000/18.75);
 assert.deepEqual([...p.regions.map(r=>r.rawAdcSum)].sort((a,b)=>a-b),[10,30]);
 if(originalMean!==null)close(p.averagePressureKPa!,originalMean);originalMean=p.averagePressureKPa;
 sample=rotate(sample);
}
const emptyArea=api.calculateDummyDisplayedAreaFrame(zeros(46),null);
const empty=calculateLiveSensorForce(config.type,zeros(46),zeros(23),0,{area:emptyArea,rotation:0})!;
assert.equal(empty.forceN,0);assert.equal(empty.contactPressure!.status,'no_contact');assert.equal(empty.averagePressureKPa,null);
const noArea=calculateSeatRegionPressure(physical,100,{area:emptyArea,rotation:0});
assert.equal(noArea.status,'incomplete');assert.equal(noArea.averagePressureKPa,null);
assert.throws(()=>predictSeatTotalForce([[1]]));
assert.equal(calculateLiveSensorForce(config.type,[[0]],zeros(23)),null);
let maxPythonDifferenceN=0,maxFeatureDifference=0;
const results=frames.map((f:any,i:number)=>{
 const before=hash(f),ref=refs[i];assert.equal(ref.file,f.file);assert.equal(ref.index,f.index);
 const decoded=Array.from({length:23},(_,r)=>Array.from({length:23},(_,c)=>f.raw[config.wireMap[r*23+c]]));
 assert.deepEqual(decoded,f.physical);assert.deepEqual(lineInterp2x2(decoded,23,23),f.source);
 const area=api.calculateDummyDisplayedAreaFrame(f.areaInput,null);
 assert.equal(hash(area),hash(f.baselineArea),'Full original area, masks and thresholds must remain identical');
 const rotation=Number(f.savedPhysicalOrientation.match(/rotate(\d+)/)[1])/90;
 const predicted=calculateLiveSensorForce(config.type,f.source,f.physical,area.areaCm2,{area,rotation,mirrorColumns:f.savedPhysicalOrientation.includes('mirrorColumns')})!;
 close(predicted.forceN,ref.forceN);maxPythonDifferenceN=Math.max(maxPythonDifferenceN,Math.abs(predicted.forceN-ref.forceN));
 extractSeatForceFeatures(f.physical).forEach((v,j)=>{close(v,ref.features[j]);maxFeatureDifference=Math.max(maxFeatureDifference,Math.abs(v-ref.features[j]));});
 if(ref.errorN!==null)assert.ok(Math.abs(predicted.forceN-f.referenceForceN)<=5);
 assert.equal(predicted.forceAggregation,'total_only');assert.deepEqual(predicted.regionForcesN,[]);
 assert.equal(predicted.independentlyValidated,false);assert.equal(predicted.accepted,false);assert.equal(predicted.areaCm2,area.areaCm2);
 const p=predicted.contactPressure!;
 assert.equal(p.regions.reduce((s,r)=>s+r.areaCm2,0),area.areaCm2);
 if(p.status==='estimated'){
   close(p.regions.reduce((s,r)=>s+r.estimatedForceN,0),predicted.forceN);
   close(p.averagePressureKPa!,p.regions.reduce((s,r)=>s+10*r.estimatedForceN/r.areaCm2,0)/p.regions.length);
   const filter=new ForceReadout(),shown=filter.update('seat',{},predicted,0,0)!;
   close(shown.contactPressure!.averagePressureKPa!,p.averagePressureKPa!);
   const double=filter.update('seat',{},{...predicted,forceN:2*predicted.forceN},100,100,false)!;
   close(double.contactPressure!.averagePressureKPa!,2*p.averagePressureKPa!);
 }
 assert.equal(hash(f),before,'Raw ADC and original capture must be retained');
 return {...ref,areaCm2:area.areaCm2,contactPressure:p,averagePressureKPa:p.averagePressureKPa};
});
const selected:any[]=[];
const seven=frames.find((f:any)=>f.kind==='七级加载').file;
selected.push(...frames.filter((f:any)=>f.file===seven));
for(const mass of [3.25,4.875,6.5,8.125])selected.push(frames.find((f:any)=>f.kind==='平铺'&&f.mass_kg===mass));
for(const mass of [1.625,3.25,4.875,6.5,8.125])selected.push(frames.find((f:any)=>f.kind==='新增连续实测'&&f.mass_kg===mass));
const settings=createDefaultAdcCompensationSettings();
const wire=selected.map(f=>{
  const displayed=applyFilter(rotate(rotate(rotate(compensateAndFilterAdcMatrix(f.source,config.type,settings)))),{threshold:30,calibrationMode:'none',resultScale:1}).filteredMatrix;
  const area=api.calculateDummyDisplayedAreaFrame(displayed,null),forceN=predictSeatTotalForce(f.physical);
  const p=calculateSeatRegionPressure(f.physical,forceN,{area,rotation:3});
  assert.equal(p.status,'estimated');
  return {file:f.file,index:f.index,massKg:f.mass_kg,forceN,expectedAreaCm2:area.areaCm2,
    packet:[...f.raw,170,85,3,153],contactPressure:p,sensorType:config.type};
});
const audit=path.join(out,'上位机接入验证');
fs.writeFileSync(path.join(audit,'browser-wire-fixtures.json'),JSON.stringify(wire));
fs.writeFileSync(path.join(audit,'seat-integration-comparison.json'),JSON.stringify(results));
const known=results.filter((r:any)=>r.errorN!==null);
const summary={modelVersion:seatTotalForceModelVersion,frames:frames.length,labelledFrames:known.length,unknownWeightFrames:frames.length-known.length,
 within5N:known.filter((r:any)=>Math.abs(r.errorN)<=5).length,maxAbsErrorN:Math.max(...known.map((r:any)=>Math.abs(r.errorN))),
 maxPythonDifferenceN,maxFeatureDifference,originalAreaFramesUnchanged:frames.length,originalRawAdcPreserved:true,
 regionMeanFormulaPassed:true,unequalAreaAndRotationTestsPassed:true,emptyAndMissingAreaPassed:true,
 estimatedRegionPressureFrames:results.filter((r:any)=>r.contactPressure.status==='estimated').length,
 multiRegionFrames:results.filter((r:any)=>r.contactPressure.regions.length>1).length,
 browserFixtures:wire.length,independentAcceptancePassed:false};
fs.writeFileSync(path.join(audit,'seat-integration-result.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary,null,2));
