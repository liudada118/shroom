import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  ADC_COMPENSATION_VERSION,
  ADC_POST_COMPENSATION_FILTER_THRESHOLD,
  DEFAULT_BACKREST_ADC_COMPENSATION,
  DEFAULT_SEAT_ADC_COMPENSATION,
  compensateAdcValueWithoutFilter,
  compensateAndFilterAdcMatrix,
  compensateAndFilterAdcValue,
  createDefaultAdcCompensationSettings,
  getAdcCompensationFingerprint,
  normalizeAdcCompensationSettings,
  summarizeAdcMatrix,
} from "../client/src/lib/adcCompensation";
import { calculatePressureMetricsFromMatrix, estimateAvgPressureAuto } from "../client/src/lib/pressureFit";
import { APP_VERSION } from "../client/src/lib/version";

function assert(condition: boolean, message: string): void {
  if (!condition) throw new Error(message);
  console.log(`PASS ${message}`);
}

function assertClose(actual: number | null | undefined, expected: number, message: string, epsilon = 1e-9): void {
  if (actual === null || actual === undefined || Math.abs(actual - expected) > epsilon) {
    throw new Error(`${message}：期望${expected}，实际${actual}`);
  }
  console.log(`PASS ${message}: ${actual}`);
}

const legacySeatSegments = [
  { lo: 53.84, hi: 61.33375, a: 2.2732, b: 0.06000000000000003 },
  { lo: 61.33375, hi: 68.8275, a: 2.7228250000000003, b: 0.06382641966890193 },
  { lo: 68.8275, hi: 76.32125, a: 3.201124232393834, b: 0.06682641966890183 },
  { lo: 76.32125, hi: 83.815, a: 3.7019047147876676, b: 0.06982641966890177 },
  { lo: 83.815, hi: 91.30875, a: 4.2251664471815, b: 0.07282641966890172 },
  { lo: 91.30875, hi: 98.8025, a: 4.770909429575332, b: 0.07582641966890165 },
  { lo: 98.8025, hi: 106.29625, a: 5.339133661969163, b: 0.07882641966890166 },
  { lo: 106.29625, hi: 113.79, a: 5.929839144362996, b: 0.12623356167051475 },
  { lo: 113.79, hi: 121.28375, a: 6.875801897131416, b: 0.1292335616705143 },
  { lo: 121.28375, hi: 128.7775, a: 7.844245899899832, b: 0.15661037138419087 },
  { lo: 128.7775, hi: 136.27125, a: 9.017844870460113, b: 0.15961037138419065 },
  { lo: 136.27125, hi: 143.765, a: 10.213925091020393, b: 0.3384472701670871 },
  { lo: 143.765, hi: 151.25875, a: 12.750164321834994, b: 0.3414472701670874 },
  { lo: 151.25875, hi: 158.7525, a: 15.308884802649617, b: 0.3444472701670879 },
  { lo: 158.7525, hi: 166.24625, a: 17.890086533464224, b: 0.4839608686196772 },
  { lo: 166.24625, hi: 173.74, a: 21.516768292682933, b: 0.7317073170731694 },
] as const;

function legacySeatPressure(rawAdc: number): number | null {
  if (rawAdc <= 0) return null;
  if (rawAdc <= legacySeatSegments[0].lo) return Math.max(0, 0.042221396731054977 * rawAdc);
  if (rawAdc > legacySeatSegments.at(-1)!.hi) return 27;
  const segment = legacySeatSegments.find((item) => rawAdc <= item.hi)!;
  return Math.min(27, Math.max(0, segment.a + segment.b * (rawAdc - segment.lo)));
}

assert(APP_VERSION === "V2.7.79", "应用版本为V2.7.79");
assert(ADC_COMPENSATION_VERSION === "ConfigurableAffine-20260903", "可配置补偿版本正确");
assert(ADC_POST_COMPENSATION_FILTER_THRESHOLD === 30, "补偿后固定过滤阈值为30");
assert(DEFAULT_SEAT_ADC_COMPENSATION.enabled, "坐垫默认启用JSON一次函数补偿");
assert(!DEFAULT_BACKREST_ADC_COMPENSATION.enabled, "靠背默认关闭补偿并保持恒等输入");

const defaults = createDefaultAdcCompensationSettings();
assertClose(compensateAdcValueWithoutFilter(81, "endi-23x23", defaults), 87.585, "默认坐垫JSON端点81→87.585");
assertClose(compensateAdcValueWithoutFilter(177, "endi-23x23", defaults), 184.2565, "默认坐垫JSON端点177→184.2565");
assert(compensateAndFilterAdcValue(23, "endi-23x23", defaults) === 0, "默认坐垫原ADC23补偿后≤30被过滤");
assert(compensateAndFilterAdcValue(24, "endi-23x23", defaults) > 30, "默认坐垫原ADC24补偿后>30被保留");
assert(compensateAndFilterAdcValue(30, "new-backrest-32x25", defaults) === 0, "默认靠背ADC30被过滤");
assert(compensateAndFilterAdcValue(31, "new-backrest-32x25", defaults) === 31, "默认靠背关闭补偿时ADC31原值保留");

const custom = normalizeAdcCompensationSettings({
  ...defaults,
  seat: { ...defaults.seat, enabled: false },
  backrest: { ...defaults.backrest, enabled: true, scale: 1.2, offset: -5 },
});
assert(compensateAdcValueWithoutFilter(100, "endi-23x23", custom) === 100, "坐垫补偿关闭后ADC保持原值");
assertClose(compensateAdcValueWithoutFilter(100, "new-backrest-32x25", custom), 115, "靠背补偿开启后应用自定义倍率与偏移");
assert(getAdcCompensationFingerprint(custom) !== getAdcCompensationFingerprint(defaults), "补偿参数修改会生成不同采集指纹");
const clamped = normalizeAdcCompensationSettings({
  ...defaults,
  seat: { ...defaults.seat, scale: 0, offset: 5000 },
});
assertClose(clamped.seat.scale, 0.001, "非法补偿倍率限制到最小正值");
assertClose(clamped.seat.offset, 1000, "补偿偏移限制在合法范围");

const rawMatrix = [[0, 23, 24, 81, 119.21431334622824, 177]];
const snapshot = rawMatrix.map((row) => row.slice());
const correctedMatrix = compensateAndFilterAdcMatrix(rawMatrix, "endi-23x23", defaults);
assert(JSON.stringify(rawMatrix) === JSON.stringify(snapshot), "补偿不修改输入矩阵");
assert(correctedMatrix[0][0] === 0 && correctedMatrix[0][1] === 0, "补偿后过滤位置保持0");
const stats = summarizeAdcMatrix(correctedMatrix);
assert(stats.nonZeroCount === 4, "补偿过滤后重算有效点数");
assertClose(stats.max, 184.2565, "补偿过滤后重算最大ADC");

let maximumEquivalenceError = 0;
for (let index = 96; index <= 1020; index++) {
  const rawAdc = index / 4;
  const correctedAdc = compensateAndFilterAdcValue(rawAdc, "endi-23x23", defaults);
  const legacyPressure = legacySeatPressure(rawAdc)!;
  const correctedPressure = estimateAvgPressureAuto(correctedAdc, 40, "endi-23x23")!;
  maximumEquivalenceError = Math.max(maximumEquivalenceError, Math.abs(correctedPressure - Number(legacyPressure.toFixed(2))));
}
assert(maximumEquivalenceError <= 1e-9, `默认坐垫补偿后节点变换保持两位压力完全等价，最大差${maximumEquivalenceError}`);

const weightMatrix = [Array.from({ length: 300 }, (_, index) => 31 + (index % 145))];
const weightMetrics = calculatePressureMetricsFromMatrix(weightMatrix, "endi-23x23", 2.2);
assert(weightMetrics.calibrationBranch === "weight", "N=300进入砝码段");
assert(Number.isFinite(weightMetrics.normalizationScale), "砝码段返回逐点归一化系数");
assert(Math.abs(weightMetrics.meanConservationErrorKPa ?? 1) <= 1e-12, "砝码逐点归一化严格保持AVG(Pi)=Pbar");
const humanMatrix = [Array.from({ length: 301 }, (_, index) => 31 + (index % 145))];
const humanMetrics = calculatePressureMetricsFromMatrix(humanMatrix, "endi-23x23", 2.2);
assert(humanMetrics.calibrationBranch === "human" && humanMetrics.normalizationScale === undefined, "N=301进入真人段且不套用砝码归一化");

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const homeSource = readFileSync(resolve(projectRoot, "client/src/pages/Home.tsx"), "utf8");
const heatmapSource = readFileSync(resolve(projectRoot, "client/src/components/Heatmap.tsx"), "utf8");
const captureSource = readFileSync(resolve(projectRoot, "client/src/lib/captureStorage.ts"), "utf8");
const xlsxSource = readFileSync(resolve(projectRoot, "client/src/lib/xlsxExport.ts"), "utf8");

for (const expected of [
  "compensateAndFilterAdcMatrix(processed.matrix, sensorType, adcCompensationSettings)",
  "saveAdcCompensationSettings(adcCompensationSettings)",
  "activeAdcCompensation.enabled",
  "补偿倍率",
  "补偿偏移",
  "砝码逐点归一化：已启用",
  "AVG(Pᵢ)-P̄=",
]) {
  assert(homeSource.includes(expected), `可配置补偿或归一化界面接线存在：${expected}`);
}
for (const forbidden of ["consistencyEnabled", "applyConsistencyCalibration", "showGrid", "showRegions", "detectNoise", "noiseMask"]) {
  assert(!homeSource.includes(forbidden) && !heatmapSource.includes(forbidden), `已删除功能无运行时残留：${forbidden}`);
}
for (const expected of ["const DB_VERSION = 3", "raw?: number[]", "physical?: number[][]", "sourceMatrix?: number[][]"]) {
  assert(captureSource.includes(expected), `采集缓存原始数据字段存在：${expected}`);
}
for (const forbidden of ["delete frame.data.physical", "delete frame.data.raw"]) {
  assert(!captureSource.includes(forbidden), `V3升级不再删除原始数据：${forbidden}`);
}
for (const expected of ["appendRawFrameDetails", 'book_append_sheet(wb, rawWs, "原始数据")', "frame.data.raw", "frame.data.physical", "frame.data.sourceMatrix"]) {
  assert(xlsxSource.includes(expected), `XLSX恢复原始数据留档：${expected}`);
}
for (const expected of ["const sourceRaw = new Uint8Array(frame.raw)", "raw: Array.from(frame.raw)"]) {
  assert(homeSource.includes(expected), `逐帧原始快照与采集缓存接线存在：${expected}`);
}
assert(/calculatePressureMetricsFromMatrix\(\s+processedStats\.filteredMatrix/.test(homeSource), "逐点热图和最大压强仍读取补偿后过滤矩阵");

console.log("V2.7.67原始字节/矩阵留档恢复、可配置ADC补偿、砝码归一化守恒与计算隔离专项回归完成。");
