import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';
import {ForceReadout,captureForceReadout,forceReadoutExportValues,FORCE_READOUT_EXPORT_HEADERS,FORCE_READOUT_INTERVAL_MS} from '../client/src/lib/forceReadout';
import {SEAT_DISPLAY_STABILITY_VERSION} from '../client/src/lib/seatDisplayStabilizer';
import {calculateLiveSensorForce} from '../client/src/lib/sensorForce';
import {analyzeSeatArea} from '../client/src/lib/seatArea';
import {lineInterp2x2} from '../client/src/lib/sensorConfig';
import type {ContinuousForceFrame} from '../client/src/lib/sensorForce';

const out=process.argv[2];assert.ok(out,'Pass integration output directory');
const state=JSON.parse(fs.readFileSync(path.join(out,'integration-paths.json'),'utf8'));
const task=path.dirname(path.dirname(out));
const prior=await build({stdin:{contents:fs.readFileSync(path.join(state.backup,'source/client/src/lib/forceReadout.ts'),'utf8'),loader:'ts',resolveDir:path.resolve('client/src/lib')},bundle:true,platform:'node',format:'esm',write:false});
const {ForceReadout:PriorReadout}=await import('data:text/javascript;base64,'+Buffer.from(prior.outputFiles[0].contents).toString('base64'));
const close=(a:number,b:number,t=1e-9)=>assert.ok(Math.abs(a-b)<=t,`${a} != ${b}`);
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const std=(v:number[])=>{const m=v.reduce((s,n)=>s+n,0)/v.length;return Math.sqrt(v.reduce((s,n)=>s+(n-m)**2,0)/v.length);};
const range=(v:number[])=>Math.max(...v)-Math.min(...v);

function fixture(forceN:number,adc=2400,area=62,center:[number,number]=[20,20],shares=[.4,.6]):ContinuousForceFrame {
 const regions=adc===0?[]:shares.map((share,i)=>({index:i,center:[center[0]+i*10,center[1]+i*10] as [number,number],rawAdcSum:adc*share,
 forceShare:share,estimatedForceN:forceN*share,areaCm2:area/shares.length,estimatedPressureKPa:10*forceN*share/(area/shares.length)}));
 const pressure=regions.length?regions.reduce((s,r)=>s+r.estimatedPressureKPa!,0)/regions.length:null;
 return {algorithmId:'seat-synthetic-test',algorithmLabel:'synthetic',modelVersion:'seat-frozen-test',status:adc===0?'no_contact':'candidate_requires_validation',
 forceN,regionForcesN:[],forceAggregation:'total_only',areaCm2:area,averagePressureKPa:pressure,seedCount:regions.length,inputMode:'synthetic',accepted:false,
 forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',scopeNote:'Filter dynamics only',
 contactPressure:{version:'seat-raw-adc-share-region-pressure-mean-20261028',method:'raw_adc_share_then_region_arithmetic_mean',status:adc===0?'no_contact':'estimated',
 scope:'complete_frame',independentlyValidated:false,totalForceN:forceN,areaCm2:area,rawAdcSum:adc,assignedRawAdcSum:adc,regions,
 averagePressureKPa:pressure,globalAreaMeanPressureKPa:area>0?10*forceN/area:null}};
}

function aligned(v:any) {
 close(v.areaCm2,v.frame.areaCm2);close(v.forceN,v.frame.forceN);
 if(!v.contactPressure)return;
 close(v.contactPressure.totalForceN,v.forceN);close(v.contactPressure.areaCm2,v.areaCm2);
 if(v.contactPressure.regions.length){
  close(v.contactPressure.regions.reduce((s:number,r:any)=>s+r.estimatedForceN,0),v.forceN);
  close(v.contactPressure.regions.reduce((s:number,r:any)=>s+r.areaCm2,0),v.areaCm2,1e-7);
  const mean=v.contactPressure.regions.reduce((s:number,r:any)=>s+10*r.estimatedForceN/r.areaCm2,0)/v.contactPressure.regions.length;
  close(mean,v.contactPressure.averagePressureKPa);close(mean,v.frame.averagePressureKPa);
 }
}

function run(Ctor:any,samples:{t:number;raw:ContinuousForceFrame}[],enabled=true) {
 const filter=new Ctor(),shown:any[]=[];
 for(const {t,raw} of samples){
  let deadline=filter.pendingPublishAt();
  while(deadline!==null&&deadline<t){const v=filter.flush(deadline);if(v)shown.push(v);deadline=filter.pendingPublishAt();}
  const before=hash(raw),v=filter.update('test',{},raw,t,t,enabled);assert.equal(hash(raw),before);
  if(v)shown.push(v);
 }
 let deadline=filter.pendingPublishAt();while(deadline!==null){const v=filter.flush(deadline);if(v)shown.push(v);deadline=filter.pendingPublishAt();}
 return shown;
}

const noise=Array.from({length:501},(_,i)=>({t:i*20,raw:fixture(60+1.2*Math.sin(i*.43),2400+3*Math.sin(i*.37),62+1.6*Math.sin(i*.31),[20,20],[.4+.003*Math.sin(i*.27),.6-.003*Math.sin(i*.27)])}));
const shownNoise=run(ForceReadout,noise);shownNoise.forEach(aligned);
const settled=shownNoise.filter(v=>v.displayedAt>=1000),rawSettled=noise.filter(v=>v.t>=1000);
const noiseResult={rawForceStdN:std(rawSettled.map(v=>v.raw.forceN)),displayForceStdN:std(settled.map(v=>v.forceN)),
 rawAreaStdCm2:std(rawSettled.map(v=>v.raw.areaCm2)),displayAreaStdCm2:std(settled.map(v=>v.areaCm2)),
 rawPressureStdKPa:std(rawSettled.map(v=>v.raw.averagePressureKPa!)),displayPressureStdKPa:std(settled.map(v=>v.contactPressure.averagePressureKPa))};
assert.ok(noiseResult.displayForceStdN<noiseResult.rawForceStdN*.45);
assert.ok(noiseResult.displayAreaStdCm2<noiseResult.rawAreaStdCm2*.45);
assert.ok(noiseResult.displayPressureStdKPa<noiseResult.rawPressureStdKPa*.45);
close(settled.reduce((s,v)=>s+v.forceN,0)/settled.length,rawSettled.reduce((s,v)=>s+v.raw.forceN,0)/rawSettled.length,.025);

const steps:any[]=[];
for(const period of [5,20,50,100])for(const [initial,target,initialAdc,targetAdc] of [[40,80,2400,2550],[80,40,2550,2400]]){
 const onset=1000;const samples=Array.from({length:Math.ceil(1400/period)+1},(_,i)=>({t:i*period,raw:fixture(i*period<onset?initial:target,i*period<onset?initialAdc:targetAdc,62)}));
 const shown=run(ForceReadout,samples);const response=shown.find(v=>v.displayedAt>=onset&&Math.abs(v.forceN-target)<=Math.abs(target-initial)*.1)!;
 assert.ok(response);assert.ok(response.displayedAt-onset<=20);
 steps.push({sampleIntervalMs:period,initialN:initial,targetN:target,display90PercentLatencyMs:response.displayedAt-onset});
}

// A model discontinuity without corroborating ADC movement receives smoothing.
const modelOnly=run(ForceReadout,[{t:0,raw:fixture(40)},{t:20,raw:fixture(80)}]);
assert.ok(modelOnly[1].forceN>40&&modelOnly[1].forceN<50);
assert.equal(modelOnly[1].displayChangeReason,'small-change');
// An actual short ADC pulse is shown intact even when it starts/ends inside 20 ms.
const short=run(ForceReadout,[{t:0,raw:fixture(40,2400)},{t:5,raw:fixture(80,2550)},{t:10,raw:fixture(40,2400)}]);
assert.ok(short.some(v=>v.forceN===80));assert.equal(short.at(-1).forceN,40);
const zero=run(ForceReadout,[{t:0,raw:fixture(60,2400)},{t:5,raw:fixture(0,0,0)}]);
assert.equal(zero.at(-1).forceN,0);assert.equal(zero.at(-1).areaCm2,0);assert.equal(zero.at(-1).contactPressure.averagePressureKPa,null);
assert.equal(zero.at(-1).displayedAt,20);
const moving=run(ForceReadout,[{t:0,raw:fixture(60,2400,62)},{t:20,raw:fixture(60,2400,82,[24,24])}]);
assert.equal(moving.at(-1).areaCm2,82);assert.equal(moving.at(-1).displayChangeReason,'contact-moved');
const topology=run(ForceReadout,[{t:0,raw:fixture(60)},{t:20,raw:fixture(60,2400,80,[20,20],[1])}]);
assert.equal(topology.at(-1).areaCm2,80);assert.equal(topology.at(-1).displayChangeReason,'contact-change');
// Different contact counts inside one chunk must not overwrite a short peak.
const topologyPulse=run(ForceReadout,[{t:0,raw:fixture(40,2400,62,[20,20],[1])},{t:5,raw:fixture(180,7000,186,[20,20],[.3,.3,.4])},{t:5,raw:fixture(40,2400,62,[20,20],[1])}]);
assert.ok(topologyPulse.some(v=>v.forceN===180));assert.equal(topologyPulse.at(-1).forceN,40);
const zeroTopologyPulse=run(ForceReadout,[{t:0,raw:fixture(0,0,0)},{t:5,raw:fixture(180,7000,186,[20,20],[.3,.3,.4])},{t:5,raw:fixture(0,0,0)}]);
assert.ok(zeroTopologyPulse.some(v=>v.forceN===180));assert.equal(zeroTopologyPulse.at(-1).forceN,0);
// Turning filtering off and CSV playback remain exact instantaneous snapshots.
const instant=run(ForceReadout,noise.slice(0,20),false);
instant.forEach((v,i)=>{assert.equal(v.mode,'instantaneous');assert.deepEqual(v.frame,noise[i].raw);});

// Existing non-seat/backrest behavior must remain exactly equal to the backup.
const backrest=noise.map(v=>({t:v.t,raw:{...v.raw,algorithmId:'backrest-test',modelVersion:'frozen-backrest',contactPressure:{...v.raw.contactPressure!,version:'backrest-raw-adc-share-region-pressure-mean-20261028' as const}}}));
const beforeBackrest=run(PriorReadout,backrest),afterBackrest=run(ForceReadout,backrest);
assert.deepEqual(afterBackrest,beforeBackrest,'Backrest readouts must remain byte-for-byte equivalent to V80');

const identityFilter=new ForceReadout(),identity={},raw=fixture(60);
const first=identityFilter.update('id',identity,raw,0,0)!;
assert.equal(identityFilter.update('id',identity,raw,10,10),null);
const second=identityFilter.update('id',{},fixture(60.3,2401,62.2),20,20)!;assert.equal(second.sampleSequence,2);
const metadata=captureForceReadout(second)!;assert.equal(metadata.filterVersion,SEAT_DISPLAY_STABILITY_VERSION);
assert.equal(forceReadoutExportValues(metadata).length,FORCE_READOUT_EXPORT_HEADERS.length);
assert.deepEqual(metadata.rawContactPressure,fixture(60.3,2401,62.2).contactPressure);
aligned(second);const oldSaved=hash(second);metadata.rawContactPressure!.regions[0].areaCm2=999;assert.equal(hash(second),oldSaved);

// Replay each original steady sequence independently. Timestamps are replayed at
// 20 ms for a controlled display test; these exports are not hardware timing logs.
const sourceCurrent=JSON.parse(fs.readFileSync(path.join(task,'当前复测原始ADC与标签.json'),'utf8'));
const sourceReload=JSON.parse(fs.readFileSync(path.join(task,'独立2块重新放置原始ADC与对比.json'),'utf8'));
const realGroups=new Map<string,any[]>();for(const r of [...sourceCurrent,...sourceReload]){const list=realGroups.get(r.file)??[];list.push(r);realGroups.set(r.file,list);}
const replay:any[]=[];
for(const [file,records] of realGroups){
 records.sort((a,b)=>a.index-b.index);const samples=records.map((r,i)=>{const source=lineInterp2x2(r.physical,23,23),area=analyzeSeatArea(source);const live=calculateLiveSensorForce('endi-23x23',source,r.physical,area.areaCm2,{area,rotation:0})!;assert.ok(live);return {t:i*20,raw:live};});
 const shown=run(ForceReadout,samples);shown.forEach(aligned);
 const rawForce=samples.map(r=>r.raw.forceN),displayForce=shown.map(r=>r.forceN),rawArea=samples.map(r=>r.raw.areaCm2),displayArea=shown.map(r=>r.areaCm2),rawPressure=samples.map(r=>r.raw.averagePressureKPa!),displayPressure=shown.map(r=>r.contactPressure.averagePressureKPa);
 replay.push({file,frames:records.length,samplingNote:'Original frame order, controlled 20ms interval; no accuracy acceptance',rawForceStdN:std(rawForce),displayForceStdN:std(displayForce),rawForceRangeN:range(rawForce),displayForceRangeN:range(displayForce),rawAreaStdCm2:std(rawArea),displayAreaStdCm2:std(displayArea),rawAreaRangeCm2:range(rawArea),displayAreaRangeCm2:range(displayArea),rawPressureStdKPa:std(rawPressure),displayPressureStdKPa:std(displayPressure),rawForceN:rawForce,displayForceN:displayForce});
}
const result={version:SEAT_DISPLAY_STABILITY_VERSION,publishIntervalMs:FORCE_READOUT_INTERVAL_MS,noise:noiseResult,syntheticSteps:steps,
 modelOnlyJumpSmoothed:true,adcBackedShortPeakPreserved:true,topologyChangingShortPeakPreserved:true,zeroClearedWithoutFilterTail:true,zeroPublicationLatencyMs:20,
 areaMovementAndTopologyReset:true,instantaneousAndCsvExact:true,backrestEqualToV80:true,pressureFormulaAligned:true,rawObjectsUnchanged:true,
 duplicateFramesIgnored:true,allDistinctFramesSampled:true,metadataCloneAndExportPassed:true,steadyReplays:replay,
 qualification:'Display dynamics verification only; not sensor force or area calibration accuracy acceptance'};
fs.writeFileSync(path.join(out,'seat-synchronous-display-verification.json'),JSON.stringify(result,null,2));
fs.writeFileSync(path.join(out,'seat-synchronous-display-traces.json'),JSON.stringify({noise:shownNoise,short,zero,modelOnly,moving,topology},null,2));
console.log(JSON.stringify(result,null,2));
