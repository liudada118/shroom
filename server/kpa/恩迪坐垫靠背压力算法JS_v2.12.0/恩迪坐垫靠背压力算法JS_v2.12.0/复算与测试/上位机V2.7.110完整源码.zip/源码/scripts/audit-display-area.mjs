import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { transformSync } from "esbuild";

const algorithmContext = {};
vm.runInNewContext(
  fs.readFileSync(new URL("../client/public/dummyArea_v2.10.36.js", import.meta.url), "utf8"),
  algorithmContext,
);
const api = algorithmContext.DummyAreaV21036;
const selfCheck = api.runSelfCheck();
assert.equal(selfCheck.pass, true, "Original algorithm self-check");

const wrapperCode = transformSync(
  fs.readFileSync(new URL("../client/src/lib/displayArea.ts", import.meta.url), "utf8"),
  { loader: "ts", format: "cjs" },
).code;
const wrapperContext = { window: { DummyAreaV21036: api }, module: { exports: {} } };
vm.runInNewContext(wrapperCode, wrapperContext);
const calculate = wrapperContext.module.exports.calculateDisplayedArea;
const selection = { startRow: 0, endRow: 0, startCol: 5, endCol: 8 };
const splitMatrix = [[80, 80, 80, 80, 0, 100, 100, 100, 100]];

assert.equal(calculate(null, null, null), null);
assert.equal(calculate([], null, null), null);
assert.equal(calculate([[0, 0, 0, 0]], null, null).areaCm2, 0);
assert.equal(calculate([[120, 80, 60, 25]], null, null).areaCm2, 4.6875);
assert.equal(calculate([[120, 80, 60]], null, null).areaCm2, 0);
assert.equal(calculate(splitMatrix, null, null).areaCm2, 12.5);
assert.equal(calculate(splitMatrix, null, selection).areaCm2, 6.25);

const mask = [[false, false, false, false, true, true, true, true, true]];
assert.equal(calculate(splitMatrix, mask, null).areaCm2, 6.25);
const before = JSON.stringify({ splitMatrix, mask, selection });
assert.equal(calculate(splitMatrix, mask, selection).retainedCellCount, 4);
assert.equal(JSON.stringify({ splitMatrix, mask, selection }), before, "Inputs must remain unchanged");
mask[0][5] = false;
assert.equal(calculate(splitMatrix, mask, selection).areaCm2, 0, "Selection must also honor sensor geometry");

const rotate = matrix => matrix[0].map((_, c) => matrix.map(row => row[c]).reverse());
const matrix = [[120, 80, 60, 25], [0, 0, 0, 0], [90, 90, 90, 90]];
const alignedMask = [[false, true, true, true], [true, true, true, true], [true, true, true, true]];
const originalArea = calculate(matrix, alignedMask, null).areaCm2;
assert.equal(originalArea, 6.25);
assert.equal(calculate(rotate(matrix), rotate(alignedMask), null).areaCm2, originalArea);
wrapperContext.window.DummyAreaV21036 = undefined;
assert.equal(calculate(matrix, null, null), null);

console.log(JSON.stringify({ algorithmSelfCheck: selfCheck, displayIntegration: "passed" }, null, 2));
