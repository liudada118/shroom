import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';

const audit=process.argv[2];
assert.ok(audit,'Pass the integration audit directory');
const fixtures=JSON.parse(fs.readFileSync(path.join(audit,'browser-wire-fixtures.json'),'utf8'));
const expectedVersion=process.argv[3]??'V2.7.70';
const expectedModel=process.argv[4]??'2026-10-28-field-compensated-985frames-12features';
const sensorType=fixtures[0]?.sensorType??'new-backrest-32x25';
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'region-pressure-runtime-'));
const browser=spawn('C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',[
 '--headless=new','--disable-gpu','--no-first-run','--window-size=1800,1200',
 '--remote-debugging-port=9336',`--user-data-dir=${profile}`,'about:blank',
],{stdio:'ignore',windowsHide:true});
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let socket;
const errors=[];
try {
 let target;
 for(let i=0;i<60;i++){
  try{const list=await fetch('http://127.0.0.1:9336/json/list').then(r=>r.json());target=list.find(t=>t.type==='page');if(target)break;}catch{}
  await sleep(100);
 }
 assert.ok(target,'Browser debugger must become available');
 socket=new WebSocket(target.webSocketDebuggerUrl);
 let sequence=0;
 const pending=new Map();
 socket.addEventListener('message',event=>{
  const value=JSON.parse(event.data);
  if(value.method==='Runtime.exceptionThrown')errors.push(value.params.exceptionDetails);
  const request=pending.get(value.id);if(!request)return;
  pending.delete(value.id);clearTimeout(request.timer);
  value.error?request.reject(new Error(value.error.message)):request.resolve(value.result);
 });
 await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
 const send=(method,params={})=>new Promise((resolve,reject)=>{
  const id=++sequence;
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`Timeout: ${method}`));},15000);
  pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));
 });
 const evaluate=async expression=>{
  const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value;
 };
 const click=async expression=>{
  const pos=await evaluate(`(()=>{const e=${expression};if(!e)throw Error('Element not found');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
  await send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...pos});
  await send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...pos});
 };
 const button=text=>`[...document.querySelectorAll('button')].find(e=>e.textContent?.trim()===${JSON.stringify(text)})`;
 await send('Page.enable');await send('Runtime.enable');
 await send('Page.addScriptToEvaluateOnNewDocument',{source:`
  window.__serialAudit={controller:null};
  window.__auditBlobs=[];
  const originalCreate=URL.createObjectURL.bind(URL);
  URL.createObjectURL=blob=>{window.__auditBlobs.push(blob);return originalCreate(blob);};
  HTMLAnchorElement.prototype.click=function(){};
  const port={
   open:async()=>{},close:async()=>{},getInfo:()=>({usbVendorId:0,usbProductId:0}),
   readable:new ReadableStream({start(c){window.__serialAudit.controller=c;}})
  };
  Object.defineProperty(navigator,'serial',{configurable:true,value:{requestPort:async()=>port,getPorts:async()=>[]}});
 `});
 await send('Page.navigate',{url:'http://127.0.0.1:3000/'});
 for(let i=0;i<80;i++){
  if(await evaluate(`!!document.querySelector('button[role="combobox"]')`))break;
  await sleep(100);
 }
 assert.ok((await evaluate('document.title')).includes(expectedVersion));
 if(sensorType==='new-backrest-32x25'){
  await click(`document.querySelector('button[role="combobox"]')`);await sleep(100);
  await click(`[...document.querySelectorAll('[role="option"]')].find(e=>e.textContent?.includes('新靠背'))`);
 }
 await sleep(200);
 await click(button('连接串口'));await sleep(300);
 assert.ok(await evaluate(`document.body.innerText.includes('已连接')`));
 const observations=[];
 for(const f of fixtures){
  // Preserve the display filter's existing reset after a gap between stable loads.
  if(observations.length)await sleep(1600);
  await evaluate(`window.__serialAudit.controller.enqueue(new Uint8Array(${JSON.stringify(f.packet)}))`);
  await sleep(130);
  const observed=await evaluate(`({force:Number(document.querySelector('[data-testid="force-value"]').textContent),area:Number(document.querySelector('[data-testid="area-value"]').textContent),averagePressure:Number(document.querySelector('[data-testid="region-average-pressure-value"]').textContent),regionCount:document.querySelectorAll('[data-testid="region-pressure-row"]').length})`);
  assert.ok(Math.abs(observed.averagePressure-f.contactPressure.averagePressureKPa)<=0.0051,JSON.stringify({frame:f.index,...observed,expected:f.contactPressure.averagePressureKPa}));
  assert.equal(observed.regionCount,f.contactPressure.regions.length);
  assert.ok(Math.abs(observed.force-f.forceN)<=0.0051,JSON.stringify({frame:f.index,...observed,expected:f.forceN}));
  assert.equal(observed.area,Number(f.expectedAreaCm2.toFixed(2)),`Frame ${f.index} existing area display`);
  const captureButton=await evaluate(`([...document.querySelectorAll('button')].filter(e=>e.textContent?.includes('采集')).map(e=>({text:e.textContent.trim(),title:e.title,disabled:e.disabled})))`);
  const manual=captureButton.find(e=>e.text==='采集当前帧'||e.text==='手动采集'||e.text==='采集一帧');
  assert.ok(manual,JSON.stringify(captureButton));
  await click(button(manual.text));
  observations.push({index:f.index,forceN:observed.force,referenceForceN:f.forceN,areaCm2:observed.area,averagePressureKPa:observed.averagePressure,regionCount:observed.regionCount});
 }
 await sleep(300);
 const saved=await evaluate(`new Promise((resolve,reject)=>{const r=indexedDB.open('SensorCaptureDB',3);r.onerror=()=>reject(r.error);r.onsuccess=()=>{const d=r.result,q=d.transaction('capturedFrames').objectStore('capturedFrames').getAll();q.onsuccess=()=>{d.close();resolve(q.result.map(f=>({capture:f,id:f.id,force:f.forceMetrics,display:f.forceDisplayMetrics,area:f.areaMetrics,rawLength:f.data.raw?.length,physicalShape:[f.data.physical?.length,f.data.physical?.[0]?.length]})));};q.onerror=()=>reject(q.error);};})`);
 assert.equal(saved.length,fixtures.length);
 saved.forEach((row,i)=>{
  assert.ok(Math.abs(row.force.forceN-fixtures[i].forceN)<1e-9);
  assert.equal(row.force.modelVersion,expectedModel);
  assert.equal(row.force.forceAggregation,'total_only');
  const pressure=row.force.contactPressure, expected=fixtures[i].contactPressure;
  assert.ok(Math.abs(pressure.averagePressureKPa-expected.averagePressureKPa)<1e-9);
  assert.deepEqual(pressure.regions,expected.regions);
  assert.ok(Math.abs(row.capture.avgPressureKPa-Number(expected.averagePressureKPa.toFixed(2)))<1e-9);
  assert.ok(Math.abs(row.display.contactPressure.averagePressureKPa-expected.averagePressureKPa)<1e-9);
  assert.equal(row.display.contactPressure.independentlyValidated,false);
  assert.deepEqual(row.force.regionForcesN,[]);
  assert.equal(row.area.areaCm2,fixtures[i].expectedAreaCm2);
  assert.equal(row.rawLength,1024);assert.deepEqual(row.physicalShape,sensorType==='endi-23x23'?[23,23]:[25,32]);
 });
 await evaluate(`(()=>{const e=document.querySelector('[data-testid="region-pressure-details"]');e.open=true;e.scrollIntoView({block:'center'});})()`);
 await click(button('CSV'));await sleep(300);
 const csv=await evaluate(`window.__auditBlobs[window.__auditBlobs.length-1].text()`);
 assert.ok(csv.includes('各区压强算术平均（kPa）'));
 fs.writeFileSync(path.join(audit,'浏览器实际导出.csv'),csv,'utf8');
 for(let i=0;i<40;i++){if(await evaluate(`!!(${button('XLSX')})`))break;await sleep(100);}
 await click(button('XLSX'));
 for(let i=0;i<100;i++){if(await evaluate(`window.__auditBlobs.length>=2`))break;await sleep(100);}
 assert.ok(await evaluate(`window.__auditBlobs.length>=2`),'XLSX browser export completed');
 const xlsx=await evaluate(`window.__auditBlobs[window.__auditBlobs.length-1].arrayBuffer().then(b=>Array.from(new Uint8Array(b)))`);
 fs.writeFileSync(path.join(audit,'浏览器实际导出.xlsx'),Buffer.from(xlsx));
 await evaluate(`document.querySelector('[data-testid="region-pressure-details"]').scrollIntoView({block:'center'})`);
 const screenshot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
 fs.writeFileSync(path.join(audit,'上位机区域压强运行.png'),Buffer.from(screenshot.data,'base64'));
 let zeroUnloadVerified=false;
 if(sensorType==='endi-23x23'){
  await evaluate(`window.__serialAudit.controller.enqueue(new Uint8Array(${JSON.stringify([...Array(1024).fill(0),170,85,3,153])}))`);
  await sleep(200);
  const unloaded=await evaluate(`({force:document.querySelector('[data-testid="force-value"]').textContent,area:document.querySelector('[data-testid="area-value"]').textContent,pressure:document.querySelector('[data-testid="region-average-pressure-value"]').textContent})`);
  assert.equal(Number(unloaded.force),0);assert.equal(Number(unloaded.area),0);assert.equal(unloaded.pressure,'--');zeroUnloadVerified=true;
 }
 await click(button('断开连接'));
 assert.deepEqual(errors,[],'No uncaught browser runtime errors');
 const result={version:expectedVersion,sensorType,productionUrl:'http://127.0.0.1:3000/',zeroUnloadVerified,
  input:'Mock Web Serial byte stream using original ADC; no physical device connected',
  stableLoadFrames:observations.length,forceDisplayMatches:true,areaDisplayMatches:true,regionMeanDisplayMatches:true,regionMetadataPreserved:true,browserCsvExport:true,browserXlsxExport:true,
  capturedFrames:saved.length,rawCaptureForceMatches:true,originalAdcPreserved:true,
  uncaughtRuntimeErrors:errors.length,observations,captured:saved};
 fs.writeFileSync(path.join(audit,'browser-runtime-result.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify({...result,observations:undefined,captured:undefined},null,2));
}catch(error){
 fs.writeFileSync(path.join(audit,'browser-failure.json'),JSON.stringify({message:String(error),errors},null,2));
 throw error;
}finally{
 socket?.close();browser.kill();
}
