import {analyzeSeatRecognitionForce} from "./seatRecognitionPressure";
import {predictSeatPiecewiseForce,SEAT_PIECEWISE_FORCE_VERSION,nativeSeeds} from './seatPiecewiseForce';
import {predictSeatPerCellGmapForce,SEAT_PER_CELL_GMAP_VERSION} from './seatPerCellGmap';
export type SeatForceMethod='spatial_piecewise'|'spatial_response_spline'|'per_cell_gmap'|'fixed_load_recognition';

/** Frozen zone curves default; the previous V80 correction remains selectable.
 * Accuracy is unaccepted for both methods; area and regional pressure stay in
 * their existing independent path.
 */
export function analyzeSeatForce(source:number[][],physical:number[][],context?:SeatPressureContext,method:SeatForceMethod='per_cell_gmap'):ContinuousForceFrame {
  if(method==='fixed_load_recognition')return analyzeSeatRecognitionForce(source,physical,context);
  if(method==='per_cell_gmap')return analyzePerCellGmapForce(source,physical,context);
  if(method==='spatial_response_spline')return analyzeRegionalResponseForce(source,physical,context);
  if(method!=='spatial_piecewise')throw new TypeError('Unknown seat force method');
  const result=predictSeatPiecewiseForce(source,physical,context);
  const noContact=result.reason==='no_contact',complete=result.reason!=='no_regions';
  return {algorithmId:'seat-spatial-piecewise-trial',algorithmLabel:'坐垫总力（分区曲线试用）',
    modelVersion:SEAT_PIECEWISE_FORCE_VERSION,
    status:noContact?'no_contact':!complete?'contact_partition_unavailable':result.outsideResponseRegions?'outside_response_range':result.globalFallbackRegions?'global_curve_fallback':'candidate_requires_validation',
    forceN:result.forceN,regionForcesN:[],forceAggregation:'total_only',forceEstimateComplete:complete,seedCount:result.seedCount,
    averagePressureKPa:null,areaCm2:0,forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',
    inputMode:'native-original-physical-adc-23x23',accepted:false,independentlyValidated:false,
    loadLabel:noContact?'无接触':!complete?'接触区域不可用':result.outsideResponseRegions?'分区曲线响应超范围（使用曲线端点）':result.globalFallbackRegions?'分区样本不足，使用全局曲线':'按空间分区计算ADC力曲线（试用、未验收）',
    scoreMargin:null,
    scopeNote:`19个空间区单调分段线性曲线＋全局回退试用；总力±1N未通过。完整算法整文件5折留出207/877帧在±1N，最大误差190.520N；重新放置开发10帧最大误差2.173N，不能作为新独立验收。当前${result.seedCount}个接触，${result.globalFallbackRegions}区全局回退，${result.outsideResponseRegions}区超ADC支持范围。硬分区边界存在不连续；没有按目标重量吸附。面积算法不变，各区压强仍按原始ADC占比分配总力后取区域压强算术平均，区域力和压强未独立验收。`};
}

import {validateSeatAdc} from './seatTotalForce';
import {predictSeatRegionalCompensatedForce,SEAT_REGIONAL_COMPENSATION_VERSION} from './seatRegionalCompensation';
import type {SeatPressureContext} from './seatRegionPressure';
import type {ContinuousForceFrame} from './sensorForce';

/** User-authorized regional trial; force accuracy remains unaccepted. */
function analyzeRegionalResponseForce(source:number[][],physical:number[][],context?:SeatPressureContext):ContinuousForceFrame {
  validateSeatAdc(source,46);validateSeatAdc(physical,23);
  const result=predictSeatRegionalCompensatedForce(source,physical,context);
  return {algorithmId:'seat-position-response-compensation-trial',algorithmLabel:'坐垫总力（区域补偿试用）',
    modelVersion:SEAT_REGIONAL_COMPENSATION_VERSION,
    status:result.reason==='no_contact'?'no_contact':result.applied?'candidate_requires_validation':'outside_compensation_range',
    forceN:result.forceN,regionForcesN:[],forceAggregation:'total_only',forceEstimateComplete:true,seedCount:0,
    averagePressureKPa:null,areaCm2:0,forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',
    inputMode:'native-original-physical-adc-23x23',accepted:false,independentlyValidated:false,
    loadLabel:result.applied?'区域位置＋ADC响应双向补偿（试用、未验收）':result.reason==='no_contact'?'无接触':'区域补偿未应用，本帧保留原基线',
    scoreMargin:null,
    scopeNote:`区域双向补偿试用；总力±1N尚未通过验收。已有两块重新放置最大误差约7.718N。原基线=${result.baseForceN.toFixed(6)}N，区域补偿=${result.correctionN.toFixed(6)}N，应用状态=${result.reason}。面积算法保持原样，各区力仍按原始ADC占比分配补偿后的总力，再计算各区域压强的算术平均；区域力及压强未独立标定。`};
}


/** Per-cell sensitivity map total force (1.625 kg calibrated to ±0.5 N). */
function analyzePerCellGmapForce(source:number[][],physical:number[][],context?:SeatPressureContext):ContinuousForceFrame {
  const seeds=nativeSeeds(source,context);
  const result=predictSeatPerCellGmapForce(physical,seeds);
  const noContact=result.reason==='no_contact';
  return {algorithmId:'seat-per-cell-gmap',algorithmLabel:'坐垫总力（逐点g图）',
    modelVersion:SEAT_PER_CELL_GMAP_VERSION,
    status:noContact?'no_contact':'candidate_requires_validation',
    forceN:result.forceN,regionForcesN:[],forceAggregation:'total_only',forceEstimateComplete:true,seedCount:result.seedCount,
    averagePressureKPa:null,areaCm2:0,forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',
    inputMode:'native-original-physical-adc-23x23',accepted:false,independentlyValidated:false,
    loadLabel:noContact?'无接触':'按逐点灵敏度求和（1.625kg档±0.5N）',
    scoreMargin:null,
    scopeNote:'逐点g图：f_cell=g[r,c]*(ADC/100)^0.3；按标定面积种子分区，各区按自身ADC就近选1.625/3.25/4.875/6.5/8.125/16.5kg档位g图再求和（多接触平铺按区分算）。g取9.8。1.625kg档内检均值约0.38N。区域力与压强仍按原始ADC占比分配总力。'};
}
