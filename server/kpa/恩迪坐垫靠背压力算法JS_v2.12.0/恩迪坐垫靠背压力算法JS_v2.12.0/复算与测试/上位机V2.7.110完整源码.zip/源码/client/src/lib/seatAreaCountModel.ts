import model from './seatAreaCountModel.generated';

export const SEAT_AREA_COUNT_MODEL_VERSION='seat-area-count-contour-20261030';

function quantile(sorted:number[],fraction:number):number {
  const p=(sorted.length-1)*fraction,lo=Math.floor(p),hi=Math.ceil(p);
  return sorted[lo]+(sorted[hi]-sorted[lo])*(p-lo);
}

/** Current-region ADC/shape features only; physical reference area is not an input. */
export function describeSeatAreaCountContour(values:number[],rows:number[],cols:number[]):number[] {
  const positive=values.filter(v=>v>5).sort((a,b)=>a-b);
  if(!positive.length)return Array(28).fill(0);
  const peak=Math.max(...values),den=Math.max(peak,1),total=values.reduce((a,b)=>a+b,0);
  const mean=positive.reduce((a,b)=>a+b,0)/positive.length;
  const sd=Math.sqrt(positive.reduce((s,v)=>s+(v-mean)**2,0)/positive.length);
  const q=[.1,.25,.5,.75,.9].map(f=>quantile(positive,f)/den);
  const counts=[.1,.2,.3,.4,.5,.6,.7,.8,.9].map(level=>values.reduce((s,v)=>s+(v/den>=level?1:0),0));
  const mr=values.reduce((s,v,i)=>s+v*rows[i],0)/Math.max(total,1);
  const mc=values.reduce((s,v,i)=>s+v*cols[i],0)/Math.max(total,1);
  const covrr=values.reduce((s,v,i)=>s+v*(rows[i]-mr)**2,0)/Math.max(total,1);
  const covcc=values.reduce((s,v,i)=>s+v*(cols[i]-mc)**2,0)/Math.max(total,1);
  const covrc=values.reduce((s,v,i)=>s+v*(rows[i]-mr)*(cols[i]-mc),0)/Math.max(total,1);
  return [peak,positive.length,mean/den,sd/den,...q,...counts.map(n=>n/100),
    counts[4]/Math.max(counts[1],1),counts[6]/Math.max(counts[2],1),counts[8]/Math.max(counts[4],1),
    mr/45,mc/45,covrr/100,covcc/100,covrc/100,total/den/100,
    Math.sqrt(values.reduce((s,v)=>s+v*v,0))/den/10];
}

/** Calibrated contour, followed by an independent binary grid count in seatArea. */
export function predictSeatAreaCountThreshold(values:number[],rows:number[],cols:number[]):number {
  if(!values.length)return 8;
  const peak=Math.max(...values);
  if(peak<=0)return 8;
  const x=describeSeatAreaCountContour(values,rows,cols).map(Math.fround);
  let relative=0;
  for(const root of model.roots){
    let node=root;
    while(model.left[node]>=0)node=x[model.feature[node]]<=model.threshold[node]?model.left[node]:model.right[node];
    relative+=model.value[node];
  }
  relative/=model.roots.length;
  return Math.max(8,peak*Math.max(.2,Math.min(.9,relative)));
}
