import type { ContinuousForceFrame } from "./sensorForce";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";

/** Display state only. No coefficient, retained area mask or original ADC is changed. */
export const SEAT_DISPLAY_STABILITY_VERSION = "seat-synchronous-force-area-adc-share-ema-20261029";
export const SEAT_DISPLAY_FORCE_TAU_MS = 120;
export const SEAT_DISPLAY_AREA_TAU_MS = 180;
export const SEAT_DISPLAY_SHARE_TAU_MS = 120;

export type SeatDisplayChangeReason = "initial" | "instantaneous" | "small-change" | "adc-step" | "contact-change" | "contact-moved" | "zero";
type RegionTrack = { center: [number, number]; areaCm2: number; share: number; rawAdcSum: number };

export interface SeatStableDisplay {
  frame: ContinuousForceFrame;
  areaCm2: number;
  regionAreasCm2: number[];
  regionAdcShares: number[];
  forceTimeConstantMs: number;
  areaTimeConstantMs: number;
  shareTimeConstantMs: number;
  changeReason: SeatDisplayChangeReason;
  topologyChanged: boolean;
  zero: boolean;
}

export function usesSeatStableDisplay(raw: ContinuousForceFrame): boolean {
  return raw.contactPressure?.version === "seat-raw-adc-share-region-pressure-mean-20261028"
    || raw.algorithmId.startsWith("seat-");
}

function alpha(dt: number, tau: number): number {
  // Several distinct frames may arrive in one serial callback with the same ms.
  // A 1 ms lower bound lets each distinct frame contribute without a frame skip.
  return 1 - Math.exp(-Math.max(1, dt) / tau);
}

function matchRegions(current: RegionTrack[], previous: RegionTrack[]): Map<number, number> {
  const pairs: { current: number; previous: number; distance: number }[] = [];
  current.forEach((r, i) => previous.forEach((p, j) => {
    const distance = (r.center[0] - p.center[0]) ** 2 + (r.center[1] - p.center[1]) ** 2;
    if (distance <= 64) pairs.push({ current: i, previous: j, distance });
  }));
  pairs.sort((a, b) => a.distance - b.distance || a.current - b.current || a.previous - b.previous);
  const result = new Map<number, number>(), used = new Set<number>();
  for (const pair of pairs) if (!result.has(pair.current) && !used.has(pair.previous)) {
    result.set(pair.current, pair.previous); used.add(pair.previous);
  }
  return result;
}

/** One common state produces force, area and the ADC shares used for pressure. */
export class SeatDisplayStabilizer {
  private initialized = false;
  private forceN = 0;
  private areaCm2 = 0;
  private adcReference = 0;
  private lastRawAdcSum = 0;
  private regions: RegionTrack[] = [];

  reset(): void {
    this.initialized = false; this.forceN = 0; this.areaCm2 = 0;
    this.adcReference = 0; this.lastRawAdcSum = 0; this.regions = [];
  }

  update(raw: ContinuousForceFrame, dt: number, enabled: boolean): SeatStableDisplay {
    const pressure = raw.contactPressure;
    const rawAdcSum = pressure?.rawAdcSum ?? 0;
    const current = (pressure?.regions ?? []).map(r => ({ center: [...r.center] as [number, number],
      areaCm2: r.areaCm2, share: r.forceShare, rawAdcSum: r.rawAdcSum }));
    const zero = pressure ? rawAdcSum === 0 : raw.status === "no_contact" || (raw.forceN === 0 && raw.areaCm2 === 0);
    const assigned = matchRegions(current, this.regions);
    const topologyChanged = this.regions.length !== current.length || assigned.size !== current.length;
    const moved = !topologyChanged && current.some((r, i) => {
      const p = this.regions[assigned.get(i)!];
      return (r.center[0] - p.center[0]) ** 2 + (r.center[1] - p.center[1]) ** 2 > 4;
    });
    // Model-only jumps do not trigger fast attack. Raw response must corroborate
    // a load/unload step. Compare both last raw and a short response reference so
    // a real ramp is not concealed by a long history window.
    const adcBand = Math.max(24, Math.max(rawAdcSum, this.adcReference) * 0.01);
    const adcStep = !!pressure && this.initialized && Math.max(
      Math.abs(rawAdcSum - this.lastRawAdcSum), Math.abs(rawAdcSum - this.adcReference),
    ) >= adcBand;
    const regionalAdcStep = !!pressure && !topologyChanged && this.initialized && current.some((r, i) => {
      const p = this.regions[assigned.get(i)!];
      return Math.abs(r.rawAdcSum - p.rawAdcSum) >= Math.max(24, Math.max(r.rawAdcSum, p.rawAdcSum) * 0.02);
    });
    const initial = !this.initialized;
    const forceImmediate = !enabled || initial || zero || topologyChanged || moved || adcStep || regionalAdcStep;
    // Counted grid area always describes the current source frame; keep legacy force/share smoothing.
    const areaImmediate = raw.seatAreaMetadata?.areaMeaning === "spatial_denoised_grid_count"
      || !enabled || initial || zero || topologyChanged || moved;
    const shareImmediate = forceImmediate;
    const forceAlpha = forceImmediate ? 1 : alpha(dt, SEAT_DISPLAY_FORCE_TAU_MS);
    const areaAlpha = areaImmediate ? 1 : alpha(dt, SEAT_DISPLAY_AREA_TAU_MS);
    const shareAlpha = shareImmediate ? 1 : alpha(dt, SEAT_DISPLAY_SHARE_TAU_MS);
    this.forceN = zero ? 0 : this.forceN + forceAlpha * (raw.forceN - this.forceN);
    this.areaCm2 = zero ? 0 : this.areaCm2 + areaAlpha * (raw.areaCm2 - this.areaCm2);
    this.regions = zero ? [] : current.map((r, i) => {
      const previous = assigned.has(i) ? this.regions[assigned.get(i)!] : undefined;
      return { ...r,
        areaCm2: previous && !areaImmediate ? previous.areaCm2 + areaAlpha * (r.areaCm2 - previous.areaCm2) : r.areaCm2,
        share: previous && !shareImmediate ? previous.share + shareAlpha * (r.share - previous.share) : r.share };
    });
    const shareSum = this.regions.reduce((sum, r) => sum + r.share, 0);
    if (shareSum > 0) this.regions.forEach(r => { r.share /= shareSum; });
    this.adcReference = forceImmediate ? rawAdcSum : this.adcReference + alpha(dt, SEAT_DISPLAY_FORCE_TAU_MS) * (rawAdcSum - this.adcReference);
    this.lastRawAdcSum = rawAdcSum;
    this.initialized = true;

    let contactPressure: BackrestRegionPressureFrame | undefined;
    if (pressure) {
      const regions = zero ? [] : pressure.regions.map((r, i) => {
        const track = this.regions[i];
        const estimatedForceN = this.forceN * track.share;
        return { ...r, center: [...r.center] as [number, number], forceShare: track.share,
          areaCm2: track.areaCm2, estimatedForceN,
          estimatedPressureKPa: track.areaCm2 > 0 && r.rawAdcSum > 0 ? 10 * estimatedForceN / track.areaCm2 : null };
      });
      const complete = regions.length > 0 && regions.every(r => r.estimatedPressureKPa !== null);
      contactPressure = { ...pressure, totalForceN: this.forceN, areaCm2: this.areaCm2, regions,
        status: zero ? "no_contact" : complete ? "estimated" : "incomplete",
        averagePressureKPa: !zero && complete ? regions.reduce((s, r) => s + r.estimatedPressureKPa!, 0) / regions.length : null,
        globalAreaMeanPressureKPa: this.areaCm2 > 0 ? 10 * this.forceN / this.areaCm2 : null };
    }
    const regionForcesN = raw.forceAggregation === "total_only" ? [] : raw.regionForcesN.map(value => raw.forceN > 0 ? value * this.forceN / raw.forceN : 0);
    const frame: ContinuousForceFrame = !enabled ? raw : { ...raw, forceN: this.forceN,
      areaCm2: this.areaCm2, regionForcesN, contactPressure,
      averagePressureKPa: contactPressure ? contactPressure.averagePressureKPa : this.areaCm2 > 0 ? 10 * this.forceN / this.areaCm2 : null };
    return { frame, areaCm2: enabled ? this.areaCm2 : raw.areaCm2,
      regionAreasCm2: enabled ? this.regions.map(r => r.areaCm2) : (pressure?.regions.map(r => r.areaCm2) ?? []),
      regionAdcShares: enabled ? this.regions.map(r => r.share) : (pressure?.regions.map(r => r.forceShare) ?? []),
      forceTimeConstantMs: forceImmediate ? 0 : SEAT_DISPLAY_FORCE_TAU_MS,
      areaTimeConstantMs: areaImmediate ? 0 : SEAT_DISPLAY_AREA_TAU_MS,
      shareTimeConstantMs: shareImmediate ? 0 : SEAT_DISPLAY_SHARE_TAU_MS,
      changeReason: !enabled ? "instantaneous" : zero ? "zero" : initial ? "initial" : topologyChanged ? "contact-change"
        : moved ? "contact-moved" : adcStep || regionalAdcStep ? "adc-step" : "small-change",
      topologyChanged, zero };
  }
}
