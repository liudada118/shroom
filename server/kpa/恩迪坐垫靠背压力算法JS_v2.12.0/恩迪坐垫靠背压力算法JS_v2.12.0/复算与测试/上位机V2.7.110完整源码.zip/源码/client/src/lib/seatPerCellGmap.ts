import {
  SEAT_PER_CELL_GMAP_GAMMA,
  SEAT_PER_CELL_GMAP_CELL_SCALE,
  SEAT_PER_CELL_GMAP_LEVELS,
} from "./seatPerCellGmap.generated";
import { SEAT_LEVEL_ADC_POINTS } from "./seatLevelSpatial.generated";

export const SEAT_PER_CELL_GMAP_VERSION = "seat-per-cell-gmap-region-nearest-20261029";

export interface SeatPerCellGmapDetails {
  forceN: number;
  levelKg: number;
  totalAdc: number;
  seedCount: number;
  contactCount: number;
  reason: "applied" | "no_contact" | "no_regions";
}

/** Complete native 23×23 physical ADC only; display rotation/selection excluded. */
export function validateSeatPhysicalAdc(matrix: number[][]): void {
  if (
    !Array.isArray(matrix) || matrix.length !== 23 ||
    matrix.some(row => !Array.isArray(row) || row.length !== 23 ||
      row.some(v => typeof v !== "number" || !Number.isFinite(v) || v < 0 || v > 255))
  ) {
    throw new TypeError("Complete native 23×23 physical ADC matrix required");
  }
}

/** Select load level by the nearest calibrated position's per-level ADC. */
/** Expected ADC at (r,c) for a given load level = the nearest calibrated point's ADC. */
function nearestAdc(kg: number, r: number, c: number): number {
  const pts = SEAT_LEVEL_ADC_POINTS[String(kg)];
  let bestD2 = Infinity, bestAdc = 0;
  for (let i = 0; i < pts.length; i += 3) {
    const pr = pts[i], pc = pts[i + 1], adc = pts[i + 2];
    const d2 = (r - pr) ** 2 + (c - pc) ** 2;
    if (d2 < bestD2) { bestD2 = d2; bestAdc = adc; }
  }
  return bestAdc;
}

/** Select load level by comparing actual ADC to the spatially-interpolated expected ADC per level. */
function nearestLevel(adcSum: number, r: number, c: number) {
  let level = SEAT_PER_CELL_GMAP_LEVELS[0];
  let best = Infinity;
  for (const lv of SEAT_PER_CELL_GMAP_LEVELS) {
    const expected = nearestAdc(lv.massKg, r, c);
    const distance = Math.abs(adcSum - expected);
    if (distance < best) { best = distance; level = lv; }
  }
  return level;
}

/**
 * Per-cell sensitivity summed over contact cells, partitioned by the calibrated
 * area seeds (46×46 coordinates) exactly like the piecewise force model, so
 * multi-contact flat placement is split into independent contacts. Each region
 * selects its own load level by its own ADC sum and centroid (position-local
 * level thresholds). f_cell = g[r][c] * (ADC/100)^gamma ; F = Σ regions Σ cells.
 */
export function predictSeatPerCellGmapForce(physical: number[][], seeds: [number, number][]): SeatPerCellGmapDetails {
  validateSeatPhysicalAdc(physical);
  let totalAdc = 0;
  for (let r = 0; r < 23; r++) {
    const row = physical[r];
    for (let c = 0; c < 23; c++) totalAdc += row[c];
  }
  if (totalAdc === 0) {
    return { forceN: 0, levelKg: 0, totalAdc: 0, seedCount: 0, contactCount: 0, reason: "no_contact" };
  }
  if (!seeds.length) {
    return { forceN: 0, levelKg: 0, totalAdc, seedCount: 0, contactCount: 0, reason: "no_regions" };
  }

  const regions = seeds.map(() => ({ cells: [] as [number, number][], adcSum: 0, cy: 0, cx: 0 }));
  for (let r = 0; r < 23; r++) {
    for (let c = 0; c < 23; c++) {
      const adc = physical[r][c];
      if (adc === 0) continue;
      let nearest = 0, best = Infinity;
      for (let i = 0; i < seeds.length; i++) {
        const [sr, sc] = seeds[i];
        const distance = (2 * r - sr) ** 2 + (2 * c - sc) ** 2;
        if (distance < best) { best = distance; nearest = i; }
      }
      regions[nearest].cells.push([r, c]);
      regions[nearest].adcSum += adc;
      regions[nearest].cy += r * adc;
      regions[nearest].cx += c * adc;
    }
  }

  const gamma = SEAT_PER_CELL_GMAP_GAMMA;
  const scale = SEAT_PER_CELL_GMAP_CELL_SCALE;
  let forceN = 0;
  let seedCount = 0;
  let contactCount = 0;
  let levelKg = 0;
  for (const region of regions) {
    if (region.adcSum === 0) continue;
    contactCount++;
    const level = nearestLevel(region.adcSum, region.cy / region.adcSum, region.cx / region.adcSum);
    levelKg = level.massKg;
    const g = level.g;
    for (const [r, c] of region.cells) {
      seedCount++;
      forceN += g[r][c] * Math.pow(physical[r][c] / scale, gamma);
    }
  }
  return { forceN, levelKg, totalAdc, seedCount, contactCount, reason: "applied" };
}
