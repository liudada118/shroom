/**
 * SortableList - 可拖拽排序列表组件
 * 支持通过拖拽上下箭头来调整列表项顺序
 */
import { useCallback } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";

interface SortableListProps<T> {
  items: T[];
  keyExtractor: (item: T) => string;
  onReorder: (items: T[]) => void;
  renderItem: (item: T, index: number) => React.ReactNode;
}

export default function SortableList<T>({
  items,
  keyExtractor,
  onReorder,
  renderItem,
}: SortableListProps<T>) {
  const moveUp = useCallback((index: number) => {
    if (index <= 0) return;
    const newItems = [...items];
    [newItems[index - 1], newItems[index]] = [newItems[index], newItems[index - 1]];
    onReorder(newItems);
  }, [items, onReorder]);

  const moveDown = useCallback((index: number) => {
    if (index >= items.length - 1) return;
    const newItems = [...items];
    [newItems[index], newItems[index + 1]] = [newItems[index + 1], newItems[index]];
    onReorder(newItems);
  }, [items, onReorder]);

  return (
    <div className="space-y-0.5">
      {items.map((item, index) => (
        <div key={keyExtractor(item)} className="flex items-center gap-1 group">
          <div className="flex flex-col gap-0 flex-shrink-0">
            <button
              onClick={() => moveUp(index)}
              disabled={index === 0}
              className="w-4 h-3 flex items-center justify-center text-muted-foreground/40 hover:text-foreground disabled:opacity-20 transition-colors"
              title="上移"
            >
              <ChevronUp className="w-3 h-3" />
            </button>
            <button
              onClick={() => moveDown(index)}
              disabled={index === items.length - 1}
              className="w-4 h-3 flex items-center justify-center text-muted-foreground/40 hover:text-foreground disabled:opacity-20 transition-colors"
              title="下移"
            >
              <ChevronDown className="w-3 h-3" />
            </button>
          </div>
          <div className="flex-1 min-w-0">
            {renderItem(item, index)}
          </div>
        </div>
      ))}
    </div>
  );
}
