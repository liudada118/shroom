import type {SeatAreaFrame} from './seatArea';
import type {BackrestRegionPressureFrame} from './backrestRegionPressure';
import {validateSeatAdc} from './seatTotalForce';

export const SEAT_REGION_PRESSURE_VERSION='seat-raw-adc-share-region-pressure-mean-20261028' as const;
export interface SeatPressureContext {
  area:SeatAreaFrame;
  /** Clockwise quarter-turns from native source ADC to calibrated area. */
  rotation:number;
  mirrorColumns?:boolean;
  /** Optional live stream identity/time; static recomputation never advances history. */
  timestampMs?:number;
  streamId?:string;
  static?:boolean;
}

/** Use calibrated spatial regions even when neighbouring retained masks touch. */
export function calculateSeatRegionPressure(physical:number[][],forceN:number,context:SeatPressureContext):BackrestRegionPressureFrame {
  validateSeatAdc(physical,23);
  if(!Number.isFinite(forceN)||forceN<0)throw new TypeError('Finite nonnegative total force required');
  const {area}=context;
  if(area.rows!==46||area.cols!==46)throw new TypeError('Complete calibrated seat area required');
  const centers=area.seeds;
  if(centers.length!==area.regions.length)throw new TypeError('Seat contact seeds and regions must match');
  const adcSums=centers.map(()=>0);let rawAdcSum=0;
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const value=physical[r][c];rawAdcSum+=value;if(value===0||!centers.length)continue;
    let row=2*r,col=2*c;
    for(let k=0;k<((context.rotation%4)+4)%4;k++){const next=col;col=45-row;row=next;}
    if(context.mirrorColumns)col=45-col;
    let nearest=0,best=Infinity;
    centers.forEach(([sr,sc],i)=>{const d=(row-sr)**2+(col-sc)**2;if(d<best){best=d;nearest=i;}});
    adcSums[nearest]+=value;
  }
  const assigned=adcSums.reduce((s,v)=>s+v,0);
  const regions=area.regions.map((region,i)=>{
    const share=assigned>0?adcSums[i]/assigned:0,estimatedForceN=forceN*share;
    return {index:i,center:centers[i],rawAdcSum:adcSums[i],forceShare:share,estimatedForceN,areaCm2:region.areaCm2,
      estimatedPressureKPa:region.areaCm2>0&&adcSums[i]>0?10*estimatedForceN/region.areaCm2:null};
  });
  const noContact=rawAdcSum===0&&forceN===0;
  const complete=regions.length>0&&assigned>0&&regions.every(r=>r.estimatedPressureKPa!==null);
  return {version:SEAT_REGION_PRESSURE_VERSION,method:'raw_adc_share_then_region_arithmetic_mean',
    status:noContact?'no_contact':complete?'estimated':'incomplete',scope:'complete_frame',independentlyValidated:false,
    totalForceN:forceN,areaCm2:area.areaCm2,rawAdcSum,assignedRawAdcSum:assigned,regions,
    averagePressureKPa:!noContact&&complete?regions.reduce((s,r)=>s+r.estimatedPressureKPa!,0)/regions.length:null,
    globalAreaMeanPressureKPa:area.areaCm2>0?10*forceN/area.areaCm2:null};
}
