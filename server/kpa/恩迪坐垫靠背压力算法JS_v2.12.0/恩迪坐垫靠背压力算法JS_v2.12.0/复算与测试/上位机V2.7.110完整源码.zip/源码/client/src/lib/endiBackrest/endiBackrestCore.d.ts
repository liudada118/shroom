/* 恩迪靠背算法核心（endiBackrestCore.js）的类型声明。核心由 tools/make_backrest_core.py 生成。 */

export type EndiBackrestState = "first_contact" | "tentative" | "confirmed" | "judging" | "estimate" | "overrange";
export type EndiBackrestMode = "standard" | "estimate" | "overrange";

export interface EndiBackrestRegionOutput {
  trackId: number;
  state: EndiBackrestState;
  mode: EndiBackrestMode;
  /** 已确认标准档块数（冻结期间保持；尚未定档时为 0）。 */
  blocks: number;
  tentativeBlocks: number | null;
  firstLevel: number | null;
  addCount: number;
  massKg: number;
  forceN: number;
  /** 区面积 cm²：标准档 63.62；估算 = T39 轮廓面积；超量程估算 = T39 轮廓面积 × 2（V2.7.108）。 */
  areaCm2: number;
  pressureKPa: number | null;
  /** T39 轮廓面积（插值格数 × 1.30 cm²）。 */
  contourAreaCm2: number;
  footprint: boolean;
  /** 算法方向物理格坐标（行, 列）。 */
  center: { r: number; c: number };
  lnR: number;
  massFitKg: number;
  peak: number;
  cells: number;
}

export interface EndiBackrestFrameOutput {
  timestamp: number;
  totalMassKg: number;
  totalForceN: number;
  totalAreaCm2: number;
  avgPressureKPa: number | null;
  regionCount: number;
  regions: EndiBackrestRegionOutput[];
  interpolated?: Float64Array;
  areaMap?: Float64Array;
}

export interface EndiBackrestAlgorithmInstance {
  cfg: Record<string, any>;
  calib: Record<string, any>;
  reset(): void;
  process(matrix: number[][] | ArrayLike<number>, timestampMs?: number): EndiBackrestFrameOutput;
}

export declare const EndiBackrestAlgorithm: {
  new (options?: Record<string, unknown>): EndiBackrestAlgorithmInstance;
};
export declare const CALIB: {
  version: string;
  fittedOn: string;
  sensor: string;
  data: string;
  nodeIds: string[];
  sigmaMm: number;
  area: { threshold: number; nMin: number; nMax: number; spanMaxMm: number; eccMax: number };
  overrange: Record<string, number>;
  fit: Record<string, any>;
  [key: string]: any;
};
export declare const DEFAULT_CONFIG: {
  rows: number;
  cols: number;
  pitchRowMm: number;
  pitchColMm: number;
  interpCellAreaCm2: number;
  blockMassKg: number;
  baseAreaCm2: number;
  g: number;
  areaThreshold: number;
  /** V2.7.103：超量程启动门限（N）：基准估算力与连续拟合估算力均 > 90 N（超过 5 块砝码）；ovrHoldMs（500）为回落 ≤ 90 N 后的取消防抖。 */
  ovrForceInN: number;
  ovrHoldMs: number;
  /** 超量程压力倍率（规定值 2）。 */
  overrangeMultiplier: number;
  /** V2.7.108：超量程面积倍率（规定值 2）：超量程估算区面积 = T39 轮廓面积 × 2，区压强 = 2F / 2S = F / S。 */
  overrangeAreaMultiplier: number;
  maxStdLevel: number;
  [key: string]: any;
};
export declare const STATE: Record<"FIRST" | "TENT" | "CONF" | "JUDGE" | "EST" | "OVR", EndiBackrestState>;
export declare function interpolate(a: ArrayLike<number>, rows?: number, cols?: number): Float64Array;
export declare function estimateMassFit(matrix: number[][] | ArrayLike<number>, options?: Record<string, unknown>): { center: { r: number; c: number }; massFitKg: number }[];
export declare const ENDI_BACKREST_CORE_VERSION: string;
export declare const ENDI_BACKREST_CORE_SOURCE_SHA256: string;
declare const EndiBackrest: {
  EndiBackrestAlgorithm: typeof EndiBackrestAlgorithm;
  CALIB: typeof CALIB;
  DEFAULT_CONFIG: typeof DEFAULT_CONFIG;
  STATE: typeof STATE;
  interpolate: typeof interpolate;
  estimateMassFit: typeof estimateMassFit;
};
export default EndiBackrest;
