import { BackrestTaxelEstimator } from "./backrestTaxelRuntime";
import { recognizeBackrestLoad, type BackrestLoadRecognition } from "./backrestLoadRecognition";

export interface RecognizedBackrestContact extends BackrestLoadRecognition {
  contactId: number;
  centerRow: number;
  centerCol: number;
  possiblyMerged: boolean;
}

export interface BackrestRecognitionPreview {
  timestampMs: number;
  contacts: RecognizedBackrestContact[];
  nominalTotalForceN: number;
  uncertain: boolean;
  meaning: "recognized_fixed_load_nominal_force";
  simulated: false;
}

/** A separate UI-only stream. It never mutates the measured force pipeline. */
export class BackrestRecognitionPreviewStream {
  private estimator = new BackrestTaxelEstimator();
  private streamId: string | null = null;
  private previousMatrix: readonly (readonly number[])[] | null = null;
  private previousTimestamp: number | null = null;
  private sampleTimestamp: number | null = null;
  private previousResult: BackrestRecognitionPreview | null = null;

  reset(): void {
    this.estimator.reset();
    this.streamId = null;
    this.previousMatrix = null;
    this.previousTimestamp = null;
    this.sampleTimestamp = null;
    this.previousResult = null;
  }

  update(nativePhysical: readonly (readonly number[])[], timestampMs: number, streamId: string): BackrestRecognitionPreview {
    if (nativePhysical.length !== 32 || nativePhysical.some(row => row.length !== 25)) {
      throw new TypeError("Recognition needs original native32x25 physical ADC");
    }
    if (!Number.isFinite(timestampMs)) throw new TypeError("Finite frame timestamp required");
    if (this.streamId !== streamId) { this.reset(); this.streamId = streamId; }
    if (this.previousMatrix === nativePhysical && this.previousTimestamp === timestampMs && this.previousResult) return this.previousResult;
    let sampleTime = timestampMs;
    if (this.previousTimestamp !== null && sampleTime >= this.previousTimestamp) {
      sampleTime = Math.max(sampleTime, this.sampleTimestamp! + .001);
    }
    const canonical = Array.from({ length: 25 }, (_, row) => Array.from({ length: 32 }, (_, col) => nativePhysical[col][row]));
    const tracked = this.estimator.update(canonical, sampleTime);
    const contacts: RecognizedBackrestContact[] = tracked.contacts.map(contact => ({
      ...recognizeBackrestLoad(contact.filteredMatrix),
      contactId: contact.trackId,
      centerRow: contact.centroidRow,
      centerCol: contact.centroidCol,
      possiblyMerged: contact.possiblyMerged,
    }));
    this.previousMatrix = nativePhysical;
    this.previousTimestamp = timestampMs;
    this.sampleTimestamp = sampleTime;
    this.previousResult = {
      timestampMs, contacts,
      nominalTotalForceN: contacts.reduce((sum, contact) => sum + contact.nominalForceN, 0),
      uncertain: contacts.some(contact => contact.uncertain || contact.possiblyMerged),
      meaning: "recognized_fixed_load_nominal_force", simulated: false,
    };
    return this.previousResult;
  }
}

/** Synthetic UI effect, deliberately kept outside force records and exports. */
export function simulatedNominalForceN(nominalForceN: number, random: () => number = Math.random): number {
  if (!Number.isFinite(nominalForceN) || nominalForceN < 0) throw new TypeError("Nonnegative finite nominal force required");
  if (nominalForceN === 0) return 0;
  const draw = random();
  if (!Number.isFinite(draw) || draw < 0 || draw > 1) throw new TypeError("Random draw must be in[0,1]");
  return nominalForceN + (2 * draw - 1) * .5;
}
