/**
 * Inferno 色谱颜色映射
 * 用于将压力值(0-255)映射为RGB颜色
 * 
 * 关键设计：value=0 为背景色（纯黑/深色），value>0 从一个明显可见的
 * 起始颜色开始，确保任何非零值都能与零值区域清晰区分。
 */

// Inferno colormap stops (from dark to bright)
// 用于 value > 0 的映射（从深紫色开始，确保可见）
const INFERNO_STOPS: [number, number, number][] = [
  [30, 12, 75],     // 深紫色 - 最低非零值的起始颜色（明显可见）
  [55, 12, 100],
  [73, 13, 106],
  [106, 23, 110],
  [137, 34, 106],
  [165, 48, 96],
  [192, 65, 77],
  [213, 89, 54],
  [231, 117, 30],
  [244, 149, 10],
  [249, 183, 12],
  [246, 215, 70],
  [252, 246, 125],
  [252, 255, 164],
];

// value=0 时的背景色（与canvas背景 #0f172a 融合）
const ZERO_COLOR: [number, number, number] = [0, 0, 4];

/**
 * 将 0-255 的压力值映射为 RGB 颜色
 * value=0 返回深色背景色，value>0 从明显可见的深紫色开始
 */
export function valueToColor(value: number): [number, number, number] {
  // 非有限值与 value=0 均返回背景色，避免动态压强色标输入异常时越界。
  if (!Number.isFinite(value) || value <= 0) return ZERO_COLOR;

  // value>0 映射到 INFERNO_STOPS（从深紫色到亮黄色）
  // 使用 1-255 映射到 0-1 范围
  const safeValue = Math.max(1, Math.min(255, value));
  const t = ((safeValue - 1) / 254) * (INFERNO_STOPS.length - 1);
  const lower = Math.floor(t);
  const upper = Math.min(lower + 1, INFERNO_STOPS.length - 1);
  const frac = t - lower;

  return [
    Math.round(INFERNO_STOPS[lower][0] + (INFERNO_STOPS[upper][0] - INFERNO_STOPS[lower][0]) * frac),
    Math.round(INFERNO_STOPS[lower][1] + (INFERNO_STOPS[upper][1] - INFERNO_STOPS[lower][1]) * frac),
    Math.round(INFERNO_STOPS[lower][2] + (INFERNO_STOPS[upper][2] - INFERNO_STOPS[lower][2]) * frac),
  ];
}

/**
 * 获取颜色映射的CSS渐变字符串（用于图例）
 */
export function getColorGradient(): string {
  // 图例从零色开始，经过所有inferno stops
  const allStops = [ZERO_COLOR, ...INFERNO_STOPS];
  const stops = allStops.map((c, i) => {
    const pct = (i / (allStops.length - 1)) * 100;
    return `rgb(${c[0]},${c[1]},${c[2]}) ${pct}%`;
  });
  return `linear-gradient(to right, ${stops.join(", ")})`;
}
