import { analyzeSeatArea, snapshotSeatAreaMetadata } from "./seatArea";
import { analyzeSeatForce } from "./seatTotalForceFrame";
import { nativeSeeds } from "./seatPiecewiseForce";
import { calculateSeatRegionPressure, type SeatPressureContext } from "./seatRegionPressure";
import { analyzeBackrestArea } from "./backrestArea";
import { rescaleBackrestRegionPressure } from "./backrestRegionPressure";
import { analyzeBackrestForce, type BackrestStreamContext } from "./backrestForce";
import { BackrestTaxelEstimator } from "./backrestTaxelRuntime";
import { calculateBackrestTaxelPressure } from "./backrestTaxelPressure";
import type { ContinuousForceFrame } from "./sensorForce";

export const HUMAN_ESTIMATION_BRANCH_VERSION = "existing-continuous-human-area600-inclusive-force2-20261030";
export const HUMAN_ESTIMATION_AREA_THRESHOLD_CM2 = 600;
export const HUMAN_ESTIMATION_MASS_THRESHOLD_KG = null;
export const HUMAN_ESTIMATION_FORCE_THRESHOLD_N = null;
export const HUMAN_ESTIMATION_FORCE_MULTIPLIER = 2;

/** Over-range estimates are equivalent supported mass, never full body weight. */
export interface HumanEstimationMetadata {
  active: true;
  branchVersion: string;
  sensorType: "endi-23x23" | "new-backrest-32x25";
  areaThresholdCm2: 600;
  massThresholdKg: null;
  forceThresholdN: null;
  triggerMode: "area_only";
  areaThresholdComparison: "greater_or_equal";
  forceMultiplier: 2;
  fullFrameAreaCm2: number;
  provisionalForceN: number;
  provisionalMassKg: number;
  estimatedForceN: number;
  estimatedMassKg: number;
  averagePressureKPa: number | null;
  sourceMethod: "per_cell_gmap" | "taxel_continuous";
  sourceModelVersion: string;
  calibrationStatus: "area_triggered_continuous_estimate";
}

/** Area-only current-frame gate, including equality; reject invalid numeric data. */
export function shouldUseHumanEstimation(areaCm2: number, forceN: number): boolean {
  return Number.isFinite(areaCm2) && Number.isFinite(forceN)
    && areaCm2 >= HUMAN_ESTIMATION_AREA_THRESHOLD_CM2;
}

function decorateHumanEstimate(
  candidate: ContinuousForceFrame,
  sensorType: HumanEstimationMetadata["sensorType"],
  sourceMethod: HumanEstimationMetadata["sourceMethod"],
  areaCm2: number,
): ContinuousForceFrame {
  const sourceModelVersion = candidate.modelVersion;
  // Apply the requested gain only to published results; never alter ADC or filter history.
  const forceN = candidate.forceN * HUMAN_ESTIMATION_FORCE_MULTIPLIER;
  const regionForcesN = candidate.regionForcesN.map(value => value * HUMAN_ESTIMATION_FORCE_MULTIPLIER);
  const contactPressure = candidate.contactPressure
    ? rescaleBackrestRegionPressure(candidate.contactPressure, forceN, regionForcesN) : undefined;
  const averagePressureKPa = contactPressure ? contactPressure.averagePressureKPa
    : candidate.averagePressureKPa === null ? null : candidate.averagePressureKPa * HUMAN_ESTIMATION_FORCE_MULTIPLIER;
  const scaled: ContinuousForceFrame = {
    ...candidate, forceN, regionForcesN, contactPressure, averagePressureKPa,
    ...(candidate.cellForceMapN ? { cellForceMapN: candidate.cellForceMapN.map(row => row.map(value => value * HUMAN_ESTIMATION_FORCE_MULTIPLIER)) } : {}),
    ...(candidate.backrestTaxelDiagnostics ? { backrestTaxelDiagnostics: {
      ...candidate.backrestTaxelDiagnostics,
      contacts: candidate.backrestTaxelDiagnostics.contacts.map(contact => ({ ...contact, forceN: contact.forceN * HUMAN_ESTIMATION_FORCE_MULTIPLIER })),
    } } : {}),
  };
  const metadata: HumanEstimationMetadata = {
    active: true, branchVersion: HUMAN_ESTIMATION_BRANCH_VERSION, sensorType,
    areaThresholdCm2: HUMAN_ESTIMATION_AREA_THRESHOLD_CM2,
    massThresholdKg: HUMAN_ESTIMATION_MASS_THRESHOLD_KG,
    forceThresholdN: HUMAN_ESTIMATION_FORCE_THRESHOLD_N,
    triggerMode: "area_only", areaThresholdComparison: "greater_or_equal",
    forceMultiplier: HUMAN_ESTIMATION_FORCE_MULTIPLIER,
    fullFrameAreaCm2: areaCm2,
    provisionalForceN: candidate.forceN, provisionalMassKg: candidate.forceN / 9.8,
    estimatedForceN: scaled.forceN, estimatedMassKg: scaled.forceN / 9.8,
    averagePressureKPa: scaled.averagePressureKPa,
    sourceMethod, sourceModelVersion, calibrationStatus: "area_triggered_continuous_estimate",
  };
  return {
    ...scaled, humanEstimation: metadata,
    algorithmId: `${sensorType === "endi-23x23" ? "seat" : "backrest"}-human-area-existing-continuous-force2-estimate`,
    algorithmLabel: `${sensorType === "endi-23x23" ? "坐垫" : "靠背"}大面积承载力估算`,
    modelVersion: `${sourceModelVersion}|${HUMAN_ESTIMATION_BRANCH_VERSION}`,
    status: "human_estimate_area_triggered", accepted: false, independentlyValidated: false,
    forceMeaning: "continuous_adc_regression", calculationMode: "continuous_adc_regression",
    loadLabel: "大面积接触的连续承载力估算（系数2，非人体总重）", scoreMargin: null,
    scopeNote: "原算法全帧接触面积达到600cm²即启用连续估算，不设置力或重量门限。按用户设置将原连续算法估算力乘2，各区力及压强同步换算；ADC、面积、原曲线系数及区域压强公式保持原样。主平均压强沿用原区域算术平均与缺失判定。等效承载质量为缩放后F/9.8，不代表人体总重。系数2为用户设置，未经真人参考数据标定。",
  };
}

/** Stateless shadow calculation; a failed gate returns the exact original object. */
export function maybeEstimateSeatHuman(
  original: ContinuousForceFrame,
  source: number[][],
  physical: number[][],
  context?: SeatPressureContext,
): ContinuousForceFrame {
  if ((original.calculationMode !== "fixed_load_recognition" && original.calculationMode !== "calibrated_interval_estimation")
    || !Number.isFinite(original.areaCm2) || original.areaCm2 < HUMAN_ESTIMATION_AREA_THRESHOLD_CM2) return original;
  try {
    const pressureContext = context ?? { area: analyzeSeatArea(source), rotation: 0, static: true };
    const area = pressureContext.area;
    if (area.areaCm2 < HUMAN_ESTIMATION_AREA_THRESHOLD_CM2) return original;
    const candidate = analyzeSeatForce(source, physical, pressureContext, "per_cell_gmap");
    if (!shouldUseHumanEstimation(area.areaCm2, candidate.forceN)) return original;
    const contactPressure = calculateSeatRegionPressure(physical, candidate.forceN, pressureContext);
    const continuous = {
      ...candidate, areaCm2: area.areaCm2, seatAreaMetadata: snapshotSeatAreaMetadata(area),
      contactPressure, averagePressureKPa: contactPressure.averagePressureKPa,
      seedCount: contactPressure.regions.length, forceAggregation: "regional_sum" as const,
      regionForcesN: contactPressure.regions.map(region => region.estimatedForceN),
      regionCenters: nativeSeeds(source, pressureContext).map(([r, c]) => [r / 2, c / 2] as [number, number]),
    };
    return decorateHumanEstimate(continuous, "endi-23x23", "per_cell_gmap", area.areaCm2);
  } catch { return original; }
}

const transpose = (matrix: number[][]): number[][] => matrix[0].map((_, col) => matrix.map(row => row[col]));
type CandidateCache = WeakMap<ContinuousForceFrame, ContinuousForceFrame | null>;
let liveCandidates: CandidateCache = new WeakMap();
let staticCandidates: CandidateCache = new WeakMap();
let liveResults = new WeakMap<ContinuousForceFrame, Map<number, ContinuousForceFrame>>();
let staticResults = new WeakMap<ContinuousForceFrame, Map<number, ContinuousForceFrame>>();
const shadowEstimator = new BackrestTaxelEstimator();
let shadowStreamId: string | null = null;
let shadowMethod: string | null = null;
let lastRawTimestamp: number | null = null;
let lastSampleTimestamp: number | null = null;

/** Called with the existing backrest reset through sensorForce's reset wrapper. */
export function resetHumanBackrestEstimation(): void {
  shadowEstimator.reset(); liveCandidates = new WeakMap(); staticCandidates = new WeakMap();
  liveResults = new WeakMap(); staticResults = new WeakMap();
  shadowStreamId = null; shadowMethod = null;
  lastRawTimestamp = null; lastSampleTimestamp = null;
}

function backrestCandidate(
  identity: ContinuousForceFrame, source: number[][], physical: number[][],
  context?: BackrestStreamContext,
): ContinuousForceFrame | null {
  const isLive = !!context && !context.static;
  const cache = isLive ? liveCandidates : staticCandidates;
  if (cache.has(identity)) return cache.get(identity) ?? null;
  let candidate: ContinuousForceFrame | null = null;
  try {
    let sampleTimestamp = context?.timestampMs ?? 0;
    // Match the original estimator's treatment of successive frames sharing a clock tick.
    if (isLive && lastRawTimestamp !== null && sampleTimestamp === lastRawTimestamp) sampleTimestamp = lastSampleTimestamp! + .001;
    else if (isLive && lastRawTimestamp !== null && sampleTimestamp > lastRawTimestamp) sampleTimestamp = Math.max(sampleTimestamp, lastSampleTimestamp! + .001);
    const canonical = analyzeBackrestForce(transpose(source), transpose(physical), sampleTimestamp,
      isLive ? shadowEstimator : undefined, "taxel_continuous");
    if (isLive) { lastRawTimestamp = context.timestampMs; lastSampleTimestamp = sampleTimestamp; }
    const cellForceMapN = transpose(canonical.cellForceMapN!);
    const area = analyzeBackrestArea(source);
    const contactPressure = calculateBackrestTaxelPressure(source, physical, cellForceMapN, area);
    candidate = {
      ...canonical, cellForceMapN, areaCm2: area.areaCm2, seedCount: area.seedCount,
      regionForcesN: contactPressure.regions.map(region => region.estimatedForceN),
      regionCenters: area.seeds.map(([r, c]) => [r / 2, c / 2]),
      forceAggregation: area.seedCount ? "regional_sum" : "total_only",
      contactPressure, averagePressureKPa: contactPressure.averagePressureKPa,
      inputMode: "original-physical-adc-32x25-native-fixed-transpose-causal-filtered",
    };
  } catch { /* Invalid/incomplete frames cannot activate an estimate. */ }
  cache.set(identity, candidate);
  return candidate;
}

/** Separate history never switches or advances the existing recognition estimator. */
export function maybeEstimateBackrestHuman(
  original: ContinuousForceFrame,
  source: number[][],
  physical: number[][],
  context?: BackrestStreamContext,
  frameIdentity: ContinuousForceFrame = original,
): ContinuousForceFrame {
  const isLive = !!context && !context.static;
  const method = context?.method ?? "fixed_load_recognition";
  if (isLive && (context.streamId !== shadowStreamId || method !== shadowMethod)) {
    resetHumanBackrestEstimation(); shadowStreamId = context.streamId; shadowMethod = method;
  }
  if (method !== "fixed_load_recognition") return original;
  // Live shadow tracks all fixed-route frames, so entering the gate retains direction.
  // Static small-area reads need no estimator and never touch live history.
  if (!isLive && (!Number.isFinite(original.areaCm2) || original.areaCm2 < HUMAN_ESTIMATION_AREA_THRESHOLD_CM2)) return original;
  const candidate = backrestCandidate(frameIdentity, source, physical, context);
  if (!candidate || !shouldUseHumanEstimation(original.areaCm2, candidate.forceN)) return original;
  const results = isLive ? liveResults : staticResults;
  let areas = results.get(frameIdentity);
  if (!areas) { areas = new Map(); results.set(frameIdentity, areas); }
  if (!areas.has(original.areaCm2)) {
    areas.set(original.areaCm2, decorateHumanEstimate({ ...candidate, areaCm2: original.areaCm2 },
      "new-backrest-32x25", "taxel_continuous", original.areaCm2));
  }
  return areas.get(original.areaCm2)!;
}
