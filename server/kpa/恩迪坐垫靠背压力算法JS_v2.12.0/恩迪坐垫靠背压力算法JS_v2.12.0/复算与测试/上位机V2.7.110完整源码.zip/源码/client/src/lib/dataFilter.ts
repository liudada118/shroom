/**
 * 数据过滤与标定模式 V6.0 (V2.0.0)
 *
 * V2.0.0 更新：
 * - 简化标定模式：去掉A/B/C多模式，只保留"无标定"和"压强标定"
 * - 压强标定使用过滤后非零总和(sum)作为输入
 * - 所有过滤统一使用用户设置的过滤阈值
 *
 * 结果标定系数：所有ADC值乘以该系数后显示和计算，点数不变
 */

export type CalibrationMode = "none" | "pressure";

export interface FilterConfig {
  /** 过滤阈值，低于等于此值的数据被过滤 */
  threshold: number;
  /** 标定模式 */
  calibrationMode: CalibrationMode;
  /** 结果标定系数，默认1，所有ADC值乘以该系数 */
  resultScale: number;
  /**
   * 锁定点位集合（可选）。格式为 Set<"row,col">。
   * 当提供时，只有锁定点位内的值参与统计计算（avg/sum/nz等），
   * 但 filteredMatrix 中所有有效点位仍然保留值（用于热力图显示）。
   */
  lockedPositions?: Set<string>;
}

export interface FilteredStats {
  max: number;
  min: number;
  avg: number;
  sum: number;
  nonZeroCount: number;
  nonZeroMin: number;
  coverage: number;
  /** 过滤后的矩阵（被过滤的值设为0，已应用结果标定系数） */
  filteredMatrix: number[][];
  /** 加权均值 */
  weightedAvg?: number;
}

/**
 * 辅助函数：构建过滤后矩阵并计算统计
 */
function buildFilteredResult(
  matrix: number[][],
  isValid: (val: number, row: number, col: number) => boolean,
  scale: number,
  lockedPositions?: Set<string>
): FilteredStats {
  const rows = matrix.length;
  const cols = matrix[0]?.length ?? 0;
  const totalPoints = rows * cols;
  const filteredMatrix: number[][] = [];
  let max = 0, min = Infinity, sum = 0, nonZeroCount = 0, nonZeroMin = Infinity;
  let weightedSum = 0, weightTotal = 0;

  for (let r = 0; r < rows; r++) {
    const row: number[] = [];
    for (let c = 0; c < cols; c++) {
      const val = matrix[r][c];
      if (val <= 0 || !isValid(val, r, c)) {
        row.push(0);
      } else {
        const scaledVal = Math.round(val * scale);
        if (scaledVal <= 0) { row.push(0); continue; }
        row.push(scaledVal);
        const inLocked = !lockedPositions || lockedPositions.has(`${r},${c}`);
        if (inLocked) {
          if (scaledVal > max) max = scaledVal;
          if (scaledVal < min) min = scaledVal;
          if (scaledVal < nonZeroMin) nonZeroMin = scaledVal;
          sum += scaledVal;
          nonZeroCount++;
          weightedSum += scaledVal * scaledVal;
          weightTotal += scaledVal;
        }
      }
    }
    filteredMatrix.push(row);
  }

  if (nonZeroCount === 0) { min = 0; nonZeroMin = 0; }
  if (nonZeroMin === Infinity) nonZeroMin = 0;
  if (min === Infinity) min = 0;

  const avg = nonZeroCount > 0 ? Math.round((sum / nonZeroCount) * 100) / 100 : 0;
  const coverage = Math.round((nonZeroCount / totalPoints) * 1000) / 10;
  const weightedAvg = weightTotal > 0 ? Math.round((weightedSum / weightTotal) * 100) / 100 : 0;

  return { max, min, avg, sum, nonZeroCount, nonZeroMin, coverage, filteredMatrix, weightedAvg };
}

/**
 * 应用过滤阈值和结果标定系数，返回过滤后的矩阵和统计数据
 */
export function applyFilter(
  matrix: number[][],
  config: FilterConfig
): FilteredStats {
  const scale = config.resultScale;
  const locked = config.lockedPositions;

  return buildFilteredResult(
    matrix,
    (val) => val > config.threshold,
    scale,
    locked
  );
}
