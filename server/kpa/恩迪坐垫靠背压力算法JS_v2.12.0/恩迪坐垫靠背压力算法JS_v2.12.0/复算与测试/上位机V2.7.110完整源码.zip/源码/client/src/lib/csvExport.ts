/** Fitting CSV: only original bytes, physical ADC, raw interpolated ADC and metadata. */
import {
  collectFittingFrames, fittingMetadataRow, fittingMatrixSize, FITTING_METADATA_HEADERS,
  type FittingCell, type FittingExportFrame, type FittingExportConfig,
} from "./fittingExportData";

/** Legacy type names retained for callers. Only the fitting whitelist is read. */
export type CaptureCsvFrame = FittingExportFrame;
export type CaptureCsvData = FittingExportFrame["data"];
export type CaptureCsvConfig = FittingExportConfig;

function csvCell(value: FittingCell): string {
  const text = String(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

/** Deterministic string builder. Captured objects and arrays are only read.
 * IDs sort the combined manual/automatic/continuous input and remove duplicate
 * copies of the same frame. Actual reference labels are deliberately blank.
 */
export function buildCaptureCsv(
  frames: readonly CaptureCsvFrame[], _config: CaptureCsvConfig,
  _visibleFields: readonly string[] = [],
): string {
  const retainedFrames = collectFittingFrames(frames);
  const lines: string[] = [];
  const append = (row: readonly FittingCell[]) => lines.push(row.map(csvCell).join(","));
  append(["=== 拟合用原始数据 ==="]);
  append(["说明", "仅保留原始字节、插值前原始物理ADC、ADC补偿前插值ADC与帧元数据；实测标签留空，请按实际实验记录填写。"]);
  append(["坐标", "原始字节保持接收顺序，偏移从0开始。物理/插值矩阵保持采集保存方向：R0/C0为矩阵左上角，行向下、列向右；具体方向见每帧行列序。数值原值导出。"]);
  append([]);
  append(FITTING_METADATA_HEADERS);
  retainedFrames.forEach(frame => append(fittingMetadataRow(frame)));
  append([]);

  const appendMatrix = (title: string, matrix?: number[][]) => {
    append([title]);
    if (!matrix?.length) {
      append(["未保存原始矩阵"]);
    } else {
      const columns = matrix[0]?.length ?? 0;
      append(["", ...Array.from({length: columns}, (_, column) => `C${column}`)]);
      matrix.forEach((row, index) => append([`R${index}`, ...row]));
    }
    append([]);
  };
  retainedFrames.forEach(frame => {
    append([`--- 帧序号 #${frame.id} ---`]);
    const raw = frame.data.raw;
    append([`原始字节（${raw?.length ?? 0}字节）`]);
    if (!raw?.length) {
      append(["原始字节未保存"]);
    } else {
      const bytesPerRow = 32;
      append(["偏移", ...Array.from({length: bytesPerRow}, (_, column) => `B+${column}`)]);
      for (let offset = 0; offset < raw.length; offset += bytesPerRow) {
        append([offset, ...raw.slice(offset, offset + bytesPerRow)]);
      }
    }
    append([]);
    appendMatrix(`插值前原始物理矩阵（${fittingMatrixSize(frame.data.physical)}）`, frame.data.physical);
    appendMatrix(`ADC补偿前插值矩阵（${fittingMatrixSize(frame.data.sourceMatrix)}）`, frame.data.sourceMatrix);
  });
  return "\uFEFF" + lines.join("\r\n");
}
