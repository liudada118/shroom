/**
 * 恩迪坐垫（endi-23x23）面积与压力算法 —— 上位机接入层
 * ----------------------------------------------------------------------------
 * 替换原坐垫链路（原接触区分割 + PCHIP 区间估算、原面积模型、面积 ≥ 600 cm² 真人分支）。
 * 算法核心 endiCushion/endiCushionCore.js 由实测数据拟合（31 位置 × 2 组 × 5 档），
 * 与 Python 参考实现逐帧一致；本文件只负责：
 *   1. 方向：串口 wireMap 原生物理矩阵 → 顺时针 90° → 算法方向。
 *      算法方向 = “拟合用原始数据” CSV 中“插值前原始物理矩阵”的方向（= 热力图屏幕方向，R0/C0 为左上角），
 *      已用原始字节逐帧核对（1000/1000 帧一致）。显示旋转设置不影响算法输入。
 *   2. 输入：未做 ADC 补偿的原始物理 ADC（sourcePhysical），与拟合数据口径一致。
 *   3. 实时会话：每个 streamId 一个有状态实例；同一帧对象只处理一次；时间戳保持严格递增，
 *      时间倒退（如 CSV 回放跳转）由核心自动重置。
 *   4. 输出映射为上位机 ContinuousForceFrame：总力、面积、各区压强及区域平均压强。
 *   5. V2.7.103 超量程与真人估算（真人仅坐垫；两者互斥，不会叠乘；V2.7.104 真人压力系数改为 0.4，V2.7.105 改为 1，V2.7.106 改回 0.4，V2.7.107 真人面积系数 0.8 改为 0.9）。核心输出未乘倍率的基准值 m / F / S，本层施加系数：
 *      · 真人估算：全帧基准面积 ΣS > 600 cm² 且全帧基准力 ΣF > 300 N 时启动（条件连续不满足 500 ms 后退出），
 *        全部非标准档接触区压力 ×0.4（V2.7.106 起）、面积 ×0.9（V2.7.107 起，原 ×0.8）
 *        （压强 = 0.4F / 0.9S ≈ 0.444 × 基准压强），不再乘超量程 ×2；识别为标准砝码（标准档）的接触区不变。
 *      · 超量程估算：未启动真人估算时，基准估算力 F > 90 N 且连续拟合估算力 9.8·m_fit > 90 N（双重确认超过 5 块砝码）
 *        的接触区压力 ×2，面积取 T29 轮廓不乘倍率（核心 over 标记：满足即启动，任一回落 ≤ 90 N 连续 500 ms 后取消）。
 *      · 其余接触区系数为 1。实时会话中每个接触区的系数切换按 120 ms S 曲线过渡。
 *   6. V2.7.110 真人估算区逐格压强最大值 ×1.5：本文件给出每区 humanWeight（真人 1、其余 0，与系数同一 120 ms 过渡）
 *      与 peakPressureGain = 1 + 0.5 × humanWeight；逐格压强模块（endiPointPressure.ts）按该倍数重新分配真人区格子压强，
 *      最大格 = 原比例分配最大格 × 1.5，区内格子平均仍 = 区压强（平均压强与格子平均不变）。
 */
import {
  EndiAlgorithm, DEFAULT_PARAMS, ENDI_CUSHION_CORE_VERSION, ENDI_CUSHION_CORE_SOURCE_SHA256,
  type EndiAlgorithmInstance, type EndiFrameOutput, type EndiRegionOutput,
} from "./endiCushion/endiCushionCore.js";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";
import { pressureKPaFromForceArea, roundAreaCm2, roundForceN, roundPressureKPa } from "./pressureUnits";
import type { ContinuousForceFrame } from "./sensorForce";

type Matrix = number[][];

export const ENDI_SEAT_ALGORITHM_ID = "endi-cushion-anchor-state-machine-g9p8" as const;
export const ENDI_SEAT_ALGORITHM_LABEL = "恩迪坐垫实测拟合算法（位置锚点＋相对档位状态机，g=9.8）" as const;
export const ENDI_SEAT_MODEL_VERSION = `endi-cushion-${ENDI_CUSHION_CORE_VERSION}-fit-20261109`;
export const ENDI_SEAT_PRESSURE_VERSION = "endi-cushion-region-pressure-mean-g9p8-20261109" as const;
export const ENDI_SEAT_CONTACT_VERSION = "endi-algo-orientation-adc1-8conn-min3-20261109" as const;
export const ENDI_SEAT_AREA_VERSION = "endi-cushion-t29-contour-count-20261109" as const;
export const ENDI_SEAT_CALCULATION_MODE = "endi_cushion_fitted" as const;
export const ENDI_SEAT_CORE_SOURCE_SHA256 = ENDI_CUSHION_CORE_SOURCE_SHA256;

const N_PHYS = 23;
const N_INT = 46;
export const ENDI_SEAT_GRAVITY = DEFAULT_PARAMS.standard.g;
export const ENDI_SEAT_UNIT_MASS_KG = DEFAULT_PARAMS.standard.mb;
export const ENDI_SEAT_BASE_AREA_CM2 = DEFAULT_PARAMS.standard.base_area;
export const ENDI_SEAT_AREA_THRESHOLD_ADC = DEFAULT_PARAMS.area.T;
/** V2.7.103：超量程启动门限——接触区基准估算力 > 90 N（超过 5 块砝码：5 块 = 79.63 N，6 块 = 95.55 N）。 */
export const ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N = DEFAULT_PARAMS.over.force_in;
/** 超量程估算压力倍率（规定值 ×2；面积不乘倍率）。 */
export const ENDI_SEAT_OVER_RANGE_GAIN = DEFAULT_PARAMS.over.gain;

/** V2.7.103：真人估算启动门限——全帧基准面积 > 600 cm²。 */
export const ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2 = 600;
/** V2.7.103：真人估算启动门限——全帧基准力 > 300 N（与面积条件同时满足）。 */
export const ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N = 300;
/** 真人估算压力系数（V2.7.104：0.3 → 0.4；V2.7.105：0.4 → 1；V2.7.106：1 → 0.4）。 */
export const ENDI_SEAT_HUMAN_FORCE_FACTOR = 0.4;
/** 真人估算面积系数（V2.7.107：0.8 → 0.9）。 */
export const ENDI_SEAT_HUMAN_AREA_FACTOR = 0.9;
/** 真人估算退出防抖：条件（ΣS > 600 cm² 且 ΣF > 300 N）连续不满足 500 ms 后才退出（与超量程退出保持时间相同）。 */
export const ENDI_SEAT_HUMAN_EXIT_HOLD_MS = Number(DEFAULT_PARAMS.over.hold_ms) > 0 ? Number(DEFAULT_PARAMS.over.hold_ms) : 500;
/** V2.7.110：真人估算区逐格压强最大值倍数（最大格 = 原比例分配最大格 × 1.5；区内格子平均不变）。 */
export const ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN = 1.5;
export const ENDI_SEAT_HUMAN_VERSION = "endi-cushion-human-frame-area-gt600-force-gt300-force0.4-area0.9-peak1.5-v110-20261114" as const;
export const ENDI_SEAT_OVER_RANGE_VERSION = "endi-cushion-over-range-base-force-gt90n-gain2-20261113" as const;
/** 系数切换过渡时长（与核心换模式平滑 smooth_ms 相同）。 */
const FACTOR_SMOOTH_MS = Number(DEFAULT_PARAMS.smooth_ms) > 0 ? Number(DEFAULT_PARAMS.smooth_ms) : 120;

/** 接触区系数类别：标准（×1）/ 超量程估算（压力 ×2）/ 真人估算（压力 ×0.4、面积 ×0.9）。 */
export type EndiSeatFactorKind = "standard" | "over_range" | "human";

/** 每个接触区的诊断信息（与输出同帧）。 */
export interface EndiSeatRegionDiagnostics {
  track: number;
  mode: EndiRegionOutput["mode"];
  state: EndiRegionOutput["state"];
  /** 当前识别块数（尚未定档时为 0）。 */
  level: number;
  massKg: number;
  forceN: number;
  areaCm2: number;
  pressureKPa: number | null;
  footprint: boolean;
  contourCells: number;
  fitMassKg: number;
  peakAdc: number;
  overRange: boolean;
  frozen: boolean;
  /** 算法方向（热力图屏幕方向）物理格坐标 [行, 列]。 */
  center: [number, number];
  adcSum: number;
  cells: number;
  /** V2.7.103：本区系数类别（真人估算优先于超量程，两者互斥）。 */
  factorKind: EndiSeatFactorKind;
  /** 本区按真人估算输出（全帧 ΣS > 600 cm² 且 ΣF > 300 N，且本区不是标准档）。 */
  humanEstimate: boolean;
  /** 本区按超量程估算输出（核心 over：基准估算力与连续拟合估算力均 > 90 N，且未启动真人估算），压力 ×2。 */
  overRangeEstimate: boolean;
  /** 本区实际使用的压力系数（真人 1、超量程 2、其余 1；实时会话中切换期间按 120 ms 过渡）。 */
  forceFactor: number;
  /** 本区实际使用的面积系数（真人 0.9、其余 1；切换期间按 120 ms 过渡）。 */
  areaFactor: number;
  /** V2.7.110：真人估算权重（真人 1、其余 0；切换期间与系数同一 120 ms 过渡）。 */
  humanWeight: number;
  /** V2.7.110：本区逐格压强最大值倍数 = 1 + (1.5 − 1) × humanWeight（真人 1.5、其余 1），由逐格压强模块使用。 */
  peakPressureGain: number;
  /** 算法核心原值（乘系数前的基准值）。 */
  coreMassKg: number;
  coreForceN: number;
  coreAreaCm2: number;
  corePressureKPa: number | null;
}

export interface EndiSeatDiagnostics {
  version: string;
  coreVersion: string;
  coreSourceSha256: string;
  gravityMS2: number;
  unitMassKg: number;
  baseAreaCm2: number;
  areaThresholdAdc: number;
  inputOrientation: "native-rotated-90cw";
  massKg: number;
  humanVersion: typeof ENDI_SEAT_HUMAN_VERSION;
  humanForceFactor: number;
  humanAreaFactor: number;
  /** V2.7.110：真人估算区逐格压强最大值倍数（1.5）。 */
  humanPeakPressureGain: number;
  humanAreaThresholdCm2: number;
  humanForceThresholdN: number;
  /** 全帧基准面积 ΣS（乘系数前，cm²），用于真人估算判定。 */
  baseAreaTotalCm2: number;
  /** 全帧基准力 ΣF（乘系数前，N），用于真人估算判定。 */
  baseForceTotalN: number;
  /** 本帧基准值是否满足真人条件（ΣS > 600 cm² 且 ΣF > 300 N，未防抖）。 */
  humanConditionMet: boolean;
  /** 真人估算退出防抖时长（ms）。 */
  humanExitHoldMs: number;
  /** 本帧是否按真人估算输出（满足条件即启动；条件连续不满足 500 ms 后退出）。 */
  humanEstimateActive: boolean;
  overRangeVersion: typeof ENDI_SEAT_OVER_RANGE_VERSION;
  overRangeForceThresholdN: number;
  overRangeGain: number;
  /** 本帧是否存在超量程估算接触区（按超量程 ×2 输出）。 */
  overRangeActive: boolean;
  regions: EndiSeatRegionDiagnostics[];
}

/** 框选 / 采集留档用的 T29 轮廓格数面积（每格 10 mm × 10 mm = 1 cm²）。 */
export interface EndiSeatAreaFrame {
  version: typeof ENDI_SEAT_AREA_VERSION;
  modelVersion: typeof ENDI_SEAT_AREA_VERSION;
  algorithmId: "endi-cushion-t29-contour-count";
  algorithmLabel: "恩迪坐垫T29轮廓格数面积";
  sensorType: "endi-23x23";
  status: "no_contact" | "measured";
  unit: "cm²";
  scope: "full_frame" | "selection";
  rows: number;
  cols: number;
  cellAreaCm2: 1;
  areaCm2: number;
  retainedCellCount: number;
  thresholdAdc: number;
}

function isAdcMatrix(m: unknown, rows: number, cols: number): m is Matrix {
  if (!Array.isArray(m) || m.length !== rows) return false;
  for (const row of m) {
    if (!Array.isArray(row) || row.length !== cols) return false;
    for (const v of row) if (typeof v !== "number" || !Number.isFinite(v) || v < 0 || v > 255) return false;
  }
  return true;
}

/** 原生 wireMap 方向 → 算法方向：顺时针旋转 90°，out[r][c] = native[22 − c][r]。 */
export function endiNativeToAlgorithm(native: Matrix): Matrix {
  const out: Matrix = new Array(N_PHYS);
  for (let r = 0; r < N_PHYS; r++) {
    const row = new Array<number>(N_PHYS);
    for (let c = 0; c < N_PHYS; c++) row[c] = native[N_PHYS - 1 - c][r];
    out[r] = row;
  }
  return out;
}

/** 全帧基准面积 / 基准力（核心未乘系数的值，各区相加）。 */
export function endiSeatBaseTotals(regions: readonly Pick<EndiRegionOutput, "F" | "S">[]): { areaCm2: number; forceN: number } {
  let areaCm2 = 0, forceN = 0;
  for (const r of regions) { areaCm2 += r.S; forceN += r.F; }
  return { areaCm2, forceN };
}

/** V2.7.103 真人估算判定（全帧）：基准面积 > 600 cm² 且基准力 > 300 N。 */
export function isEndiSeatHumanFrame(regions: readonly Pick<EndiRegionOutput, "F" | "S">[]): boolean {
  const { areaCm2, forceN } = endiSeatBaseTotals(regions);
  return areaCm2 > ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2 && forceN > ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N;
}

/**
 * V2.7.103 超量程判定（逐区）：取核心 over 标记——本帧基准估算力 9.8 × m > 90 N 且连续拟合估算力 9.8 × m_fit > 90 N 立即启动，
 * 任一回落 ≤ 90 N 连续 500 ms 后取消（核心内防抖，与冻结退出保持时间相同）。
 */
export function isEndiSeatOverRangeRegion(r: Pick<EndiRegionOutput, "over">): boolean {
  return r.over === true;
}

/**
 * 各接触区的目标系数类别：真人估算（全帧）优先；否则超量程（逐区）；否则标准 ×1。标准档接触区不受真人估算影响。
 * @param humanActive 本帧是否处于真人估算（实时会话传入防抖后的状态；缺省按本帧条件判定）
 */
export function endiSeatFactorKinds(regions: readonly EndiRegionOutput[], humanActive = isEndiSeatHumanFrame(regions)): EndiSeatFactorKind[] {
  const human = humanActive;
  return regions.map(r => {
    if (human && r.mode !== "标准档") return "human";
    if (isEndiSeatOverRangeRegion(r)) return "over_range";
    return "standard";
  });
}

/** 系数类别 → 真人估算权重（真人 1、其余 0）。 */
export function endiSeatKindHumanWeight(kind: EndiSeatFactorKind): number {
  return kind === "human" ? 1 : 0;
}

/** 真人估算权重 → 逐格压强最大值倍数（权重 1 时为 1.5，权重 0 时为 1）。 */
export function endiSeatPeakPressureGain(humanWeight: number): number {
  const w = Math.min(Math.max(Number.isFinite(humanWeight) ? humanWeight : 0, 0), 1);
  return 1 + (ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN - 1) * w;
}

/** 系数类别 → [压力系数, 面积系数]。 */
export function endiSeatKindFactors(kind: EndiSeatFactorKind): [number, number] {
  if (kind === "human") return [ENDI_SEAT_HUMAN_FORCE_FACTOR, ENDI_SEAT_HUMAN_AREA_FACTOR];
  if (kind === "over_range") return [ENDI_SEAT_OVER_RANGE_GAIN, 1];
  return [1, 1];
}

function regionLabel(r: EndiRegionOutput, kind: EndiSeatFactorKind, massKg: number): string {
  if (kind === "human") {
    return `真人估算 ${massKg.toFixed(2)} kg（压力×${ENDI_SEAT_HUMAN_FORCE_FACTOR}，面积×${ENDI_SEAT_HUMAN_AREA_FACTOR}，最大压强×${ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN}）`;
  }
  if (kind === "over_range") {
    return `超量程估算 ${massKg.toFixed(2)} kg（压力×${ENDI_SEAT_OVER_RANGE_GAIN}）`;
  }
  if (r.mode === "标准档") {
    return r.level > 0 ? `${r.level}块（${(r.level * ENDI_SEAT_UNIT_MASS_KG).toFixed(3)} kg，${r.state}）` : `标准档（${r.state}）`;
  }
  return `${r.mode} ${massKg.toFixed(2)} kg`;
}

function smoothStep(tau: number): number {
  const x = Math.min(Math.max(tau, 0), 1);
  return 3 * x * x - 2 * x * x * x;
}

const SCOPE_NOTE = "恩迪坐垫实测拟合算法：未补偿原始物理ADC顺时针90°进入算法方向；接触区=ADC≥1八邻域连通（≥3格），"
  + "响应量R=Σ−ln(1−ADC/256)经3帧中值滤波，按31个位置锚点（σ=2.5格）与相对档位状态机识别标准砝码块数（每块1.625kg），"
  + "非砝码轮廓按连续拟合估算；F=9.8m。面积=46×46插值矩阵T29轮廓：标准档每区取砝码底面63.62cm²，"
  + "估算按轮廓格数×1cm²；各区Fⱼ取2位小数，Pⱼ=Fⱼ/Sⱼ（N/cm²，3位小数，内部存kPa=10Fⱼ/Sⱼ），总力=ΣFⱼ。"
  + "逐格压强 Pᵢ=P区×ADCᵢ/mean(ADC区)（ADC取热力图显示值，按0.001N/cm²保和取整，区内格子平均=P区），"
  + "平均压强=全部压强格子的平均值（与热力图格子显示的压强同步，同一帧、同一0.001N/cm²取整），最大压强=MAX(Pᵢ)，见 pointPressure。"
  + "V2.7.103（仅坐垫，两者互斥）：真人估算=全帧基准面积>600cm²且基准力>300N时，非标准档接触区压力×0.4、面积×0.9（压强=0.4F/0.9S，不再乘×2，条件连续不满足500ms后退出）；"
  + "否则基准估算力与连续拟合估算力均>90N（超过5块）的接触区按超量程估算压力×2、面积取T29轮廓（任一回落≤90N持续500ms后取消）；系数切换按120ms S曲线过渡。"
  + "V2.7.110：真人估算区逐格压强改为按ADCᵢ^γ分配（γ≥1自动求解），最大格=原比例分配最大格×1.5，区内保和取整，格子平均仍=区压强、平均压强仍=格子平均。";

/** 实时会话给出的本帧系数（类别已防抖，系数已按 120 ms 过渡）。 */
interface LiveFactorResult {
  humanActive: boolean;
  kinds: EndiSeatFactorKind[];
  factors: [number, number][];
  /** V2.7.110：各区真人估算权重（按 120 ms 过渡）。 */
  humanWeights: number[];
}

function toForceFrame(out: EndiFrameOutput, native: Matrix, liveResult?: LiveFactorResult): ContinuousForceFrame {
  const regions = out.regions;
  let rawAdcSum = 0;
  for (const row of native) for (const v of row) rawAdcSum += v;
  const noContact = regions.length === 0;
  // V2.7.103：真人估算（全帧 ΣS > 600 cm² 且 ΣF > 300 N）与超量程（逐区基准力与连续拟合力均 > 90 N）互斥；
  // 实时会话传入防抖后的类别与按 120 ms 过渡后的系数，静态复算直接按本帧条件取目标系数。
  const humanRaw = isEndiSeatHumanFrame(regions);
  const humanFrame = liveResult ? liveResult.humanActive : humanRaw;
  const kinds = liveResult ? liveResult.kinds : endiSeatFactorKinds(regions, humanFrame);
  const factors = regions.map((r, i) => liveResult?.factors[i] ?? endiSeatKindFactors(kinds[i]));
  const fF = factors.map(f => f[0]);
  const fS = factors.map(f => f[1]);
  const hW = regions.map((r, i) => liveResult?.humanWeights[i] ?? endiSeatKindHumanWeight(kinds[i]));
  const baseTotals = endiSeatBaseTotals(regions);
  const mOut = regions.map((r, i) => r.m * fF[i]);
  const FOut = regions.map((r, i) => r.F * fF[i]);
  const SOut = regions.map((r, i) => r.S * fS[i]);
  // V2.7.101：各区压力取 2 位小数，面积 2 位小数，压强 Pⱼ = Fⱼ/Sⱼ（N/cm²）取 3 位小数（内部 kPa = 10Fⱼ/Sⱼ，0.01 kPa 取整）；
  // 总力 = Σ 各区（取整后）压力，界面上各区压力相加等于总力。
  const regionF = FOut.map(v => roundForceN(v));
  const regionS = SOut.map(v => roundAreaCm2(v));
  const regionP = regions.map((r, i) => (r.P === null ? null : pressureKPaFromForceArea(regionF[i], regionS[i])));
  const totalF = roundForceN(regionF.reduce((s, v) => s + v, 0));
  const totalS = roundAreaCm2(SOut.reduce((s, v) => s + v, 0));
  const complete = !noContact && regionP.every(p => p !== null);
  const arithmeticMeanP = complete ? roundPressureKPa(regionP.reduce((s, p) => s + p!, 0) / regionP.length) : null;
  const prRegions = regions.map((r, i) => ({
    index: i, center: [r.cy, r.cx] as [number, number], rawAdcSum: r.adcSum,
    forceShare: totalF > 0 ? regionF[i] / totalF : 0, estimatedForceN: regionF[i], areaCm2: regionS[i], estimatedPressureKPa: regionP[i],
  }));
  const contactPressure: BackrestRegionPressureFrame = {
    version: ENDI_SEAT_PRESSURE_VERSION, method: "endi_region_force_over_region_area_then_arithmetic_mean",
    status: noContact ? "no_contact" : complete ? "estimated" : "incomplete", scope: "complete_frame",
    independentlyValidated: false, totalForceN: totalF, areaCm2: totalS, rawAdcSum,
    assignedRawAdcSum: regions.reduce((s, r) => s + r.adcSum, 0), regions: prRegions,
    // 各区算术平均；接入逐格压强后（attachEndiPointPressure）改为全部压强格子的平均值。
    averagePressureKPa: arithmeticMeanP, globalAreaMeanPressureKPa: totalS > 0 ? pressureKPaFromForceArea(totalF, totalS) : null,
  };
  const anyOver = kinds.some(k => k === "over_range");
  const anyEstimate = regions.some(r => r.mode !== "标准档");
  const diagnostics: EndiSeatDiagnostics = {
    version: ENDI_SEAT_MODEL_VERSION, coreVersion: ENDI_CUSHION_CORE_VERSION, coreSourceSha256: ENDI_CUSHION_CORE_SOURCE_SHA256,
    gravityMS2: ENDI_SEAT_GRAVITY, unitMassKg: ENDI_SEAT_UNIT_MASS_KG, baseAreaCm2: ENDI_SEAT_BASE_AREA_CM2,
    areaThresholdAdc: ENDI_SEAT_AREA_THRESHOLD_ADC, inputOrientation: "native-rotated-90cw",
    massKg: mOut.reduce((s, v) => s + v, 0),
    humanVersion: ENDI_SEAT_HUMAN_VERSION, humanForceFactor: ENDI_SEAT_HUMAN_FORCE_FACTOR,
    humanAreaFactor: ENDI_SEAT_HUMAN_AREA_FACTOR, humanPeakPressureGain: ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN,
    humanAreaThresholdCm2: ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2,
    humanForceThresholdN: ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N, baseAreaTotalCm2: baseTotals.areaCm2, baseForceTotalN: baseTotals.forceN,
    humanConditionMet: humanRaw, humanExitHoldMs: ENDI_SEAT_HUMAN_EXIT_HOLD_MS,
    humanEstimateActive: humanFrame && kinds.some(k => k === "human"),
    overRangeVersion: ENDI_SEAT_OVER_RANGE_VERSION, overRangeForceThresholdN: ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N,
    overRangeGain: ENDI_SEAT_OVER_RANGE_GAIN, overRangeActive: anyOver,
    regions: regions.map((r, i) => ({
      track: r.track, mode: r.mode, state: r.state, level: r.level, massKg: mOut[i], forceN: FOut[i], areaCm2: SOut[i],
      pressureKPa: r.P === null || !(SOut[i] > 0) ? null : 10 * FOut[i] / SOut[i],
      footprint: r.footprint, contourCells: r.NT, fitMassKg: r.mfit, peakAdc: r.peak,
      overRange: r.over, frozen: r.frozen, center: [r.cy, r.cx], adcSum: r.adcSum, cells: r.nCells,
      factorKind: kinds[i], humanEstimate: kinds[i] === "human", overRangeEstimate: kinds[i] === "over_range",
      forceFactor: fF[i], areaFactor: fS[i], humanWeight: hW[i], peakPressureGain: endiSeatPeakPressureGain(hW[i]),
      coreMassKg: r.m, coreForceN: r.F, coreAreaCm2: r.S, corePressureKPa: r.P,
    })),
  };
  return {
    algorithmId: ENDI_SEAT_ALGORITHM_ID, algorithmLabel: ENDI_SEAT_ALGORITHM_LABEL, modelVersion: ENDI_SEAT_MODEL_VERSION,
    status: noContact ? "no_contact" : anyOver ? "over_range_estimate" : anyEstimate ? "estimated" : "standard_recognized",
    forceN: totalF, averagePressureKPa: arithmeticMeanP, areaCm2: totalS, contactPressure,
    seedCount: regions.length, regionForcesN: regionF, forceAggregation: "regional_sum",
    regionCenters: regions.map(r => [r.cy, r.cx] as [number, number]),
    contactDetectionVersion: ENDI_SEAT_CONTACT_VERSION, forceEstimateComplete: true,
    calibratedSeedCount: regions.length, detectedContactCount: regions.length,
    detectedContactCenters: regions.map(r => [r.cy, r.cx] as [number, number]),
    inputMode: "native-uncompensated-physical-adc-23x23-rotated-90cw",
    accepted: false, independentlyValidated: false,
    forceMeaning: ENDI_SEAT_CALCULATION_MODE, calculationMode: ENDI_SEAT_CALCULATION_MODE,
    loadLabel: noContact ? "无接触" : regions.map((r, i) => regionLabel(r, kinds[i], mOut[i])).join("；"),
    scopeNote: SCOPE_NOTE,
    endiCushion: diagnostics,
  };
}

export interface EndiSeatStreamContext {
  timestampMs?: number;
  streamId?: string;
  /** 静态复算：使用独立实例，不推进实时会话状态。 */
  static?: boolean;
}

interface FactorBlend {
  /** 过渡起点的 [压力系数, 面积系数] */
  from: [number, number];
  /** 过渡起点的真人估算权重（V2.7.110） */
  fromHuman: number;
  /** 目标类别 */
  kind: EndiSeatFactorKind;
  t0: number;
}

interface LiveState {
  streamId: string;
  alg: EndiAlgorithmInstance;
  lastRawT: number | null;
  lastT: number | null;
  results: WeakMap<Matrix, ContinuousForceFrame>;
  /** 各轨迹系数过渡状态（键 = 核心轨迹号） */
  factors: Map<number, FactorBlend>;
  /** 真人估算防抖状态（全帧）：on = 当前处于真人估算；offSince = 条件开始连续不满足的时刻 */
  human: { on: boolean; offSince: number | null };
}

/** 过渡中的系数：s = 0 取起点，s = 1 严格取目标值。 */
function blendFactors(b: FactorBlend, t: number): [number, number] {
  const to = endiSeatKindFactors(b.kind);
  const s = smoothStep((t - b.t0) / FACTOR_SMOOTH_MS);
  if (s >= 1) return to;
  return [b.from[0] + (to[0] - b.from[0]) * s, b.from[1] + (to[1] - b.from[1]) * s];
}

/** 过渡中的真人估算权重（与系数同一 S 曲线）。 */
function blendHuman(b: FactorBlend, t: number): number {
  const to = endiSeatKindHumanWeight(b.kind);
  const s = smoothStep((t - b.t0) / FACTOR_SMOOTH_MS);
  if (s >= 1) return to;
  return b.fromHuman + (to - b.fromHuman) * s;
}

/** 真人估算防抖：条件满足立即启动；连续不满足 500 ms 后退出；无接触时立即退出。 */
function latchHuman(state: LiveState, out: EndiFrameOutput, t: number): boolean {
  const h = state.human;
  if (out.regions.length === 0) { h.on = false; h.offSince = null; return false; }
  if (isEndiSeatHumanFrame(out.regions)) { h.on = true; h.offSince = null; return true; }
  if (h.on) {
    if (h.offSince === null) h.offSince = t;
    if (t - h.offSince >= ENDI_SEAT_HUMAN_EXIT_HOLD_MS) { h.on = false; h.offSince = null; }
  }
  return h.on;
}

/** 实时会话：各接触区系数随类别切换（标准 / 超量程 / 真人），按 120 ms S 曲线过渡（新轨迹直接取目标值）。 */
function liveFactors(state: LiveState, out: EndiFrameOutput, t: number): LiveFactorResult {
  const humanActive = latchHuman(state, out, t);
  const kinds = endiSeatFactorKinds(out.regions, humanActive);
  const seen = new Set<number>();
  const humanWeights: number[] = [];
  const result = out.regions.map((r, i) => {
    const kind = kinds[i];
    seen.add(r.track);
    let b = state.factors.get(r.track);
    if (!b) {
      b = { from: endiSeatKindFactors(kind), fromHuman: endiSeatKindHumanWeight(kind), kind, t0: t };
      state.factors.set(r.track, b);
    } else if (b.kind !== kind) {
      b = { from: blendFactors(b, t), fromHuman: blendHuman(b, t), kind, t0: t };
      state.factors.set(r.track, b);
    }
    humanWeights.push(blendHuman(b, t));
    return blendFactors(b, t);
  });
  for (const id of Array.from(state.factors.keys())) if (!seen.has(id)) state.factors.delete(id);
  return { humanActive, kinds, factors: result, humanWeights };
}

let live: LiveState | null = null;

/** 清空实时会话（切换数据源、传感器或重置显示时调用）。 */
export function resetLiveEndiSeat(): void {
  live = null;
}

/**
 * 计算坐垫一帧的力、面积与压强。
 * @param native 串口 wireMap 解码的原生方向 23×23 物理 ADC（未补偿）
 */
export function calculateEndiSeatForce(native: Matrix | null | undefined, context?: EndiSeatStreamContext): ContinuousForceFrame | null {
  if (!isAdcMatrix(native, N_PHYS, N_PHYS)) return null;
  const isLive = !!context && !context.static && typeof context.streamId === "string" && Number.isFinite(context.timestampMs);
  if (!isLive) {
    const out = new EndiAlgorithm().process(0, endiNativeToAlgorithm(native));
    return toForceFrame(out, native);
  }
  if (!live || live.streamId !== context!.streamId) {
    live = { streamId: context!.streamId!, alg: new EndiAlgorithm(), lastRawT: null, lastT: null, results: new WeakMap(), factors: new Map(), human: { on: false, offSince: null } };
  }
  const cached = live.results.get(native);
  if (cached) return cached;
  const rawT = context!.timestampMs!;
  let t = rawT;
  // 同一毫秒内到达的多帧保持严格递增；时间真正倒退时交由核心重置。
  if (live.lastRawT !== null && live.lastT !== null && rawT >= live.lastRawT) t = Math.max(rawT, live.lastT + 0.001);
  // 时间倒退时核心自动重置（轨迹号重新编号），系数过渡状态一并清空。
  if (live.lastT !== null && t < live.lastT) { live.factors.clear(); live.human = { on: false, offSince: null }; }
  const out = live.alg.process(t, endiNativeToAlgorithm(native));
  live.lastRawT = rawT;
  live.lastT = t;
  const frame = toForceFrame(out, native, liveFactors(live, out, t));
  live.results.set(native, frame);
  return frame;
}

/**
 * T29 轮廓格数面积：在与显示对齐的补偿前插值矩阵（46×46）上统计 ADC ≥ 29 的格子，每格 1 cm²。
 * 设备插值与算法插值逐格一致，因此与算法内部轮廓同口径；用于框选统计与采集留档。
 */
export function analyzeEndiSeatArea(
  sourceMatrix: Matrix,
  options: { validMask?: boolean[][] | null; selection?: { startRow: number; startCol: number; endRow: number; endCol: number } | null } = {},
): EndiSeatAreaFrame {
  if (!isAdcMatrix(sourceMatrix, N_INT, N_INT)) throw new TypeError("需要 46×46 补偿前插值 ADC 矩阵");
  const T = ENDI_SEAT_AREA_THRESHOLD_ADC;
  const sel = options.selection;
  const r0 = sel ? Math.max(0, Math.min(sel.startRow, sel.endRow)) : 0;
  const r1 = sel ? Math.min(N_INT - 1, Math.max(sel.startRow, sel.endRow)) : N_INT - 1;
  const c0 = sel ? Math.max(0, Math.min(sel.startCol, sel.endCol)) : 0;
  const c1 = sel ? Math.min(N_INT - 1, Math.max(sel.startCol, sel.endCol)) : N_INT - 1;
  let count = 0;
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
    if (options.validMask?.[r]?.[c] === false) continue;
    if (sourceMatrix[r][c] >= T) count++;
  }
  return {
    version: ENDI_SEAT_AREA_VERSION, modelVersion: ENDI_SEAT_AREA_VERSION,
    algorithmId: "endi-cushion-t29-contour-count", algorithmLabel: "恩迪坐垫T29轮廓格数面积",
    sensorType: "endi-23x23", status: count > 0 ? "measured" : "no_contact", unit: "cm²",
    scope: sel ? "selection" : "full_frame", rows: N_INT, cols: N_INT, cellAreaCm2: 1,
    areaCm2: count, retainedCellCount: count, thresholdAdc: T,
  };
}
