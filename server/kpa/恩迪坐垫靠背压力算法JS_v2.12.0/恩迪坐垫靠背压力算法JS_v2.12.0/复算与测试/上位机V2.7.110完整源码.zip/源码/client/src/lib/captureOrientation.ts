/** 采集矩阵按热力图从上到下、从左到右的顺序保存。 */
export const CAPTURE_MATRIX_ROW_ORDER = "heatmap-top-to-bottom-v1" as const;

/** 新采集矩阵的列序与修正后的热力图从左到右一致。 */
export const CAPTURE_MATRIX_COLUMN_ORDER = "heatmap-left-to-right-v2" as const;

/** 只有当前坐垫配置需要额外左右镜像；靠背保持已有方向。 */
export function shouldMirrorHeatmapColumns(sensorType: string | undefined): boolean {
  return sensorType === "endi-23x23";
}

/** 矩阵列与屏幕列的双向转换；镜像是自身的逆变换。 */
export function heatmapColumnIndex(col: number, numCols: number, sensorType: string | undefined): number {
  return shouldMirrorHeatmapColumns(sensorType) ? numCols - 1 - col : col;
}

/** Screen row/column and matrix row/column use the same reversible transform. */
export function heatmapCellIndex(
  row: number, col: number, numRows: number, numCols: number, sensorType: string | undefined,
): { row: number; col: number } | null {
  if (!Number.isInteger(row) || !Number.isInteger(col) || row < 0 || row >= numRows || col < 0 || col >= numCols) return null;
  return { row: numRows - 1 - row, col: heatmapColumnIndex(col, numCols, sensorType) };
}

/** Return the exact finite cell value, or null when masked/legacy-thresholded; never rescale it. */
export function heatmapCellValue(
  matrix: number[][], row: number, col: number, validMask?: boolean[][] | null, filterThreshold = 0,
): number | null {
  if (validMask?.[row]?.[col] === false) return null;
  const value = matrix[row]?.[col];
  if (!Number.isFinite(value) || (filterThreshold > 0 && value > 0 && value <= filterThreshold)) return null;
  return value;
}

/** Dimensions of the physical matrix after the same clockwise rotation as the main matrix. */
export function rotatedPhysicalSize(rows: number, cols: number, matrixRotation = 3): { rows: number; cols: number } {
  const turns = ((matrixRotation % 4) + 4) % 4;
  return turns % 2 === 0 ? { rows, cols } : { rows: cols, cols: rows };
}

/**
 * A native sample originally at [2*r,2*c] acquires an odd row/column after
 * rotations around a 2H by 2W grid. pr/pc are in the ROTATED physical matrix,
 * matching the physical Heatmap's hover callback and highlightedPhysical.
 */
export function physicalCellInRotatedMatrix(pr: number, pc: number, matrixRotation = 3): { row: number; col: number } {
  const turns = ((matrixRotation % 4) + 4) % 4;
  return { row: 2 * pr + (turns >= 2 ? 1 : 0), col: 2 * pc + (turns === 1 || turns === 2 ? 1 : 0) };
}

/** Inverse sample mapping; interpolated cells between physical samples return null. */
export function rotatedMatrixCellToPhysical(row: number, col: number, matrixRotation = 3): { pr: number; pc: number } | null {
  const offset = physicalCellInRotatedMatrix(0, 0, matrixRotation);
  const pr2 = row - offset.row, pc2 = col - offset.col;
  if (pr2 < 0 || pc2 < 0 || pr2 % 2 !== 0 || pc2 % 2 !== 0) return null;
  return { pr: pr2 / 2, pc: pc2 / 2 };
}

/** 创建上下翻转的独立快照，不改变实时矩阵或共享行数组。 */
export function flipCaptureMatrixRows(matrix: number[][]): number[][] {
  return matrix.map((_, row) => [...matrix[matrix.length - 1 - row]]);
}

/** 保存为热图从上到下、从左到右的独立快照；不改变实时矩阵或原始字节。 */
export function orientCaptureMatrix(matrix: number[][], sensorType: string | undefined): number[][] {
  const snapshot = flipCaptureMatrixRows(matrix);
  return shouldMirrorHeatmapColumns(sensorType) ? snapshot.map((row) => row.reverse()) : snapshot;
}
