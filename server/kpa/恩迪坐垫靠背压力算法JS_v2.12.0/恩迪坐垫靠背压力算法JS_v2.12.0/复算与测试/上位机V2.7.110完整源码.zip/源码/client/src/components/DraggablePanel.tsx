/**
 * DraggablePanel - 可拖拽浮动面板组件
 * 支持拖拽移动、折叠/展开、最小化
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { GripHorizontal, Minus, Plus, X } from "lucide-react";

interface DraggablePanelProps {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  defaultPosition?: { x: number; y: number };
  defaultCollapsed?: boolean;
  width?: number;
  minHeight?: number;
  maxHeight?: number;
  className?: string;
  headerExtra?: React.ReactNode;
  onClose?: () => void;
  visible?: boolean;
}

export default function DraggablePanel({
  title,
  icon,
  children,
  defaultPosition = { x: 0, y: 0 },
  defaultCollapsed = false,
  width = 280,
  minHeight,
  maxHeight = 600,
  className = "",
  headerExtra,
  onClose,
  visible = true,
}: DraggablePanelProps) {
  const [position, setPosition] = useState(defaultPosition);
  const [collapsed, setCollapsed] = useState(defaultCollapsed);
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; startPosX: number; startPosY: number } | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Browser zoom changes the CSS viewport; keep floating results reachable.
  useEffect(() => {
    const keepInViewport = () => setPosition(previous => {
      const x = Math.max(0, Math.min(previous.x, Math.max(0, window.innerWidth - width)));
      const y = Math.max(0, Math.min(previous.y, Math.max(0, window.innerHeight - 40)));
      return x === previous.x && y === previous.y ? previous : { x, y };
    });
    keepInViewport();
    window.addEventListener("resize", keepInViewport);
    return () => window.removeEventListener("resize", keepInViewport);
  }, [width]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startPosX: position.x,
      startPosY: position.y,
    };
  }, [position]);

  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!dragRef.current) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      const newX = dragRef.current.startPosX + dx;
      const newY = dragRef.current.startPosY + dy;
      
      // 限制在视口范围内
      const maxX = window.innerWidth - 100;
      const maxY = window.innerHeight - 40;
      setPosition({
        x: Math.max(-100, Math.min(maxX, newX)),
        y: Math.max(0, Math.min(maxY, newY)),
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging]);

  if (!visible) return null;

  return (
    <div
      ref={panelRef}
      className={`fixed z-30 ${isDragging ? "cursor-grabbing" : ""} ${className}`}
      style={{
        left: position.x,
        top: position.y,
        width,
        transition: isDragging ? "none" : "box-shadow 0.2s",
      }}
    >
      <div className="bg-card/95 backdrop-blur-xl border border-border/50 rounded-xl shadow-2xl shadow-black/30 overflow-hidden">
        {/* 拖拽手柄 + 标题栏 */}
        <div
          className="flex items-center justify-between px-3 py-2 bg-muted/30 border-b border-border/30 cursor-grab active:cursor-grabbing select-none"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center gap-2 min-w-0">
            <GripHorizontal className="w-3.5 h-3.5 text-muted-foreground/50 flex-shrink-0" />
            {icon && <span className="flex-shrink-0">{icon}</span>}
            <span className="text-xs font-semibold text-foreground truncate">{title}</span>
          </div>
          <div className="flex items-center gap-0.5 flex-shrink-0">
            {headerExtra}
            <button
              onClick={(e) => { e.stopPropagation(); setCollapsed(!collapsed); }}
              className="w-5 h-5 flex items-center justify-center rounded hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-colors"
              title={collapsed ? "展开" : "折叠"}
            >
              {collapsed ? <Plus className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
            </button>
            {onClose && (
              <button
                onClick={(e) => { e.stopPropagation(); onClose(); }}
                className="w-5 h-5 flex items-center justify-center rounded hover:bg-red-500/20 text-muted-foreground hover:text-red-400 transition-colors"
                title="关闭"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* 内容区域 */}
        {!collapsed && (
          <div
            className="overflow-y-auto overflow-x-hidden"
            style={{ maxHeight, minHeight }}
          >
            {children}
          </div>
        )}
      </div>
    </div>
  );
}
