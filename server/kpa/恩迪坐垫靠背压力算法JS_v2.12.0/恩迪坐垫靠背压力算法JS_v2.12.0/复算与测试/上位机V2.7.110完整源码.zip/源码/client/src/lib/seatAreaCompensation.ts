import model from './seatAreaCompensation.generated';

/** Native-ADC single-bottom contour correction, independent of total force. */
export function compensateSeatAreaThreshold(input:Float64Array,rows:number,cols:number,baseline:number):number {
  let total=0,peak=0,weightedRow=0,weightedCol=0;
  for(let i=0;i<input.length;i++){
    const value=input[i];total+=value;peak=Math.max(peak,value);
    weightedRow+=Math.floor(i/cols)*value;weightedCol+=(i%cols)*value;
  }
  if(total===0||peak===0)return baseline;
  const cy=weightedRow/total,cx=weightedCol/total;
  let vy=0,vx=0;
  const profile=Array(model.levels.length).fill(0) as number[];
  for(let i=0;i<input.length;i++){
    const value=input[i];if(value===0)continue;
    vy+=value*(Math.floor(i/cols)-cy)**2;vx+=value*(i%cols-cx)**2;
    model.levels.forEach((level,k)=>{profile[k]+=Math.max(0,Math.min(1,(value/peak-level)/model.width+.5));});
  }
  const vector=[...profile.map(v=>v/100),cy/(rows-1),cx/(cols-1),Math.sqrt(vy/total)/10,Math.sqrt(vx/total)/10,peak/255];
  const q=model.normalizedFeatureQuantization,z=vector.map((v,i)=>Math.floor(v/model.scale[i]*q+.5)/q);
  const nearest=model.anchorCoordinates.map((anchor,index)=>({index,distance:anchor.reduce((s,v,i)=>s+(z[i]-v)**2,0)}))
    .sort((a,b)=>a.distance-b.distance||a.index-b.index).slice(0,model.neighbors);
  let weighted=0,weight=model.zeroCorrectionPriorWeight;
  for(const v of nearest){const w=1/(v.distance+model.epsilonSquared);weight+=w;weighted+=w*model.anchorThresholdCorrections[v.index];}
  return Math.max(.5,Math.min(255.5,Math.round((baseline+weighted/weight)*1000)/1000));
}
