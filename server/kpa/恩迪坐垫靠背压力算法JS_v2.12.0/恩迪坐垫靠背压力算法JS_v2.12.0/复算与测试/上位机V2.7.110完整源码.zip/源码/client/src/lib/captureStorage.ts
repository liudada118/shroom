/**
 * 采集数据持久化存储模块
 * 
 * 使用 IndexedDB 实现帧数据的实时持久化存储，支持：
 * - 每采集一帧实时保存到 IndexedDB
 * - 软件重启后自动检测未完成的采集会话
 * - 恢复已采集的帧数据并继续采集
 * - 采集完成/导出后清除会话数据
 */

const DB_NAME = "SensorCaptureDB";
const DB_VERSION = 3;
const STORE_FRAMES = "capturedFrames";
const STORE_SESSION = "captureSession";

export type CapturedForceMetrics = import("./sensorForce").CapturedSensorForceMetrics;

/** 记录采集当时实际使用的传感器独立面积标定，历史帧缺失时不补算。 */
export interface CapturedAreaMetrics {
  algorithmId: string;
  algorithmLabel: string;
  areaCm2: number;
  retainedCellCount: number;
  cellAreaCm2: number;
  thresholdAdc: number | null;
  modelVersion?: string;
  seedCount?: number;
  regionThresholds?: number[];
  status: string;
  /** Optional on historical/backrest records; describes current-frame seat grid counting. */
  areaMeaning?: "spatial_denoised_grid_count";
  denoiseMethod?: "median3_reflect_current_frame";
  sourceGridCellAreaCm2?: number;
  /** Validation reference only; never used as a runtime area quota. */
  calibrationReferenceAreaCm2?: number;
  countModelVersion?: string;
}

export interface StoredCapturedFrame {
  id: number;
  /** standard为既有手动/自动采集；continuous仅写入Excel新增连续采集工作表。 */
  captureKind?: "standard" | "continuous";
  /** 连续采集在本次会话内的从1开始帧序号。 */
  continuousSequence?: number;
  data: {
    /** 补偿后矩阵；新采集按采集时热力图从上到下的行序保存。 */
    matrix: number[][];
    /** 数据源提供的原始字节序列；串口帧通常为1024字节。 */
    raw?: number[];
    /** 当前模式实际绘图矩阵，坐标与热力图一致。 */
    heatmapMatrix?: number[][];
    /** 插值前原始ADC物理矩阵；新采集按热力图方向排列。 */
    physical?: number[][];
    /** ADC补偿前插值矩阵；新采集按热力图方向排列。 */
    sourceMatrix?: number[][];
    max: number;
    min: number;
    nonZeroMin: number;
    avg: number;
    sum: number;
    nonZeroCount: number;
    timestamp: number;
  };
  capturedAt: string; // ISO string for serialization
  sensorType: string;
  filteredStats?: any;
  areaMetrics?: CapturedAreaMetrics;
  /** 采集当时实际使用的传感器独立总力结果；历史记录缺失时不追算。 */
  forceMetrics?: CapturedForceMetrics;
  /** 屏幕平滑值是独立时间快照；forceMetrics始终保留采集当帧值。 */
  forceDisplayMetrics?: import("./forceReadout").CapturedForceReadout;
  captureConfig?: {
    filterThreshold: number;
    resultScale: number;
    visibleFields: string[];
    /** 缺失时为历史帧行序；恢复时保留已保存的矩阵，不再次翻转。 */
    matrixRowOrder?: "heatmap-top-to-bottom-v1";
    /** 新采集的列序标记；历史帧缺失时保留原保存顺序。 */
    matrixColumnOrder?: "heatmap-left-to-right-v2";
    matrixRotation?: number;
    heatmapValueMode?: "adc" | "pressure";
    heatmapValueUnit?: "ADC" | "kPa";
    adcCompensationVersion?: string;
    adcCompensation?: {
      sensor: "seat" | "backrest";
      enabled: boolean;
      scale: number;
      offset: number;
      fingerprint: string;
    };
  };
  /** 采集时的锁定压强值(KPa) */
  lockedPressureKPa?: number | null;
  /** 采集时的平均压强(KPa) */
  avgPressureKPa?: number | null;
  /** 采集时的最大压强(KPa) */
  maxPressureKPa?: number | null;
  /** 采集时用于砝码段压强公式的插值矩阵排序区间均值 ADC。 */
  pressureInputAdc?: number;
  /** 采集时参与砝码段排序区间均值的有效点数。 */
  pressureInputTopCount?: number;
  /** 采集时实际采用的砝码段 / 真人段。 */
  calibrationBranch?: "weight" | "human";
  /** 采集时真人段使用的传感器独立动态系数；砝码段为 null。 */
  humanCoefficient?: number | null;
  /** 砝码段逐点压强比例归一化系数；真人段为空。 */
  pressureNormalizationScale?: number | null;
  /** 砝码段基础曲线响应平均值。 */
  pressureCurveResponseMeanKPa?: number | null;
  /** 砝码段逐点平均值与拟合目标平均值之差。 */
  pressureMeanConservationErrorKPa?: number | null;
  /** 砝码段逐点压强数量；真人段为全部有效点数量。 */
  pointPressureCount?: number;
  /** 砝码段异常回退状态。 */
  pointPressureFallbackMode?: "none" | "no-valid-points" | "all-zero" | "equal-distribution" | null;
  /** 采集时的最大值坐标 */
  maxCoordStr?: string;
}

export interface CaptureSession {
  id: string; // "current"
  sensorType: string;
  filterThreshold: number;
  resultScale: number;
  /** V2.7.41：坐垫与靠背真人段动态系数独立保存。 */
  seatHumanCoefficient?: number;
  backrestHumanCoefficient?: number;
  expectedNonZero: number;
  nonZeroTolerance: number;
  autoCaptureDelay?: number; // 兼容旧版
  autoCaptureInterval: number; // 采集间隔(秒)
  matrixRotation: number;
  lastCaptureId: number;
  frameCount: number;
  /** 连续采集帧数；缺失时兼容旧会话。 */
  continuousFrameCount?: number;
  startedAt: string;
  updatedAt: string;
  isCompleted: boolean;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // 帧数据存储
      if (!db.objectStoreNames.contains(STORE_FRAMES)) {
        const frameStore = db.createObjectStore(STORE_FRAMES, { keyPath: "id" });
        frameStore.createIndex("capturedAt", "capturedAt", { unique: false });
      }
      
      // 会话信息存储
      if (!db.objectStoreNames.contains(STORE_SESSION)) {
        db.createObjectStore(STORE_SESSION, { keyPath: "id" });
      }

      // V2.7.67：恢复原始字节与矩阵字段。字段均为可选，升级时保留已有记录；
      // V2缓存中已被旧版本清除的原始数据无法追溯，新采集帧会完整写入。
    };
    
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/** 在事务完成后返回结果，失败及主动中止时统一释放数据库连接。 */
async function runTransaction<T = void>(
  stores: string | string[],
  mode: IDBTransactionMode,
  execute: (tx: IDBTransaction) => IDBRequest<T> | void,
): Promise<T> {
  const db = await openDB();
  return new Promise<T>((resolve, reject) => {
    let tx: IDBTransaction | undefined;
    let request: IDBRequest<T> | void;
    let settled = false;
    const fail = (error: unknown) => {
      if (settled) return;
      settled = true;
      db.close();
      reject(error);
    };
    try {
      tx = db.transaction(stores, mode);
      tx.oncomplete = () => {
        if (settled) return;
        settled = true;
        db.close();
        resolve(request ? request.result : (undefined as T));
      };
      tx.onerror = (event) => fail(
        tx!.error ?? (event.target as IDBRequest | null)?.error ?? new Error("采集缓存事务失败"),
      );
      tx.onabort = () => fail(tx!.error ?? new Error("采集缓存事务已中止"));
      request = execute(tx);
    } catch (error) {
      // 某个put同步失败时中止整个事务，避免另一张表先写入造成帧/会话不一致。
      try { tx?.abort(); } catch { /* 事务可能已经结束。 */ }
      fail(error);
    }
  });
}

/** 保存单帧数据到 IndexedDB */
export async function saveFrame(frame: StoredCapturedFrame): Promise<void> {
  return runTransaction(STORE_FRAMES, "readwrite", (tx) => {
    tx.objectStore(STORE_FRAMES).put(frame);
  });
}

interface PendingCaptureWrite {
  frame: StoredCapturedFrame;
  session: CaptureSession;
  resolve: (count: number) => void;
  reject: (error: unknown) => void;
}

// A serial read can decode many frames synchronously. Batch only IndexedDB I/O,
// preserving every frame and the newest session in one ordered transaction.
let pendingCaptureWrites: PendingCaptureWrite[] = [];
let captureWriteTimer: ReturnType<typeof setTimeout> | null = null;
let captureWriteTail: Promise<void> = Promise.resolve();

export function flushCaptureWrites(): Promise<void> {
  if (captureWriteTimer !== null) clearTimeout(captureWriteTimer);
  captureWriteTimer = null;
  const batch = pendingCaptureWrites;
  pendingCaptureWrites = [];
  if (batch.length === 0) return captureWriteTail;
  const write = captureWriteTail.then(async () => {
    try {
      const count = await runTransaction<number>([STORE_FRAMES, STORE_SESSION], "readwrite", (tx) => {
        const frames = tx.objectStore(STORE_FRAMES);
        for (const item of batch) frames.put(item.frame);
        tx.objectStore(STORE_SESSION).put(batch[batch.length - 1].session);
        return frames.count();
      });
      for (const item of batch) item.resolve(count);
    } catch (error) {
      for (const item of batch) item.reject(error);
      throw error;
    }
  });
  // A failed batch must not prevent subsequent frames from being persisted.
  captureWriteTail = write.catch(() => {});
  return write;
}

/** Every frame is queued without downsampling; resolve after its transaction. */
export function saveFrameAndSession(
  frame: StoredCapturedFrame,
  session: CaptureSession,
): Promise<number> {
  const saved = new Promise<number>((resolve, reject) => {
    pendingCaptureWrites.push({ frame, session, resolve, reject });
  });
  if (captureWriteTimer === null) {
    captureWriteTimer = setTimeout(() => { void flushCaptureWrites().catch(() => {}); }, 25);
  }
  return saved;
}

/** 删除单帧数据 */
export async function deleteStoredFrame(frameId: number): Promise<void> {
  await flushCaptureWrites();
  return runTransaction(STORE_FRAMES, "readwrite", (tx) => {
    tx.objectStore(STORE_FRAMES).delete(frameId);
  });
}

/** 获取所有已保存的帧数据 */
export async function getAllFrames(): Promise<StoredCapturedFrame[]> {
  await flushCaptureWrites();
  return runTransaction<StoredCapturedFrame[]>(STORE_FRAMES, "readonly", (tx) =>
    tx.objectStore(STORE_FRAMES).getAll(),
  );
}

/** 获取已保存帧数量 */
export async function getFrameCount(): Promise<number> {
  await flushCaptureWrites();
  return runTransaction<number>(STORE_FRAMES, "readonly", (tx) =>
    tx.objectStore(STORE_FRAMES).count(),
  );
}

/** 清除所有帧数据 */
export async function clearAllFrames(): Promise<void> {
  await flushCaptureWrites();
  return runTransaction(STORE_FRAMES, "readwrite", (tx) => {
    tx.objectStore(STORE_FRAMES).clear();
  });
}

/** 保存/更新采集会话信息 */
export async function saveSession(session: CaptureSession): Promise<void> {
  return runTransaction(STORE_SESSION, "readwrite", (tx) => {
    tx.objectStore(STORE_SESSION).put(session);
  });
}

/** 获取当前采集会话 */
export async function getSession(): Promise<CaptureSession | null> {
  await flushCaptureWrites();
  const session = await runTransaction<CaptureSession | undefined>(STORE_SESSION, "readonly", (tx) =>
    tx.objectStore(STORE_SESSION).get("current"),
  );
  return session ?? null;
}

/** 清除采集会话 */
export async function clearSession(): Promise<void> {
  await flushCaptureWrites();
  return runTransaction(STORE_SESSION, "readwrite", (tx) => {
    tx.objectStore(STORE_SESSION).delete("current");
  });
}

/** 清除所有数据（帧 + 会话） */
export async function clearAll(): Promise<void> {
  await flushCaptureWrites();
  return runTransaction([STORE_FRAMES, STORE_SESSION], "readwrite", (tx) => {
    tx.objectStore(STORE_FRAMES).clear();
    tx.objectStore(STORE_SESSION).clear();
  });
}

/** 检查是否有未完成的采集会话 */
export async function hasUnfinishedSession(): Promise<{
  hasSession: boolean;
  session: CaptureSession | null;
  frameCount: number;
}> {
  try {
    const session = await getSession();
    if (!session || session.isCompleted) {
      return { hasSession: false, session: null, frameCount: 0 };
    }
    const count = await getFrameCount();
    if (count === 0) {
      // 会话存在但没有帧数据，清除无效会话
      await clearSession();
      return { hasSession: false, session: null, frameCount: 0 };
    }
    return { hasSession: true, session, frameCount: count };
  } catch (e) {
    console.error("检查未完成会话失败:", e);
    return { hasSession: false, session: null, frameCount: 0 };
  }
}

/** 标记会话为已完成 */
export async function markSessionCompleted(): Promise<void> {
  const session = await getSession();
  if (session) {
    session.isCompleted = true;
    session.updatedAt = new Date().toISOString();
    await saveSession(session);
  }
}
