import { APP_VERSION } from "@/lib/version";
import { SEAT_LOAD_RECOGNITION_VALIDATION } from "@/lib/seatLoadRecognition";
import type { ContinuousForceFrame } from "@/lib/sensorForce";

/** Reads the exact nominal recognition snapshot used by main force and capture. */
export default function SeatRecognitionPanel({ forceFrame }: { forceFrame: ContinuousForceFrame | null }) {
  const recognition = forceFrame?.seatLoadRecognition;
  const contacts = recognition?.contacts ?? [];
  const uncertain = contacts.some(contact => contact.uncertain);
  const status = !recognition ? "等待原始采集帧" : !contacts.length ? "无接触" : uncertain ? "存在不确定识别，请核对档位" : "已输出候选档位";
  return (
    <section data-testid="seat-recognition-panel" className="mt-2 rounded border border-cyan-500/25 bg-cyan-500/5 px-3 py-2 text-[11px]">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
        <strong className="text-cyan-300">坐垫六档识别 · {APP_VERSION}试用</strong>
        <span className="rounded border border-amber-500/30 px-1.5 text-[10px] text-amber-300">试用 · 存在错档</span>
        <span data-testid="seat-recognition-status" role="status" className={uncertain ? "text-amber-300" : "text-muted-foreground"}>{status}</span>
        <span className="ml-auto text-muted-foreground">识别标称合计 <output data-testid="seat-recognition-nominal-total" className="font-mono text-sm font-semibold text-cyan-200">{recognition ? forceFrame!.forceN.toFixed(3) : "--"}</output> N</span>
      </div>
      <p className="mt-1 text-[10px] text-muted-foreground">仅识别1.625、3.25、4.875、6.5、8.125、16.5 kg；按g=9.8换算标称力。{SEAT_LOAD_RECOGNITION_VALIDATION.label}。</p>
      {contacts.length > 0 && (
        <div className="mt-1 max-h-36 overflow-auto">
          <table className="w-full text-right tabular-nums">
            <thead className="text-[10px] text-muted-foreground"><tr><th className="text-left">接触区域 / 原始中心</th><th>识别砝码 kg</th><th>标称力 N</th><th>识别状态</th></tr></thead>
            <tbody>{contacts.map(contact => (
              <tr key={contact.trackId} data-testid="seat-recognition-contact" className="border-t border-cyan-500/10">
                <td className="py-1 text-left text-muted-foreground">#{contact.trackId} · 行{contact.center[0].toFixed(1)} 列{contact.center[1].toFixed(1)}</td>
                <td data-testid="seat-recognized-mass" className="font-mono text-cyan-200">{contact.recognizedMassKg.toFixed(3)}</td>
                <td data-testid="seat-recognition-nominal" className="font-mono">{contact.nominalForceN.toFixed(3)}</td>
                <td className={contact.uncertain ? "text-amber-300" : "text-muted-foreground"} title={`最高识别分数${(Math.max(0, ...contact.scores) * 100).toFixed(1)}%，领先差${(contact.scoreMargin * 100).toFixed(1)}%；不是校准概率`}>{contact.uncertain ? "不确定" : "候选"}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
      <p className="mt-1 text-[10px] text-muted-foreground">各接触区分别识别；标称力用于主力值、面积换算与采集计算记录。单格及区域内的力分配是估算。拟合CSV/XLSX保留原始ADC，不含模拟力值。</p>
    </section>
  );
}
