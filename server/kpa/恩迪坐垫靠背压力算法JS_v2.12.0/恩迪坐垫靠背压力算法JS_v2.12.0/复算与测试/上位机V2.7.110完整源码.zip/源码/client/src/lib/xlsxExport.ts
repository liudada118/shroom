/** V2.7.84: export only the three original fitting datasets and blank labels. */
import XLSX from "xlsx-js-style";
import {
  collectFittingFrames,
  fittingMetadataRow,
  FITTING_METADATA_HEADERS,
  type FittingCell,
  type FittingExportConfig,
  type FittingExportFrame,
} from "./fittingExportData";

export interface ExportOptions {
  /** Merged with standard frames, sorted and deduplicated by internal frame id. */
  continuousFrames?: FittingExportFrame[];
  /** Optional lower limit for constrained exports/tests; all rows are retained. */
  worksheetRowLimit?: number;
}

const EXCEL_MAX_ROWS = 1_048_576;
const EXCEL_MAX_COLUMNS = 16_384;
const BYTES_PER_ROW = 32;
const HEADER_STYLE = {
  font: { bold: true },
  fill: { fgColor: { rgb: "D9E1F2" }, patternType: "solid" as const },
};

/** Every continuation repeats its column header. Every data row retains its
 * frame id and original byte offset / matrix row, including mid-frame splits. */
class ChunkedSheetRows {
  private rows: FittingCell[][];
  private chunk = 0;

  constructor(
    private readonly workbook: XLSX.WorkBook,
    private readonly name: string,
    private readonly header: readonly string[],
    private readonly rowLimit: number,
  ) {
    if (header.length > EXCEL_MAX_COLUMNS) {
      throw new RangeError("原始矩阵宽度超过 Excel 列数限制，未生成截断文件");
    }
    this.rows = [[...header]];
  }

  append(row: FittingCell[]): void {
    if (row.length > EXCEL_MAX_COLUMNS) {
      throw new RangeError("原始数据宽度超过 Excel 列数限制，未生成截断文件");
    }
    if (this.rows.length >= this.rowLimit) this.flush();
    this.rows.push(row);
  }

  private flush(): void {
    const worksheet = XLSX.utils.aoa_to_sheet(this.rows);
    worksheet["!cols"] = this.header.map((_, index) => ({ wch: index < 2 ? 22 : 15 }));
    this.header.forEach((_, column) => {
      const cell = worksheet[XLSX.utils.encode_cell({ r: 0, c: column })];
      if (cell) cell.s = HEADER_STYLE;
    });
    this.chunk += 1;
    const suffix = this.chunk === 1 ? "" : `_${this.chunk}`;
    XLSX.utils.book_append_sheet(
      this.workbook,
      worksheet,
      this.name.slice(0, 31 - suffix.length) + suffix,
    );
    this.rows = [[...this.header]];
  }

  finish(): void {
    this.flush();
  }
}

function writeRawBytes(
  workbook: XLSX.WorkBook,
  frames: readonly FittingExportFrame[],
  rowLimit: number,
): void {
  const writer = new ChunkedSheetRows(workbook, "原始字节", [
    "帧序号", "字节偏移（0起）",
    ...Array.from({ length: BYTES_PER_ROW }, (_, index) => `B+${index}`),
  ], rowLimit);
  for (const frame of frames) {
    const raw = frame.data.raw;
    if (!raw?.length) {
      writer.append([frame.id, "原始字节未保存"]);
      continue;
    }
    for (let offset = 0; offset < raw.length; offset += BYTES_PER_ROW) {
      writer.append([frame.id, offset, ...raw.slice(offset, offset + BYTES_PER_ROW)]);
    }
  }
  writer.finish();
}

function writeOriginalMatrix(
  workbook: XLSX.WorkBook,
  frames: readonly FittingExportFrame[],
  field: "physical" | "sourceMatrix",
  sheetName: string,
  rowLimit: number,
): void {
  const width = frames.reduce((maxWidth, frame) => (
    frame.data[field]?.reduce((maxRow, row) => Math.max(maxRow, row.length), maxWidth) ?? maxWidth
  ), 0);
  if (width + 2 > EXCEL_MAX_COLUMNS) {
    throw new RangeError("原始矩阵宽度超过 Excel 列数限制，未生成截断文件");
  }
  const writer = new ChunkedSheetRows(workbook, sheetName, [
    "帧序号", "矩阵行（按记录行序，R0起）",
    ...Array.from({ length: width }, (_, column) => `C${column}`),
  ], rowLimit);
  for (const frame of frames) {
    const matrix = frame.data[field];
    if (!matrix?.length) {
      writer.append([frame.id, field === "physical" ? "原始物理矩阵未保存" : "补偿前插值矩阵未保存"]);
      continue;
    }
    // These are the saved original matrices. Do not rotate, filter, compensate,
    // scale, round, or substitute the processed data.matrix / heatmapMatrix.
    matrix.forEach((row, index) => writer.append([frame.id, `R${index}`, ...row]));
  }
  writer.finish();
}

/** Preserve the legacy call shape. Display fields and the old matrix toggle
 * are intentionally ignored: every export contains all three raw datasets. */
export async function exportToXlsx(
  frames: FittingExportFrame[],
  config: FittingExportConfig,
  visibleFields: string[],
  onProgress?: (percent: number) => void,
  includeSubTables: boolean = true,
  exportOptions?: ExportOptions,
): Promise<void> {
  void config;
  void visibleFields;
  void includeSubTables;
  const allFrames = collectFittingFrames(frames, exportOptions?.continuousFrames);
  if (allFrames.length === 0) return;
  const rowLimit = exportOptions?.worksheetRowLimit ?? EXCEL_MAX_ROWS;
  if (!Number.isInteger(rowLimit) || rowLimit < 8 || rowLimit > EXCEL_MAX_ROWS) {
    throw new RangeError(`Worksheet row limit must be 8..${EXCEL_MAX_ROWS}`);
  }
  const workbook = XLSX.utils.book_new();
  const metadata = new ChunkedSheetRows(workbook, "帧信息与标注", FITTING_METADATA_HEADERS, rowLimit);
  allFrames.forEach(frame => metadata.append(fittingMetadataRow(frame)));
  metadata.finish();
  onProgress?.(20);
  await new Promise(resolve => setTimeout(resolve, 0));

  writeRawBytes(workbook, allFrames, rowLimit);
  onProgress?.(40);
  await new Promise(resolve => setTimeout(resolve, 0));

  writeOriginalMatrix(workbook, allFrames, "physical", "原始物理ADC", rowLimit);
  onProgress?.(60);
  await new Promise(resolve => setTimeout(resolve, 0));

  writeOriginalMatrix(workbook, allFrames, "sourceMatrix", "原始插值ADC", rowLimit);
  onProgress?.(80);
  await new Promise(resolve => setTimeout(resolve, 0));

  const output = XLSX.write(workbook, {
    bookType: "xlsx", type: "array", bookSST: false, compression: true,
  });
  const blob = new Blob([output], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `sensor_capture_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.xlsx`;
  document.body.appendChild(anchor);
  try {
    anchor.click();
  } finally {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }
  onProgress?.(100);
}
