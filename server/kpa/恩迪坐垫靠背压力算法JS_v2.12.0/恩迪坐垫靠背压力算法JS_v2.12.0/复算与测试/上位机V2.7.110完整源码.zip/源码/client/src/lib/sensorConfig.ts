/**
 * 传感器配置 V2.7.3
 * ----------------------------------------------------------
 * 严格按厂方线序文档实现：
 *   - 坐垫 endiSit1024:   1024 字节 → 物理 23×23 → 2×2 线性插值 → 46×46（2116 点）
 *   - 靠背 endiBack1024:  1024 字节 → 物理 32×25 → 2×2 线性插值 → 64×50（3200 点）
 *
 * 公开接口：
 *   rows/cols       → 供 UI / 热力图 / 下游循环使用的"最终分辨率"（即已插值后的尺寸）
 *   physicalRows/
 *   physicalCols    → 未插值前的物理像素尺寸（23×23 / 32×25），供一致性标定等
 *                     仍按物理分辨率标定的模块使用
 *   interpFactor    → 插值倍率（2 表示 2×2 线性插值）
 *   wireMap         → 长度 = physicalRows*physicalCols，映射到原始 1024 字节的索引
 *                     （即厂方 arrX/arrY 逻辑，旋转/翻转后排布）
 */

export interface SensorConfig {
  type: string;
  name: string;
  /** 最终输出矩阵行数（已插值） */
  rows: number;
  /** 最终输出矩阵列数（已插值） */
  cols: number;
  /** 物理像素行数（未插值） */
  physicalRows: number;
  /** 物理像素列数（未插值） */
  physicalCols: number;
  /** 插值倍率 */
  interpFactor: number;
  /** 向后兼容：等于 rows（部分旧代码用来判定 N×N） */
  matrixSize: number;
  rawStride: number;
  frameSize: number;
  delimiter: Uint8Array;
  /** 长度 = physicalRows*physicalCols，物理矩阵像素 → 原始 1024 字节索引 */
  wireMap: number[];
  /**
   * 有效区域掩码（可选，尺寸为 physical）
   * physicalValidMask[r][c] = true 表示该物理像素位置有效
   * undefined 表示全部有效（默认矩形）
   */
  physicalValidMask?: boolean[][];
  /**
   * 有效区域掩码（可选，尺寸为 matrix）
   * validMask[r][c] = true 表示该插值后像素位置有效
   * undefined 表示全部有效
   * 由 physicalValidMask 按 interpFactor 扩充生成：matrix[2r..2r+1][2c..2c+1] = phys[r][c]
   */
  validMask?: boolean[][];
}

// ------------------------- 辅助 -------------------------

/** 把 [[0,10],[22,11]] 这样的段写法展开成一维索引数组 */
function buildAxis(segments: Array<[number, number]>): number[] {
  const out: number[] = [];
  for (const seg of segments) {
    const [a, b] = seg;
    if (a <= b) for (let i = a; i <= b; i++) out.push(i);
    else for (let i = a; i >= b; i--) out.push(i);
  }
  return out;
}

// ------------------------- 坐垫 23×23 → 46×46 -------------------------

function createEndiConfig(): SensorConfig {
  // 文档 endiSit1024:
  //   arrX = [22..0]   （沿列，len 23）
  //   arrY = [0..10] + [22..11] （沿行，len 23）
  //   之后对 23×23 做 2×2 线性插值 → 46×46
  //   最后反转 + 旋转（文档里 push(45-i) / reverse() / 重排）
  const realX = buildAxis([[22, 0]]);                 // len 23
  const realY = buildAxis([[0, 10], [22, 11]]);       // len 23
  const physicalRows = realY.length;                  // 23
  const physicalCols = realX.length;                  // 23

  const wireMap = new Array<number>(physicalRows * physicalCols);
  for (let r = 0; r < physicalRows; r++) {
    for (let c = 0; c < physicalCols; c++) {
      wireMap[r * physicalCols + c] = realY[r] * 32 + realX[c];
    }
  }

  const interpFactor = 2;
  return {
    type: "endi-23x23",
    name: "恩迪座椅 46×46（2×2 插值）",
    rows: physicalRows * interpFactor,   // 46
    cols: physicalCols * interpFactor,   // 46
    physicalRows,
    physicalCols,
    interpFactor,
    matrixSize: physicalRows * interpFactor,
    rawStride: 32,
    frameSize: 1024,
    delimiter: new Uint8Array([0xAA, 0x55, 0x03, 0x99]),
    wireMap,
  };
}

// V2.7.15：老靠背 backrest-32x25 已删除，统一使用 new-backrest-32x25 作为唯一靠背配置。
// ------------------------- 新靠背测量系统 32×25 → 64×50（不规则形状）-------------------------
/**
 * 把 physical 尺寸的 mask 按 interpFactor 扩充为 matrix 尺寸。
 * 策略：phys[r][c] 有效 → matrix 中对应 interp×interp 块全部有效；
 * 即无效像素在插值后所有尺度上也不渲染。
 */
function expandMask(
  physMask: boolean[][],
  interp: number
): boolean[][] {
  const pR = physMask.length;
  const pC = physMask[0]?.length ?? 0;
  const R = pR * interp;
  const C = pC * interp;
  const out: boolean[][] = new Array(R);
  for (let r = 0; r < R; r++) {
    const row = new Array<boolean>(C);
    const pr = Math.floor(r / interp);
    for (let c = 0; c < C; c++) {
      const pc = Math.floor(c / interp);
      row[c] = !!physMask[pr][pc];
    }
    out[r] = row;
  }
  return out;
}
function createNewBackrestConfig(): SensorConfig {
  // 新靠背测量系统 32×25（2026-04-23 新线序图）
  //   realY = [15..31] + [14..0]
  //   realX = [24..0]（列反序）
  //   byte = realY[r] * 32 + realX[c]
  const realX = buildAxis([[24, 0]]);                 // len 25
  const realY = buildAxis([[15, 31], [14, 0]]);       // len 32
  const physicalRows = realY.length;                  // 32
  const physicalCols = realX.length;                  // 25
  const wireMap = new Array<number>(physicalRows * physicalCols);
  for (let r = 0; r < physicalRows; r++) {
    for (let c = 0; c < physicalCols; c++) {
      wireMap[r * physicalCols + c] = realY[r] * 32 + realX[c];
    }
  }
  // 不规则形状：
  //   显示行 0-8（头枝区域）仅显示列 8-18 有效（11 列）
  //   显示行 9-31（主体区域）全部 25 列有效
  //   总有效点数：9×11 + 23×25 = 99 + 575 = 674
  const physicalValidMask: boolean[][] = [];
  for (let r = 0; r < physicalRows; r++) {
    const rowMask: boolean[] = [];
    for (let c = 0; c < physicalCols; c++) {
      if (r <= 8) {
        rowMask.push(c >= 8 && c <= 18);
      } else {
        rowMask.push(true);
      }
    }
    physicalValidMask.push(rowMask);
  }
  const interpFactor = 2;
  const validMask = expandMask(physicalValidMask, interpFactor);
  return {
    type: "new-backrest-32x25",
    name: "新靠背测量系统 64×50（2×2 插值、不规则）",
    rows: physicalRows * interpFactor,   // 64
    cols: physicalCols * interpFactor,   // 50
    physicalRows,
    physicalCols,
    interpFactor,
    matrixSize: physicalRows * interpFactor,
    rawStride: 32,
    frameSize: 1024,
    delimiter: new Uint8Array([0xAA, 0x55, 0x03, 0x99]),
    wireMap,
    physicalValidMask,
    validMask,
  };
}
const SENSOR_CONFIGS: Record<string, SensorConfig> = {
  "endi-23x23": createEndiConfig(),
  "new-backrest-32x25": createNewBackrestConfig(),
};

export function getSensorConfig(type: string): SensorConfig {
  return SENSOR_CONFIGS[type];
}

export const SENSOR_TYPES = Object.keys(SENSOR_CONFIGS);
export const SENSOR_LIST = Object.values(SENSOR_CONFIGS);

/**
 * V2.7.15：判断是否为靠背类传感器。
 * 老 backrest-32x25 已废弃，目前唯一保留 new-backrest-32x25。
 */
export function isBackrestType(type: string | undefined | null): boolean {
  return type === "new-backrest-32x25";
}

// ------------------------- 2×2 线性插值工具 -------------------------
/**
 * 完全 1:1 复刻恩迪官方 lineInterp（行优先一维平铺版）。
 * 作者原代码：
 *   function lineInterp(smallMat, width, height, interp1, interp2) {
 *     let bigMat = new Array((width * interp1) * (height * interp2)).fill(0)
 *     for (let i = 0; i < height; i++) for (let j = 0; j < width; j++) {
 *       const realValue = smallMat[i*width+j]
 *       const rowValue = j == width-1 ? 0 : smallMat[i*width+j+1] * 1 ? smallMat[i*width+j+1] * 1 : 0
 *       bigMat[(width*interp1)*i*interp2 + j*interp1] = smallMat[i*width+j]
 *       for (let k = 0; k < interp1; k++)
 *         bigMat[(width*interp1)*(i*interp2) + (j*interp1+k)] = realValue + (rowValue-realValue)*k/interp1
 *     }
 *     const newWidth = width*interp1
 *     for (let i = 0; i < height; i++) for (let j = 0; j < newWidth; j++) {
 *       const realValue = bigMat[i*interp2*newWidth + j]
 *       const colValue = bigMat[((i+1)*interp2)*newWidth + j] ? bigMat[((i+1)*interp2)*newWidth + j] : 0
 *       for (let k = 0; k < interp2; k++)
 *         bigMat[newWidth*(i*interp2+k) + j] = realValue + (colValue-realValue)*k/interp2
 *     }
 *     bigMat = bigMat.map(a => parseInt(a))
 *     return bigMat
 *   }
 * 调用示例：
 *   sit:  newArr = lineInterp(newArr, 23, 23, 2, 2)   // 23×23 → 46×46
 *   back: newArr = lineInterp(newArr, 25, 32, 2, 2)   // width=25(列), height=32(行) → 50×64
 */
export function lineInterp(
  smallMat: ReadonlyArray<number>,
  width: number,
  height: number,
  interp1: number,
  interp2: number
): number[] {
  const interpValue = 1;
  const newWidth = width * interp1;
  const bigLen = newWidth * (height * interp2);
  let bigMat: number[] = new Array(bigLen).fill(0);

  // 第一轮：横向插值（仅填充偶数行 i*interp2）
  for (let i = 0; i < height; i++) {
    for (let j = 0; j < width; j++) {
      const realValue = smallMat[i * width + j] * interpValue;
      // 与原代码 1:1：j==width-1 时为 0；右邻为 0 时三元也走 0 分支。
      const rightRaw = j === width - 1 ? 0 : smallMat[i * width + j + 1] * interpValue;
      const rowValue = rightRaw ? rightRaw : 0;
      bigMat[newWidth * i * interp2 + j * interp1] = smallMat[i * width + j] * interpValue;
      for (let k = 0; k < interp1; k++) {
        bigMat[newWidth * (i * interp2) + (j * interp1 + k)] = realValue + (rowValue - realValue) * k / interp1;
      }
    }
  }

  // 第二轮：纵向插值（跨上下两个采样行）
  for (let i = 0; i < height; i++) {
    for (let j = 0; j < newWidth; j++) {
      const realValue = bigMat[i * interp2 * newWidth + j];
      const downRaw = bigMat[((i + 1) * interp2) * newWidth + j];
      const colValue = downRaw ? downRaw : 0; // 越界 → undefined → falsy → 0
      for (let k = 0; k < interp2; k++) {
        bigMat[newWidth * (i * interp2 + k) + j] = realValue + (colValue - realValue) * k / interp2;
      }
    }
  }

  // parseInt(a) ≡ 去小数部分（对正数等价于 Math.trunc）
  bigMat = bigMat.map((a) => Math.trunc(a));
  return bigMat;
}

/**
 * 2×2 插值二维包装（供软件热力图使用）。
 * 调用顺序与官方完全一致：
 *   - 坐垫（rows=23, cols=23）→ lineInterp(flat, 23, 23, 2, 2) → 46×46
 *   - 靠背（rows=32, cols=25）→ lineInterp(flat, 25, 32, 2, 2) → 50×64
 * 注意：调用 lineInterp 时 width=cols、height=rows。
 */
export function lineInterp2x2(
  small: ReadonlyArray<ReadonlyArray<number>>,
  rows: number,
  cols: number
): number[][] {
  // 1) 二维 small[r][c] → 行优先一维 flat（与官方 smallMat[i*width+j] 一致，i=r,j=c）
  const flat = new Array<number>(rows * cols);
  for (let r = 0; r < rows; r++) {
    const srcRow = small[r];
    for (let c = 0; c < cols; c++) {
      flat[r * cols + c] = srcRow[c];
    }
  }
  // 2) 调用原版：width=cols, height=rows
  const flatBig = lineInterp(flat, cols, rows, 2, 2);
  // 3) reshape 回 (rows*2)×(cols*2)，同时 clamp 到 [0,255]
  const bigRows = rows * 2;
  const bigCols = cols * 2;
  const big: number[][] = new Array(bigRows);
  for (let r = 0; r < bigRows; r++) {
    const row = new Array<number>(bigCols);
    for (let c = 0; c < bigCols; c++) {
      let v = flatBig[r * bigCols + c];
      if (v < 0) v = 0;
      else if (v > 255) v = 255;
      row[c] = v;
    }
    big[r] = row;
  }
   return big;
}

/**
 * 按文档规则对 big 矩阵做"180°旋转 + 水平镜像"排布。
 * endiSit: push(45-i) 作为 y 索引、每行 reverse() 相当于 col 翻转
 * endiBack: push(63-i) 作为 y 索引、每行 reverse() 相当于 col 翻转
 * 二者等价于：flip 上下 + flip 左右 = 180° 旋转。
 */
export function rotate180(big: ReadonlyArray<ReadonlyArray<number>>): number[][] {
  const h = big.length;
  const w = big[0].length;
  const out: number[][] = new Array(h);
  for (let i = 0; i < h; i++) {
    const src = big[h - 1 - i];
    const row = new Array<number>(w);
    for (let j = 0; j < w; j++) row[j] = src[w - 1 - j];
    out[i] = row;
  }
  return out;
}
