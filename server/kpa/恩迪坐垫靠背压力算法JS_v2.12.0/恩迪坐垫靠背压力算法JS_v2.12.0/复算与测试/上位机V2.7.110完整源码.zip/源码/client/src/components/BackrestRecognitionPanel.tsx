import { useEffect, useRef, useState } from "react";
import { BACKREST_LOAD_RECOGNITION_VALIDATION } from "@/lib/backrestLoadRecognition";
import { BackrestRecognitionPreviewStream, simulatedNominalForceN, type BackrestRecognitionPreview, type RecognizedBackrestContact } from "@/lib/backrestRecognitionPreview";
import type { ContinuousForceFrame } from "@/lib/sensorForce";

type DisplayContact = Pick<RecognizedBackrestContact, "contactId" | "centerRow" | "centerCol" | "possiblyMerged" | "recognizedMassKg" | "nominalForceN" | "topScore" | "scoreMargin" | "uncertain">;
type DisplayResult = Pick<BackrestRecognitionPreview, "timestampMs" | "nominalTotalForceN" | "uncertain"> & { contacts: DisplayContact[] };

interface Props {
  physical: number[][] | undefined;
  timestampMs: number | undefined;
  streamId: string;
  active: boolean;
  paused: boolean;
  replay: boolean;
  /** Fixed-load mode shares the exact force snapshot used by main pressure/capture. */
  forceFrame?: ContinuousForceFrame | null;
}

/** Synthetic display remains local React state; nominal mode uses authoritative force metadata. */
export default function BackrestRecognitionPanel({ physical, timestampMs, streamId, active, paused, replay, forceFrame }: Props) {
  const runtime = useRef(new BackrestRecognitionPreviewStream());
  const [result, setResult] = useState<DisplayResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [simulationEnabled, setSimulationEnabled] = useState(true);
  const [simulated, setSimulated] = useState<Record<number, { nominal: number; value: number }>>({});
  const [stale, setStale] = useState(false);
  const lastArrival = useRef(0);

  useEffect(() => {
    runtime.current.reset(); setResult(null); setError(null); setSimulated({}); setStale(false);
  }, [streamId]);

  useEffect(() => {
    if (forceFrame !== undefined) {
      const recognition = forceFrame?.backrestLoadRecognition;
      if (!recognition || timestampMs === undefined) { setResult(null); setSimulated({}); return; }
      const contacts: DisplayContact[] = recognition.contacts.map(contact => ({
        contactId: contact.trackId, centerRow: contact.center[0], centerCol: contact.center[1],
        recognizedMassKg: contact.recognizedMassKg, nominalForceN: contact.nominalForceN,
        topScore: Math.max(0, ...contact.scores), scoreMargin: contact.scoreMargin,
        uncertain: contact.uncertain, possiblyMerged: false,
      }));
      setResult({ timestampMs, contacts, nominalTotalForceN: forceFrame!.forceN,
        uncertain: contacts.some(contact => contact.uncertain) });
      setError(null); setStale(false); lastArrival.current = Date.now();
      return;
    }
    if (!physical || timestampMs === undefined) { setResult(null); setSimulated({}); return; }
    try {
      const next = runtime.current.update(physical, timestampMs, streamId);
      setResult(next); setError(null); setStale(false); lastArrival.current = Date.now();
    } catch {
      setResult(null); setSimulated({}); setError("缺少有效原始ADC，本帧无法识别");
    }
  }, [physical, timestampMs, streamId, forceFrame]);

  useEffect(() => {
    if (!result || !simulationEnabled) { setSimulated({}); return; }
    const refresh = () => {
      const expired = !replay && Date.now() - lastArrival.current > 2000;
      setStale(expired);
      if (!active || paused || expired) return;
      setSimulated(Object.fromEntries(result.contacts.map(contact => [contact.contactId,
        { nominal: contact.nominalForceN, value: simulatedNominalForceN(contact.nominalForceN) }])));
    };
    refresh();
    const timer = window.setInterval(refresh, 250);
    return () => window.clearInterval(timer);
  }, [result, simulationEnabled, active, paused, replay]);

  const status = error ?? (!result ? "等待原始采集帧" : !result.contacts.length ? "无接触" : result.uncertain ? "存在不确定识别，请核对档位" : "已输出候选档位");
  const refreshing = active && !paused && !stale;
  return (
    <section data-testid="backrest-recognition-panel" className="mt-2 rounded border border-cyan-500/25 bg-cyan-500/5 px-3 py-2 text-[11px]">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
        <strong className="text-cyan-300">靠背六档识别 · V2.7.87试用</strong>
        <span className="rounded border border-amber-500/30 px-1.5 text-[10px] text-amber-300">试用 · 存在错档</span>
        <span data-testid="backrest-recognition-status" role="status" className={result?.uncertain || error ? "text-amber-300" : "text-muted-foreground"}>{status}</span>
        <span className="ml-auto text-muted-foreground">识别标称合计 <output data-testid="backrest-recognition-nominal-total" className="font-mono text-sm font-semibold text-cyan-200">{result ? result.nominalTotalForceN.toFixed(3) : "--"}</output> N</span>
        <label className="flex cursor-pointer items-center gap-1.5 text-amber-200">
          <input data-testid="backrest-simulation-toggle" type="checkbox" checked={simulationEnabled} onChange={event => setSimulationEnabled(event.target.checked)} />
          模拟波动 ±0.5 N
        </label>
      </div>
      <p className="mt-1 text-[10px] text-muted-foreground">仅识别1.625、3.25、4.875、6.5、8.125、16.5 kg；按g=9.8换算标称力。{BACKREST_LOAD_RECOGNITION_VALIDATION.label}。</p>
      {result && result.contacts.length > 0 && (
        <div className="mt-1 max-h-36 overflow-auto">
          <table className="w-full text-right tabular-nums">
            <thead className="text-[10px] text-muted-foreground"><tr><th className="text-left">接触区域 / 中心</th><th>识别砝码 kg</th><th>标称力 N</th><th>识别状态</th>{simulationEnabled && <th className="text-amber-200">模拟力 N（±0.5）</th>}</tr></thead>
            <tbody>{result.contacts.map(contact => (
              <tr key={contact.contactId} data-testid="backrest-recognition-contact" className="border-t border-cyan-500/10">
                <td className="py-1 text-left text-muted-foreground">#{contact.contactId} · 行{contact.centerRow.toFixed(1)} 列{contact.centerCol.toFixed(1)}</td>
                <td data-testid="backrest-recognized-mass" className="font-mono text-cyan-200">{contact.recognizedMassKg.toFixed(3)}</td>
                <td data-testid="backrest-recognition-nominal" className="font-mono">{contact.nominalForceN.toFixed(3)}</td>
                <td className={contact.uncertain || contact.possiblyMerged ? "text-amber-300" : "text-muted-foreground"} title={`最高投票份额${(contact.topScore * 100).toFixed(1)}%，领先差${(contact.scoreMargin * 100).toFixed(1)}%；不是校准概率`}>{contact.possiblyMerged ? "可能合并" : contact.uncertain ? "不确定" : "候选"}</td>
                {simulationEnabled && <td className="font-mono text-amber-200"><span className="mr-1 text-[9px]">模拟</span><output data-testid="backrest-simulated-force" data-simulated="true" data-nominal-force={contact.nominalForceN}>{(simulated[contact.contactId]?.nominal === contact.nominalForceN ? simulated[contact.contactId].value : contact.nominalForceN).toFixed(3)}</output></td>}
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
      <p data-testid="backrest-simulation-note" className="mt-1 text-[10px] text-amber-200/80">{simulationEnabled ? `模拟值每250 ms随机刷新，${refreshing ? "当前启用" : paused ? "已暂停" : stale ? "无新帧，已冻结" : "数据源停止，已冻结"}。` : "模拟波动已关闭。"}模拟值不是实测压力，不参与总力、热图、CSV/XLSX或精度统计。</p>
    </section>
  );
}
