/**
 * Frozen hard-band backrest model, ported from the audited Python runtime.
 * Input is ORIGINAL canonical 25 x 32 ADC, never an interpolated display map.
 * Segmentation and per-contact causal ADC filtering precede every cell curve.
 */
import { backrestTaxelModel, type BackrestTaxelModel } from "./backrestTaxelModel.generated";

export type BackrestLoadDirection = "up" | "down";
type Matrix = number[][];
type Point = [number, number];
type Pixel = [number, number, number];
interface SplitEvidence { principalVariance: number; centerDistance: number; valleyRatio: number; }

export interface BackrestTaxelContact {
  forceN: number;
  cellForceMapN: Matrix;
  direction: BackrestLoadDirection;
  directionConfirmed: boolean;
  directionSource: "startup_assumption" | "observed_step" | "observed_reversal";
  centroidRow: number;
  centroidCol: number;
  filterEvent: string;
  possiblyMerged: boolean;
  geometrySplit: boolean;
  flags: string[];
  trackId: number;
  rawAdcSum: number;
  filteredAdcSum: number;
  filteredMatrix: Matrix;
  boundsRC: [number, number, number, number];
  centroidMovementCells: number | null;
  positionChangeBypass: boolean;
}

export interface BackrestTaxelFrame {
  timestampMs: number;
  forceN: number;
  cellForceMapN: Matrix;
  contactCount: number;
  contacts: BackrestTaxelContact[];
  invalidInputAdcSum: number;
  rawInputAdcSum: number;
  retainedContactAdcSum: number;
  status: "continuous_taxel_force_candidate_requires_validation";
}

interface Patch {
  rawAdcSum: number;
  centroidRow: number;
  centroidCol: number;
  matrix: Matrix;
  boundsRC: [number, number, number, number];
  possiblyMerged: boolean;
  evidence: SplitEvidence[];
}
interface Track {
  filteredAdc: number;
  previousAdc: number;
  direction: BackrestLoadDirection;
  directionConfirmed: boolean;
  directionSource: BackrestTaxelContact["directionSource"];
  extremeAdc: number;
  filteredMatrix: Matrix;
  centroidRow: number;
  centroidCol: number;
}
interface TrackedPatch extends Patch {
  trackId: number;
  filteredAdcSum: number;
  filteredMatrix: Matrix;
  direction: BackrestLoadDirection;
  directionConfirmed: boolean;
  directionSource: BackrestTaxelContact["directionSource"];
  filterEvent: string;
  centroidMovementCells: number | null;
  positionChangeBypass: boolean;
}

const ROWS = 25, COLS = 32;
const PARAMETERS = {
  seedThreshold: 8, minSeedPixels: 4, minSeedSum: 100, weakRadius: 1.5,
  splitVarianceThreshold: 3.773802, minCenterDistance: 3.4, maxValleyRatio: .9,
  densityBandwidth: .75, maxContacts: 8,
};
const zeroMatrix = (): Matrix => Array.from({ length: ROWS }, () => Array(COLS).fill(0));
const copyMatrix = (matrix: Matrix): Matrix => matrix.map(row => [...row]);

/** Compensated accumulation matches Python 3.12 float sum to roundoff. */
function sum(values: number[]): number {
  let high = 0, low = 0;
  for (const value of values) {
    const next = high + value;
    low += Math.abs(high) >= Math.abs(value) ? (high-next)+value : (value-next)+high;
    high = next;
  }
  return high + low;
}
const matrixSum = (matrix: Matrix): number => sum(matrix.map(row => sum(row)));

export function validateBackrestTaxelAdc(matrix: Matrix): void {
  if (!Array.isArray(matrix) || matrix.length !== ROWS || matrix.some(row =>
    !Array.isArray(row) || row.length !== COLS || row.some(value =>
      typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 255))) {
    throw new TypeError("Expected original canonical 25 x 32 finite ADC in [0,255]");
  }
}

/** Integral of the frozen nonnegative segment slopes; result is N, no extra g. */
export function calculateBackrestCellForceMap(
  matrix: Matrix,
  direction: BackrestLoadDirection = "up",
  model: BackrestTaxelModel = backrestTaxelModel,
): Matrix {
  validateBackrestTaxelAdc(matrix);
  if (direction !== "up" && direction !== "down") throw new TypeError("Unknown loading direction");
  const slopes = model.directions[direction].slopesNPerAdc;
  return matrix.map((row, r) => row.map((adc, c) => {
    if (!model.physicalValidMask[r][c]) return 0;
    const contributions = slopes[r][c].map((slope, j) => slope *
      Math.min(Math.max(adc-model.knotsAdc[j], 0), model.knotsAdc[j+1]-model.knotsAdc[j]));
    return sum(contributions);
  }));
}

function components(points: Point[]): Point[][] {
  const remaining = new Set(points.map(([r,c]) => r*COLS+c));
  const output: Point[][] = [];
  while (remaining.size) {
    const start = Math.min(...Array.from(remaining));
    const todo: Point[] = [[Math.floor(start/COLS), start%COLS]], region: Point[] = [];
    while (todo.length) {
      const [r,c] = todo.pop()!;
      const key = r*COLS+c;
      if (!remaining.has(key)) continue;
      remaining.delete(key); region.push([r,c]);
      for (let dr=-1; dr<=1; dr++) for (let dc=-1; dc<=1; dc++) {
        if ((dr || dc) && r+dr>=0 && r+dr<ROWS && c+dc>=0 && c+dc<COLS) todo.push([r+dr,c+dc]);
      }
    }
    output.push(region);
  }
  return output;
}

function principalAxis(points: Point[], matrix: Matrix): [number, Point] {
  const total = sum(points.map(([r,c]) => matrix[r][c]));
  const cy = sum(points.map(([r,c]) => r*matrix[r][c]))/total;
  const cx = sum(points.map(([r,c]) => c*matrix[r][c]))/total;
  const rr = sum(points.map(([r,c]) => matrix[r][c]*(r-cy)**2))/total;
  const cc = sum(points.map(([r,c]) => matrix[r][c]*(c-cx)**2))/total;
  const rc = sum(points.map(([r,c]) => matrix[r][c]*(r-cy)*(c-cx)))/total;
  const eigen = (rr+cc+Math.sqrt((rr-cc)**2+4*rc*rc))/2;
  let vr: number, vc: number;
  if (Math.abs(rc)>1e-12) {
    vr=rc; vc=eigen-rr;
    const norm=Math.hypot(vr,vc); vr/=norm; vc/=norm;
  } else { vr=rr>=cc?1:0; vc=rr>=cc?0:1; }
  return [eigen,[vr,vc]];
}

function quantile(values: number[], q: number): number {
  const ordered=[...values].sort((a,b)=>a-b), pos=(ordered.length-1)*q, i=Math.floor(pos);
  return ordered[i]+(pos-i)*(ordered[Math.min(i+1,ordered.length-1)]-ordered[i]);
}

function splitSeedComponent(points: Point[], matrix: Matrix): [Point[][], SplitEvidence[]] {
  const p=PARAMETERS, groups=[points], proofs: SplitEvidence[]=[];
  while (groups.length<p.maxContacts) {
    let changed=false;
    for (let k=0; k<groups.length; k++) {
      const region=groups[k];
      if (region.length<2*p.minSeedPixels) continue;
      const [eigen,axis]=principalAxis(region,matrix);
      if (eigen<=p.splitVarianceThreshold) continue;
      const projection=region.map(([r,c])=>r*axis[0]+c*axis[1]);
      const weights=region.map(([r,c])=>matrix[r][c]);
      let centers=[quantile(projection,.25),quantile(projection,.75)], labels: number[]=[];
      for (let iteration=0; iteration<30; iteration++) {
        labels=projection.map(value=>Math.abs(value-centers[0])<=Math.abs(value-centers[1])?0:1);
        if (!labels.includes(0)||!labels.includes(1)) break;
        const next=[0,1].map(i=>sum(projection.map((v,j)=>labels[j]===i?v*weights[j]:0))/
          sum(weights.filter((_,j)=>labels[j]===i)));
        if (Math.max(...next.map((a,i)=>Math.abs(a-centers[i])))<1e-7) { centers=next; break; }
        centers=next;
      }
      if (Math.abs(centers[1]-centers[0])<p.minCenterDistance) continue;
      const halves=[0,1].map(i=>region.filter((_,j)=>labels[j]===i));
      if (halves.some(part=>part.length<p.minSeedPixels ||
        sum(part.map(([r,c])=>matrix[r][c]))<p.minSeedSum)) continue;
      const density=(x:number)=>sum(projection.map((v,i)=>weights[i]*Math.exp(-.5*((v-x)/p.densityBandwidth)**2)));
      const [low,high]=[...centers].sort((a,b)=>a-b);
      const valley=Math.min(...Array.from({length:11},(_,j)=>density(low+(high-low)*(j+5)/20)));
      const peaks=centers.map(center=>Math.max(...Array.from({length:9},(_,j)=>density(center+p.densityBandwidth*((j-4)/4)))));
      const ratio=valley/Math.min(...peaks);
      if (ratio>p.maxValleyRatio) continue;
      groups.splice(k,1,...halves);
      proofs.push({principalVariance:eigen,centerDistance:Math.abs(centers[1]-centers[0]),valleyRatio:ratio});
      changed=true; break;
    }
    if (!changed) break;
  }
  return [groups,proofs];
}

/** Same fixed geometry-only splitter as segmentation_v2.py; no force labels. */
function splitContacts(matrix: Matrix): Patch[] {
  validateBackrestTaxelAdc(matrix);
  const p=PARAMETERS, strong: Point[]=[];
  for (let r=0;r<ROWS;r++) for (let c=0;c<COLS;c++) if (matrix[r][c]>=p.seedThreshold) strong.push([r,c]);
  const seeds=components(strong).filter(region=>region.length>=p.minSeedPixels &&
    sum(region.map(([r,c])=>matrix[r][c]))>=p.minSeedSum);
  const groups: Point[][]=[], proofs: SplitEvidence[][]=[];
  for (const region of seeds) {
    const [parts,evidence]=splitSeedComponent(region,matrix);
    groups.push(...parts); proofs.push(...parts.map(()=>evidence));
  }
  if (!groups.length) return [];
  const seedOwner=new Map<number,number>();
  groups.forEach((region,i)=>region.forEach(([r,c])=>seedOwner.set(r*COLS+c,i)));
  const pixelGroups: Pixel[][]=groups.map(()=>[]);
  for (let r=0;r<ROWS;r++) for (let c=0;c<COLS;c++) {
    const value=matrix[r][c]; if (value<=0) continue;
    let owner=seedOwner.get(r*COLS+c);
    if (owner===undefined) {
      const distances=groups.map(region=>Math.min(...region.map(([rr,cc])=>(r-rr)**2+(c-cc)**2)));
      owner=0;
      for (let i=1;i<distances.length;i++) if (distances[i]<distances[owner]) owner=i;
      if (distances[owner]>p.weakRadius**2) continue;
    }
    pixelGroups[owner].push([r,c,value]);
  }
  const contacts: Patch[]=groups.map((seed,i)=>{
    const points=pixelGroups[i], total=sum(points.map(point=>point[2]));
    const cy=sum(points.map(([r,,v])=>r*v))/total, cx=sum(points.map(([,c,v])=>c*v))/total;
    const bounds: [number,number,number,number]=[
      Math.min(...points.map(point=>point[0])),Math.min(...points.map(point=>point[1])),
      Math.max(...points.map(point=>point[0])),Math.max(...points.map(point=>point[1])),
    ];
    const height=bounds[2]-bounds[0]+1, width=bounds[3]-bounds[1]+1, patch=zeroMatrix();
    points.forEach(([r,c,v])=>{patch[r][c]=v;});
    return {rawAdcSum:total,centroidRow:cy,centroidCol:cx,matrix:patch,boundsRC:bounds,
      possiblyMerged:seed.length>=45&&Math.max(height,width)>=9,evidence:proofs[i]};
  });
  return contacts.sort((a,b)=>a.centroidRow-b.centroidRow||a.centroidCol-b.centroidCol);
}

/** One independent tracker per sensor stream; repeated UI reads must use a cache. */
export class BackrestTaxelEstimator {
  private tracks = new Map<number, Track>();
  private nextId = 1;
  private timestampMs: number | null = null;
  private readonly alpha=.25;
  private readonly threshold=18; // max(18, 6*1.8), exactly the frozen tracker.
  private readonly maxGapMs=2000;
  private readonly matchRadiusCells=2.5;
  private readonly positionBypassCells=.5;

  constructor(private readonly model: BackrestTaxelModel=backrestTaxelModel) {}

  reset(): void { this.tracks.clear(); this.timestampMs=null; }

  private track(contacts: Patch[], now: number): TrackedPatch[] {
    const validHistory=this.timestampMs!==null && now>this.timestampMs && now-this.timestampMs<=this.maxGapMs;
    const previousCenters=new Map<number,Point>();
    if (validHistory) this.tracks.forEach((t,id)=>previousCenters.set(id,[t.centroidRow,t.centroidCol]));
    if (this.timestampMs!==null && (now<=this.timestampMs || now-this.timestampMs>this.maxGapMs)) this.reset();
    const pairs: [number,number,number][]=[];
    contacts.forEach((contact,i)=>this.tracks.forEach((track,id)=>pairs.push([
      Math.hypot(contact.centroidRow-track.centroidRow,contact.centroidCol-track.centroidCol),i,id,
    ])));
    pairs.sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]);
    const matched=new Map<number,number>(), usedIds=new Set<number>();
    pairs.forEach(([distance,i,id])=>{
      if (distance<=this.matchRadiusCells&&!matched.has(i)&&!usedIds.has(id)) {matched.set(i,id);usedIds.add(id);}
    });
    const nextTracks=new Map<number,Track>(), output: TrackedPatch[]=[];
    contacts.forEach((contact,i)=>{
      const raw=contact.rawAdcSum, matchedId=matched.get(i);
      let id: number, track: Track, event: string;
      if (matchedId===undefined) {
        id=this.nextId++;
        track={filteredAdc:raw,previousAdc:raw,direction:"up",directionConfirmed:false,
          directionSource:"startup_assumption",extremeAdc:raw,filteredMatrix:copyMatrix(contact.matrix),
          centroidRow:contact.centroidRow,centroidCol:contact.centroidCol};
        event="new_contact";
      } else {
        id=matchedId; track={...this.tracks.get(id)!};
        const delta=raw-track.previousAdc, step=Math.abs(delta)>=this.threshold;
        track.filteredAdc=step?raw:track.filteredAdc+this.alpha*(raw-track.filteredAdc);
        event=step?"step_bypass":"ema";
        if (track.direction==="up") {
          if (raw<=track.extremeAdc-this.threshold) {
            track.direction="down";track.directionConfirmed=true;track.directionSource="observed_reversal";
            track.extremeAdc=raw;track.filteredAdc=raw;event="reversal_bypass";
          } else {
            track.extremeAdc=Math.max(track.extremeAdc,raw);
            if (delta>=this.threshold) {track.directionConfirmed=true;track.directionSource="observed_step";}
          }
        } else {
          if (raw>=track.extremeAdc+this.threshold) {
            track.direction="up";track.directionConfirmed=true;track.directionSource="observed_reversal";
            track.extremeAdc=raw;track.filteredAdc=raw;event="reversal_bypass";
          } else {
            track.extremeAdc=Math.min(track.extremeAdc,raw);
            if (delta<=-this.threshold) {track.directionConfirmed=true;track.directionSource="observed_step";}
          }
        }
        track.previousAdc=raw;
        track.filteredMatrix=event!=="ema"?copyMatrix(contact.matrix):
          track.filteredMatrix.map((oldRow,r)=>oldRow.map((old,c)=>old+this.alpha*(contact.matrix[r][c]-old)));
      }
      track.filteredAdc=matrixSum(track.filteredMatrix);
      track.centroidRow=contact.centroidRow; track.centroidCol=contact.centroidCol;
      const old=previousCenters.get(id);
      const distance=old?Math.hypot(contact.centroidRow-old[0],contact.centroidCol-old[1]):null;
      const bypass=distance!==null&&distance>=this.positionBypassCells;
      if (bypass) {
        track.filteredAdc=raw;track.filteredMatrix=copyMatrix(contact.matrix);event="position_change_bypass";
      }
      nextTracks.set(id,track);
      output.push({...contact,trackId:id,filteredAdcSum:track.filteredAdc,filteredMatrix:track.filteredMatrix,
        direction:track.direction,directionConfirmed:track.directionConfirmed,directionSource:track.directionSource,
        filterEvent:event,centroidMovementCells:distance,positionChangeBypass:bypass});
    });
    this.tracks=nextTracks; this.timestampMs=now;
    return output;
  }

  update(matrix: Matrix, timestampMs: number): BackrestTaxelFrame {
    validateBackrestTaxelAdc(matrix);
    if (typeof timestampMs!=="number" || !Number.isFinite(timestampMs)) throw new TypeError("Finite timestampMs required");
    const tracked=this.track(splitContacts(matrix),timestampMs), total=zeroMatrix();
    const contacts=tracked.map((patch): BackrestTaxelContact=>{
      const forceMap=calculateBackrestCellForceMap(patch.filteredMatrix,patch.direction,this.model);
      const newMask=this.model.directions[patch.direction].newCoveredMask, flags: string[]=[];
      if (!patch.directionConfirmed) flags.push("direction_assumed_loading_on_startup");
      if (patch.filteredMatrix.some((row,r)=>row.some((v,c)=>v>0&&this.model.physicalValidMask[r][c]&&!newMask[r][c]))) {
        flags.push("active_taxel_outside_primary_branch_support");
      }
      for (let r=0;r<ROWS;r++) for (let c=0;c<COLS;c++) total[r][c]+=forceMap[r][c];
      return {forceN:matrixSum(forceMap),cellForceMapN:forceMap,direction:patch.direction,
        directionConfirmed:patch.directionConfirmed,directionSource:patch.directionSource,
        centroidRow:patch.centroidRow,centroidCol:patch.centroidCol,filterEvent:patch.filterEvent,
        possiblyMerged:patch.possiblyMerged,geometrySplit:patch.evidence.length>0,flags,
        trackId:patch.trackId,rawAdcSum:patch.rawAdcSum,filteredAdcSum:patch.filteredAdcSum,
        filteredMatrix:copyMatrix(patch.filteredMatrix),boundsRC:[...patch.boundsRC],
        centroidMovementCells:patch.centroidMovementCells,positionChangeBypass:patch.positionChangeBypass};
    });
    return {timestampMs,forceN:matrixSum(total),cellForceMapN:total,contactCount:contacts.length,contacts,
      invalidInputAdcSum:sum(matrix.flatMap((row,r)=>row.filter((_,c)=>!this.model.physicalValidMask[r][c]))),
      rawInputAdcSum:matrixSum(matrix),retainedContactAdcSum:sum(tracked.map(p=>p.rawAdcSum)),
      status:"continuous_taxel_force_candidate_requires_validation"};
  }
}

export const backrestTaxelModelVersion=backrestTaxelModel.version;
