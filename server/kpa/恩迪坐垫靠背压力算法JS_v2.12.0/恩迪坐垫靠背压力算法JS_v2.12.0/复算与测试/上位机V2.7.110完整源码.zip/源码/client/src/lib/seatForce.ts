// Generated seat continuous ADC regression; runtime parity tested against Python.
import model from './seatForceModel';
import fixedWeightModel from './seatForceSoftModel.generated';
import { analyzeSeatSoftFixedForce } from './seatForceSoft.generated';
import type {ContinuousForceFrame} from './sensorForce';
import { supplementSeatForceContacts } from './forceContacts';
function validate(m:number[][],rows:number,cols:number){if(!Array.isArray(m)||m.length!==rows||m.some(r=>!Array.isArray(r)||r.length!==cols||r.some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0||v>255)))throw new TypeError('Expected complete native '+rows+'×'+cols+' ADC matrix.');}
function reflect(i:number,n:number){while(i<0||i>=n)i=i<0?-i-1:2*n-i-1;return i;}
function gaussian(s:number[][],sigma=1.5){const radius=Math.round(4*sigma),k:number[]=[];let z=0;for(let i=-radius;i<=radius;i++){const v=Math.exp(-.5*i*i/(sigma*sigma));k.push(v);z+=v;}for(let i=0;i<k.length;i++)k[i]/=z;const a=Array.from({length:46},()=>Array(46).fill(0)),b=Array.from({length:46},()=>Array(46).fill(0));for(let r=0;r<46;r++)for(let c=0;c<46;c++){for(let d=-radius;d<=radius;d++)a[r][c]+=s[reflect(r+d,46)][c]*k[d+radius];}for(let r=0;r<46;r++)for(let c=0;c<46;c++){for(let d=-radius;d<=radius;d++)b[r][c]+=a[r][reflect(c+d,46)]*k[d+radius];}return b;}
function seedLabels(rows:number,cols:number,seeds:number[][],scale=1){const out=new Int32Array(rows*cols);for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){let best=0,distance=Infinity;for(let j=0;j<seeds.length;j++){const d=(r*scale-seeds[j][0])**2+(c*scale-seeds[j][1])**2;if(d<distance){distance=d;best=j;}}out[r*cols+c]=best;}return out;}
function coarseContactSeeds(source:number[][]){const smooth=gaussian(source),maximum=Math.max(...smooth.flat()),cutoff=Math.max(15,maximum*.2),candidates:number[][]=[];for(let r=0;r<46;r++)for(let c=0;c<46;c++){const value=smooth[r][c];if(value<cutoff)continue;let maximum=true;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++)if(smooth[reflect(r+dr,46)][reflect(c+dc,46)]>value)maximum=false;if(maximum)candidates.push([r,c,value]);}candidates.sort((a,b)=>b[2]-a[2]||a[0]-b[0]||a[1]-b[1]);const seeds:number[][]=[];for(const p of candidates)if(seeds.every(q=>(p[0]-q[0])**2+(p[1]-q[1])**2>=49))seeds.push(p.slice(0,2));if(!seeds.length)return seeds;const labels=seedLabels(46,46,seeds),counts=Array(seeds.length).fill(0);for(let r=0;r<46;r++)for(let c=0;c<46;c++)if(source[r][c]>5)counts[labels[r*46+c]]++;const keep=seeds.filter((_,j)=>counts[j]>=32);return keep.length?keep:seeds;}

function roundEven(value:number){const floor=Math.floor(value),fraction=value-floor;return fraction===.5?(floor%2===0?floor:floor+1):Math.round(value);}
function existingContactSeeds(source:number[][]):number[][]{
 const coarse=coarseContactSeeds(source);if(!coarse.length)return coarse;
 const labels=seedLabels(46,46,coarse),fine=gaussian(source,.75),fineMaximum=Math.max(...fine.flat()),result:number[][]=[];
 for(let j=0;j<coarse.length;j++){
  let count=0,total=0,rs=0,cs=0;for(let r=0;r<46;r++)for(let c=0;c<46;c++)if(labels[r*46+c]===j){const v=source[r][c],w=v*v;if(v>30)count++;total+=w;rs+=r*w;cs+=c*w;}
  let split:number[][]|null=null;
  if(count>=120&&total>0){
   const row=rs/total,col=cs/total;let vr=0,vc=0,cov=0;
   for(let r=0;r<46;r++)for(let c=0;c<46;c++)if(labels[r*46+c]===j){const w=source[r][c]**2;vr+=w*(r-row)**2;vc+=w*(c-col)**2;cov+=w*(r-row)*(c-col);}
   vr/=total;vc/=total;cov/=total;const disc=Math.sqrt((vr-vc)**2+4*cov*cov),small=(vr+vc-disc)/2,large=(vr+vc+disc)/2;
   if(large>=2*Math.max(small,1e-12)){
    const candidates:number[][]=[];for(let r=0;r<46;r++)for(let c=0;c<46;c++){
     if(labels[r*46+c]!==j||fine[r][c]<Math.max(20,fineMaximum*.25))continue;
     let maximum=true;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++)if(fine[reflect(r+dr,46)][reflect(c+dc,46)]>fine[r][c])maximum=false;
     if(maximum)candidates.push([r,c,fine[r][c]]);
    }
    candidates.sort((a,b)=>b[2]-a[2]||a[0]-b[0]||a[1]-b[1]);const peaks:number[][]=[];
    for(const p of candidates)if(peaks.every(q=>(p[0]-q[0])**2+(p[1]-q[1])**2>=25))peaks.push(p.slice(0,2));
    let bestScore=-1;for(let ai=0;ai<peaks.length;ai++)for(let bi=ai+1;bi<peaks.length;bi++){
     const a=peaks[ai],b=peaks[bi],distance2=(a[0]-b[0])**2+(a[1]-b[1])**2;if(distance2<56.25||distance2>256)continue;const low=Math.min(fine[a[0]][a[1]],fine[b[0]][b[1]]);let valley=Infinity;
     for(let k=0;k<=100;k++){const t=k/100,r=roundEven(a[0]+(b[0]-a[0])*t),c=roundEven(a[1]+(b[1]-a[1])*t);valley=Math.min(valley,fine[r][c]);}
     const score=((a[0]-b[0])**2+(a[1]-b[1])**2)*low;if(valley<=.85*low&&score>bestScore){split=[a,b];bestScore=score;}
    }
   }
  }
  result.push(...(split||[coarse[j]]));
 }
 return result;
}

export function contactSeeds(source:number[][]):number[][] {
  return supplementSeatForceContacts(source, existingContactSeeds(source));
}

function quantile(a:number[],q:number){if(!a.length)return 0;const p=(a.length-1)*q,lo=Math.floor(p),hi=Math.ceil(p);return a[lo]+(a[hi]-a[lo])*(p-lo);}
function stats(values:number[]){const sorted=values.slice().sort((a,b)=>a-b),valid=sorted.filter(v=>v>30),out:number[]=[];for(const q of [0,.1,.25,.5,.75,.9,1])out.push(quantile(valid,q));for(const p of [1,2,3,6])out.push(values.reduce((sum,v)=>sum+(p===1?v:(v/255)**p),0));for(const t of [0,5,15,30,60,90,120,150,180,210,240])out.push(values.reduce((sum,v)=>sum+(v>t?1:0),0));for(const k of [1,3,5,10,20,46])out.push(sorted.slice(-k).reduce((a,b)=>a+b,0)/k);for(const t of [30,60,90,120,150,180,210])out.push(values.reduce((sum,v)=>sum+Math.max(0,v-t),0));for(const upper of [260,300,400])for(const p of [1,2,3])out.push(values.reduce((sum,v)=>sum+(v/(upper-v))**p,0));return out;}
function globalLocalFeatures(source:number[][],physical:number[][],seeds:number[][]){const sl=seedLabels(46,46,seeds),pl=seedLabels(23,23,seeds,2),result:number[][]=[];for(let j=0;j<seeds.length;j++){const a=source.map((row,r)=>row.map((v,c)=>sl[r*46+c]===j?v:0)),b=physical.map((row,r)=>row.map((v,c)=>pl[r*23+c]===j?v:0));let total=0,rs=0,cs=0;for(let r=0;r<46;r++)for(let c=0;c<46;c++){const w=a[r][c]**2;total+=w;rs+=r*w;cs+=c*w;}const row=rs/total,col=cs/total,shape:number[]=[];for(const [rp,cp] of [[2,0],[0,2],[1,1],[3,0],[0,3],[4,0],[0,4],[2,2]]){let sum=0;for(let r=0;r<46;r++)for(let c=0;c<46;c++)sum+=a[r][c]**2*(r-row)**rp*(c-col)**cp;shape.push(sum/total);}const st=[...stats(a.flat()),...stats(b.flat())],full=[...st,...shape,row/45,col/45,Math.sin(Math.PI*row),Math.cos(Math.PI*row),Math.sin(Math.PI*col),Math.cos(Math.PI*col)];const amp=[3,4,5,6,22,23,24,25,26,27,47,48,49,50,66,67,68,69,70,71],totals=[7,8,9,10,51,52,53,54],compact=[...amp.map(i=>Math.log1p(st[i])),...totals.map(i=>Math.log1p(st[i])),...shape,row/45,col/45];result.push(model.feature==='full'?full:model.feature==='response'?compact.slice(0,28):model.feature==='phase'?[...compact,...full.slice(-4)]:compact);}return result;}

/** Isolate physical ADC locally before interpolation. Other contacts never enter a region's features. */
export function localFeatures(source:number[][],physical:number[][],seeds:number[][]):number[][] {
  const physicalLabels=seedLabels(23,23,seeds,2),result:number[][]=[];
  for(let j=0;j<seeds.length;j++) {
    const b=physical.map((row,r)=>row.map((value,c)=>physicalLabels[r*23+c]===j&&(r*2-seeds[j][0])**2+(c*2-seeds[j][1])**2<=36?value:0));
    const a=Array.from({length:46},()=>Array(46).fill(0));
    for(let r=0;r<23;r++)for(let c=0;c<23;c++) {
      const v=b[r][c],right=b[r][c+1]??0,down=b[r+1]?.[c]??0,diag=b[r+1]?.[c+1]??0;
      a[2*r][2*c]=v;a[2*r][2*c+1]=Math.floor((v+right)/2);a[2*r+1][2*c]=Math.floor((v+down)/2);a[2*r+1][2*c+1]=Math.floor((v+right+down+diag)/4);
    }
    result.push(globalLocalFeatures(a,b,[seeds[j]])[0]);
  }
  return result;
}

function predict(features:number[]){const x=features.map((v,i)=>(v-model.scalerMean[i])/model.scalerScale[i]);let result=model.intercept;for(let i=0;i<model.trainingFeatures.length;i++){const a=model.trainingFeatures[i];let distance=0;for(let k=0;k<x.length;k++)distance+=(x[k]-a[k])**2;result+=model.dualCoefficients[i]*Math.exp(-model.gamma*distance);}return model.logTarget?Math.exp(result):result;}
export function analyzeSeatForce(source:number[][],physical:number[][]):ContinuousForceFrame {
 validate(source,46,46);validate(physical,23,23);
 const existing=existingContactSeeds(source),seeds=supplementSeatForceContacts(source,existing);
 const prediction=analyzeSeatSoftFixedForce(source,physical,existing),regionForcesN=prediction.regionForcesN,forceN=prediction.forceN;
 if(regionForcesN.some(value=>!Number.isFinite(value))||!Number.isFinite(forceN))throw new TypeError('Seat source and physical ADC do not provide a finite regional force.');
 const complete=seeds.length===existing.length&&seeds.every((p,i)=>p[0]===existing[i][0]&&p[1]===existing[i][1]);
 return {algorithmId:'seat-fixed-weight-continuous-region-sum',algorithmLabel:'坐垫独立砝码总力',modelVersion:fixedWeightModel.version,
 status:!seeds.length?'no_contact':!complete?'outside_calibration':forceN<0?'negative_candidate':'candidate_requires_validation',
 forceN,regionForcesN,regionCenters:existing.map(p=>[p[0],p[1]] as [number,number]),
 contactDetectionVersion:'seat-force-local-support-shape-20261028',forceEstimateComplete:complete,calibratedSeedCount:existing.length,detectedContactCount:seeds.length,detectedContactCenters:seeds.map(p=>[p[0],p[1]] as [number,number]),
 seedCount:existing.length,scoreMargin:null,averagePressureKPa:null,areaCm2:0,forceMeaning:'continuous_adc_regression',calculationMode:'continuous_adc_regression',
 scopeNote:'坐垫1.625kg砝码与16.5kg极限载荷专用；各接触区以ADC概率期望和连续残差校正估算后相加；不同位置±1N尚未通过。',
 accepted:false,independentlyValidated:false,inputMode:'native46x46-physical23x23-local-isolation',loadLabel:'连续ADC回归'};
}
export function canonicalFromRaw(raw:number[]){if(!Array.isArray(raw)||raw.length!==1024||raw.some(v=>!Number.isInteger(v)||v<0||v>255))throw new TypeError('1024 raw bytes required');const ys=[...Array.from({length:11},(_,i)=>i),...Array.from({length:12},(_,i)=>22-i)],p=ys.map(y=>Array.from({length:23},(_,c)=>raw[y*32+22-c])),s=Array.from({length:46},()=>Array(46).fill(0));for(let r=0;r<23;r++)for(let c=0;c<23;c++){const a=p[r][c],b=p[r][c+1]??0,d=p[r+1]?.[c]??0,e=p[r+1]?.[c+1]??0;s[2*r][2*c]=a;s[2*r][2*c+1]=Math.trunc((a+b)/2);s[2*r+1][2*c]=Math.trunc((a+d)/2);s[2*r+1][2*c+1]=Math.trunc((a+b+d+e)/4);}return {source:s,physical:p};}
