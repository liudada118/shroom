import { IntervalLoadEstimator, LOAD_INTERVAL_VERSION } from "./loadIntervalEstimator";
import { analyzeBackrestArea } from "./backrestArea";
import { validateBackrestAdc } from "./backrestTotalForce";
import type { ContinuousForceFrame } from "./sensorForce";
import { calculateBackrestTaxelPressure } from "./backrestTaxelPressure";
import { BackrestTaxelEstimator } from "./backrestTaxelRuntime";
import { backrestTaxelModel } from "./backrestTaxelModel.generated";
import { BACKREST_LOAD_RECOGNITION } from "./backrestLoadRecognition.generated";
import { recognizeBackrestContactForces, recognizedBackrestPressureMetadata } from "./backrestRecognitionPressure";

export type BackrestForceMethod = "fixed_load_recognition" | "taxel_continuous";
export interface BackrestStreamContext {
  timestampMs: number;
  streamId: string;
  method?: BackrestForceMethod;
  /** Static capture recomputation chooses a method without advancing live state. */
  static?: boolean;
}
export const backrestForceModelVersion = backrestTaxelModel.version;
let intervalEstimators = new WeakMap<BackrestTaxelEstimator, IntervalLoadEstimator>();

/** Canonical source is50x64; canonical ORIGINAL physical ADC is25x32. */
export function analyzeBackrestForce(source: number[][], physical: number[][], timestampMs = 0,
  estimator = new BackrestTaxelEstimator(), method: BackrestForceMethod = "taxel_continuous"): ContinuousForceFrame {
  validateBackrestAdc(source, 50, 64, "Source");
  const prediction = estimator.update(physical, timestampMs);
  const area = analyzeBackrestArea(source);
  let interval=intervalEstimators.get(estimator);
  if(!interval){interval=new IntervalLoadEstimator("backrest");intervalEstimators.set(estimator,interval);}
  const recognized = method === "fixed_load_recognition" ? recognizeBackrestContactForces(prediction.contacts,interval,timestampMs) : null;
  const cellForceMapN = recognized?.cellForceMapN ?? prediction.cellForceMapN;
  const pressure = calculateBackrestTaxelPressure(source, physical, cellForceMapN, area);
  const contactPressure = recognized ? recognizedBackrestPressureMetadata(pressure) : pressure;
  return {
    algorithmId: recognized ? "backrest-calibrated-interval-force-pressure-g9p8" : "backrest-per-cell-monotone-piecewise-hard-band-g9p8",
    algorithmLabel: recognized ? "靠背标定区间连续估算（g=9.8）" : "靠背逐格分段曲线（g=9.8）",
    modelVersion: recognized ? LOAD_INTERVAL_VERSION : backrestForceModelVersion,
    status: physical.some(row => row.some(v => v > 0)) ? "candidate_requires_validation" : "no_contact",
    forceN: recognized?.forceN ?? prediction.forceN, areaCm2: area.areaCm2, seedCount: area.seedCount,
    forceAggregation: area.seedCount ? "regional_sum" : "total_only",
    regionForcesN: contactPressure.regions.map(region => region.estimatedForceN),
    regionCenters: area.seeds.map(([r, c]) => [r / 2, c / 2]), cellForceMapN,
    backrestTaxelDiagnostics: {
      gravityMS2: 9.8, inputCoordinates: "canonical-25x32",
      modelSourceSha256: recognized ? BACKREST_LOAD_RECOGNITION.sourceSha256 : backrestTaxelModel.sourceSha256,
      contactCount: prediction.contactCount, invalidInputAdcSum: prediction.invalidInputAdcSum,
      contacts: prediction.contacts.map((contact, i) => ({ direction: contact.direction,
        directionConfirmed: contact.directionConfirmed, filterEvent: contact.filterEvent,
        center: [contact.centroidRow, contact.centroidCol], forceN: recognized?.contacts[i].interval.estimatedForceN ?? contact.forceN,
        flags: [...contact.flags, ...(recognized ? ["continuous_force_from_calibrated_response_interval", "cell_distribution_estimated_from_contact_ADC"] : [])] })),
    },
    ...(recognized ? { intervalLoadEstimation:{modelId:LOAD_INTERVAL_VERSION,gravityMS2:9.8,method:"spatial_monotone_response_pchip" as const,contacts:recognized.contacts.map(contact=>({...contact.interval}))}, backrestLoadRecognition: {
      modelId: BACKREST_LOAD_RECOGNITION.id, outputKind: "recognition_diagnostic_with_interval_force" as const,
      gravityMS2: 9.8, randomDisplayIncluded: false as const,
      contacts: recognized.contacts.map(contact => ({ trackId: contact.trackId, center: contact.center,
        recognizedMassKg: contact.recognition.recognizedMassKg, nominalForceN: contact.recognition.nominalForceN,
        scores: [...contact.recognition.scores], scoreMargin: contact.recognition.scoreMargin,
        uncertain: contact.recognition.uncertain })),
      distribution: "per_contact_filtered_ADC_normalized_to_interval_estimate_then_existing_area_Voronoi" as const,
    } } : {}),
    contactDetectionVersion: "backrest-geometry-v2-position-aware-causal-adc-20261029",
    contactPressure, averagePressureKPa: contactPressure.averagePressureKPa,
    inputMode: "original-physical-adc-25x32-canonical-causal-filtered",
    forceMeaning: recognized ? "calibrated_interval_estimation" : "continuous_adc_regression",
    calculationMode: recognized ? "calibrated_interval_estimation" : "continuous_adc_regression",
    accepted: false, independentlyValidated: false,
    loadLabel: recognized ? "标准砝码锚点之间连续估算力，区域压强同步计算" : "每格ADC独立曲线求力，再按接触区域求和",
    scoreMargin: recognized && recognized.contacts.length ? Math.min(...recognized.contacts.map(c => c.recognition.scoreMargin)) : null,
    forceEstimateComplete: true,
    scopeNote: recognized
      ? "标准质量锚点之间按逐格ADC非线性响应、位置灵敏度与加减载曲线进行保单调PCHIP连续估算，g=9.8；六档识别只保留诊断，不锁定输出。方向反转从上一测量状态连续衔接，无时间动画或随机值。按原ADC支持分配各接触区估算力，保留面积与区域压强公式；新增小砝码精度与单格压强尚未独立实测。"
      : "使用保留的hard_band逐格分段曲线，g=9.8。先几何分割、因果ADC滤波，逐格求力后合计；方向由历史响应推断，首次接触默认加荷。换位置及平铺多点尚未达标。面积使用原独立算法；逐格力及局部压强未独立标定。",
  };
}

type MethodCache = Map<BackrestForceMethod, ContinuousForceFrame | null>;
type Cache = WeakMap<number[][], WeakMap<number[][], MethodCache>>;
let liveCache: Cache = new WeakMap();
const staticCache: Cache = new WeakMap();
const liveEstimator = new BackrestTaxelEstimator();
let streamId: string | null = null;
let liveMethod: BackrestForceMethod | null = null;
let lastRawTimestamp: number | null = null;
let lastSampleTimestamp: number | null = null;
const transpose = (m: number[][]) => m[0].map((_, c) => m.map(row => row[c]));

/** Reset on a new connection/session/method; duplicate reads do not advance state. */
export function resetLiveBackrestForce(): void {
  liveEstimator.reset(); intervalEstimators = new WeakMap(); liveCache = new WeakMap(); streamId = null; liveMethod = null;
  lastRawTimestamp = null; lastSampleTimestamp = null;
}

/** Default native32x25 ADC uses a fixed transpose, independent of screen rotation. */
export function calculateLiveBackrestForce(sensorType: string, source?: number[][] | null, physical?: number[][] | null,
  context?: BackrestStreamContext): ContinuousForceFrame | null {
  if (sensorType !== "new-backrest-32x25" || !source || !physical) return null;
  const method = context?.method ?? "fixed_load_recognition";
  const isLive = !!context && !context.static;
  if (isLive && (context.streamId !== streamId || method !== liveMethod)) {
    resetLiveBackrestForce(); streamId = context.streamId; liveMethod = method;
  }
  const caches = isLive ? liveCache : staticCache;
  let cache = caches.get(source);
  if (!cache) { cache = new WeakMap(); caches.set(source, cache); }
  let methods = cache.get(physical);
  if (!methods) { methods = new Map(); cache.set(physical, methods); }
  if (methods.has(method)) return methods.get(method) ?? null;
  let result: ContinuousForceFrame | null = null;
  try {
    validateBackrestAdc(source, 64, 50, "Native source");
    validateBackrestAdc(physical, 32, 25, "Native physical");
    let sampleTimestamp = context?.timestampMs ?? 0;
    if (isLive && lastRawTimestamp !== null && sampleTimestamp === lastRawTimestamp) sampleTimestamp = lastSampleTimestamp! + .001;
    else if (isLive && lastRawTimestamp !== null && sampleTimestamp > lastRawTimestamp) sampleTimestamp = Math.max(sampleTimestamp, lastSampleTimestamp! + .001);
    const canonical = analyzeBackrestForce(transpose(source), transpose(physical), sampleTimestamp,
      isLive ? liveEstimator : undefined, method);
    if (isLive) { lastRawTimestamp = context.timestampMs; lastSampleTimestamp = sampleTimestamp; }
    const cellForceMapN = transpose(canonical.cellForceMapN!);
    const area = analyzeBackrestArea(source);
    const pressure = calculateBackrestTaxelPressure(source, physical, cellForceMapN, area);
    const contactPressure = method === "fixed_load_recognition" ? recognizedBackrestPressureMetadata(pressure) : pressure;
    result = { ...canonical, cellForceMapN, areaCm2: area.areaCm2, seedCount: area.seedCount,
      regionForcesN: contactPressure.regions.map(region => region.estimatedForceN),
      regionCenters: area.seeds.map(([r, c]) => [r / 2, c / 2]),
      forceAggregation: area.seedCount ? "regional_sum" : "total_only",
      contactPressure, averagePressureKPa: contactPressure.averagePressureKPa,
      inputMode: "original-physical-adc-32x25-native-fixed-transpose-causal-filtered" };
  } catch { /* Incomplete original ADC remains unavailable, not zero force. */ }
  methods.set(method, result);
  return result;
}
