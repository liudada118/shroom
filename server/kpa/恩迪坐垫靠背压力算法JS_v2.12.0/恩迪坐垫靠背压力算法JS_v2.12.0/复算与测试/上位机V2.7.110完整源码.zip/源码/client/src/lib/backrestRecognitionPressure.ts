import { IntervalLoadEstimator, type IntervalLoadEstimate } from "./loadIntervalEstimator";
import { recognizeBackrestLoad, type BackrestLoadRecognition } from "./backrestLoadRecognition";
import { backrestTaxelModel } from "./backrestTaxelModel.generated";
import type { BackrestTaxelContact } from "./backrestTaxelRuntime";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";

export const BACKREST_RECOGNITION_PRESSURE_VERSION = "backrest-recognized-nominal-force-region-pressure-mean-g9p8-20261030" as const;

export interface RecognizedContactForce {
  trackId: number;
  center: [number, number];
  recognition: BackrestLoadRecognition;
  interval: IntervalLoadEstimate;
}

/**
 * Preserve each recognized contact's nominal total, distributing only within its
 * measured filtered footprint. Cell values are estimated contributions, not
 * independently calibrated single-cell forces. No random display value enters.
 */
export function distributeRecognizedContactForces(
  contacts: { filteredMatrix: number[][]; nominalForceN: number }[],
): number[][] {
  const output = Array.from({ length: 25 }, () => Array<number>(32).fill(0));
  for (const contact of contacts) {
    const matrix = contact.filteredMatrix;
    if (matrix.length !== 25 || matrix.some(row => row.length !== 32 || row.some(v => !Number.isFinite(v) || v < 0 || v > 255)) ||
        !Number.isFinite(contact.nominalForceN) || contact.nominalForceN < 0) throw new TypeError("Finite recognized force and canonical filtered25x32 ADC required");
    const cells: [number, number, number][] = [];
    for (let r = 0; r < 25; r++) for (let c = 0; c < 32; c++) {
      if (backrestTaxelModel.physicalValidMask[r][c] && matrix[r][c] > 0) cells.push([r, c, matrix[r][c]]);
    }
    const support = cells.reduce((sum, cell) => sum + cell[2], 0);
    if (!support) {
      if (contact.nominalForceN > 0) throw new TypeError("Nonzero recognized force needs measured physical support");
      continue;
    }
    let assigned = 0;
    cells.forEach(([r, c, adc], index) => {
      // Last-cell residual conserves the contact total to floating roundoff.
      const value = index === cells.length - 1 ? Math.max(0, contact.nominalForceN - assigned) : contact.nominalForceN * adc / support;
      output[r][c] += value; assigned += value;
    });
  }
  return output;
}

export function recognizeBackrestContactForces(contacts: BackrestTaxelContact[], interval=new IntervalLoadEstimator("backrest"), timestamp=0): {
  forceN: number; cellForceMapN: number[][]; contacts: RecognizedContactForce[];
} {
  const estimates=interval.update(contacts.map(contact=>({trackId:contact.trackId,matrix:contact.filteredMatrix})),timestamp);
  const recognized = contacts.map((contact,index) => ({ trackId: contact.trackId,
    center: [contact.centroidRow, contact.centroidCol] as [number, number],
    recognition: recognizeBackrestLoad(contact.filteredMatrix), interval:estimates[index] }));
  const cellForceMapN = distributeRecognizedContactForces(contacts.map((contact, index) => ({
    filteredMatrix: contact.filteredMatrix, nominalForceN: recognized[index].interval.estimatedForceN,
  })));
  return { forceN: recognized.reduce((sum, contact) => sum + contact.interval.estimatedForceN, 0),
    cellForceMapN, contacts: recognized };
}

export function recognizedBackrestPressureMetadata(frame: BackrestRegionPressureFrame): BackrestRegionPressureFrame {
  return { ...frame, version: BACKREST_RECOGNITION_PRESSURE_VERSION,
    method: "recognized_nominal_force_map_then_region_arithmetic_mean" };
}
