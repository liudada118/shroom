/**
 * 压强显示单位与数值精度（V2.7.101）。
 *
 * - 界面压强单位为 N/cm²，保留 3 位小数；1 N/cm² = 10 kPa。
 * - 内部字段沿用 kPa（字段名 …KPa 不变），按 0.01 kPa（= 0.001 N/cm²）为最小单位取整，
 *   因此显示的 N/cm² 三位小数与内部数值完全一致，不存在二次舍入误差。
 * - 压力（力）保留 2 位小数（N）。
 */

export const PRESSURE_DISPLAY_UNIT = "N/cm²" as const;
/** 内部压强最小单位：0.01 kPa = 0.001 N/cm² */
export const PRESSURE_UNITS_PER_KPA = 100;

/** 压力取 2 位小数（N）。 */
export function roundForceN(value: number): number {
  return Math.round(value * 100) / 100;
}

/** 面积取 2 位小数（cm²）。 */
export function roundAreaCm2(value: number): number {
  return Math.round(value * 100) / 100;
}

/** kPa → 整数压强单位（0.001 N/cm²）。 */
export function pressureUnitsFromKPa(kPa: number): number {
  return Math.round(kPa * PRESSURE_UNITS_PER_KPA);
}

/** 压强按 0.001 N/cm²（0.01 kPa）取整，返回 kPa。 */
export function roundPressureKPa(kPa: number): number {
  return pressureUnitsFromKPa(kPa) / PRESSURE_UNITS_PER_KPA;
}

/** 由压力 F（N）与面积 S（cm²）求压强：P = F/S（N/cm²）= 10F/S（kPa），按 0.001 N/cm² 取整，返回 kPa。 */
export function pressureKPaFromForceArea(forceN: number, areaCm2: number): number | null {
  if (!(areaCm2 > 0) || !Number.isFinite(forceN)) return null;
  return roundPressureKPa((10 * forceN) / areaCm2);
}

/** kPa → N/cm²（按 0.001 N/cm² 取整）。 */
export function kPaToNcm2(kPa: number): number {
  return pressureUnitsFromKPa(kPa) / 1000;
}

/** 压强显示文字：N/cm²，3 位小数；空值显示 “--”。 */
export function formatPressureNcm2(kPa: number | null | undefined): string {
  if (kPa === null || kPa === undefined || !Number.isFinite(kPa)) return "--";
  return kPaToNcm2(kPa).toFixed(3);
}

/** 压力显示文字：N，2 位小数；空值显示 “--”。 */
export function formatForceN(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "--";
  return roundForceN(value).toFixed(2);
}
