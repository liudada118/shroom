import type { HumanEstimationMetadata } from "./humanEstimation";
import type { ContinuousForceFrame } from "./sensorForce";
import { rescaleBackrestRegionPressure, type BackrestRegionPressureFrame } from "./backrestRegionPressure";
import { SeatDisplayStabilizer, usesSeatStableDisplay, SEAT_DISPLAY_STABILITY_VERSION, type SeatDisplayChangeReason } from "./seatDisplayStabilizer";

export const FORCE_READOUT_VERSION = "total-or-regional-attack0-release30ms-peak-preserving-50hz-20261028";
export const FORCE_READOUT_INTERVAL_MS = 20;
/** Loading passes through; small downward fluctuations receive light smoothing. */
export const FORCE_READOUT_TAU_MS = 30;
export const FORCE_READOUT_FAST_TAU_MS = 0;

/** A screen snapshot has its own time and never replaces a captured raw frame. */
export interface CapturedForceReadout {
  /** Same-frame over-range meaning, preserved in historical captures. */
  humanEstimation?: HumanEstimationMetadata;
  forceN: number;
  regionForcesN: number[];
  forceAggregation?: "regional_sum" | "total_only";
  regionCenters?: [number, number][];
  modelVersion: string;
  contactDetectionVersion?: string;
  forceEstimateComplete?: boolean;
  filterVersion: string;
  mode: "median3-ema" | "median3-adaptive-ema" | "fast-attack-light-release" | "seat-synchronous-adaptive-ema" | "instantaneous";
  medianWindow: number;
  timeConstantMs: number;
  publishIntervalMs: number;
  displayedAt: number;
  sourceFrameTimestamp: number;
  sourceEpoch: string;
  sampleSequence: number;
  contactPressure?: BackrestRegionPressureFrame;
  /** Optional on historical/backrest snapshots; seat force/area/pressure share one time. */
  areaCm2?: number;
  regionAreasCm2?: number[];
  regionAdcShares?: number[];
  areaTimeConstantMs?: number;
  shareTimeConstantMs?: number;
  displayStabilityMode?: "seat-synchronous" | "instantaneous";
  displayChangeReason?: SeatDisplayChangeReason;
  rawAreaCm2?: number;
  rawContactPressure?: BackrestRegionPressureFrame;
}

export interface ForceReadoutSnapshot extends CapturedForceReadout {
  frame: ContinuousForceFrame;
}

type Track = { center?: [number, number]; value: number; timeConstantMs: number };

/** Display-only filter: one sample per new frame, matched by contact position. */
export class ForceReadout {
  private key = "";
  private lastFrame: object | null = null;
  private lastSampleAt = 0;
  private lastPublishAt = -Infinity;
  private sequence = 0;
  private tracks: Track[] = [];
  private snapshot: ForceReadoutSnapshot | null = null;
  private pendingSnapshot: ForceReadoutSnapshot | null = null;
  private pendingPeak: ForceReadoutSnapshot | null = null;
  private seatDisplay = new SeatDisplayStabilizer();

  reset(): void {
    this.key = "";
    this.lastFrame = null;
    this.lastSampleAt = 0;
    this.lastPublishAt = -Infinity;
    this.sequence = 0;
    this.tracks = [];
    this.snapshot = null;
    this.pendingSnapshot = null;
    this.pendingPeak = null;
    this.seatDisplay.reset();
  }

  current(): ForceReadoutSnapshot | null { return this.snapshot; }

  pendingPublishAt(): number | null {
    return this.pendingSnapshot ? this.lastPublishAt + FORCE_READOUT_INTERVAL_MS : null;
  }

  /** Publish the last sampled value without counting a duplicate frame as a sample. */
  flush(publishAt: number): ForceReadoutSnapshot | null {
    const deadline = this.pendingPublishAt();
    if (deadline === null || publishAt < deadline) return null;
    return this.publishPending(publishAt);
  }

  private publishPending(publishAt: number): ForceReadoutSnapshot {
    const latest = this.pendingSnapshot!;
    const peak = this.pendingPeak;
    // A transient increase is displayed once, followed by the latest input. This
    // adds at most one publication interval, without fabricating or amplifying force.
    const preservePeak = peak && peak.forceN > latest.forceN
      && peak.forceN > (this.snapshot?.forceN ?? -Infinity);
    this.snapshot = { ...(preservePeak ? peak : latest), displayedAt: publishAt };
    this.pendingSnapshot = preservePeak ? latest : null;
    this.pendingPeak = null;
    this.lastPublishAt = publishAt;
    return this.snapshot;
  }

  update(
    sourceEpoch: string,
    frameIdentity: object,
    raw: ContinuousForceFrame,
    sampleAt: number,
    sourceFrameTimestamp: number,
    enabled = true,
  ): ForceReadoutSnapshot | null {
    const totalOnly = raw.forceAggregation === "total_only";
    const key = `${sourceEpoch}|${raw.calculationMode}|${raw.modelVersion}|${raw.forceAggregation ?? "regional_sum"}|${raw.contactDetectionVersion ?? ""}|${raw.forceEstimateComplete}|${enabled}`;
    if (key !== this.key || sampleAt < this.lastSampleAt || sampleAt - this.lastSampleAt > 1500) {
      this.reset(); this.key = key;
    }
    if (frameIdentity === this.lastFrame) return null;
    const dt = this.lastFrame ? sampleAt - this.lastSampleAt : 0;
    this.lastFrame = frameIdentity;
    this.lastSampleAt = sampleAt;
    this.sequence++;
    if (raw.humanEstimation?.active) {
      // Entry and exit cannot mix estimates with a prior class, area or pressure.
      const nextSnapshot: ForceReadoutSnapshot = {
        frame: raw, forceN: raw.forceN, regionForcesN: [...raw.regionForcesN],
        contactPressure: raw.contactPressure, forceAggregation: raw.forceAggregation,
        regionCenters: raw.regionCenters?.map(p => [...p] as [number, number]),
        modelVersion: raw.modelVersion, contactDetectionVersion: raw.contactDetectionVersion,
        forceEstimateComplete: raw.forceEstimateComplete,
        humanEstimation: { ...raw.humanEstimation },
        filterVersion: "human-overrange-estimate-instantaneous-20261030", mode: "instantaneous",
        medianWindow: 1, timeConstantMs: 0, publishIntervalMs: 0,
        displayedAt: sampleAt, sourceFrameTimestamp, sourceEpoch, sampleSequence: this.sequence,
        areaCm2: raw.areaCm2,
      };
      this.pendingSnapshot = null; this.pendingPeak = null;
      this.snapshot = nextSnapshot; this.lastPublishAt = sampleAt;
      return this.snapshot;
    }
    if (raw.calculationMode === "fixed_load_recognition" || raw.calculationMode === "calibrated_interval_estimation" || raw.calculationMode === "endi_cushion_fitted" || raw.calculationMode === "endi_backrest_fitted") {
      // Publish the same current estimated force and pressure immediately.
      // ADC interval interpolation happens in the model, without a display ramp.
      // 恩迪坐垫算法内部已含 3 帧中值滤波、噪声带混合读数与切换平滑，显示层不再二次平滑。
      // 恩迪靠背算法内部已含 120 ms 时间平均、状态机读数与切换平滑，同样直接透传。
      const nextSnapshot: ForceReadoutSnapshot = {
        frame: raw, forceN: raw.forceN, regionForcesN: [...raw.regionForcesN],
        contactPressure: raw.contactPressure, forceAggregation: raw.forceAggregation,
        regionCenters: raw.regionCenters?.map(p => [...p] as [number, number]),
        modelVersion: raw.modelVersion, contactDetectionVersion: raw.contactDetectionVersion,
        forceEstimateComplete: raw.forceEstimateComplete,
        filterVersion: raw.calculationMode === "endi_cushion_fitted" ? "endi-cushion-internal-filter-passthrough-20261109"
          : raw.calculationMode === "endi_backrest_fitted" ? "endi-backrest-internal-filter-passthrough-20261109"
          : raw.calculationMode === "calibrated_interval_estimation" ? "calibrated-interval-force-instantaneous-20261101" : "recognized-nominal-force-instantaneous-20261030", mode: "instantaneous",
        medianWindow: 1, timeConstantMs: 0, publishIntervalMs: 0,
        displayedAt: sampleAt, sourceFrameTimestamp, sourceEpoch, sampleSequence: this.sequence,
        areaCm2: raw.areaCm2,
      };
      this.pendingSnapshot = null; this.pendingPeak = null;
      this.snapshot = nextSnapshot; this.lastPublishAt = sampleAt;
      return this.snapshot;
    }
    if (usesSeatStableDisplay(raw)) {
      const stable = this.seatDisplay.update(raw, dt, enabled);
      const frame = stable.frame;
      const nextSnapshot: ForceReadoutSnapshot = {
        frame, forceN: frame.forceN, regionForcesN: [...frame.regionForcesN], contactPressure: frame.contactPressure,
        forceAggregation: raw.forceAggregation, regionCenters: raw.regionCenters?.map(p => [...p] as [number, number]),
        modelVersion: raw.modelVersion, filterVersion: SEAT_DISPLAY_STABILITY_VERSION,
        contactDetectionVersion: raw.contactDetectionVersion, forceEstimateComplete: raw.forceEstimateComplete,
        mode: enabled ? "seat-synchronous-adaptive-ema" : "instantaneous", medianWindow: 1,
        timeConstantMs: stable.forceTimeConstantMs, areaTimeConstantMs: stable.areaTimeConstantMs,
        shareTimeConstantMs: stable.shareTimeConstantMs, publishIntervalMs: enabled ? FORCE_READOUT_INTERVAL_MS : 0,
        displayedAt: sampleAt, sourceFrameTimestamp, sourceEpoch, sampleSequence: this.sequence,
        areaCm2: stable.areaCm2, regionAreasCm2: stable.regionAreasCm2, regionAdcShares: stable.regionAdcShares,
        displayStabilityMode: enabled ? "seat-synchronous" : "instantaneous", displayChangeReason: stable.changeReason,
        rawAreaCm2: raw.areaCm2, rawContactPressure: raw.contactPressure,
      };
      if (!enabled || !this.snapshot) {
        this.pendingSnapshot = null; this.pendingPeak = null;
        this.snapshot = nextSnapshot; this.lastPublishAt = sampleAt;
        return this.snapshot;
      }
      this.pendingSnapshot = nextSnapshot;
      // Preserve short real ADC-backed loading peaks. Small model fluctuations
      // are not peak-held, so the symmetric filter does not acquire upward bias.
      if ((stable.changeReason === "adc-step" || stable.topologyChanged || stable.changeReason === "contact-moved")
        && (!this.pendingPeak || frame.forceN >= this.pendingPeak.forceN)) this.pendingPeak = nextSnapshot;
      return sampleAt - this.lastPublishAt < FORCE_READOUT_INTERVAL_MS ? null : this.publishPending(sampleAt);
    }
    // A total-only estimate gets one internal filter track, never a fabricated contact force.
    // A zero total removes that track immediately to avoid residual load after unloading.
    const values = totalOnly ? (raw.forceN > 0 ? [raw.forceN] : []) : raw.regionForcesN;
    const centers = !totalOnly && raw.regionCenters?.length === values.length ? raw.regionCenters : undefined;
    const old = this.tracks;
    const assigned = new Map<number, number>();
    if (centers && old.every(t => t.center)) {
      const pairs: { current: number; previous: number; distance: number }[] = [];
      centers.forEach((p, current) => old.forEach((t, previous) => {
        const distance = (p[0] - t.center![0]) ** 2 + (p[1] - t.center![1]) ** 2;
        if (distance <= 16) pairs.push({ current, previous, distance });
      }));
      pairs.sort((a, b) => a.distance - b.distance || a.current - b.current || a.previous - b.previous);
      const used = new Set<number>();
      for (const pair of pairs) if (!assigned.has(pair.current) && !used.has(pair.previous)) {
        assigned.set(pair.current, pair.previous); used.add(pair.previous);
      }
    } else if (values.length === 1 && old.length === 1) assigned.set(0, 0);
    const topologyChanged = old.length !== values.length || assigned.size !== values.length;
    this.tracks = values.map((value, i) => {
      const previous = assigned.has(i) ? old[assigned.get(i)!] : undefined;
      if (!enabled || !previous) return { center: centers?.[i], value, timeConstantMs: 0 };
      const decrease = previous.value - value;
      // Do not classify short loading pulses as noise. All increases pass through.
      // Meaningful unloading also passes through; only sub-0.5 N/0.5% downward
      // fluctuations are smoothed. No dead zone and no gain are applied to force.
      const releaseBand = Math.max(0.5, Math.abs(previous.value) * 0.005);
      if (decrease <= 0 || decrease >= releaseBand || decrease <= 0.005) {
        return { center: centers?.[i], value, timeConstantMs: 0 };
      }
      const alpha = 1 - Math.exp(-Math.max(0, dt) / FORCE_READOUT_TAU_MS);
      return { center: centers?.[i], timeConstantMs: FORCE_READOUT_TAU_MS,
        value: previous.value + alpha * (value - previous.value) };
    });
    const regionForcesN = totalOnly ? [] : this.tracks.map(t => t.value);
    const forceN = this.tracks.reduce((sum, track) => sum + track.value, 0);
    const contactPressure = raw.contactPressure ? rescaleBackrestRegionPressure(raw.contactPressure, forceN,
      (raw.contactPressure.method === "per_cell_force_sum_then_region_arithmetic_mean" || raw.contactPressure.method === "recognized_nominal_force_map_then_region_arithmetic_mean") && !totalOnly ? regionForcesN : undefined) : undefined;
    const frame = { ...raw, regionForcesN, forceN, contactPressure,
      averagePressureKPa: contactPressure ? contactPressure.averagePressureKPa
        : raw.areaCm2 > 0 && forceN >= 0 ? 10 * forceN / raw.areaCm2 : null };
    const nextSnapshot: ForceReadoutSnapshot = {
      frame, forceN, contactPressure, regionForcesN: [...regionForcesN], forceAggregation: raw.forceAggregation,
      regionCenters: centers?.map(p => [...p] as [number, number]),
      modelVersion: raw.modelVersion, filterVersion: FORCE_READOUT_VERSION,
      contactDetectionVersion: raw.contactDetectionVersion,
      forceEstimateComplete: raw.forceEstimateComplete,
      mode: enabled ? "fast-attack-light-release" : "instantaneous",
      medianWindow: 1,
      timeConstantMs: enabled ? Math.max(FORCE_READOUT_FAST_TAU_MS, ...this.tracks.map(t => t.timeConstantMs)) : 0,
      publishIntervalMs: enabled ? FORCE_READOUT_INTERVAL_MS : 0,
      displayedAt: sampleAt, sourceFrameTimestamp, sourceEpoch, sampleSequence: this.sequence,
    };
    // A new/rearranged nonempty contact publishes immediately. Empty input uses
    // the next publication slot, so a brief contact followed by zero in the same
    // serial chunk is visible before zero and cannot vanish in React batching.
    if (!enabled || (topologyChanged && forceN > 0) || !this.snapshot) {
      this.pendingSnapshot = null;
      this.pendingPeak = null;
      this.snapshot = nextSnapshot;
      this.lastPublishAt = sampleAt;
      return this.snapshot;
    }
    this.pendingSnapshot = nextSnapshot;
    if (!this.pendingPeak || nextSnapshot.forceN >= this.pendingPeak.forceN) this.pendingPeak = nextSnapshot;
    return sampleAt - this.lastPublishAt < FORCE_READOUT_INTERVAL_MS ? null : this.publishPending(sampleAt);
  }
}

export function captureForceReadout(snapshot: ForceReadoutSnapshot | null): CapturedForceReadout | undefined {
  if (!snapshot) return undefined;
  const { frame: _frame, ...metadata } = snapshot;
  return { ...metadata, contactPressure: metadata.contactPressure ? structuredClone(metadata.contactPressure) : undefined,
    ...(metadata.humanEstimation ? { humanEstimation: { ...metadata.humanEstimation } } : {}),
    ...(metadata.rawContactPressure ? { rawContactPressure: structuredClone(metadata.rawContactPressure) } : {}),
    ...(metadata.regionAreasCm2 ? { regionAreasCm2: [...metadata.regionAreasCm2] } : {}),
    ...(metadata.regionAdcShares ? { regionAdcShares: [...metadata.regionAdcShares] } : {}),
    regionForcesN: [...metadata.regionForcesN],
    regionCenters: metadata.regionCenters?.map(p => [...p] as [number, number]) };
}

export const FORCE_READOUT_EXPORT_HEADERS = [
  "平滑显示总力（N）", "平滑显示分区力（N）", "力值显示模式", "力值平滑版本",
  "平滑窗口帧数", "平滑时间常数（ms）", "力值显示间隔（ms）",
  "力值显示时间戳", "显示所用帧时间戳", "显示数据源", "显示采样序号", "显示力模型版本",
  "显示落点检测版本", "显示完整总力可估算", "显示区域中心", "显示力汇总方式",
  "显示接触区平均压强（kPa）", "显示各区估算力（N）", "显示各区估算压强（kPa）", "显示接触区压强版本",
  "同步显示面积（cm²）", "同步显示各区面积（cm²）", "同步显示各区ADC份额", "同步稳定显示模式",
  "面积显示时间常数（ms）", "ADC份额显示时间常数（ms）", "显示变化判定", "显示所用原始面积（cm²）", "显示所用原始ADC总和",
];

export function forceReadoutExportValues(snapshot?: CapturedForceReadout): (string | number)[] {
  if (!snapshot) return FORCE_READOUT_EXPORT_HEADERS.map(() => "--");
  return [snapshot.forceN, snapshot.regionForcesN.join(";"), snapshot.mode, snapshot.filterVersion,
    snapshot.medianWindow, snapshot.timeConstantMs, snapshot.publishIntervalMs,
    snapshot.displayedAt, snapshot.sourceFrameTimestamp, snapshot.sourceEpoch,
    snapshot.sampleSequence, snapshot.modelVersion, snapshot.contactDetectionVersion ?? "--",
    snapshot.forceEstimateComplete === undefined ? "--" : String(snapshot.forceEstimateComplete),
    snapshot.regionCenters?.map(p => p.join(":" )).join(";") ?? "--",
    snapshot.forceAggregation ?? "regional_sum",
    snapshot.contactPressure?.averagePressureKPa ?? "--",
    snapshot.contactPressure?.regions.map(r => r.estimatedForceN).join(";") ?? "--",
    snapshot.contactPressure?.regions.map(r => r.estimatedPressureKPa ?? "--").join(";") ?? "--",
    snapshot.contactPressure?.version ?? "--",
    snapshot.areaCm2 ?? "--", snapshot.regionAreasCm2?.join(";") ?? "--", snapshot.regionAdcShares?.join(";") ?? "--",
    snapshot.displayStabilityMode ?? "--", snapshot.areaTimeConstantMs ?? "--", snapshot.shareTimeConstantMs ?? "--",
    snapshot.displayChangeReason ?? "--", snapshot.rawAreaCm2 ?? "--", snapshot.rawContactPressure?.rawAdcSum ?? "--"];
}
