/**
 * 串口连接 Hook
 * 使用 Web Serial API 连接压力传感器
 * 使用 ref 确保 readLoop 中的回调始终使用最新的 config
 */

import { useCallback, useRef, useState } from "react";
import { getSensorConfig, lineInterp2x2 } from "@/lib/sensorConfig";
import type { FrameData } from "./useDemo";

export interface SerialState {
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  frameRate: number;
  totalFrames: number;
}

export interface LogEntry {
  timestamp: number;
  level: "info" | "warn" | "error" | "data";
  message: string;
  detail?: string;
}

/** Yield cooperatively without the 4 ms nesting clamp of repeated timers. */
async function yieldSerialWork(): Promise<void> {
  // Use the same task priority as React's MessageChannel work so continuation
  // cannot overtake the pending force render and hide an intermediate peak.
  await new Promise<void>(resolve => {
    const channel = new MessageChannel();
    channel.port1.onmessage = () => { channel.port1.close(); channel.port2.close(); resolve(); };
    channel.port2.postMessage(null);
  });
}

export function useSerial(
  sensorType: string,
  onFrame: (data: FrameData) => void,
  onLog?: (entry: LogEntry) => void
) {
  const [state, setState] = useState<SerialState>({
    isConnected: false,
    isConnecting: false,
    error: null,
    frameRate: 0,
    totalFrames: 0,
  });

  const portRef = useRef<any>(null);
  const readerRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);
  const bufferRef = useRef<Uint8Array>(new Uint8Array(0));
  const frameCountRef = useRef(0);
  const fpsIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const readingRef = useRef(false);
  // Invalidate a cooperative drain when its connection is closed or replaced.
  const readSessionRef = useRef(0);
  const totalFramesRef = useRef(0);
  // 成功帧/读取调试日志按秒汇总，重要事件与错误仍立即记录。
  const logSummaryRef = useRef({ lastFrameAt: 0, lastFrameCount: 0, lastReadAt: 0 });
  const logCallbackRef = useRef(onLog);
  logCallbackRef.current = onLog;

  // 使用 ref 保存最新的 config 和 onFrame，避免 readLoop 闭包捕获旧值
  const configRef = useRef(getSensorConfig(sensorType));
  const onFrameRef = useRef(onFrame);
  configRef.current = getSensorConfig(sensorType);
  onFrameRef.current = onFrame;

  const log = useCallback(
    (level: LogEntry["level"], message: string, detail?: string) => {
      logCallbackRef.current?.({
        timestamp: Date.now(),
        level,
        message,
        detail,
      });
    },
    []
  );

  const parseFrame = useCallback(
    (rawBytes: Uint8Array): FrameData => {
      const config = configRef.current;
      const {
        rows,
        cols,
        physicalRows,
        physicalCols,
        interpFactor,
        wireMap,
      } = config;

      // 1) 先按 wireMap 把 1024 字节原始帧映射到“物理分辨率”矩阵（23×23 / 32×25）
      const physical: number[][] = new Array(physicalRows);
      for (let r = 0; r < physicalRows; r++) {
        const row = new Array<number>(physicalCols);
        for (let c = 0; c < physicalCols; c++) {
          const idx = wireMap[r * physicalCols + c];
          row[c] = idx < rawBytes.length ? rawBytes[idx] : 0;
        }
        physical[r] = row;
      }

      // 2) 按文档 lineInterp(..., 2, 2) 做 2×2 线性插值，得到高分辨率矩阵
      //    V2.7.15: 不再在此处做 rotate180，让 matrix 与 physical 严格同源同方向；
      //    显示方向统一由 Home.tsx 的 matrixRotation（默认 3 = 顺时针 270°）控制，
      //    这样小面板和大图天然同方向，原始点定位无需额外坐标补偿。
      let matrix: number[][];
      if (interpFactor && interpFactor > 1) {
        matrix = lineInterp2x2(physical, physicalRows, physicalCols);
      } else {
        matrix = physical;
      }

      // 3) 基于最终高分辨率矩阵统一计算统计量
      let max = 0;
      let min = 255;
      let sum = 0;
      let nonZeroMin = 255;
      let nonZeroCount = 0;
      for (let r = 0; r < rows; r++) {
        const row = matrix[r];
        for (let c = 0; c < cols; c++) {
          const val = row[c];
          if (val > max) max = val;
          if (val < min) min = val;
          if (val > 0) {
            if (val < nonZeroMin) nonZeroMin = val;
            nonZeroCount++;
          }
          sum += val;
        }
      }
      if (nonZeroCount === 0) nonZeroMin = 0;
      const totalPoints = rows * cols;

      return {
        matrix,
        physical,
        raw: rawBytes,
        timestamp: Date.now(),
        max,
        min,
        avg: Math.round((sum / totalPoints) * 100) / 100,
        nonZeroMin,
        sum,
        nonZeroCount,
      };
    },
    [] // 无依赖，通过 configRef 获取最新 config
  );

  const findDelimiter = useCallback(
    (buffer: Uint8Array, startPos: number = 0): number => {
      const delim = configRef.current.delimiter;
      for (let i = startPos; i <= buffer.length - delim.length; i++) {
        if (
          buffer[i] === delim[0] &&
          buffer[i + 1] === delim[1] &&
          buffer[i + 2] === delim[2] &&
          buffer[i + 3] === delim[3]
        ) {
          return i;
        }
      }
      return -1;
    },
    [] // 无依赖，通过 configRef 获取最新 config
  );

  const processBuffer = useCallback(async (session: number) => {
    const config = configRef.current;
    let buffer = bufferRef.current;
    const frameSize = config.frameSize;
    let processed = false;

    // Drain every complete frame already received. Never leave a valid tail
    // waiting for a future read, and never truncate a burst of valid frames.
    // Yield to painting/timers after ~4 ms instead of imposing a frame-count cap.
    let sliceStartedAt = performance.now();
    while (buffer.length >= frameSize + 4 && readingRef.current && session === readSessionRef.current) {
      // 内层循环：从buffer开头开始搜索分隔符，跳过数据不足的假分隔符
      let searchPos = 0;
      let foundFrame = false;

      while (searchPos <= buffer.length - 4) {
        const delimPos = findDelimiter(buffer, searchPos);

        if (delimPos === -1) {
          // 没有找到更多分隔符，等待更多数据
          break;
        }

        if (delimPos >= frameSize) {
          // 分隔符前有足够的数据，提取帧
          const frameStart = delimPos - frameSize;
          const frameBytes = buffer.slice(frameStart, delimPos);
          const frame = parseFrame(frameBytes);

          frameCountRef.current++;
          totalFramesRef.current++;
          processed = true;
          foundFrame = true;

          const logNow = Date.now();
          const summary = logSummaryRef.current;
          if (summary.lastFrameAt === 0 || logNow - summary.lastFrameAt >= 1000) {
            const hexPreview = Array.from(frameBytes.slice(0, 8))
              .map((b) => b.toString(16).toUpperCase().padStart(2, "0"))
              .join(" ");
            const received = totalFramesRef.current - summary.lastFrameCount;
            log(
              "data",
              `帧 #${totalFramesRef.current} 解析成功 (${config.rows}×${config.cols} 映射)`,
              `本段${received}帧 max=${frame.max} min=${frame.min} avg=${frame.avg} 前8字节: ${hexPreview}...`
            );
            summary.lastFrameAt = logNow;
            summary.lastFrameCount = totalFramesRef.current;
          }

          onFrameRef.current(frame);

          // 跳过已处理的帧和分隔符，继续处理剩余buffer
          buffer = buffer.subarray(delimPos + 4);
          bufferRef.current = buffer;
          break; // 跳出内层循环，外层循环继续尝试下一帧
        } else {
          // 分隔符前数据不足frameSize：这可能是数据中的巧合匹配
          // 不丢弃数据，跳过这个分隔符继续搜索下一个
          searchPos = delimPos + 4;
        }
      }

      if (!foundFrame) {
        // 没有找到有效帧，停止处理
        // 如果buffer过大，截断前面的旧数据
        if (buffer.length > frameSize * 2 + 256) {
          const trimTo = buffer.length - (frameSize + 256);
          buffer = buffer.slice(trimTo);
          bufferRef.current = buffer;
        }
        break;
      }
      if (buffer.length >= frameSize + 4 && performance.now() - sliceStartedAt >= 4) {
        await yieldSerialWork();
        sliceStartedAt = performance.now();
      }
    }
    if (session === readSessionRef.current) bufferRef.current = buffer.slice();

    return processed;
  }, [findDelimiter, parseFrame, log]); // 无 config 依赖，通过 configRef 获取

  const readLoop = useCallback(async () => {
    const reader = readerRef.current;
    if (!reader) return;
    const session = ++readSessionRef.current;
    readingRef.current = true;

    const config = configRef.current;
    log("info", "开始读取串口数据流...");
    log("info", `传感器类型: ${config.name} (${config.rows}×${config.cols})`);
    log("info", `帧大小: ${config.frameSize} 字节，分隔符: AA 55 03 99`);

    let readCount = 0;
    let totalBytes = 0;

    try {
      while (readingRef.current && session === readSessionRef.current) {
        const { value, done } = await reader.read();
        if (session !== readSessionRef.current || !readingRef.current) break;
        if (done) {
          log("info", "串口数据流结束 (done=true)");
          break;
        }

        if (value) {
          readCount++;
          totalBytes += value.length;

          const logNow = Date.now();
          if (readCount <= 5 || logNow - logSummaryRef.current.lastReadAt >= 1000) {
            const hexPreview = Array.from(value.slice(0, 16))
              .map((b) => b.toString(16).toUpperCase().padStart(2, "0"))
              .join(" ");
            log(
              "data",
              `读取 #${readCount}: ${value.length} 字节 (累计 ${totalBytes})`,
              `buffer=${bufferRef.current.length} 前16字节: ${hexPreview}`
            );
            logSummaryRef.current.lastReadAt = logNow;
          }

          // 合并buffer
          const oldBuffer = bufferRef.current;
          const newBuffer = new Uint8Array(oldBuffer.length + value.length);
          newBuffer.set(oldBuffer, 0);
          newBuffer.set(value, oldBuffer.length);
          bufferRef.current = newBuffer;

          await processBuffer(session);
        }
      }
    } catch (err: any) {
      if (readingRef.current && session === readSessionRef.current) {
        log("error", `读取异常: ${err.message}`, err.stack);
        setState((s) => ({
          ...s,
          error: `读取错误: ${err.message}`,
          isConnected: false,
        }));
      }
    }

    log("info", `读取循环结束，共 ${readCount} 次读取，${totalBytes} 字节`);
  }, [processBuffer, log]);

  const connect = useCallback(async () => {
    if (!("serial" in navigator)) {
      log("error", "您的浏览器不支持 Web Serial API。请使用 Chrome 89+ 或 Edge 89+。");
      setState((s) => ({
        ...s,
        error: "您的浏览器不支持 Web Serial API。请使用 Chrome 89+ 或 Edge 89+。",
      }));
      return;
    }

    setState((s) => ({ ...s, isConnecting: true, error: null }));
    log("info", "正在请求串口设备...");

    try {
      const port = await (navigator as any).serial.requestPort();
      log("info", "用户已选择串口设备，正在打开...");

      const deviceInfo = port.getInfo?.();
      if (deviceInfo) {
        log(
          "info",
          `设备信息: vendorId=${deviceInfo.usbVendorId ?? "N/A"} productId=${deviceInfo.usbProductId ?? "N/A"}`
        );
      }

      await port.open({ baudRate: 1000000, dataBits: 8, stopBits: 1, parity: "none", bufferSize: 65536 });
      log("info", "串口已打开: 1000000 baud, 8N1, bufferSize=65536");

      portRef.current = port;
      bufferRef.current = new Uint8Array(0);
      frameCountRef.current = 0;
      logSummaryRef.current = { lastFrameAt: 0, lastFrameCount: totalFramesRef.current, lastReadAt: 0 };

      if (port.readable) {
        readerRef.current = port.readable.getReader();
        log("info", "已获取 readable stream reader，开始读取");

        // FPS计算
        fpsIntervalRef.current = setInterval(() => {
          setState((s) => ({
            ...s,
            frameRate: frameCountRef.current,
            totalFrames: totalFramesRef.current,
          }));
          frameCountRef.current = 0;
        }, 1000);

        setState((s) => ({
          ...s,
          isConnected: true,
          isConnecting: false,
        }));

        readLoop();
      } else {
        log("error", "串口 readable 为 null，无法读取数据");
      }
    } catch (err: any) {
      log("error", `连接失败: ${err.message}`, err.stack);
      setState((s) => ({
        ...s,
        isConnecting: false,
        error: `连接失败: ${err.message}`,
      }));
    }
  }, [readLoop, log]);

  const disconnect = useCallback(async () => {
    log("info", "正在断开连接...");
    readingRef.current = false;
    readSessionRef.current++;

    if (fpsIntervalRef.current) {
      clearInterval(fpsIntervalRef.current);
      fpsIntervalRef.current = null;
    }

    try {
      if (readerRef.current) {
        await readerRef.current.cancel();
        readerRef.current.releaseLock();
        readerRef.current = null;
        log("info", "Reader 已释放");
      }
      if (portRef.current) {
        await portRef.current.close();
        portRef.current = null;
        log("info", "串口已关闭");
      }
    } catch (err: any) {
      log("warn", `断开时出错 (可忽略): ${err.message}`);
    }

    bufferRef.current = new Uint8Array(0);
    frameCountRef.current = 0;

    setState({
      isConnected: false,
      isConnecting: false,
      error: null,
      frameRate: 0,
      totalFrames: totalFramesRef.current,
    });

    log("info", "已断开连接");
  }, [log]);

  return { state, connect, disconnect };
}
