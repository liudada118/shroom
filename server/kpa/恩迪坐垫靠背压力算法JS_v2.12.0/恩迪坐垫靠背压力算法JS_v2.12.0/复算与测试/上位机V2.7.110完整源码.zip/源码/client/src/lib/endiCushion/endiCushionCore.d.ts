/** 类型声明：恩迪坐垫面积与压力算法核心（endiCushionCore.js）。 */

/** 单个接触区的逐帧输出。坐标 cy/cx 为算法方向（= 采集导出方向 = 热力图屏幕方向）的物理格坐标。 */
export interface EndiRegionOutput {
  /** 轨迹编号（同一物体在会话内保持不变）。 */
  track: number;
  /** 质量 kg（V2.7.103 起为未乘超量程倍率 / 真人系数的基准值）。 */
  m: number;
  /** 力 N（= 9.8 × m）。 */
  F: number;
  /** 面积 cm²：标准档 = 63.62；估算 = T29 轮廓格数 × 1 cm²。 */
  S: number;
  /** 平均压强 kPa（= 10F/S；S = 0 时为 null）。 */
  P: number | null;
  /** 输出方式。 */
  mode: "标准档" | "估算" | "超量程估算";
  /** 状态机状态。 */
  state: "首次接触确认中" | "暂定档" | "已确认" | "加减块判断中";
  /** 当前识别块数（尚未定档时为 0）。 */
  level: number;
  L: number | null;
  added: number;
  first: number | null;
  /** 该接触区是否为单块砝码底面轮廓。 */
  footprint: boolean;
  /** 该区 T29 轮廓格数。 */
  NT: number;
  /** 连续拟合质量 kg。 */
  mfit: number;
  /** 区内最大 ADC。 */
  peak: number;
  /** 超量程：基准估算力 9.8 × m > 90 N 且连续拟合估算力 9.8 × mfit > 90 N（超过 5 块砝码）时置位；任一回落 ≤ 90 N 连续 500 ms 后清除。 */
  over: boolean;
  /** 冻结计数（> 90 N 或有基准时非砝码轮廓）；砝码轮廓且 ≤ 90 N 持续 500 ms 后解除。 */
  frozen: boolean;
  cy: number;
  cx: number;
  /** 区内物理 ADC 总和。 */
  adcSum: number;
  /** 区内物理格数（ADC ≥ 1）。 */
  nCells: number;
}

/** 整帧输出。 */
export interface EndiFrameOutput {
  t: number;
  /** 总质量 kg。 */
  m: number;
  /** 总力 N。 */
  F: number;
  /** 总面积 cm²。 */
  S: number;
  /** 各区压强算术平均 kPa（无接触或任一区面积为 0 时为 null）。 */
  P: number | null;
  regions: EndiRegionOutput[];
}

export interface EndiAlgorithmInstance {
  /** 每帧调用一次：t 为毫秒时间戳（不递减），a 为算法方向的 23×23 物理 ADC 矩阵。 */
  process(t: number, a: ReadonlyArray<ReadonlyArray<number>> | ReadonlyArray<number>): EndiFrameOutput;
  reset(): void;
}

export interface EndiAlgorithmConstructor {
  new (params?: unknown, opts?: { maxEvents?: number }): EndiAlgorithmInstance;
}

export interface EndiCushionParams {
  sensor: { n_phys: number; n_int: number; phys_mm: number; cell_mm: number; cell_area: number; adc_full: number; map: string };
  standard: { mb: number; base_area: number; g: number };
  area: { T: number; N_min: number; N_max: number; span_max: number; ecc_max: number };
  /** V2.7.103：超量程 = 基准估算力与连续拟合估算力均 > force_in（90 N），hold_ms（500）为取消防抖；gain（×2）由上位机适配层施加，核心输出未乘倍率的基准值。 */
  over: { level: number; force_in: number; hold_ms: number; gain: number };
  [key: string]: unknown;
}

export declare const EndiAlgorithm: EndiAlgorithmConstructor;
export declare const DEFAULT_PARAMS: EndiCushionParams;
export declare const STATES: { FIRST: string; TENT: string; CONF: string; JUDGE: string };
/** 23×23（行优先一维）→ 46×46（行优先一维），与设备插值逐格一致。 */
export declare function interpolate(a: ArrayLike<number>): Float64Array;
export declare function contactRegions(a: ArrayLike<number>, minCells: number): unknown[];
export declare function areaRegions(b: ArrayLike<number>, T: number): unknown[];
export declare const ENDI_CUSHION_CORE_VERSION: string;
export declare const ENDI_CUSHION_CORE_SOURCE_SHA256: string;

declare const EndiCushion: {
  EndiAlgorithm: EndiAlgorithmConstructor;
  DEFAULT_PARAMS: EndiCushionParams;
  STATES: typeof STATES;
  interpolate: typeof interpolate;
  contactRegions: typeof contactRegions;
  areaRegions: typeof areaRegions;
  version: string;
};
export default EndiCushion;
