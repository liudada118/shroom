import { analyzeSeatArea, snapshotSeatAreaMetadata } from "./seatArea";
import { validateSeatAdc } from "./seatTotalForce";
import { IntervalLoadEstimator, LOAD_INTERVAL_VERSION } from "./loadIntervalEstimator";
import { recognizeSeatLoad } from "./seatLoadRecognition";
import { SEAT_LOAD_RECOGNITION } from "./seatLoadRecognition.generated";
import type { SeatPressureContext } from "./seatRegionPressure";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";
import type { ContinuousForceFrame } from "./sensorForce";

type Matrix = number[][];
type Point = [number, number];
export const SEAT_RECOGNITION_CONTACT_VERSION = "seat-native-connected-seed-current-frame-20261030";
export const SEAT_RECOGNITION_PRESSURE_VERSION = "seat-recognized-nominal-force-region-pressure-mean-g9p8-20261030" as const;
const emptyMatrix = (): Matrix => Array.from({length:23},()=>Array<number>(23).fill(0));
const matrixSum = (m: Matrix) => m.reduce((s,row)=>s+row.reduce((a,b)=>a+b,0),0);
const copy = (m: Matrix) => m.map(row=>[...row]);
const nativeAreaSeed = ([row,col]:Point,context:SeatPressureContext):Point => {
  if(context.mirrorColumns)col=45-col;
  for(let k=0;k<((context.rotation%4)+4)%4;k++){const previousRow=45-col;col=row;row=previousRow;}
  return [row/2,col/2];
};

export interface SeatRecognitionPatch {
  matrix: Matrix; rawAdcSum: number; center: Point; fallback: boolean;
}
export interface SeatTrackedRecognitionPatch extends SeatRecognitionPatch {
  trackId: number; filteredMatrix: Matrix; filteredAdcSum: number; filterEvent: string;
}

/** Exact native connected-seed policy shared with training segmentation.py. */
export function splitSeatRecognitionContacts(physical: Matrix): SeatRecognitionPatch[] {
  validateSeatAdc(physical,23);
  const remaining=new Set<number>();
  for(let r=0;r<23;r++)for(let c=0;c<23;c++)if(physical[r][c]>=8)remaining.add(r*23+c);
  const groups:Point[][]=[];
  while(remaining.size){
    const start=Math.min(...Array.from(remaining)),todo=[start],points:Point[]=[];
    while(todo.length){
      const key=todo.pop()!;if(!remaining.has(key))continue;remaining.delete(key);
      const r=Math.floor(key/23),c=key%23;points.push([r,c]);
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++)if((dr||dc)&&r+dr>=0&&r+dr<23&&c+dc>=0&&c+dc<23)todo.push((r+dr)*23+c+dc);
    }
    if(points.length>=4&&points.reduce((s,[r,c])=>s+physical[r][c],0)>=100)groups.push(points);
  }
  groups.sort((a,b)=>Math.min(...a.map(([r,c])=>r*23+c))-Math.min(...b.map(([r,c])=>r*23+c)));
  const owners=new Map<number,number>();groups.forEach((g,i)=>g.forEach(([r,c])=>owners.set(r*23+c,i)));
  const partitions=groups.map(()=>emptyMatrix());
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const adc=physical[r][c];if(adc<=0)continue;
    let owner=owners.get(r*23+c);
    if(owner===undefined){
      let best=Infinity,nearest=-1;
      groups.forEach((g,i)=>{const d=Math.min(...g.map(([sr,sc])=>(r-sr)**2+(c-sc)**2));if(d<best){best=d;nearest=i;}});
      if(best>1.5**2||nearest<0)continue;owner=nearest;
    }
    partitions[owner][r][c]=adc;
  }
  return partitions.map(matrix=>{
    const rawAdcSum=matrixSum(matrix);let sy=0,sx=0;
    for(let r=0;r<23;r++)for(let c=0;c<23;c++){sy+=r*matrix[r][c];sx+=c*matrix[r][c];}
    return {matrix,rawAdcSum,center:[sy/rawAdcSum,sx/rawAdcSum] as Point,fallback:false};
  }).filter(p=>p.rawAdcSum>0).sort((a,b)=>a.center[0]-b.center[0]||a.center[1]-b.center[1]);
}

interface Track { center:Point; filteredMatrix:Matrix; previousAdc:number; }

/** Associate IDs causally; classifier always receives the current raw contact. */
export class SeatRecognitionEstimator {
  private tracks=new Map<number,Track>();
  private nextId=1;
  private timestamp:number|null=null;
  reset():void{this.tracks.clear();this.timestamp=null;}
  update(physical:Matrix,timestampMs:number):SeatTrackedRecognitionPatch[]{
    if(!Number.isFinite(timestampMs))throw new TypeError("Finite seat timestamp required");
    if(this.timestamp!==null&&(timestampMs<=this.timestamp||timestampMs-this.timestamp>2000))this.reset();
    const patches=splitSeatRecognitionContacts(physical),pairs:[number,number,number][]=[];
    patches.forEach((p,i)=>this.tracks.forEach((t,id)=>pairs.push([Math.hypot(p.center[0]-t.center[0],p.center[1]-t.center[1]),i,id])));
    pairs.sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]);
    const assigned=new Map<number,number>(),used=new Set<number>();
    pairs.forEach(([d,i,id])=>{if(d<=2.5&&!assigned.has(i)&&!used.has(id)){assigned.set(i,id);used.add(id);}});
    const next=new Map<number,Track>();
    const out=patches.map((p,i):SeatTrackedRecognitionPatch=>{
      const matched=assigned.get(i),previous=matched===undefined?undefined:this.tracks.get(matched);
      const trackId=matched??this.nextId++;let filteredMatrix:Matrix,filterEvent:string;
      if(!previous){filteredMatrix=copy(p.matrix);filterEvent="new_contact";}
      else if(Math.hypot(p.center[0]-previous.center[0],p.center[1]-previous.center[1])>=.5){filteredMatrix=copy(p.matrix);filterEvent="position_change_bypass";}
      else if(Math.abs(p.rawAdcSum-previous.previousAdc)>=18){filteredMatrix=copy(p.matrix);filterEvent="step_bypass";}
      else {filteredMatrix=copy(p.matrix);filterEvent="current_frame_unfiltered";}
      next.set(trackId,{center:p.center,filteredMatrix,previousAdc:p.rawAdcSum});
      return {...p,trackId,filteredMatrix,filteredAdcSum:matrixSum(filteredMatrix),filterEvent};
    });
    this.tracks=next;this.timestamp=timestampMs;return out;
  }
}

export function distributeSeatRecognizedContactForces(contacts:{filteredMatrix:Matrix;nominalForceN:number}[]):Matrix{
  const map=emptyMatrix();
  for(const contact of contacts){
    validateSeatAdc(contact.filteredMatrix,23);
    if(!Number.isFinite(contact.nominalForceN)||contact.nominalForceN<0)throw new TypeError("Finite nonnegative seat nominal force required");
    const values:[number,number,number][]=[];
    for(let r=0;r<23;r++)for(let c=0;c<23;c++)if(contact.filteredMatrix[r][c]>0)values.push([r,c,contact.filteredMatrix[r][c]]);
    const total=values.reduce((s,v)=>s+v[2],0);if(!total){if(contact.nominalForceN>0)throw new TypeError("Nominal seat force requires ADC support");continue;}
    let assigned=0;
    values.forEach(([r,c,adc],i)=>{const value=i===values.length-1?Math.max(0,contact.nominalForceN-assigned):contact.nominalForceN*adc/total;map[r][c]+=value;assigned+=value;});
  }
  return map;
}

/** Use the current-frame counted area; transform native nodes into its coordinate frame. */
export function calculateSeatRecognizedPressure(physical:Matrix,cellForceMapN:Matrix,context:SeatPressureContext):BackrestRegionPressureFrame{
  validateSeatAdc(physical,23);
  if(cellForceMapN.length!==23||cellForceMapN.some(row=>row.length!==23||row.some(v=>!Number.isFinite(v)||v<0)))throw new TypeError("Native23x23 seat force contributions required");
  const {area}=context,turns=((context.rotation%4)+4)%4;
  if(!Number.isInteger(turns)||area.rows!==46||area.cols!==46||area.seeds.length!==area.regions.length)throw new TypeError("Complete aligned seat area context required");
  const adc=area.seeds.map(()=>0),forces=area.seeds.map(()=>0);let rawAdcSum=0,totalForceN=0;
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const value=physical[r][c],force=cellForceMapN[r][c];rawAdcSum+=value;totalForceN+=force;
    if(!area.seeds.length||(value===0&&force===0))continue;
    let row=2*r,col=2*c;for(let k=0;k<turns;k++){const next=col;col=45-row;row=next;}if(context.mirrorColumns)col=45-col;
    let nearest=0,best=Infinity;area.seeds.forEach(([sr,sc],i)=>{const d=(row-sr)**2+(col-sc)**2;if(d<best){nearest=i;best=d;}});
    adc[nearest]+=value;forces[nearest]+=force;
  }
  const regions=area.regions.map((region,i)=>({index:i,center:area.seeds[i],rawAdcSum:adc[i],forceShare:totalForceN>0?forces[i]/totalForceN:0,
    estimatedForceN:forces[i],areaCm2:region.areaCm2,estimatedPressureKPa:region.areaCm2>0?10*forces[i]/region.areaCm2:null}));
  const noContact=rawAdcSum===0&&totalForceN===0,complete=regions.length>0&&regions.every(r=>r.estimatedPressureKPa!==null);
  return {version:SEAT_RECOGNITION_PRESSURE_VERSION,method:"recognized_nominal_force_map_then_region_arithmetic_mean",
    status:noContact?"no_contact":complete?"estimated":"incomplete",scope:"complete_frame",independentlyValidated:false,totalForceN,
    areaCm2:area.areaCm2,rawAdcSum,assignedRawAdcSum:adc.reduce((a,b)=>a+b,0),regions,
    averagePressureKPa:!noContact&&complete?regions.reduce((s,r)=>s+r.estimatedPressureKPa!,0)/regions.length:null,
    globalAreaMeanPressureKPa:area.areaCm2>0?10*totalForceN/area.areaCm2:null};
}

const liveEstimator=new SeatRecognitionEstimator();
const liveIntervalEstimator=new IntervalLoadEstimator("seat");
let liveStream:string|null=null,lastRawTime:number|null=null,lastSampleTime:number|null=null;
let liveResults=new WeakMap<Matrix,WeakMap<Matrix,ReturnType<typeof recognizeContacts>>>();

function recognizeContacts(patches:SeatTrackedRecognitionPatch[], interval=new IntervalLoadEstimator("seat"), timestamp=0){
  const estimates=interval.update(patches.map(p=>({trackId:p.trackId,matrix:p.filteredMatrix})),timestamp);
  const contacts=patches.map((p,i)=>({...p,recognition:recognizeSeatLoad(p.filteredMatrix),interval:estimates[i]}));
  const cellForceMapN=distributeSeatRecognizedContactForces(contacts.map(c=>({filteredMatrix:c.filteredMatrix,nominalForceN:c.interval.estimatedForceN})));
  return {contacts,cellForceMapN,forceN:contacts.reduce((sum,c)=>sum+c.interval.estimatedForceN,0)};
}

export function resetLiveSeatRecognition():void{
  liveEstimator.reset();liveIntervalEstimator.reset();liveStream=null;lastRawTime=null;lastSampleTime=null;liveResults=new WeakMap();
}

export function analyzeSeatRecognitionForce(source:Matrix,physical:Matrix,context?:SeatPressureContext):ContinuousForceFrame{
  validateSeatAdc(source,46);validateSeatAdc(physical,23);
  const live=!!context&&!context.static&&typeof context.streamId==="string"&&Number.isFinite(context.timestampMs);
  let prediction:ReturnType<typeof recognizeContacts>;
  if(live){
    if(context.streamId!==liveStream){resetLiveSeatRecognition();liveStream=context.streamId!;}
    let cache=liveResults.get(source);if(!cache){cache=new WeakMap();liveResults.set(source,cache);}
    const existing=cache.get(physical);
    if(existing)prediction=existing;
    else {
      let now=context.timestampMs!;
      if(lastRawTime!==null&&now>=lastRawTime)now=Math.max(now,lastSampleTime!+.001);
      prediction=recognizeContacts(liveEstimator.update(physical,now),liveIntervalEstimator,now);cache.set(physical,prediction);
      lastRawTime=context.timestampMs!;lastSampleTime=now;
    }
  }else prediction=recognizeContacts(new SeatRecognitionEstimator().update(physical,context?.timestampMs??0));
  const pressureContext=context??{area:analyzeSeatArea(source),rotation:0};
  const contactPressure=calculateSeatRecognizedPressure(physical,prediction.cellForceMapN,pressureContext);
  const noContact=matrixSum(physical)===0;
  return {algorithmId:"seat-calibrated-interval-force-pressure-g9p8",algorithmLabel:"坐垫标定区间连续估算（g=9.8）",
    modelVersion:LOAD_INTERVAL_VERSION,status:noContact?"no_contact":"candidate_requires_validation",
    forceN:prediction.forceN,regionForcesN:contactPressure.regions.map(r=>r.estimatedForceN),
    forceAggregation:contactPressure.regions.length?"regional_sum":"total_only",
    regionCenters:pressureContext.area.seeds.map(seed=>nativeAreaSeed(seed,pressureContext)),
    forceEstimateComplete:true,seedCount:contactPressure.areaCm2>0?contactPressure.regions.length:0,
    areaCm2:contactPressure.areaCm2,seatAreaMetadata:snapshotSeatAreaMetadata(pressureContext.area),averagePressureKPa:contactPressure.averagePressureKPa,contactPressure,cellForceMapN:prediction.cellForceMapN,
    contactDetectionVersion:SEAT_RECOGNITION_CONTACT_VERSION,inputMode:"native-original-physical-adc-23x23-per-contact-current-frame",
    accepted:false,independentlyValidated:false,forceMeaning:"calibrated_interval_estimation",calculationMode:"calibrated_interval_estimation",
    loadLabel:noContact?"无接触":"各接触区在标准砝码锚点间连续估算力与压强",
    scoreMargin:prediction.contacts.length?Math.min(...prediction.contacts.map(c=>c.recognition.scoreMargin)):null,
    intervalLoadEstimation:{modelId:LOAD_INTERVAL_VERSION,gravityMS2:9.8,method:"spatial_monotone_response_pchip",contacts:prediction.contacts.map(c=>({...c.interval}))},
    seatLoadRecognition:{modelId:SEAT_LOAD_RECOGNITION.id,outputKind:"recognition_diagnostic_with_interval_force",gravityMS2:9.8,randomDisplayIncluded:false,
      contacts:prediction.contacts.map(c=>({trackId:c.trackId,center:c.center,recognizedMassKg:c.recognition.recognizedMassKg,
        nominalForceN:c.recognition.nominalForceN,scores:[...c.recognition.scores],scoreMargin:c.recognition.scoreMargin,
        uncertain:c.recognition.uncertain,filterEvent:c.filterEvent,segmentationFallback:c.fallback})),
      distribution:"per_contact_current_ADC_normalized_to_interval_estimate_then_existing_area_Voronoi"},
    scopeNote:"标准质量锚点之间按逐格ADC非线性响应、位置灵敏度与加减载曲线进行保单调PCHIP连续估算，g=9.8；六档识别只保留为诊断，不锁定输出。加减载反转通过上一测量状态连续衔接，无时间动画或随机数。各接触区估算力按原ADC支持分配，区域Pj=10Fj/Sj，平均压强沿用区域算术平均；面积与最大显示倍率保持原样。新增小砝码和独立逐格压强尚未实测标定。"};
}
