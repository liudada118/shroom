import type { IntervalLoadEstimate } from "./loadIntervalEstimator";
import type { HumanEstimationMetadata } from "./humanEstimation";
export type { HumanEstimationMetadata } from "./humanEstimation";
import type { SeatAreaSnapshotMetadata } from "./seatArea";
import type { BackrestStreamContext } from "./backrestForce";
import type { SeatForceMethod } from "./seatTotalForceFrame";
export type { SeatForceMethod } from "./seatTotalForceFrame";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";
import type { SeatPressureContext } from "./seatRegionPressure";
import { calculateEndiSeatForce, resetLiveEndiSeat, type EndiSeatDiagnostics } from "./endiSeatForce";
import { calculateEndiBackrestForce, resetLiveEndiBackrest, type EndiBackrestDiagnostics } from "./endiBackrestForce";
import type { EndiPointPressureSummary } from "./endiPointPressure";

/** Captured values are historical snapshots; optional fields retain older models. */
export interface CapturedSensorForceMetrics {
  intervalLoadEstimation?: {modelId:string;gravityMS2:number;method:"spatial_monotone_response_pchip";contacts:IntervalLoadEstimate[]};
  /** Present only for the strict current-frame over-range estimate branch. */
  humanEstimation?: HumanEstimationMetadata;
  /** Metadata copied from the same frame as areaCm2 and contactPressure. */
  seatAreaMetadata?: SeatAreaSnapshotMetadata;
  algorithmId: string;
  algorithmLabel: string;
  modelVersion: string;
  status: string;
  forceN: number;
  averagePressureKPa: number | null;
  contactPressure?: BackrestRegionPressureFrame;
  areaCm2: number;
  seedCount: number;
  regionForcesN: number[];
  /** Per-cell contributions in input coordinates; not independent local truth. */
  cellForceMapN?: number[][];
  backrestTaxelDiagnostics?: {
    gravityMS2: number;
    inputCoordinates: "canonical-25x32";
    modelSourceSha256: string;
    contactCount: number;
    invalidInputAdcSum: number;
    contacts: { direction: "up" | "down"; directionConfirmed: boolean; filterEvent: string;
      center: [number, number]; forceN: number; flags: string[] }[];
  };
  /** Six-level nominal force is explicitly distinguished from continuous regression. */
  backrestLoadRecognition?: {
    modelId: string;
    outputKind: "recognized_nominal_force" | "recognition_diagnostic_with_interval_force";
    gravityMS2: number;
    randomDisplayIncluded: false;
    contacts: { trackId: number; center: [number, number]; recognizedMassKg: number; nominalForceN: number;
      scores: number[]; scoreMargin: number; uncertain: boolean }[];
    distribution: "per_contact_filtered_ADC_normalized_to_recognized_nominal_then_existing_area_Voronoi" | "per_contact_filtered_ADC_normalized_to_interval_estimate_then_existing_area_Voronoi";
  };
  /** Seat fixed-load output is nominal recognition, never a continuous force measurement. */
  seatLoadRecognition?: {
    modelId: string;
    outputKind: "recognized_nominal_force" | "recognition_diagnostic_with_interval_force";
    gravityMS2: number;
    randomDisplayIncluded: false;
    contacts: { trackId: number; center: [number, number]; recognizedMassKg: number; nominalForceN: number;
      scores: number[]; scoreMargin: number; uncertain: boolean; filterEvent: string; segmentationFallback: boolean }[];
    distribution: "per_contact_current_ADC_normalized_to_recognized_nominal_then_existing_area_Voronoi" | "per_contact_current_ADC_normalized_to_interval_estimate_then_existing_area_Voronoi";
  };
  /** Total-only models do not supply independently calibrated regional forces. */
  forceAggregation?: "regional_sum" | "total_only";
  /** Centers in this sensor's fixed calibration coordinates, independent of display rotation. */
  regionCenters?: [number, number][];
  /** Force contact detection can change independently of the frozen ADC regression coefficients. */
  contactDetectionVersion?: string;
  /** False when the contact partition differs from the calibrated model input. */
  forceEstimateComplete?: boolean;
  calibratedSeedCount?: number;
  detectedContactCount?: number;
  detectedContactCenters?: [number, number][];
  inputMode: string;
  accepted?: boolean;
  forceMeaning?: string;
  calculationMode?: string;
  independentlyValidated?: boolean;
  loadLabel?: string;
  scoreMargin?: number | null;
  scopeNote?: string;
  /** 恩迪坐垫实测拟合算法（V2.7.97 起坐垫唯一力/面积/压强算法）的逐区诊断。 */
  endiCushion?: EndiSeatDiagnostics;
  /** 恩迪靠背实测拟合算法（V2.7.98 起靠背唯一力/面积/压强算法）的逐区诊断。 */
  endiBackrest?: EndiBackrestDiagnostics;
  /** V2.7.99：恩迪逐格压强摘要（Pᵢ = P_区 × ADCᵢ / median(ADC_区)）；逐格矩阵见 endiPointPressureMatrix() */
  pointPressure?: EndiPointPressureSummary;
}

export interface ContinuousForceFrame extends CapturedSensorForceMetrics {
  accepted: false;
  forceMeaning: "continuous_adc_regression" | "fixed_load_recognition" | "calibrated_interval_estimation" | "endi_cushion_fitted" | "endi_backrest_fitted";
  calculationMode: "continuous_adc_regression" | "fixed_load_recognition" | "calibrated_interval_estimation" | "endi_cushion_fitted" | "endi_backrest_fitted";
  scopeNote: string;
}

/** 靠背：清空恩迪靠背算法的实时会话状态。 */
export function resetLiveBackrestForce(): void {
  resetLiveEndiBackrest();
}

/** 坐垫：清空恩迪坐垫算法的实时会话状态。 */
export function resetLiveSeatForce(): void {
  resetLiveEndiSeat();
}

/**
 * Full, uncompensated native ADC only. Display rotation and selection are excluded.
 * 坐垫（endi-23x23）自 V2.7.97 起只使用恩迪坐垫实测拟合算法：输入原生物理 ADC，
 * 面积、总力、各区压强与平均压强均由该算法给出；fullFrameAreaCm2 与 seatForceMethod 对坐垫不再生效。
 * 靠背（new-backrest-32x25）自 V2.7.98 起只使用恩迪靠背实测拟合算法：输入原生 32×25 物理 ADC（转置后进入算法），
 * 面积、总力、各区压强与平均压强均由该算法给出；fullFrameAreaCm2 与 backrestStreamContext.method 对靠背不再生效。
 */
export function calculateLiveSensorForce(
  sensorType: string,
  source?: number[][] | null,
  physical?: number[][] | null,
  fullFrameAreaCm2?: number | null,
  seatPressureContext?: SeatPressureContext,
  _seatForceMethod: SeatForceMethod = "fixed_load_recognition",
  backrestStreamContext?: BackrestStreamContext,
): ContinuousForceFrame | null {
  if (sensorType === "endi-23x23") {
    const context = backrestStreamContext ?? seatPressureContext;
    try {
      return calculateEndiSeatForce(physical, context ? { timestampMs: context.timestampMs, streamId: context.streamId, static: context.static } : undefined);
    } catch {
      return null;
    }
  }
  if (sensorType === "new-backrest-32x25") {
    const context = backrestStreamContext;
    try {
      return calculateEndiBackrestForce(physical, context ? { timestampMs: context.timestampMs, streamId: context.streamId, static: context.static } : undefined);
    } catch {
      return null;
    }
  }
  return null;
}
