/**
 * V2.7.66 可配置逐帧ADC补偿模块。
 * 设计原则：坐垫/靠背配置独立；补偿参数可启停与编辑；补偿后固定执行ADC≤30过滤；
 * 所有函数均非破坏性，显示、标定、采集和导出共用同一补偿后矩阵。
 */

export const ADC_COMPENSATION_VERSION = "ConfigurableAffine-20260903" as const;
export const LEGACY_ADC_COMPENSATION_VERSION = "SeatFixedAffine-20260901" as const;
export const ADC_COMPENSATION_STORAGE_KEY = "pressure-sensor-adc-compensation-v2766" as const;
export const ADC_POST_COMPENSATION_FILTER_THRESHOLD = 30;
export const MIN_ADC_COMPENSATION_SCALE = 0.001;
export const MAX_ADC_COMPENSATION_SCALE = 10;
export const MIN_ADC_COMPENSATION_OFFSET = -1000;
export const MAX_ADC_COMPENSATION_OFFSET = 1000;

export interface AdcCompensationProfile {
  sensor: "seat" | "backrest";
  enabled: boolean;
  scale: number;
  offset: number;
  source: string;
}

export interface AdcCompensationSettings {
  version: typeof ADC_COMPENSATION_VERSION;
  seat: AdcCompensationProfile;
  backrest: AdcCompensationProfile;
}

export interface AdcMatrixStats {
  max: number;
  min: number;
  avg: number;
  nonZeroMin: number;
  sum: number;
  nonZeroCount: number;
}

export const DEFAULT_SEAT_ADC_COMPENSATION: AdcCompensationProfile = {
  sensor: "seat",
  enabled: true,
  scale: 1.0069947916666666,
  offset: 6.018421875000001,
  source: "《ADC补偿结果.json》sensor_id=file1；manual_override=true",
};

export const DEFAULT_BACKREST_ADC_COMPENSATION: AdcCompensationProfile = {
  sensor: "backrest",
  enabled: false,
  scale: 1,
  offset: 0,
  source: "默认恒等补偿；可由用户单独启用并编辑",
};

export const DEFAULT_ADC_COMPENSATION_SETTINGS: AdcCompensationSettings = {
  version: ADC_COMPENSATION_VERSION,
  seat: DEFAULT_SEAT_ADC_COMPENSATION,
  backrest: DEFAULT_BACKREST_ADC_COMPENSATION,
};

function cloneProfile(profile: AdcCompensationProfile): AdcCompensationProfile {
  return { ...profile };
}

export function createDefaultAdcCompensationSettings(): AdcCompensationSettings {
  return {
    version: ADC_COMPENSATION_VERSION,
    seat: cloneProfile(DEFAULT_SEAT_ADC_COMPENSATION),
    backrest: cloneProfile(DEFAULT_BACKREST_ADC_COMPENSATION),
  };
}

export function isBackrestSensorType(sensorType?: string): boolean {
  return sensorType === "backrest"
    || sensorType === "backrest-32x25"
    || sensorType === "new-backrest-32x25";
}

function finiteOrDefault(value: unknown, fallback: number): number {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

export function normalizeAdcCompensationProfile(
  profile: Partial<AdcCompensationProfile> | null | undefined,
  fallback: AdcCompensationProfile,
): AdcCompensationProfile {
  const scale = Math.min(
    MAX_ADC_COMPENSATION_SCALE,
    Math.max(MIN_ADC_COMPENSATION_SCALE, finiteOrDefault(profile?.scale, fallback.scale)),
  );
  const offset = Math.min(
    MAX_ADC_COMPENSATION_OFFSET,
    Math.max(MIN_ADC_COMPENSATION_OFFSET, finiteOrDefault(profile?.offset, fallback.offset)),
  );
  return {
    sensor: fallback.sensor,
    enabled: typeof profile?.enabled === "boolean" ? profile.enabled : fallback.enabled,
    scale,
    offset,
    source: typeof profile?.source === "string" && profile.source.trim()
      ? profile.source.trim()
      : fallback.source,
  };
}

export function normalizeAdcCompensationSettings(
  settings: Partial<AdcCompensationSettings> | null | undefined,
): AdcCompensationSettings {
  return {
    version: ADC_COMPENSATION_VERSION,
    seat: normalizeAdcCompensationProfile(settings?.seat, DEFAULT_SEAT_ADC_COMPENSATION),
    backrest: normalizeAdcCompensationProfile(settings?.backrest, DEFAULT_BACKREST_ADC_COMPENSATION),
  };
}

export function loadAdcCompensationSettings(): AdcCompensationSettings {
  if (typeof window === "undefined") return createDefaultAdcCompensationSettings();
  try {
    const raw = window.localStorage.getItem(ADC_COMPENSATION_STORAGE_KEY);
    if (!raw) return createDefaultAdcCompensationSettings();
    return normalizeAdcCompensationSettings(JSON.parse(raw));
  } catch {
    return createDefaultAdcCompensationSettings();
  }
}

export function saveAdcCompensationSettings(settings: AdcCompensationSettings): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(
    ADC_COMPENSATION_STORAGE_KEY,
    JSON.stringify(normalizeAdcCompensationSettings(settings)),
  );
}

export function getAdcCompensationProfile(
  sensorType?: string,
  settings: AdcCompensationSettings = DEFAULT_ADC_COMPENSATION_SETTINGS,
): AdcCompensationProfile {
  const normalized = normalizeAdcCompensationSettings(settings);
  return isBackrestSensorType(sensorType) ? normalized.backrest : normalized.seat;
}

export function getAdcCompensationFormula(profile: AdcCompensationProfile): string {
  return profile.enabled
    ? `ADC'= ${profile.scale.toFixed(9)} × ADC ${profile.offset < 0 ? "-" : "+"} ${Math.abs(profile.offset).toFixed(9)}`
    : "ADC'=ADC（补偿关闭）";
}

export function getAdcCompensationFingerprint(settings: AdcCompensationSettings): string {
  const normalized = normalizeAdcCompensationSettings(settings);
  const encode = (profile: AdcCompensationProfile) => [
    profile.enabled ? "1" : "0",
    profile.scale.toPrecision(12),
    profile.offset.toPrecision(12),
  ].join(":");
  return `${ADC_COMPENSATION_VERSION}|seat=${encode(normalized.seat)}|backrest=${encode(normalized.backrest)}`;
}

/** 识别V2.7.64起任何已经补偿过的缓存帧，避免升级后重复补偿。 */
export function hasAdcCompensationMarker(version?: string | null): boolean {
  return typeof version === "string" && version.trim().length > 0;
}

/** 仅执行一次函数补偿，不过滤。 */
export function compensateAdcValueWithoutFilter(
  rawAdc: number,
  sensorType?: string,
  settings: AdcCompensationSettings = DEFAULT_ADC_COMPENSATION_SETTINGS,
): number {
  if (!Number.isFinite(rawAdc) || rawAdc <= 0) return 0;
  const profile = getAdcCompensationProfile(sensorType, settings);
  return profile.enabled ? profile.scale * rawAdc + profile.offset : rawAdc;
}

/** 单点完整预处理：先按当前模块配置补偿，再将补偿后ADC≤30过滤为0。 */
export function compensateAndFilterAdcValue(
  rawAdc: number,
  sensorType?: string,
  settings: AdcCompensationSettings = DEFAULT_ADC_COMPENSATION_SETTINGS,
): number {
  const corrected = compensateAdcValueWithoutFilter(rawAdc, sensorType, settings);
  return corrected > ADC_POST_COMPENSATION_FILTER_THRESHOLD ? corrected : 0;
}

/** 非破坏性逐点补偿与固定30过滤，返回与输入同形的新矩阵。 */
export function compensateAndFilterAdcMatrix(
  matrix: ReadonlyArray<ReadonlyArray<number>>,
  sensorType?: string,
  settings: AdcCompensationSettings = DEFAULT_ADC_COMPENSATION_SETTINGS,
): number[][] {
  // 配置在整帧内固定，归一化一次，避免每个采样点重复创建整套配置对象。
  const profile = getAdcCompensationProfile(sensorType, settings);
  return matrix.map((row) => row.map((value) => {
    if (!Number.isFinite(value) || value <= 0) return 0;
    const corrected = profile.enabled ? profile.scale * value + profile.offset : value;
    return corrected > ADC_POST_COMPENSATION_FILTER_THRESHOLD ? corrected : 0;
  }));
}

/** 从补偿并过滤后的矩阵重算FrameData统计字段。 */
export function summarizeAdcMatrix(matrix: ReadonlyArray<ReadonlyArray<number>>): AdcMatrixStats {
  let max = 0;
  let min = Number.POSITIVE_INFINITY;
  let sum = 0;
  let nonZeroMin = Number.POSITIVE_INFINITY;
  let nonZeroCount = 0;
  let total = 0;

  for (const row of matrix) {
    for (const value of row) {
      total++;
      if (value > max) max = value;
      if (value < min) min = value;
      sum += value;
      if (value > 0) {
        nonZeroCount++;
        if (value < nonZeroMin) nonZeroMin = value;
      }
    }
  }

  if (!Number.isFinite(min)) min = 0;
  if (!Number.isFinite(nonZeroMin)) nonZeroMin = 0;
  return {
    max,
    min,
    avg: total > 0 ? Math.round((sum / total) * 100) / 100 : 0,
    nonZeroMin,
    sum,
    nonZeroCount,
  };
}

export function getAdcCompensationDisplayNote(
  sensorType?: string,
  settings: AdcCompensationSettings = DEFAULT_ADC_COMPENSATION_SETTINGS,
): string {
  const profile = getAdcCompensationProfile(sensorType, settings);
  return `ADC补偿模块${profile.enabled ? "已开启" : "已关闭"}：${getAdcCompensationFormula(profile)}；补偿后ADC≤${ADC_POST_COMPENSATION_FILTER_THRESHOLD}过滤为0；显示与压强标定共用同一矩阵。`;
}
