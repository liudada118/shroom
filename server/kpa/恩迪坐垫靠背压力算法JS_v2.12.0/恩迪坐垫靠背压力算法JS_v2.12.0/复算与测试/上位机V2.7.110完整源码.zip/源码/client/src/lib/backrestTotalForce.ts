import { backrestTotalForceModel } from "./backrestTotalForce.generated";

export const backrestTotalForceModelVersion = backrestTotalForceModel.version;
export const BACKREST_FORCE_FEATURE_NAMES = backrestTotalForceModel.feature_names;

/** Original physical ADC in fixed calibration coordinates; never a display matrix. */
export function validateBackrestAdc(matrix: number[][], rows: number, cols: number, name: string): void {
  if (!Array.isArray(matrix) || matrix.length !== rows || matrix.some(row =>
    !Array.isArray(row) || row.length !== cols || row.some(v =>
      typeof v !== "number" || !Number.isFinite(v) || v < 0 || v > 255))) {
    throw new TypeError(`${name} must have shape ${rows}×${cols} and finite ADC 0..255`);
  }
}

// Python 3.12's float sum uses compensated addition. Naive JS addition can cross a
// tree boundary by one floating-point bit, so keep the reference arithmetic here.
function sum(values: number[]): number {
  let high = 0, low = 0;
  for (const value of values) {
    const next = high + value;
    low += Math.abs(high) >= Math.abs(value) ? (high-next)+value : (value-next)+high;
    high = next;
  }
  return high+low;
}

/** Matches force_algorithm.py, including compensated sums and natural-log entropy. */
export function extractBackrestForceFeatures(physical: number[][]): number[] {
  validateBackrestAdc(physical, 25, 32, "Physical");
  const flat = physical.flat(), total = sum(flat);
  if (total === 0) return Array(12).fill(0);
  const rowSums = physical.map(sum);
  // 740 is an empirical feature parameter from this fit, not a measured circuit constant.
  const h = physical.map((row, r) => row.map(v => v / Math.max(backrestTotalForceModel.row_budget-rowSums[r], 10)));
  const sortedH = h.flat().sort((a, b) => b-a);
  const cy = sum(rowSums.map((v, r) => r*v))/total;
  const cx = sum(physical.flatMap(row => row.map((v, c) => c*v)))/total;
  const varianceY: number[] = [], varianceX: number[] = [], entropy: number[] = [];
  for (let r = 0; r < 25; r++) for (let c = 0; c < 32; c++) {
    const v = physical[r][c];
    varianceY.push(v*(r-cy)**2);
    varianceX.push(v*(c-cx)**2);
    if (v > 0) entropy.push((v/total)*Math.log(v/total));
  }
  const correctedColumns = Array.from({ length: 32 }, (_, c) => sum(h.map(row => row[c])));
  return [sum(sortedH), sum(sortedH.map(v => v*v)), sum(sortedH.slice(0,16))/16,
    cy, cx, Math.sqrt(sum(varianceY)/total), Math.sqrt(sum(varianceX)/total), -sum(entropy), total*total/sum(flat.map(v => v*v)),
    sum([...rowSums].sort((a,b) => b-a).slice(0,4)),
    sum(correctedColumns.sort((a,b) => b-a).slice(0,4)), sum(sortedH.slice(0,32))/32];
}

/** Total force only; the exported leaf values already include the learning rate. */
export function predictBackrestTotalForce(physical: number[][]): number {
  const features = extractBackrestForceFeatures(physical);
  if (features[0] === 0) return 0;
  let force = backrestTotalForceModel.baseline_N;
  for (const tree of backrestTotalForceModel.trees) {
    let index = 0;
    while (true) {
      const [feature, thresholdOrValue, left, right] = tree[index];
      if (feature < 0) { force += thresholdOrValue; break; }
      // Browser log/sqrt and Python libm can differ at the last floating-point bit.
      // Treat only machine-precision boundary ties as <=, consistently across runtimes.
      const boundaryTolerance = 4*Number.EPSILON*Math.max(1, Math.abs(thresholdOrValue));
      index = features[feature] <= thresholdOrValue+boundaryTolerance ? left : right;
    }
  }
  return Math.max(0, force);
}
