/**
 * CSV 解析工具
 * 解析传感器数据CSV文件
 */

export interface CsvFrame {
  index: number;
  relativeTime: number;
  frameNumber: number;
  absoluteTime: string;
  maxValue: number;
  sum: number;
  matrix: number[][];
  rawData: number[];
}

export interface CsvParseResult {
  frames: CsvFrame[];
  totalFrames: number;
  timeRange: { min: number; max: number };
  valueRange: { min: number; max: number };
  error?: string;
}

/**
 * 解析CSV中的一行（处理引号内的逗号）
 */
function parseCsvRow(row: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  let bracketDepth = 0;

  for (let i = 0; i < row.length; i++) {
    const ch = row[i];
    if (ch === '"' && bracketDepth === 0) {
      inQuotes = !inQuotes;
    } else if (ch === "[") {
      bracketDepth++;
      current += ch;
    } else if (ch === "]") {
      bracketDepth--;
      current += ch;
    } else if (ch === "," && !inQuotes && bracketDepth === 0) {
      result.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * 解析CSV文件内容
 */
export function parseCsvContent(content: string): CsvParseResult {
  const lines = content.trim().split("\n");

  if (lines.length < 2) {
    return {
      frames: [],
      totalFrames: 0,
      timeRange: { min: 0, max: 0 },
      valueRange: { min: 0, max: 0 },
      error: "CSV file is empty or has no data rows",
    };
  }

  const frames: CsvFrame[] = [];
  let minTime = Infinity;
  let maxTime = -Infinity;
  let minValue = Infinity;
  let maxValue = -Infinity;

  // 检测是否有标题行
  const headerOffset = lines[0].includes("时间") || lines[0].includes("Time") ? 1 : 0;

  for (let i = headerOffset; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    try {
      const cols = parseCsvRow(line);
      if (cols.length < 6) {
        console.warn(`Row ${i + 1}: Insufficient columns (${cols.length})`);
        continue;
      }

      const relativeTime = parseFloat(cols[0]);
      const frameNumber = parseInt(cols[1], 10);
      const absoluteTime = cols[2];
      const maxVal = parseInt(cols[3], 10);
      const sum = parseInt(cols[4], 10);
      const matrixStr = cols[5];

      let rawData: number[];
      try {
        rawData = JSON.parse(matrixStr);
      } catch {
        console.warn(`Row ${i + 1}: Failed to parse matrix JSON`);
        continue;
      }

      // 自动推断矩阵尺寸：支持 23x23(529), 32x25(800), 32x32(1024), 64x64(4096) 等
      const len = rawData.length;
      let mRows: number, mCols: number;
      if (len === 529) {
        mRows = 23; mCols = 23;
      } else if (len === 800) {
        mRows = 32; mCols = 25;
      } else if (len === 1024) {
        mRows = 32; mCols = 32;
      } else if (len === 4096) {
        mRows = 64; mCols = 64;
      } else {
        const side = Math.round(Math.sqrt(len));
        if (side * side === len) {
          mRows = side; mCols = side;
        } else {
          console.warn(`Row ${i + 1}: Matrix has ${len} elements, cannot determine dimensions`);
          continue;
        }
      }
      const matrix: number[][] = [];
      for (let r = 0; r < mRows; r++) {
        const row: number[] = [];
        for (let c = 0; c < mCols; c++) {
          const idx = r * mCols + c;
          row.push(idx < len ? rawData[idx] : 0);
        }
        matrix.push(row);
      }

      for (const val of rawData) {
        if (val < minValue) minValue = val;
        if (val > maxValue) maxValue = val;
      }

      minTime = Math.min(minTime, relativeTime);
      maxTime = Math.max(maxTime, relativeTime);

      frames.push({
        index: i - headerOffset,
        relativeTime,
        frameNumber,
        absoluteTime,
        maxValue: maxVal,
        sum,
        matrix,
        rawData,
      });
    } catch (err) {
      console.warn(`Row ${i + 1}: Parse error`, err);
    }
  }

  return {
    frames,
    totalFrames: frames.length,
    timeRange: { min: minTime === Infinity ? 0 : minTime, max: maxTime === -Infinity ? 0 : maxTime },
    valueRange: { min: minValue === Infinity ? 0 : minValue, max: maxValue === -Infinity ? 0 : maxValue },
  };
}
