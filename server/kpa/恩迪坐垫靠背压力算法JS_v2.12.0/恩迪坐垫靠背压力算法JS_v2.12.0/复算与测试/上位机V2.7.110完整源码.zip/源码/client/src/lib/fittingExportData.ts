/** Raw data and metadata allowed in fitting exports. No derived model values. */
export type FittingCell = string | number | boolean;

export interface FittingExportFrame {
  id: number;
  captureKind?: "standard" | "continuous";
  continuousSequence?: number;
  capturedAt: Date;
  sensorType: string;
  data: {
    raw?: number[];
    physical?: number[][];
    sourceMatrix?: number[][];
    timestamp?: number;
  };
  captureConfig?: {
    matrixRotation?: number;
    matrixRowOrder?: string;
    matrixColumnOrder?: string;
  };
}

/** Legacy options remain accepted by the export callers, but are not exported. */
export interface FittingExportConfig {
  name: string;
  rows?: number;
  cols?: number;
  matrixSize?: number;
  totalPoints?: number;
  filterThreshold?: number;
  resultScale?: number;
  exportedAt?: Date | string;
}

export const FITTING_LABEL_HEADERS = [
  "实际总质量（kg）", "砝码数量", "单块砝码质量（kg）", "摆放方式（叠放/平铺）",
  "接触底面数量", "接触底面直径（cm）", "参考接触面积（cm²）", "放置位置",
  "操作阶段（加载/卸载/重新放置）", "采集状态（稳定/移动/异常）", "备注",
] as const;

export const FITTING_METADATA_HEADERS = [
  "帧序号", "采集类型", "连续帧序号", "采集时间（ISO）", "采集时间戳（ms）", "数据源帧时间戳（ms）",
  "传感器型号", "传感器名称", "矩阵旋转（四分之一圈）", "矩阵行序", "矩阵列序",
  "原始字节长度", "原始物理矩阵尺寸", "补偿前插值矩阵尺寸", "原始数据完整性",
  ...FITTING_LABEL_HEADERS,
] as const;

export function fittingMatrixSize(matrix?: readonly (readonly number[])[]): string {
  return matrix?.length ? `${matrix.length}×${matrix[0]?.length ?? 0}` : "未保存";
}

export function fittingSensorName(sensorType: string): string {
  if (sensorType === "endi-23x23") return "坐垫（恩迪23×23）";
  if (["new-backrest-32x25", "backrest-32x25", "backrest"].includes(sensorType)) return "靠背（32×25）";
  return sensorType;
}

/** Sort a new array. Each internal id identifies one captured frame. */
export function collectFittingFrames(
  standard: readonly FittingExportFrame[], continuous: readonly FittingExportFrame[] = [],
): FittingExportFrame[] {
  const frames = [...standard, ...continuous].sort((a, b) => a.id - b.id);
  const seen = new Set<number>();
  return frames.filter(frame => {
    if (seen.has(frame.id)) return false;
    seen.add(frame.id);
    return true;
  });
}

export function fittingMetadataRow(frame: FittingExportFrame): FittingCell[] {
  const validDate = Number.isFinite(frame.capturedAt.getTime());
  const missing = [
    !frame.data.raw?.length ? "原始字节未保存" : "",
    !frame.data.physical?.length ? "原始物理矩阵未保存" : "",
    !frame.data.sourceMatrix?.length ? "补偿前插值矩阵未保存" : "",
  ].filter(Boolean);
  return [
    frame.id, frame.captureKind ?? (frame.continuousSequence === undefined ? "standard" : "continuous"),
    frame.continuousSequence ?? "", validDate ? frame.capturedAt.toISOString() : "未保存",
    validDate ? frame.capturedAt.getTime() : "",
    Number.isFinite(frame.data.timestamp) ? frame.data.timestamp! : "",
    frame.sensorType, fittingSensorName(frame.sensorType), frame.captureConfig?.matrixRotation ?? "未保存",
    frame.captureConfig?.matrixRowOrder ?? "历史保存行序", frame.captureConfig?.matrixColumnOrder ?? "历史保存列序",
    frame.data.raw?.length ?? 0, fittingMatrixSize(frame.data.physical), fittingMatrixSize(frame.data.sourceMatrix),
    missing.length ? missing.join("；") : "完整", ...FITTING_LABEL_HEADERS.map(() => ""),
  ];
}
