/** Continuous local ADC templates plus continuous log-force residual.
 * Each call receives exactly one contact's features. The caller sums contacts.
 * No load class is selected or rounded at inference.
 */
import model from './backrestForceTemplateModel.generated';

export const backrestTemplateModelVersion = model.version;
export const backrestTemplateCropRadiusCm = model.baseModel.cropRadiusCm;

export function predictBackrestTemplateContact(features: number[]): number {
  if (features.length !== 38 || features.some(value => !Number.isFinite(value))) {
    throw new TypeError('Expected 38 finite local ADC features.');
  }
  const base = model.baseModel, residual = model.residualModel, config = base.config;
  const standardized = features.map((value, index) => (value - base.scalerMean[index]) / base.scalerScale[index]);
  const distances = base.trainingFeatures.map((template, index) => {
    let distance = 0;
    for (let j = 0; j < standardized.length; j++) distance += (standardized[j] - template[j]) ** 2;
    return {index, distance};
  });
  distances.sort((a, b) => a.distance - b.distance || a.index - b.index);
  const neighbors = distances.slice(0, Math.min(config.neighbors, distances.length - 1));
  const minimumDistance = neighbors[0].distance;
  let totalWeight = 0, logBase = 0;
  for (const neighbor of neighbors) {
    const weight = Math.exp(-(neighbor.distance - minimumDistance) / config.temperature);
    const knownForceN = base.trainingForcesN[neighbor.index];
    let correction = 0;
    if (config.affineGain) {
      const levels = [16.25, 32.5, 48.75, 65, 81.25, 97.5, 165];
      let level = 0;
      for (let j = 1; j < levels.length; j++) {
        if (Math.abs(knownForceN - levels[j]) < Math.abs(knownForceN - levels[level])) level = j;
      }
      const responseIndex = base.responseFeatureIndex;
      // trainingFeatures are standardized; restore the raw compact ADC units.
      const response = base.trainingFeatures[neighbor.index][responseIndex] * base.scalerScale[responseIndex] + base.scalerMean[responseIndex];
      correction = config.affineGain * base.templateResponseSlopes[level] * (features[responseIndex] - response);
    }
    logBase += weight * (Math.log(knownForceN) + correction);
    totalWeight += weight;
  }
  logBase /= totalWeight;
  const standardizedResidual = features.map((value, index) => (value - residual.scalerMean[index]) / residual.scalerScale[index]);
  let correction = 0;
  for (let i = 0; i < residual.trainingFeatures.length; i++) {
    let distance = 0;
    for (let j = 0; j < standardizedResidual.length; j++) distance += (standardizedResidual[j] - residual.trainingFeatures[i][j]) ** 2;
    correction += Math.exp(-residual.gamma * distance) * residual.dualCoefficients[i];
  }
  const forceN = Math.exp(logBase + correction);
  if (!Number.isFinite(forceN)) throw new RangeError('ADC force regression is not finite.');
  return forceN;
}
