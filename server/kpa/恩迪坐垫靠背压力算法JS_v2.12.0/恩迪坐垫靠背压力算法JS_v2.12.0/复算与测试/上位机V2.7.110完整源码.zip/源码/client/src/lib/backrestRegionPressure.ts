import { analyzeBackrestArea, type BackrestAreaFrame } from "./backrestArea";

export const BACKREST_REGION_PRESSURE_VERSION = "backrest-raw-adc-share-region-pressure-mean-20261028";

export interface BackrestRegionPressure {
  index: number;
  center: [number, number];
  rawAdcSum: number;
  forceShare: number;
  estimatedForceN: number;
  areaCm2: number;
  estimatedPressureKPa: number | null;
}

export interface BackrestRegionPressureFrame {
  version: typeof BACKREST_REGION_PRESSURE_VERSION | "seat-raw-adc-share-region-pressure-mean-20261028" | "backrest-cell-force-sum-region-pressure-mean-g9p8-20261029" | "backrest-recognized-nominal-force-region-pressure-mean-g9p8-20261030" | "seat-recognized-nominal-force-region-pressure-mean-g9p8-20261030" | "endi-cushion-region-pressure-mean-g9p8-20261109" | "endi-backrest-region-pressure-mean-g9p8-20261109";
  method: "raw_adc_share_then_region_arithmetic_mean" | "per_cell_force_sum_then_region_arithmetic_mean" | "recognized_nominal_force_map_then_region_arithmetic_mean" | "endi_region_force_over_region_area_then_arithmetic_mean";
  status: "estimated" | "no_contact" | "incomplete";
  scope: "complete_frame";
  independentlyValidated: false;
  totalForceN: number;
  areaCm2: number;
  rawAdcSum: number;
  assignedRawAdcSum: number;
  regions: BackrestRegionPressure[];
  averagePressureKPa: number | null;
  /** Prior global quotient retained for comparison, never used as the region mean. */
  globalAreaMeanPressureKPa: number | null;
}

/** Reuse the original area's seeds and retained counts; do not refit any area. */
export function calculateBackrestRegionPressure(
  source: number[][],
  physical: number[][],
  totalForceN: number,
  area: BackrestAreaFrame = analyzeBackrestArea(source),
): BackrestRegionPressureFrame {
  if (!Number.isFinite(totalForceN) || totalForceN < 0) throw new TypeError("Finite nonnegative total force required");
  const rows = physical.length, cols = physical[0]?.length;
  if (!((rows === 25 && cols === 32) || (rows === 32 && cols === 25)) ||
      source.length !== rows*2 || source[0]?.length !== cols*2 ||
      physical.some(row => row.length !== cols || row.some(v => !Number.isFinite(v) || v < 0 || v > 255)) ||
      area.rows !== rows*2 || area.cols !== cols*2) throw new TypeError("Aligned original backrest ADC and area required");
  const adcSums = area.seeds.map(() => 0);
  let rawAdcSum = 0;
  // Partition original physical nodes by the same nearest-seed rule as the area.
  // All original ADC values count, including values below display thresholds.
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const value = physical[r][c]; rawAdcSum += value;
    if (value <= 0 || !area.seeds.length) continue;
    let nearest = 0, best = Infinity;
    area.seeds.forEach(([sr, sc], i) => {
      const distance = (2*r-sr)**2+(2*c-sc)**2;
      if (distance < best) { best = distance; nearest = i; }
    });
    adcSums[nearest] += value;
  }
  const assignedRawAdcSum = adcSums.reduce((s, v) => s+v, 0);
  const regions = area.regions.map((region, i): BackrestRegionPressure => {
    const forceShare = assignedRawAdcSum > 0 ? adcSums[i]/assignedRawAdcSum : 0;
    const estimatedForceN = totalForceN*forceShare;
    const areaCm2 = region.retainedCellCount; // Existing 1 cm² retained cells.
    return { index: i, center: [region.seedRow, region.seedCol], rawAdcSum: adcSums[i], forceShare,
      estimatedForceN, areaCm2, estimatedPressureKPa: areaCm2 > 0 && adcSums[i] > 0 ? 10*estimatedForceN/areaCm2 : null };
  });
  const noContact = rawAdcSum === 0 && totalForceN === 0;
  const complete = regions.length > 0 && assignedRawAdcSum > 0 &&
    regions.every(region => region.estimatedPressureKPa !== null);
  return {
    version: BACKREST_REGION_PRESSURE_VERSION, method: "raw_adc_share_then_region_arithmetic_mean",
    status: noContact ? "no_contact" : complete ? "estimated" : "incomplete", scope: "complete_frame",
    independentlyValidated: false, totalForceN, areaCm2: area.areaCm2, rawAdcSum, assignedRawAdcSum, regions,
    averagePressureKPa: !noContact && complete
      ? regions.reduce((s, region) => s+region.estimatedPressureKPa!, 0)/regions.length : null,
    globalAreaMeanPressureKPa: area.areaCm2 > 0 ? 10*totalForceN/area.areaCm2 : null,
  };
}

/** Use the same proportions/areas for the total-force display filter's snapshot. */
export function rescaleBackrestRegionPressure(frame: BackrestRegionPressureFrame, totalForceN: number, regionForcesN?: number[]): BackrestRegionPressureFrame {
  if ((frame.method === "per_cell_force_sum_then_region_arithmetic_mean" || frame.method === "recognized_nominal_force_map_then_region_arithmetic_mean") && regionForcesN) {
    if (regionForcesN.length !== frame.regions.length || regionForcesN.some(v => !Number.isFinite(v) || v < 0)) {
      throw new TypeError("Matching nonnegative cell-derived region forces required");
    }
    const regions = frame.regions.map((region, i) => ({ ...region, center: [...region.center] as [number, number],
      estimatedForceN: regionForcesN[i], forceShare: totalForceN > 0 ? regionForcesN[i] / totalForceN : 0,
      estimatedPressureKPa: region.estimatedPressureKPa === null ? null : 10 * regionForcesN[i] / region.areaCm2 }));
    return { ...frame, totalForceN, regions,
      averagePressureKPa: frame.status === "estimated" ? regions.reduce((sum, region) => sum + region.estimatedPressureKPa!, 0) / regions.length : null,
      globalAreaMeanPressureKPa: frame.areaCm2 > 0 ? 10 * totalForceN / frame.areaCm2 : null };
  }
  const regions = frame.regions.map(region => ({ ...region, center: [...region.center] as [number, number],
    estimatedForceN: totalForceN*region.forceShare,
    estimatedPressureKPa: region.estimatedPressureKPa === null ? null : 10*totalForceN*region.forceShare/region.areaCm2 }));
  return { ...frame, totalForceN, regions,
    averagePressureKPa: frame.status === "estimated" ? regions.reduce((s, region) => s+region.estimatedPressureKPa!, 0)/regions.length : null,
    globalAreaMeanPressureKPa: frame.areaCm2 > 0 ? 10*totalForceN/frame.areaCm2 : null };
}

/** Historical captures without this metadata keep their saved interpretation. */
export function capturedAveragePressureKPa(frame: { forceMetrics?: { contactPressure?: BackrestRegionPressureFrame }; avgPressureKPa?: number | null }, legacy: number | null): number | null {
  const pressure = frame.forceMetrics?.contactPressure;
  return pressure ? (pressure.averagePressureKPa === null ? null : Number(pressure.averagePressureKPa.toFixed(2))) : legacy ?? frame.avgPressureKPa ?? null;
}

export const REGION_PRESSURE_EXPORT_HEADERS = [
  "接触区压强算法版本", "接触区压强状态", "接触区压强范围", "区域力分配方法",
  "各区原始ADC总和", "各区总力占比", "各区估算力（N）", "各区原面积（cm²）",
  "各区估算压强（kPa）", "各区压强算术平均（kPa）", "总力除总面积（对照，kPa）", "区域压强独立验收",
];
export function regionPressureExportValues(frame?: BackrestRegionPressureFrame): (string | number)[] {
  if (!frame) return REGION_PRESSURE_EXPORT_HEADERS.map(() => "--");
  const perCell = frame.method === "per_cell_force_sum_then_region_arithmetic_mean";
  const recognized = frame.method === "recognized_nominal_force_map_then_region_arithmetic_mean";
  return [frame.version, frame.status, "全帧完整接触区", recognized ? "接触区识别名义力，按各接触区ADC分布映射至原面积区域" : perCell ? "逐单元ADC曲线求力后按区域求和" : "原始物理ADC总和占比",
    frame.regions.map(r => r.rawAdcSum).join(";"), frame.regions.map(r => r.forceShare).join(";"),
    frame.regions.map(r => r.estimatedForceN).join(";"), frame.regions.map(r => r.areaCm2).join(";"),
    frame.regions.map(r => r.estimatedPressureKPa ?? "--").join(";"), frame.averagePressureKPa ?? "--",
    frame.globalAreaMeanPressureKPa ?? "--", recognized ? "未通过独立验收（六档识别名义力推算，存在错档）" : perCell ? "未通过独立标定验收（逐格力估算）" : "未通过独立标定验收（ADC比例估算）"];
}
