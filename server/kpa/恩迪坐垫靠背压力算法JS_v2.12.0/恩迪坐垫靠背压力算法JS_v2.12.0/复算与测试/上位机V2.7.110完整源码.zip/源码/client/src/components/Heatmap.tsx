/**
 * 热力图组件
 * 使用 Canvas 渲染矩阵压力数据
 * 
 * 功能：
 * - inferno色谱渲染
 * - 数值叠加
 * - 鼠标悬停十字准线
 * - 支持非正方形矩阵（如32×25）
 * - 锁定点位可视化（非锁定点位半透明遮罩）
 * - 手动框选锁定区域
 * - 框选统计模式：拖拽选择区域，实时统计选区内数据
 * - V2.7.109 放大镜：跟随鼠标显示 N×N 格放大窗口（格内完整数值），主图上用青色框标出放大范围
 */

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { valueToColor } from "@/lib/colorMap";
import { heatmapCellIndex, heatmapCellValue, heatmapColumnIndex, physicalCellInRotatedMatrix,
  rotatedMatrixCellToPhysical, rotatedPhysicalSize, shouldMirrorHeatmapColumns } from "@/lib/captureOrientation";
import type { FrameData } from "@/hooks/useDemo";
import HeatmapMagnifier, { DEFAULT_MAGNIFIER_SIZE, nextMagnifierSize } from "@/components/HeatmapMagnifier";

/** 框选区域范围 */
export interface AreaSelection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

interface HeatmapProps {
  data: FrameData | null;
  showValues: boolean;
  /** Explicit view changes refit; browser zoom keeps the current CSS fit. */
  layoutKey?: string;
  /** 映射到色谱顶端的显示值；ADC默认255，压强模式由当前逐点最大值动态确定。 */
  colorMax?: number;
  /** 格内及区域统计的显示格式。 */
  valueFormatter?: (value: number) => string;
  /** 区域统计中显示的数值单位。 */
  valueUnit?: string;
  /** V2.7.100：格内文字的显示格式（缺省同 valueFormatter）；区域统计与悬停仍用 valueFormatter。 */
  cellValueFormatter?: (value: number) => string;
  /** V2.7.100：格内文字超出格宽时先横向压缩（≥72%），仍放不下再缩小字号（最小 6px），保证每格数值互不重叠。 */
  fitCellText?: boolean;
  /** V2.7.100：格宽不足以放下 cellValueFormatter 文字（压缩到 72% 仍超宽）时改用的紧凑格式。 */
  compactCellValueFormatter?: (value: number) => string;
  onCellHover?: (row: number, col: number, value: number) => void;
  sensorType?: string;
  /** 锁定的点位坐标集合，格式 "row,col" */
  lockedPositions?: Set<string> | null;
  /** 手动框选模式是否启用（用于锁定点位） */
  manualSelectMode?: boolean;
  /** 手动框选完成回调，返回选中的点位坐标集合 */
  onManualSelect?: (positions: Set<string>) => void;
  /** Legacy raw-matrix threshold; ignored when matrixIsFiltered is true. */
  filterThreshold?: number;
  /** data.matrix already contains the exact processed values to draw/hover/export. */
  matrixIsFiltered?: boolean;
  /** Clockwise quarter-turns already applied to data.matrix and the physical panel. */
  matrixRotation?: number;
  /** 框选统计模式是否启用 */
  areaSelectMode?: boolean;
  /** 框选统计区域变化回调（实时，拖拽过程中也会触发） */
  onAreaSelectionChange?: (selection: AreaSelection | null) => void;
  /** 当前已确认的框选区域（用于持久显示） */
  areaSelection?: AreaSelection | null;
  /** 原始点验证模式：为 true 时在大图上显示 23×23 / 32×25 原始 ADC 的定位 */
  showOriginalPoints?: boolean;
  /** 物理行数（原始） */
  physicalRows?: number;
  /** 物理列数（原始） */
  physicalCols?: number;
  /** Highlight in the current rotated physical panel's [row,column] coordinates. */
  highlightedPhysical?: { pr: number; pc: number } | null;
  /** Reports current rotated physical-panel coordinates, never native wire coordinates. */
  onPhysicalHover?: (pr: number, pc: number, value: number) => void;
  /** 有效区域掩码（与 matrix 同尺寸），false 的格子不绘制也不计入 hover/选中 */
  validMask?: boolean[][] | null;
  /** V2.7.109：放大镜开关。 */
  magnifierEnabled?: boolean;
  /** V2.7.109：放大窗口每边格数（5 / 7 / 9 / 11）。 */
  magnifierSize?: number;
  /** V2.7.109：在热力图上滚动鼠标滚轮调整放大范围时回调新的格数。 */
  onMagnifierSizeChange?: (size: number) => void;
  /**
   * V2.7.110：最大压强格标注（matrix 坐标，与 areaSelection 同一坐标系）；label 为标签文字（如“最大 0.123 N/cm²”）。
   * 只做显示标注，不参与计算；放大镜中同一格同样标出。
   */
  maxMarker?: { row: number; col: number; label: string } | null;
}

const formatDefaultValue = (value: number) => String(value);

export default function Heatmap({
  data,
  showValues,
  layoutKey = "default",
  colorMax = 255,
  valueFormatter = formatDefaultValue,
  valueUnit = "",
  cellValueFormatter,
  fitCellText = false,
  compactCellValueFormatter,
  onCellHover,
  sensorType,
  lockedPositions,
  manualSelectMode = false,
  onManualSelect,
  filterThreshold = 0,
  matrixIsFiltered = false,
  matrixRotation = 3,
  areaSelectMode = false,
  onAreaSelectionChange,
  areaSelection,
  showOriginalPoints = false,
  physicalRows,
  physicalCols,
  highlightedPhysical,
  onPhysicalHover,
  validMask,
  magnifierEnabled = false,
  magnifierSize = DEFAULT_MAGNIFIER_SIZE,
  onMagnifierSizeChange,
  maxMarker,
}: HeatmapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState<{ row: number; col: number } | null>(null);
  // V2.7.109 放大镜：中心格（屏幕显示坐标）与鼠标视口坐标；任何模式下均跟随鼠标。
  const [lens, setLens] = useState<{ row: number; col: number; x: number; y: number } | null>(null);
  const magnifierSizeRef = useRef(magnifierSize);
  magnifierSizeRef.current = magnifierSize;

  // 手动框选状态（锁定点位用）
  const [dragStart, setDragStart] = useState<{ row: number; col: number } | null>(null);
  const [dragEnd, setDragEnd] = useState<{ row: number; col: number } | null>(null);
  const isDragging = useRef(false);

  // 框选统计拖拽状态
  const [areaDragStart, setAreaDragStart] = useState<{ row: number; col: number } | null>(null);
  const [areaDragEnd, setAreaDragEnd] = useState<{ row: number; col: number } | null>(null);
  const isAreaDragging = useRef(false);

  const matrix = data?.matrix ?? null;
  const numRows = matrix ? matrix.length : 0;
  const numCols = matrix && matrix[0] ? matrix[0].length : 0;
  const effectiveThreshold = matrixIsFiltered ? 0 : filterThreshold;
  const physicalSize = rotatedPhysicalSize(physicalRows ?? 0, physicalCols ?? 0, matrixRotation);

  // Canvas 尺寸：根据矩阵比例动态计算
  const CANVAS_MAX = 768;
  const canvasWidth = numCols >= numRows ? CANVAS_MAX : Math.round(CANVAS_MAX * (numCols / numRows));
  const canvasHeight = numRows >= numCols ? CANVAS_MAX : Math.round(CANVAS_MAX * (numRows / numCols));

  // Fit once in CSS pixels at the current browser zoom. Native browser zoom
  // must magnify these pixels instead of fitting the canvas back into a smaller
  // CSS viewport. Actual window resizing still adjusts the reference fit area.
  const fitReferenceRef = useRef<{
    width: number; height: number; pixelRatio: number;
    viewportWidth: number; viewportHeight: number; widthShare: number;
  } | null>(null);
  const [renderSize, setRenderSize] = useState<{ width: number; height: number } | null>(null);
  useLayoutEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    fitReferenceRef.current = null;
    const updateFit = () => {
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (width <= 0 || height <= 0 || !canvasWidth || !canvasHeight) return;
      const pixelRatio = window.devicePixelRatio || 1;
      const viewportWidth = window.innerWidth * pixelRatio;
      const viewportHeight = window.innerHeight * pixelRatio;
      let reference = fitReferenceRef.current;
      if (!reference || Math.abs(pixelRatio - reference.pixelRatio) < 0.001) {
        reference = { width, height, pixelRatio, viewportWidth, viewportHeight,
          widthShare: width / Math.max(1, window.innerWidth) };
        fitReferenceRef.current = reference;
      }
      // Page zoom leaves viewport dimensions in device pixels unchanged; a
      // real window resize changes them. Round off subpixel browser rounding.
      const deltaWidth = viewportWidth - reference.viewportWidth;
      const deltaHeight = viewportHeight - reference.viewportHeight;
      const fitWidth = Math.max(1, reference.width + (Math.abs(deltaWidth) > 3
        ? deltaWidth / reference.pixelRatio * reference.widthShare : 0));
      const fitHeight = Math.max(1, reference.height + (Math.abs(deltaHeight) > 3
        ? deltaHeight / reference.pixelRatio : 0));
      const scale = Math.min(fitWidth / canvasWidth, fitHeight / canvasHeight);
      const next = { width: canvasWidth * scale, height: canvasHeight * scale };
      setRenderSize(previous => previous && Math.abs(previous.width - next.width) < 0.1
        && Math.abs(previous.height - next.height) < 0.1 ? previous : next);
    };
    updateFit();
    const observer = new ResizeObserver(updateFit);
    observer.observe(container);
    window.addEventListener("resize", updateFit);
    return () => { observer.disconnect(); window.removeEventListener("resize", updateFit); };
  }, [canvasWidth, canvasHeight, layoutKey]);

  // 计算canvas在容器中的实际渲染区域（考虑object-contain）
  const getCanvasRenderRect = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    const cW = canvas.width;
    const cH = canvas.height;
    const displayW = rect.width;
    const displayH = rect.height;

    const canvasAspect = cW / cH;
    const displayAspect = displayW / displayH;

    let renderW: number, renderH: number, offsetX: number, offsetY: number;

    if (canvasAspect > displayAspect) {
      renderW = displayW;
      renderH = displayW / canvasAspect;
      offsetX = 0;
      offsetY = (displayH - renderH) / 2;
    } else {
      renderH = displayH;
      renderW = displayH * canvasAspect;
      offsetX = (displayW - renderW) / 2;
      offsetY = 0;
    }

    return {
      renderW,
      renderH,
      offsetX: rect.left + offsetX,
      offsetY: rect.top + offsetY,
    };
  }, []);

  // 从鼠标事件获取单元格坐标
  const getCellFromEvent = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const renderRect = getCanvasRenderRect();
      if (!renderRect) return null;

      const { renderW, renderH, offsetX, offsetY } = renderRect;
      const relX = e.clientX - offsetX;
      const relY = e.clientY - offsetY;

      return heatmapCellIndex(Math.floor((relY / renderH) * numRows),
        Math.floor((relX / renderW) * numCols), numRows, numCols, sensorType);
    },
    [numRows, numCols, sensorType, getCanvasRenderRect]
  );

  // 计算当前要显示的框选区域（拖拽中 > 已确认的选区）
  const activeAreaSelection = (() => {
    if (areaDragStart && areaDragEnd) {
      return {
        startRow: Math.min(areaDragStart.row, areaDragEnd.row),
        startCol: Math.min(areaDragStart.col, areaDragEnd.col),
        endRow: Math.max(areaDragStart.row, areaDragEnd.row),
        endCol: Math.max(areaDragStart.col, areaDragEnd.col),
      };
    }
    return areaSelection ?? null;
  })();

  // V2.7.109 放大镜：关闭时清除镜头；打开时在热力图上滚动滚轮调整放大范围（累计约一格滚动量换一档）。
  const lensRow = magnifierEnabled && lens ? lens.row : null;
  const lensCol = magnifierEnabled && lens ? lens.col : null;
  useEffect(() => {
    if (!magnifierEnabled) setLens(null);
  }, [magnifierEnabled]);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !magnifierEnabled || !onMagnifierSizeChange) return;
    let acc = 0;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      acc += e.deltaY;
      if (Math.abs(acc) < 60) return;
      const next = nextMagnifierSize(magnifierSizeRef.current, acc);
      acc = 0;
      if (next !== magnifierSizeRef.current) onMagnifierSizeChange(next);
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => canvas.removeEventListener("wheel", onWheel);
  }, [magnifierEnabled, onMagnifierSizeChange]);

  // 主Canvas绘制
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !matrix || numRows === 0 || numCols === 0) return;

    // 动态设置canvas尺寸
    if (canvas.width !== canvasWidth) canvas.width = canvasWidth;
    if (canvas.height !== canvasHeight) canvas.height = canvasHeight;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const W = canvas.width;
    const H = canvas.height;
    const cellW = W / numCols;
    const cellH = H / numRows;
    // 显示纵轴统一翻转；坐垫另翻转横轴，数据和回调始终使用原矩阵坐标。
    const rowY = (row: number) => (numRows - 1 - row) * cellH;
    const colX = (col: number) => heatmapColumnIndex(col, numCols, sensorType) * cellW;
    const mirrorColumns = shouldMirrorHeatmapColumns(sensorType);

    const hasLock = lockedPositions && lockedPositions.size > 0;

    // 清空背景
    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    // 绘制每个单元格
    for (let r = 0; r < numRows; r++) {
      for (let c = 0; c < numCols; c++) {
        const val = heatmapCellValue(matrix, r, c, validMask, effectiveThreshold);
        if (val === null) continue;
        const isLocked = hasLock ? lockedPositions!.has(`${r},${c}`) : false;
        const isUnlocked = hasLock && !isLocked;
        const normalizedColorValue = Number.isFinite(colorMax) && colorMax > 0
          ? Math.max(0, Math.min(255, (val / colorMax) * 255))
          : 0;

        const rgb = valueToColor(normalizedColorValue);

        const x = colX(c);
        const y = rowY(r);

        ctx.fillStyle = `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
        ctx.fillRect(x, y, cellW, cellH);

        // 非锁定点位半透明遮罩
        if (isUnlocked) {
          ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
          ctx.fillRect(x, y, cellW, cellH);
        }

        // V2.7.15：被过滤的数据视觉等同于 0，与真 0 一致渲染
        if (showValues) {
          let displayValue = (cellValueFormatter ?? valueFormatter)(val);
          let fontSize = Math.max(9, Math.min(cellW, cellH) * 0.42);
          ctx.font = `bold ${fontSize}px 'JetBrains Mono', monospace`;
          // V2.7.100：文字超出格宽时先横向压缩（最多到 72%，字高不变），仍放不下再缩小字号（最小 6px）。
          let scaleX = 1;
          if (fitCellText) {
            const room = Math.max(1, cellW - 2);
            let textWidth = ctx.measureText(displayValue).width;
            if (compactCellValueFormatter && textWidth * 0.72 > room) {
              displayValue = compactCellValueFormatter(val);
              textWidth = ctx.measureText(displayValue).width;
            }
            if (textWidth > room) {
              const compress = room / textWidth;
              scaleX = Math.max(0.72, compress);
              const shrink = compress / scaleX;
              if (shrink < 1) {
                fontSize = Math.max(6, fontSize * shrink);
                ctx.font = `bold ${fontSize}px 'JetBrains Mono', monospace`;
              }
            }
          }
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";

          const textColor = normalizedColorValue > 128 ? "#000" : "#fff";
          const shadowColor = normalizedColorValue > 128 ? "rgba(255,255,255,0.3)" : "rgba(0,0,0,0.5)";

          // 非锁定点位文字也变淡
          const textAlpha = isUnlocked ? 0.4 : 1.0;

          ctx.globalAlpha = textAlpha;
          ctx.strokeStyle = shadowColor;
          ctx.lineWidth = fitCellText ? Math.min(2.5, fontSize * 0.25) : 2.5;
          if (scaleX !== 1) {
            ctx.save();
            ctx.translate(x + cellW / 2, y + cellH / 2);
            ctx.scale(scaleX, 1);
            ctx.strokeText(displayValue, 0, 0);
            ctx.fillStyle = textColor;
            ctx.fillText(displayValue, 0, 0);
            ctx.restore();
          } else {
            ctx.strokeText(displayValue, x + cellW / 2, y + cellH / 2);
            ctx.fillStyle = textColor;
            ctx.fillText(displayValue, x + cellW / 2, y + cellH / 2);
          }
          ctx.globalAlpha = 1.0;
        }
      }
    }

    // 锁定点位边框标记
    if (hasLock) {
      ctx.strokeStyle = "rgba(0, 200, 255, 0.6)";
      ctx.lineWidth = 1.5;
      for (let r = 0; r < numRows; r++) {
        for (let c = 0; c < numCols; c++) {
          if (lockedPositions!.has(`${r},${c}`)) {
            if (heatmapCellValue(matrix, r, c, validMask, effectiveThreshold) === null) continue;
            const x = colX(c);
            const y = rowY(r);
            const top = r === numRows - 1 || !lockedPositions!.has(`${r + 1},${c}`);
            const bottom = r === 0 || !lockedPositions!.has(`${r - 1},${c}`);
            const leftCol = c + (mirrorColumns ? 1 : -1);
            const rightCol = c + (mirrorColumns ? -1 : 1);
            const left = leftCol < 0 || leftCol >= numCols || !lockedPositions!.has(`${r},${leftCol}`);
            const right = rightCol < 0 || rightCol >= numCols || !lockedPositions!.has(`${r},${rightCol}`);

            ctx.beginPath();
            if (top) { ctx.moveTo(x, y); ctx.lineTo(x + cellW, y); }
            if (bottom) { ctx.moveTo(x, y + cellH); ctx.lineTo(x + cellW, y + cellH); }
            if (left) { ctx.moveTo(x, y); ctx.lineTo(x, y + cellH); }
            if (right) { ctx.moveTo(x + cellW, y); ctx.lineTo(x + cellW, y + cellH); }
            ctx.stroke();
          }
        }
      }
    }

    // 手动框选预览（锁定点位用，蓝色）
    if (dragStart && dragEnd) {
      const minR = Math.min(dragStart.row, dragEnd.row);
      const maxR = Math.max(dragStart.row, dragEnd.row);
      const minC = Math.min(dragStart.col, dragEnd.col);
      const maxC = Math.max(dragStart.col, dragEnd.col);

      const sx = Math.min(colX(minC), colX(maxC));
      const sy = rowY(maxR);
      const sw = (maxC - minC + 1) * cellW;
      const sh = (maxR - minR + 1) * cellH;

      ctx.fillStyle = "rgba(0, 200, 255, 0.15)";
      ctx.fillRect(sx, sy, sw, sh);

      ctx.strokeStyle = "rgba(0, 200, 255, 0.8)";
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 3]);
      ctx.strokeRect(sx, sy, sw, sh);
      ctx.setLineDash([]);

      const selRows = maxR - minR + 1;
      const selCols = maxC - minC + 1;
      const selText = `${selRows}×${selCols} = ${selRows * selCols}点位`;
      const selFontSize = Math.max(10, Math.min(cellW, cellH) * 0.5);
      ctx.font = `bold ${selFontSize}px 'Inter', sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      
      const tcx = sx + sw / 2;
      const tcy = sy + sh / 2;
      
      const tm = ctx.measureText(selText);
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
      ctx.fillRect(tcx - tm.width / 2 - 6, tcy - selFontSize / 2 - 4, tm.width + 12, selFontSize + 8);
      
      ctx.fillStyle = "rgba(0, 200, 255, 1)";
      ctx.fillText(selText, tcx, tcy);
    }

    // 框选统计区域（绿色）
    if (activeAreaSelection) {
      const { startRow, startCol, endRow, endCol } = activeAreaSelection;
      const sx = Math.min(colX(startCol), colX(endCol));
      const sy = rowY(endRow);
      const sw = (endCol - startCol + 1) * cellW;
      const sh = (endRow - startRow + 1) * cellH;

      // 选区外半透明遮罩
      ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
      // 上方
      if (endRow < numRows - 1) ctx.fillRect(0, 0, W, sy);
      // 下方
      if (startRow > 0) ctx.fillRect(0, sy + sh, W, H - sy - sh);
      // 左侧
      if (sx > 0) ctx.fillRect(0, sy, sx, sh);
      // 右侧
      if (sx + sw < W) ctx.fillRect(sx + sw, sy, W - sx - sw, sh);

      // 选区边框（绿色）
      ctx.strokeStyle = "rgba(16, 185, 129, 0.9)";
      ctx.lineWidth = 2.5;
      ctx.setLineDash([]);
      ctx.strokeRect(sx, sy, sw, sh);

      // 选区角标
      const cornerSize = Math.min(cellW, cellH) * 0.4;
      ctx.strokeStyle = "rgba(16, 185, 129, 1)";
      ctx.lineWidth = 3;
      // 左上角
      ctx.beginPath();
      ctx.moveTo(sx, sy + cornerSize); ctx.lineTo(sx, sy); ctx.lineTo(sx + cornerSize, sy);
      ctx.stroke();
      // 右上角
      ctx.beginPath();
      ctx.moveTo(sx + sw - cornerSize, sy); ctx.lineTo(sx + sw, sy); ctx.lineTo(sx + sw, sy + cornerSize);
      ctx.stroke();
      // 左下角
      ctx.beginPath();
      ctx.moveTo(sx, sy + sh - cornerSize); ctx.lineTo(sx, sy + sh); ctx.lineTo(sx + cornerSize, sy + sh);
      ctx.stroke();
      // 右下角
      ctx.beginPath();
      ctx.moveTo(sx + sw - cornerSize, sy + sh); ctx.lineTo(sx + sw, sy + sh); ctx.lineTo(sx + sw, sy + sh - cornerSize);
      ctx.stroke();

      // 选区信息标签
      const selRows = endRow - startRow + 1;
      const selCols = endCol - startCol + 1;

      // 计算选区内的实时统计
      let areaSum = 0, areaNonZero = 0, areaMax = 0;
      for (let r = startRow; r <= endRow; r++) {
        for (let c = startCol; c <= endCol; c++) {
          const v = heatmapCellValue(matrix, r, c, validMask, effectiveThreshold);
          if (v === null) continue;
          areaSum += v;
          if (v > 0) areaNonZero++;
          if (v > areaMax) areaMax = v;
        }
      }
      const areaAvg = areaNonZero > 0 ? valueFormatter(areaSum / areaNonZero) : valueFormatter(0);

      const unitSuffix = valueUnit ? ` ${valueUnit}` : "";
      const infoText = `${selRows}×${selCols} | 有效:${areaNonZero} | 均值:${areaAvg}${unitSuffix} | 最大:${valueFormatter(areaMax)}${unitSuffix}`;
      const infoFontSize = Math.max(9, Math.min(cellW, cellH) * 0.38);
      ctx.font = `bold ${infoFontSize}px 'Inter', sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      // 标签位置：选区上方或下方
      const labelY = endRow < numRows - 2 ? sy - infoFontSize - 8 : sy + sh + infoFontSize + 4;
      const labelX = sx + sw / 2;

      const tm = ctx.measureText(infoText);
      ctx.fillStyle = "rgba(0, 0, 0, 0.85)";
      const padX = 8, padY = 5;
      const bgX = labelX - tm.width / 2 - padX;
      const bgY = labelY - infoFontSize / 2 - padY;
      const bgW = tm.width + padX * 2;
      const bgH = infoFontSize + padY * 2;
      
      // 圆角背景
      const r = 4;
      ctx.beginPath();
      ctx.moveTo(bgX + r, bgY);
      ctx.lineTo(bgX + bgW - r, bgY);
      ctx.quadraticCurveTo(bgX + bgW, bgY, bgX + bgW, bgY + r);
      ctx.lineTo(bgX + bgW, bgY + bgH - r);
      ctx.quadraticCurveTo(bgX + bgW, bgY + bgH, bgX + bgW - r, bgY + bgH);
      ctx.lineTo(bgX + r, bgY + bgH);
      ctx.quadraticCurveTo(bgX, bgY + bgH, bgX, bgY + bgH - r);
      ctx.lineTo(bgX, bgY + r);
      ctx.quadraticCurveTo(bgX, bgY, bgX + r, bgY);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "rgba(16, 185, 129, 1)";
      ctx.fillText(infoText, labelX, labelY);
    }

    // 原始点验证叠加层：压暗非原始点，突出 23×23 / 32×25 样本点
    if (showOriginalPoints && physicalRows && physicalCols && numRows === physicalSize.rows * 2 && numCols === physicalSize.cols * 2) {
      // 全图压暗
      ctx.fillStyle = "rgba(0,0,0,0.72)";
      ctx.fillRect(0, 0, W, H);
      // Both panels have already undergone matrixRotation. Sample parity changes
      // with rotation, while pr/pc keep the physical panel's current coordinates.
      for (let pr = 0; pr < physicalSize.rows; pr++) {
        for (let pc = 0; pc < physicalSize.cols; pc++) {
          const { row: rr, col: cc } = physicalCellInRotatedMatrix(pr, pc, matrixRotation);
          if (rr < 0 || cc < 0 || rr >= numRows || cc >= numCols) continue;
          const v = heatmapCellValue(matrix, rr, cc, validMask, effectiveThreshold);
          if (v === null) continue;
          // 重绘单元格本色
          const normalizedValue = Number.isFinite(colorMax) && colorMax > 0 && Number.isFinite(v)
            ? Math.max(0, Math.min(255, (v / colorMax) * 255))
            : 0;
          const rgb = valueToColor(normalizedValue);
          ctx.fillStyle = `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
          const x = colX(cc);
          const y = rowY(rr);
          ctx.fillRect(x, y, cellW, cellH);
          // 绿色描边突出原始点
          ctx.strokeStyle = "rgba(16, 185, 129, 0.95)";
          ctx.lineWidth = 1.5;
          ctx.strokeRect(x + 0.75, y + 0.75, cellW - 1.5, cellH - 1.5);
          // 显示值（小字）
          if (showValues || cellW >= 14) {
            const fontSize = Math.max(8, Math.min(cellW, cellH) * 0.5);
            ctx.font = `${fontSize}px 'Inter', sans-serif`;
            ctx.fillStyle = normalizedValue > 128 ? "rgba(0,0,0,0.9)" : "rgba(255,255,255,0.95)";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText((cellValueFormatter ?? valueFormatter)(v), x + cellW / 2, y + cellH / 2);
          }
        }
      }
    }

    // 外部高亮（来自小面板 hover）
    if (highlightedPhysical && physicalRows && physicalCols) {
      const { pr, pc } = highlightedPhysical;
      if (pr >= 0 && pr < physicalSize.rows && pc >= 0 && pc < physicalSize.cols) {
        const { row: rr, col: cc } = physicalCellInRotatedMatrix(pr, pc, matrixRotation);
        if (rr >= 0 && cc >= 0 && rr < numRows && cc < numCols && heatmapCellValue(matrix, rr, cc, validMask, effectiveThreshold) !== null) {
          const x = colX(cc);
          const y = rowY(rr);
          // 内圈：突出半径 ~ 2×2 块
          ctx.save();
          ctx.strokeStyle = "rgba(250, 204, 21, 1)";
          ctx.lineWidth = 3;
          ctx.setLineDash([]);
          ctx.strokeRect(x - cellW - 1, y - cellH - 1, cellW * 3 + 2, cellH * 3 + 2);
          ctx.strokeStyle = "rgba(250, 204, 21, 0.5)";
          ctx.lineWidth = 6;
          ctx.strokeRect(x - cellW - 3, y - cellH - 3, cellW * 3 + 6, cellH * 3 + 6);
          ctx.restore();
        }
      }
    }

    // 鼠标悬停十字准线（框选模式下不显示）
    if (hovered && !manualSelectMode && !areaSelectMode) {
      const hx = colX(hovered.col);
      const hy = rowY(hovered.row);

      ctx.strokeStyle = "rgba(16,185,129,0.5)";
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);

      ctx.beginPath();
      ctx.moveTo(hx + cellW / 2, 0);
      ctx.lineTo(hx + cellW / 2, H);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, hy + cellH / 2);
      ctx.lineTo(W, hy + cellH / 2);
      ctx.stroke();

      ctx.setLineDash([]);
      ctx.strokeStyle = "rgba(16,185,129,0.8)";
      ctx.lineWidth = 3;
      ctx.strokeRect(hx, hy, cellW, cellH);
    }

    // V2.7.110 最大压强格标注：红白双框 + 数值标签（标签放在格子上方，靠近上边缘时放到下方，左右不出画布）。
    if (maxMarker && maxMarker.row >= 0 && maxMarker.row < numRows && maxMarker.col >= 0 && maxMarker.col < numCols) {
      const mx = colX(maxMarker.col);
      const my = rowY(maxMarker.row);
      ctx.save();
      ctx.setLineDash([]);
      ctx.strokeStyle = "rgba(255,255,255,0.95)";
      ctx.lineWidth = 4;
      ctx.strokeRect(mx - 1.5, my - 1.5, cellW + 3, cellH + 3);
      ctx.strokeStyle = "rgba(239,68,68,1)";
      ctx.lineWidth = 2;
      ctx.strokeRect(mx - 1.5, my - 1.5, cellW + 3, cellH + 3);
      const labelFont = Math.max(11, Math.min(14, Math.min(cellW, cellH) * 0.9));
      ctx.font = `bold ${labelFont}px 'JetBrains Mono', monospace`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const tw = ctx.measureText(maxMarker.label).width;
      const bw = tw + 12;
      const bh = labelFont + 8;
      let bx = mx + cellW / 2 - bw / 2;
      bx = Math.max(2, Math.min(bx, W - bw - 2));
      let by = my - bh - 6;
      if (by < 2) by = my + cellH + 6;
      by = Math.max(2, Math.min(by, H - bh - 2));
      ctx.fillStyle = "rgba(127,29,29,0.92)";
      ctx.fillRect(bx, by, bw, bh);
      ctx.strokeStyle = "rgba(254,202,202,0.95)";
      ctx.lineWidth = 1;
      ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
      ctx.fillStyle = "#fff";
      ctx.fillText(maxMarker.label, bx + bw / 2, by + bh / 2);
      ctx.restore();
    }

    // V2.7.109 放大镜范围框（屏幕显示坐标：第 row 行自上而下、第 col 列自左而右）
    if (magnifierEnabled && lensRow !== null && lensCol !== null) {
      const half = (magnifierSize - 1) / 2;
      const lx = (lensCol - half) * cellW;
      const ly = (lensRow - half) * cellH;
      ctx.save();
      ctx.setLineDash([]);
      ctx.strokeStyle = "rgba(15,23,42,0.85)";
      ctx.lineWidth = 4;
      ctx.strokeRect(lx, ly, magnifierSize * cellW, magnifierSize * cellH);
      ctx.strokeStyle = "rgba(34,211,238,0.95)";
      ctx.lineWidth = 2;
      ctx.strokeRect(lx, ly, magnifierSize * cellW, magnifierSize * cellH);
      ctx.restore();
    }
  }, [matrix, showValues, hovered, numRows, numCols, canvasWidth, canvasHeight, sensorType, lockedPositions, dragStart, dragEnd, manualSelectMode, areaSelectMode, activeAreaSelection, effectiveThreshold, showOriginalPoints, physicalRows, physicalCols, physicalSize.rows, physicalSize.cols, matrixRotation, highlightedPhysical, validMask, colorMax, valueFormatter, cellValueFormatter, fitCellText, compactCellValueFormatter, valueUnit, magnifierEnabled, magnifierSize, lensRow, lensCol, maxMarker]);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      if (magnifierEnabled) {
        const rr = getCanvasRenderRect();
        const row = rr ? Math.floor(((e.clientY - rr.offsetY) / rr.renderH) * numRows) : -1;
        const col = rr ? Math.floor(((e.clientX - rr.offsetX) / rr.renderW) * numCols) : -1;
        const x = e.clientX, y = e.clientY;
        if (row >= 0 && col >= 0 && row < numRows && col < numCols) {
          setLens(prev => (prev && prev.row === row && prev.col === col && prev.x === x && prev.y === y ? prev : { row, col, x, y }));
        } else {
          setLens(null);
        }
      }
      const cell = getCellFromEvent(e);
      if (!cell) {
        setHovered(null);
        return;
      }
      const value = matrix ? heatmapCellValue(matrix, cell.row, cell.col, validMask, effectiveThreshold) : null;
      if (value === null) {
        setHovered(null);
        return;
      }

      if (areaSelectMode && isAreaDragging.current) {
        setAreaDragEnd(cell);
      } else if (manualSelectMode && isDragging.current) {
        setDragEnd(cell);
      } else {
        setHovered(cell);
        if (matrix) {
          onCellHover?.(cell.row, cell.col, value);
          if (physicalRows && physicalCols && onPhysicalHover) {
            const physical = rotatedMatrixCellToPhysical(cell.row, cell.col, matrixRotation);
            if (physical && physical.pr < physicalSize.rows && physical.pc < physicalSize.cols) {
              onPhysicalHover(physical.pr, physical.pc, value);
            }
          }
        }
      }
    },
    [matrix, onCellHover, getCellFromEvent, getCanvasRenderRect, magnifierEnabled, manualSelectMode, areaSelectMode, physicalRows, physicalCols, physicalSize.rows, physicalSize.cols, matrixRotation, numRows, numCols, onPhysicalHover, validMask, effectiveThreshold]
  );

  const handleMouseDown = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const cell = getCellFromEvent(e);
      if (!cell || !matrix || heatmapCellValue(matrix, cell.row, cell.col, validMask, effectiveThreshold) === null) return;

      if (areaSelectMode) {
        isAreaDragging.current = true;
        setAreaDragStart(cell);
        setAreaDragEnd(cell);
      } else if (manualSelectMode) {
        isDragging.current = true;
        setDragStart(cell);
        setDragEnd(cell);
      }
    },
    [manualSelectMode, areaSelectMode, getCellFromEvent, matrix, validMask, effectiveThreshold]
  );

  const handleMouseUp = useCallback(
    (_e: React.MouseEvent<HTMLCanvasElement>) => {
      if (areaSelectMode && isAreaDragging.current && areaDragStart && areaDragEnd) {
        isAreaDragging.current = false;
        const selection: AreaSelection = {
          startRow: Math.min(areaDragStart.row, areaDragEnd.row),
          startCol: Math.min(areaDragStart.col, areaDragEnd.col),
          endRow: Math.max(areaDragStart.row, areaDragEnd.row),
          endCol: Math.max(areaDragStart.col, areaDragEnd.col),
        };
        onAreaSelectionChange?.(selection);
        // 保持拖拽状态用于显示，不清除
        setAreaDragStart(null);
        setAreaDragEnd(null);
        return;
      }

      if (manualSelectMode && isDragging.current && dragStart && dragEnd) {
        isDragging.current = false;

        const minR = Math.min(dragStart.row, dragEnd.row);
        const maxR = Math.max(dragStart.row, dragEnd.row);
        const minC = Math.min(dragStart.col, dragEnd.col);
        const maxC = Math.max(dragStart.col, dragEnd.col);

        const selected = new Set<string>();
        for (let r = minR; r <= maxR; r++) {
          for (let c = minC; c <= maxC; c++) {
            if (matrix && heatmapCellValue(matrix, r, c, validMask, effectiveThreshold) !== null) selected.add(`${r},${c}`);
          }
        }

        onManualSelect?.(selected);
        setDragStart(null);
        setDragEnd(null);
        return;
      }

      isDragging.current = false;
      isAreaDragging.current = false;
    },
    [manualSelectMode, areaSelectMode, dragStart, dragEnd, areaDragStart, areaDragEnd, onManualSelect, onAreaSelectionChange, matrix, validMask, effectiveThreshold]
  );

  const handleMouseLeave = useCallback(() => {
    setHovered(null);
    setLens(null);
    if (isDragging.current) {
      isDragging.current = false;
      setDragStart(null);
      setDragEnd(null);
    }
    if (isAreaDragging.current) {
      isAreaDragging.current = false;
      setAreaDragStart(null);
      setAreaDragEnd(null);
    }
  }, []);

  const isAnySelectMode = manualSelectMode || areaSelectMode;

  return (
    <div ref={containerRef} data-testid="heatmap-viewport" className="relative w-full h-full overflow-auto"
      data-max-marker={maxMarker ? `${maxMarker.row},${maxMarker.col}` : undefined} data-max-label={maxMarker?.label}>
      <div className="flex items-center justify-center"
        style={{ minWidth: "100%", minHeight: "100%", width: renderSize?.width, height: renderSize?.height }}>
      <canvas
        ref={canvasRef}
        width={canvasWidth}
        height={canvasHeight}
        className={`shrink-0 max-w-none object-contain ${isAnySelectMode ? 'cursor-cell' : 'cursor-crosshair'}`}
        style={{ imageRendering: "pixelated", width: renderSize?.width ?? canvasWidth, height: renderSize?.height ?? canvasHeight }}
        onMouseMove={handleMouseMove}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
      />
      </div>
      {/* 手动框选模式指示器 */}
      {manualSelectMode && (
        <div className="absolute top-2 left-2 px-2 py-1 rounded bg-amber-600/90 text-white text-[10px] font-semibold pointer-events-none">
          框选模式 · 拖拽选择区域
        </div>
      )}
      {/* 框选统计模式指示器 */}
      {areaSelectMode && (
        <div className="absolute top-2 left-2 px-2 py-1 rounded bg-emerald-600/90 text-white text-[10px] font-semibold pointer-events-none">
          框选统计 · 拖拽选择区域
        </div>
      )}
      {/* V2.7.109 放大镜窗口（挂到 body，跟随鼠标；格内完整数值，与主图同一矩阵） */}
      {magnifierEnabled && lens && matrix && (
        <HeatmapMagnifier
          matrix={matrix}
          numRows={numRows}
          numCols={numCols}
          sensorType={sensorType}
          validMask={validMask}
          threshold={effectiveThreshold}
          colorMax={colorMax}
          size={magnifierSize}
          center={{ row: lens.row, col: lens.col }}
          pointer={{ x: lens.x, y: lens.y }}
          cellFormatter={cellValueFormatter ?? valueFormatter}
          valueFormatter={valueFormatter}
          valueUnit={valueUnit}
          lockedPositions={lockedPositions}
          markedCell={maxMarker ?? null}
        />
      )}
    </div>
  );
}
