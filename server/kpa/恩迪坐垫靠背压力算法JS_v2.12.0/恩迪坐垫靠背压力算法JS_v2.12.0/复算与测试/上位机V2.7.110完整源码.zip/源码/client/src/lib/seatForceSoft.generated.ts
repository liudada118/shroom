import model from './seatForceSoftModel.generated';

export interface SeatSoftForceResult {
  forceN: number;
  regionForcesN: number[];
  regionCenters: number[][];
  forceMeaning: 'continuous_adc_regression_with_fixed_weight_prior';
  accepted: false;
  independentlyValidated: false;
}

function validate(source:number[][],physical:number[][]):void {
  if(source.length!==46||source.some(r=>r.length!==46||r.some(v=>!Number.isFinite(v)||v<0||v>255)))throw new TypeError('Expected a complete 46x46 source ADC matrix.');
  if(physical.length!==23||physical.some(r=>r.length!==23||r.some(v=>!Number.isFinite(v)||v<0||v>255)))throw new TypeError('Expected a complete 23x23 physical ADC matrix.');
}
function quantile(sorted:number[],q:number):number {
  if(!sorted.length)return 0;const x=(sorted.length-1)*q,lo=Math.floor(x),hi=Math.ceil(x);return sorted[lo]+(sorted[hi]-sorted[lo])*(x-lo);
}
function stats(values:number[]):number[] {
  const sorted=values.slice().sort((a,b)=>a-b),valid=sorted.filter(v=>v>30),out:number[]=[];
  for(const q of [0,.1,.25,.5,.75,.9,1])out.push(quantile(valid,q));
  for(const p of [1,2,3,6])out.push(values.reduce((sum,v)=>sum+(p===1?v:(v/255)**p),0));
  for(const t of [0,5,15,30,60,90,120,150,180,210,240])out.push(values.reduce((sum,v)=>sum+(v>t?1:0),0));
  for(const k of [1,3,5,10,20,46])out.push(sorted.slice(-k).reduce((a,b)=>a+b,0)/k);
  for(const t of [30,60,90,120,150,180,210])out.push(values.reduce((sum,v)=>sum+Math.max(0,v-t),0));
  for(const upper of [260,300,400])for(const p of [1,2,3])out.push(values.reduce((sum,v)=>sum+(v/(upper-v))**p,0));
  return out;
}
export function extractSeatSoftRegionFeatures(source:number[][],physical:number[][],seeds:number[][]):number[][] {
  validate(source,physical);if(!seeds.length)return [];
  const physicalLabels=new Int32Array(23*23);
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    let best=0,distance=Infinity;for(let j=0;j<seeds.length;j++){const d=(2*r-seeds[j][0])**2+(2*c-seeds[j][1])**2;if(d<distance){best=j;distance=d;}}physicalLabels[r*23+c]=best;
  }
  const output:number[][]=[];
  for(let j=0;j<seeds.length;j++){
    const a:number[]=[],b:number[]=[],sourceRows:number[]=[],sourceCols:number[]=[],physicalRows:number[]=[],physicalCols:number[]=[],crop=Array.from({length:23},()=>Array(23).fill(0));
    for(let r=0;r<23;r++)for(let c=0;c<23;c++)if(physicalLabels[r*23+c]===j&&(r*2-seeds[j][0])**2+(c*2-seeds[j][1])**2<=36)crop[r][c]=physical[r][c];
    const localSource=Array.from({length:46},()=>Array(46).fill(0));
    for(let r=0;r<23;r++)for(let c=0;c<23;c++){const v=crop[r][c],right=crop[r][c+1]??0,down=crop[r+1]?.[c]??0,diag=crop[r+1]?.[c+1]??0;localSource[2*r][2*c]=v;localSource[2*r][2*c+1]=Math.floor((v+right)/2);localSource[2*r+1][2*c]=Math.floor((v+down)/2);localSource[2*r+1][2*c+1]=Math.floor((v+right+down+diag)/4);}
    for(let r=0;r<46;r++)for(let c=0;c<46;c++){const v=localSource[r][c];a.push(v);sourceRows.push(r);sourceCols.push(c);}
    for(let r=0;r<23;r++)for(let c=0;c<23;c++){const v=crop[r][c];b.push(v);physicalRows.push(r);physicalCols.push(c);}
    let sourceWeight=0,sourceR=0,sourceC=0,physicalWeight=0,physicalR=0,physicalC=0;
    for(let i=0;i<a.length;i++){const w=a[i]*a[i];sourceWeight+=w;sourceR+=sourceRows[i]*w;sourceC+=sourceCols[i]*w;}
    for(let i=0;i<b.length;i++){const w=b[i]*b[i];physicalWeight+=w;physicalR+=physicalRows[i]*w;physicalC+=physicalCols[i]*w;}
    if(sourceWeight<=0||physicalWeight<=0)throw new RangeError('Every detected seat contact must have nonzero source and physical ADC support.');
    const sr=sourceR/sourceWeight,sc=sourceC/sourceWeight,pr=physicalR/physicalWeight,pc=physicalC/physicalWeight;
    const sourceStats=stats(a),physicalStats=stats(b),all=[...sourceStats,...physicalStats],amp=[3,4,5,6,22,23,24,25,26,27,47,48,49,50,66,67,68,69,70,71],totals=[7,8,9,10,51,52,53,54];
    const compact=[...amp.map(i=>Math.log1p(all[i])),...totals.map(i=>Math.log1p(all[i]))];
    for(const [rp,cp] of [[2,0],[0,2],[1,1],[3,0],[0,3],[4,0],[0,4],[2,2]]){
      let value=0;for(let i=0;i<a.length;i++)value+=a[i]*a[i]*(sourceRows[i]-sr)**rp*(sourceCols[i]-sc)**cp;compact.push(value/sourceWeight);
    }
    compact.push(sr/45,sc/45);
    const sorted=b.slice().sort((x,y)=>y-x);for(let k=0;k<40;k++)compact.push((sorted[k]??0)/255);
    for(const [rp,cp] of [[2,0],[0,2],[1,1]]){let value=0;for(let i=0;i<b.length;i++)value+=b[i]*b[i]*(physicalRows[i]-pr)**rp*(physicalCols[i]-pc)**cp;compact.push(value/physicalWeight);}
    compact.push(pr/22,pc/22);output.push(compact);
  }
  return output;
}
function softmax(logits:number[]):number[]{const max=Math.max(...logits),values=logits.map(v=>Math.exp(v-max)),sum=values.reduce((a,b)=>a+b,0);return values.map(v=>v/sum);}
export function predictSeatSoftRegion(feature:number[]):number {
  if(feature.length!==model.featureCount)throw new TypeError('Unexpected seat force feature count.');
  let activation=feature.map((v,i)=>(v-model.scalerMean[i])/model.scalerScale[i]);
  for(let layer=0;layer<model.layerWeights.length;layer++){
    const weights=model.layerWeights[layer],bias=model.layerBiases[layer],next=Array(bias.length).fill(0);
    for(let i=0;i<activation.length;i++)for(let j=0;j<next.length;j++)next[j]+=activation[i]*weights[i][j];
    for(let j=0;j<next.length;j++)next[j]+=bias[j];
    activation=layer<model.layerWeights.length-1?next.map(Math.tanh):softmax(next);
  }
  const prior=activation.reduce((sum,p,i)=>sum+p*model.classForceN[i],0),z=feature.map((v,i)=>(v-model.scalerMean[i])/model.scalerScale[i]);let correction=0;
  for(let i=0;i<model.residualTrainingFeatures.length;i++){
    let distance=0;const reference=model.residualTrainingFeatures[i];for(let k=0;k<z.length;k++)distance+=(z[k]-reference[k])**2;
    correction+=model.residualCoefficients[i]*Math.exp(-model.residualGamma*distance);
  }
  return prior+correction;
}
export function analyzeSeatSoftFixedForce(source:number[][],physical:number[][],seeds:number[][]):SeatSoftForceResult {
  const features=extractSeatSoftRegionFeatures(source,physical,seeds),regionForcesN=features.map(predictSeatSoftRegion);
  return {forceN:regionForcesN.reduce((a,b)=>a+b,0),regionForcesN,regionCenters:seeds.map(p=>p.slice()),forceMeaning:'continuous_adc_regression_with_fixed_weight_prior',accepted:false,independentlyValidated:false};
}
