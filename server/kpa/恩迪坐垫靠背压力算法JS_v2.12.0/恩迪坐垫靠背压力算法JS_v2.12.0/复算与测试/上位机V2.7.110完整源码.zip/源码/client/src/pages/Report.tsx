/**
 * 交互式可视化报告页面 V2.7.90
 * 
 * 以更直观和交互的方式呈现矩阵压力传感器的功能和数据
 * 设计风格: 现代深色仪表盘，带有交互式图表和动画
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import {
  BarChart3,
  Grid3X3,
  Activity,
  Zap,
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  TrendingUp,
  Eye,
  Hash,
  ArrowUp,
  ArrowDown,
  Layers,
  Clock,
  Cpu,
  Gauge,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { valueToColor, getColorGradient } from "@/lib/colorMap";

// ===================== 模拟数据生成 =====================

function generateDemoMatrix(t: number, size: number): number[][] {
  const cx = size / 2;
  const cy = size / 2;
  const matrix: number[][] = [];

  for (let r = 0; r < size; r++) {
    const row: number[] = [];
    for (let c = 0; c < size; c++) {
      const px1 = cx * 0.4 + cx * 0.3 * Math.sin(t * 0.7);
      const py1 = cy * 0.4 + cy * 0.3 * Math.cos(t * 0.5);
      const d1 = Math.sqrt((r - py1) ** 2 + (c - px1) ** 2);
      const v1 = Math.max(0, 220 - d1 * 30) * (0.7 + 0.3 * Math.sin(t * 2));

      const px2 = cx * 0.7 + cx * 0.2 * Math.cos(t * 0.3);
      const py2 = cy * 0.7 + cy * 0.2 * Math.sin(t * 0.6);
      const d2 = Math.sqrt((r - py2) ** 2 + (c - px2) ** 2);
      const v2 = Math.max(0, 180 - d2 * 28) * (0.6 + 0.4 * Math.cos(t * 1.5));

      const px3 = cx + cx * 0.3 * Math.sin(t * 0.4);
      const py3 = cy + cy * 0.3 * Math.cos(t * 0.8);
      const d3 = Math.sqrt((r - py3) ** 2 + (c - px3) ** 2);
      const v3 = Math.max(0, 150 - d3 * 25) * (0.5 + 0.5 * Math.sin(t * 3));

      const noise = Math.random() * 5;
      let value = Math.round(Math.max(v1, v2, v3) + noise);
      value = Math.max(0, Math.min(255, value));
      row.push(value);
    }
    matrix.push(row);
  }
  return matrix;
}

function computeMatrixStats(matrix: number[][]) {
  let max = 0, min = 255, sum = 0, nonZeroCount = 0, nonZeroMin = 255;
  const total = matrix.length * matrix[0].length;
  for (const row of matrix) {
    for (const val of row) {
      if (val > max) max = val;
      if (val < min) min = val;
      sum += val;
      if (val > 0) {
        nonZeroCount++;
        if (val < nonZeroMin) nonZeroMin = val;
      }
    }
  }
  return {
    max, min, sum, nonZeroCount, nonZeroMin: nonZeroCount === 0 ? 0 : nonZeroMin,
    avg: Math.round((sum / total) * 100) / 100,
    coverage: Math.round((nonZeroCount / total) * 1000) / 10,
    total,
  };
}

// ===================== 小型热力图Canvas组件 =====================

function MiniHeatmap({ matrix, size = 256 }: { matrix: number[][]; size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !matrix.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const matSize = matrix.length;
    const cellSize = size / matSize;

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, size, size);

    for (let r = 0; r < matSize; r++) {
      for (let c = 0; c < matSize; c++) {
        const val = matrix[r][c];
        const [red, green, blue] = valueToColor(val);
        ctx.fillStyle = `rgb(${red},${green},${blue})`;
        ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
      }
    }
  }, [matrix, size]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className="rounded-lg"
      style={{ width: size, height: size, imageRendering: "pixelated" }}
    />
  );
}

// ===================== 压力值分布直方图 =====================

function DistributionChart({ matrix }: { matrix: number[][] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !matrix.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;

    // 统计分布
    const bins = new Array(32).fill(0);
    for (const row of matrix) {
      for (const val of row) {
        const bin = Math.min(31, Math.floor(val / 8));
        bins[bin]++;
      }
    }
    const maxBin = Math.max(...bins, 1);

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    const barWidth = (W - 60) / bins.length;
    const chartHeight = H - 40;

    // 绘制柱状图
    for (let i = 0; i < bins.length; i++) {
      const barHeight = (bins[i] / maxBin) * chartHeight;
      const x = 40 + i * barWidth;
      const y = chartHeight - barHeight + 10;

      const val = i * 8 + 4;
      const [r, g, b] = valueToColor(val);
      ctx.fillStyle = `rgba(${r},${g},${b},0.85)`;
      ctx.fillRect(x + 1, y, barWidth - 2, barHeight);
    }

    // 坐标轴
    ctx.strokeStyle = "rgba(255,255,255,0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(40, 10);
    ctx.lineTo(40, chartHeight + 10);
    ctx.lineTo(W - 10, chartHeight + 10);
    ctx.stroke();

    // 标签
    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.font = "10px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";
    for (let i = 0; i < bins.length; i += 4) {
      ctx.fillText(`${i * 8}`, 40 + i * barWidth + barWidth / 2, chartHeight + 24);
    }

    ctx.textAlign = "right";
    for (let i = 0; i <= 4; i++) {
      const val = Math.round((maxBin / 4) * i);
      const y = chartHeight + 10 - (i / 4) * chartHeight;
      ctx.fillText(val.toString(), 36, y + 3);
    }
  }, [matrix]);

  return (
    <canvas
      ref={canvasRef}
      width={500}
      height={200}
      className="w-full rounded-lg"
      style={{ maxWidth: 500 }}
    />
  );
}

// ===================== 时间序列图表 =====================

function TimeSeriesChart({ history }: { history: { max: number; avg: number; coverage: number }[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || history.length < 2) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const padding = { top: 20, right: 20, bottom: 30, left: 45 };
    const chartW = W - padding.left - padding.right;
    const chartH = H - padding.top - padding.bottom;

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    // 网格线
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (i / 4) * chartH;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(W - padding.right, y);
      ctx.stroke();
    }

    const drawLine = (data: number[], color: string, maxVal: number) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < data.length; i++) {
        const x = padding.left + (i / (data.length - 1)) * chartW;
        const y = padding.top + (1 - data[i] / maxVal) * chartH;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    };

    // 绘制三条线
    drawLine(history.map(h => h.max), "#f59e0b", 255);
    drawLine(history.map(h => h.avg), "#a78bfa", 255);
    drawLine(history.map(h => h.coverage), "#34d399", 100);

    // 图例
    const legends = [
      { label: "最大值", color: "#f59e0b" },
      { label: "平均值", color: "#a78bfa" },
      { label: "覆盖率%", color: "#34d399" },
    ];
    ctx.font = "11px 'Space Grotesk', sans-serif";
    let lx = padding.left + 10;
    for (const leg of legends) {
      ctx.fillStyle = leg.color;
      ctx.fillRect(lx, 6, 12, 3);
      ctx.fillStyle = "rgba(255,255,255,0.6)";
      ctx.textAlign = "left";
      ctx.fillText(leg.label, lx + 16, 12);
      lx += ctx.measureText(leg.label).width + 30;
    }

    // Y轴标签
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.font = "10px 'JetBrains Mono', monospace";
    ctx.textAlign = "right";
    for (let i = 0; i <= 4; i++) {
      const val = Math.round((255 / 4) * (4 - i));
      const y = padding.top + (i / 4) * chartH;
      ctx.fillText(val.toString(), padding.left - 6, y + 3);
    }
  }, [history]);

  return (
    <canvas
      ref={canvasRef}
      width={600}
      height={220}
      className="w-full rounded-lg"
      style={{ maxWidth: 600 }}
    />
  );
}

// ===================== 3D 表面图 =====================

function Surface3D({ matrix }: { matrix: number[][] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !matrix.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const size = matrix.length;

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    // 等距投影参数
    const scale = Math.min(W, H) / (size * 2.5);
    const cx = W / 2;
    const cy = H * 0.65;
    const heightScale = 0.5;

    // 从后向前绘制
    for (let r = 0; r < size; r++) {
      for (let c = size - 1; c >= 0; c--) {
        const val = matrix[r][c];
        const h = (val / 255) * size * heightScale;

        // 等距投影
        const isoX = (c - r) * scale * 0.7;
        const isoY = (c + r) * scale * 0.35 - h * scale * 0.4;

        const x = cx + isoX;
        const y = cy + isoY - size * scale * 0.3;

        const [red, green, blue] = valueToColor(val);
        const brightness = 0.6 + (val / 255) * 0.4;

        // 顶面
        ctx.fillStyle = `rgba(${Math.round(red * brightness)},${Math.round(green * brightness)},${Math.round(blue * brightness)},0.9)`;
        ctx.fillRect(x - scale * 0.35, y - scale * 0.17, scale * 0.7, scale * 0.35);
      }
    }
  }, [matrix]);

  return (
    <canvas
      ref={canvasRef}
      width={500}
      height={350}
      className="w-full rounded-lg"
      style={{ maxWidth: 500 }}
    />
  );
}

// ===================== 行/列压力剖面图 =====================

function ProfileChart({ matrix, selectedRow }: { matrix: number[][]; selectedRow: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !matrix.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const size = matrix.length;
    const padding = { top: 20, right: 20, bottom: 30, left: 45 };
    const chartW = W - padding.left - padding.right;
    const chartH = H - padding.top - padding.bottom;

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, W, H);

    // 网格
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (i / 4) * chartH;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(W - padding.right, y);
      ctx.stroke();
    }

    // 行数据
    const row = matrix[selectedRow] || matrix[0];

    // 填充区域
    ctx.beginPath();
    ctx.moveTo(padding.left, padding.top + chartH);
    for (let i = 0; i < row.length; i++) {
      const x = padding.left + (i / (row.length - 1)) * chartW;
      const y = padding.top + (1 - row[i] / 255) * chartH;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(padding.left + chartW, padding.top + chartH);
    ctx.closePath();

    const grad = ctx.createLinearGradient(0, padding.top, 0, padding.top + chartH);
    grad.addColorStop(0, "rgba(245,158,11,0.3)");
    grad.addColorStop(1, "rgba(245,158,11,0.02)");
    ctx.fillStyle = grad;
    ctx.fill();

    // 线
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < row.length; i++) {
      const x = padding.left + (i / (row.length - 1)) * chartW;
      const y = padding.top + (1 - row[i] / 255) * chartH;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // 标签
    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.font = "11px 'Space Grotesk', sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`行 ${selectedRow} 压力剖面`, padding.left + 4, 14);

    ctx.font = "10px 'JetBrains Mono', monospace";
    ctx.textAlign = "right";
    for (let i = 0; i <= 4; i++) {
      const val = Math.round((255 / 4) * (4 - i));
      const y = padding.top + (i / 4) * chartH;
      ctx.fillText(val.toString(), padding.left - 6, y + 3);
    }
  }, [matrix, selectedRow]);

  return (
    <canvas
      ref={canvasRef}
      width={500}
      height={180}
      className="w-full rounded-lg"
      style={{ maxWidth: 500 }}
    />
  );
}

// ===================== 主报告页面 =====================

export default function Report() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [time, setTime] = useState(0);
  const [selectedRow, setSelectedRow] = useState(11);
  const [history, setHistory] = useState<{ max: number; avg: number; coverage: number }[]>([]);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const matrix = useMemo(() => generateDemoMatrix(time, 23), [time]);
  const stats = useMemo(() => computeMatrixStats(matrix), [matrix]);

  // 动画循环
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setTime(prev => prev + 0.05);
      }, 80);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying]);

  // 历史记录
  useEffect(() => {
    setHistory(prev => {
      const next = [...prev, { max: stats.max, avg: stats.avg, coverage: stats.coverage }];
      return next.length > 120 ? next.slice(-120) : next;
    });
  }, [stats]);

  const reset = useCallback(() => {
    setTime(0);
    setHistory([]);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* 顶部导航 */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                <ArrowLeft className="w-3.5 h-3.5" />
                返回主界面
              </Button>
            </Link>
            <div className="hidden sm:flex items-center gap-2">
              <Grid3X3 className="w-5 h-5 text-primary" />
              <h1 className="text-base font-semibold">矩阵压力传感器 · 交互式报告</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsPlaying(!isPlaying)}
              className="gap-1.5 text-xs"
            >
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {isPlaying ? "暂停" : "播放"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={reset}
              className="gap-1.5 text-xs"
            >
              <RotateCcw className="w-3 h-3" />
              重置
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
        {/* 系统概览卡片 */}
        <section>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Info className="w-5 h-5 text-primary" />
            系统概览
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: <Cpu className="w-4 h-4" />, label: "传感器类型", value: "恩迪座椅 23×23", color: "#6366f1" },
              { icon: <Layers className="w-4 h-4" />, label: "矩阵规模", value: "529 点", color: "#10b981" },
              { icon: <Gauge className="w-4 h-4" />, label: "通信速率", value: "1 Mbaud", color: "#f59e0b" },
              { icon: <Clock className="w-4 h-4" />, label: "帧大小", value: "1024 字节", color: "#ec4899" },
            ].map((item, i) => (
              <div
                key={i}
                className="rounded-xl border border-border/50 bg-card/50 p-4 transition-all hover:bg-card/80 hover:border-border"
                style={{ borderLeftColor: item.color, borderLeftWidth: 3 }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <span style={{ color: item.color }}>{item.icon}</span>
                  <span className="text-xs text-muted-foreground">{item.label}</span>
                </div>
                <div className="font-mono text-lg font-semibold">{item.value}</div>
              </div>
            ))}
          </div>
        </section>

        {/* 实时热力图 + 统计 */}
        <section>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            实时数据可视化
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 热力图 */}
            <div className="lg:col-span-2 rounded-xl border border-border/50 bg-card/30 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Eye className="w-4 h-4 text-primary" />
                  热力图
                </h3>
                <span className="text-[10px] font-mono text-muted-foreground">
                  t = {time.toFixed(2)}s
                </span>
              </div>
              <div className="flex justify-center">
                <MiniHeatmap matrix={matrix} size={400} />
              </div>
              <div className="flex items-center gap-2 mt-3 px-4">
                <span className="text-[10px] font-mono text-muted-foreground">0</span>
                <div className="flex-1 h-3 rounded-sm" style={{ background: getColorGradient() }} />
                <span className="text-[10px] font-mono text-muted-foreground">255</span>
              </div>
            </div>

            {/* 实时统计 */}
            <div className="space-y-3">
              {[
                { icon: <ArrowUp className="w-4 h-4" />, label: "最大值", value: stats.max, hex: `0x${stats.max.toString(16).toUpperCase().padStart(2, "0")}`, color: "#f59e0b" },
                { icon: <ArrowDown className="w-4 h-4" />, label: "最小值", value: stats.min, color: "#6366f1" },
                { icon: <TrendingUp className="w-4 h-4" />, label: "非零最小值", value: stats.nonZeroMin, color: "#22d3ee" },
                { icon: <Activity className="w-4 h-4" />, label: "平均值", value: stats.avg, color: "#a78bfa" },
                { icon: <Zap className="w-4 h-4" />, label: "总和", value: stats.sum, color: "#f97316" },
                { icon: <Hash className="w-4 h-4" />, label: "非零点数", value: `${stats.nonZeroCount} / ${stats.total}`, color: "#34d399" },
                { icon: <Eye className="w-4 h-4" />, label: "覆盖率", value: `${stats.coverage}%`, color: "#fb923c" },
              ].map((item, i) => (
                <div
                  key={i}
                  className="rounded-lg border border-border/50 bg-card/50 p-3 transition-colors hover:bg-card/80"
                  style={{ borderLeftColor: item.color, borderLeftWidth: 3 }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span style={{ color: item.color }}>{item.icon}</span>
                    <span className="text-[11px] text-muted-foreground">{item.label}</span>
                  </div>
                  <div className="font-mono text-lg font-semibold">
                    {item.value}
                    {"hex" in item && item.hex && (
                      <span className="text-xs text-muted-foreground ml-2">({item.hex})</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 分析图表标签页 */}
        <section>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            数据分析
          </h2>

          <Tabs defaultValue="distribution" className="w-full">
            <TabsList className="bg-secondary/50 mb-4">
              <TabsTrigger value="distribution">压力分布</TabsTrigger>
              <TabsTrigger value="timeseries">时间序列</TabsTrigger>
              <TabsTrigger value="surface">3D 表面</TabsTrigger>
              <TabsTrigger value="profile">行剖面</TabsTrigger>
            </TabsList>

            <TabsContent value="distribution">
              <div className="rounded-xl border border-border/50 bg-card/30 p-6">
                <h3 className="text-sm font-semibold mb-4">压力值分布直方图</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  显示当前帧中所有传感器点的压力值分布情况。X轴为压力值范围(0-255)，Y轴为该范围内的传感器点数量。
                  颜色对应 Inferno 色谱映射。
                </p>
                <div className="flex justify-center">
                  <DistributionChart matrix={matrix} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="timeseries">
              <div className="rounded-xl border border-border/50 bg-card/30 p-6">
                <h3 className="text-sm font-semibold mb-4">时间序列趋势图</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  追踪最近 120 帧的最大值、平均值和覆盖率变化趋势。可用于观察压力分布的动态变化规律。
                </p>
                <div className="flex justify-center">
                  <TimeSeriesChart history={history} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="surface">
              <div className="rounded-xl border border-border/50 bg-card/30 p-6">
                <h3 className="text-sm font-semibold mb-4">3D 压力表面图</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  以等距投影方式展示压力矩阵的三维表面形态。高度和颜色均映射到压力值，直观展示压力分布的空间特征。
                </p>
                <div className="flex justify-center">
                  <Surface3D matrix={matrix} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="profile">
              <div className="rounded-xl border border-border/50 bg-card/30 p-6">
                <h3 className="text-sm font-semibold mb-4">行压力剖面图</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  选择矩阵中的某一行，查看该行所有列的压力值分布曲线。可用于分析特定区域的压力特征。
                </p>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-xs text-muted-foreground">选择行:</span>
                  <input
                    type="range"
                    min={0}
                    max={22}
                    value={selectedRow}
                    onChange={(e) => setSelectedRow(parseInt(e.target.value))}
                    className="w-40 accent-primary"
                  />
                  <span className="font-mono text-sm text-primary">{selectedRow}</span>
                </div>
                <div className="flex justify-center">
                  <ProfileChart matrix={matrix} selectedRow={selectedRow} />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* 功能说明 */}
        <section>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-primary" />
            功能特性
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                title: "实时热力图",
                desc: "23×23 矩阵压力数据实时渲染，使用 Inferno 色谱映射，支持网格线和数值叠加显示。",
                icon: <Grid3X3 className="w-5 h-5" />,
              },
              {
                title: "串口通信",
                desc: "通过 Web Serial API 直连传感器设备，1Mbaud 高速通信，自动帧同步和数据解析。",
                icon: <Cpu className="w-5 h-5" />,
              },
              {
                title: "噪点检测",
                desc: "支持中值滤波、统计判别、自适应三种噪点检测算法，可调节灵敏度参数。",
                icon: <Eye className="w-5 h-5" />,
              },
              {
                title: "帧采集与导出",
                desc: "支持手动采集关键帧数据，批量导出为 CSV 格式，便于后续分析处理。",
                icon: <BarChart3 className="w-5 h-5" />,
              },
              {
                title: "CSV 数据回放",
                desc: "导入历史 CSV 数据文件，支持帧级回放、暂停、快进，重现历史压力分布。",
                icon: <Clock className="w-5 h-5" />,
              },
              {
                title: "演示模式",
                desc: "内置模拟数据生成器，无需硬件即可体验完整功能，多压力中心动态模拟。",
                icon: <Play className="w-5 h-5" />,
              },
            ].map((feat, i) => (
              <div
                key={i}
                className="rounded-xl border border-border/50 bg-card/30 p-5 transition-all hover:bg-card/50 hover:border-primary/30 group"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20 transition-colors">
                    {feat.icon}
                  </div>
                  <h3 className="text-sm font-semibold">{feat.title}</h3>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* 技术规格表 */}
        <section className="pb-12">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Gauge className="w-5 h-5 text-primary" />
            技术规格
          </h2>
          <div className="rounded-xl border border-border/50 bg-card/30 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50 bg-secondary/30">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground">参数</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground">恩迪座椅 23×23</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground">靠背传感器 32×25</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["矩阵尺寸", "23 × 23", "32 × 25"],
                  ["传感器点数", "529", "800"],
                  ["帧数据大小", "1024 字节", "1024 字节"],
                  ["原始步长", "32", "32"],
                  ["通信速率", "1,000,000 baud", "1,000,000 baud"],
                  ["数据位", "8", "8"],
                  ["停止位", "1", "1"],
                  ["帧分隔符", "AA 55 03 99", "AA 55 03 99"],
                  ["压力范围", "0 - 255", "0 - 255"],
                  ["线序映射", "自定义映射", "自定义映射"],
                ].map(([param, v1, v2], i) => (
                  <tr key={i} className="border-b border-border/30 hover:bg-secondary/20 transition-colors">
                    <td className="px-5 py-2.5 text-xs font-medium text-muted-foreground">{param}</td>
                    <td className="px-5 py-2.5 font-mono text-xs">{v1}</td>
                    <td className="px-5 py-2.5 font-mono text-xs">{v2}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
