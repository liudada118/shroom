/**
 * 应用版本号 单一来源 (Single Source of Truth)
 * ----------------------------------------------------
 * 所有显示版本号的位置（页面副标题、浏览器 title、Report 页头、应用名称等）
 * 都应从此处导入，避免再次出现"package.json 是 2.6.6 但页面上仍显示 V2.6.1"
 * 的版本不一致问题。
 *
 * 升版规则（用户约定）：
 *   - 每次修改修订号 +1：V2.6.6 → V2.6.7 → ... → V2.6.9
 *   - 修订号到 9 后，次版本号 +1，修订号归 0：V2.6.9 → V2.7.0
 *   - 次版本号到 9 后，主版本号 +1，次版本号和修订号归 0：V2.9.9 → V3.0.0
 *
 * 升版时：同步更新本文件、package.json#version、Home/Report 页注释顶端标记。
 */
export const APP_VERSION = "V2.7.110" as const;
export const APP_NAME = "矩阵压力传感器实时热力图" as const;
export const APP_FULL_TITLE = `${APP_NAME} ${APP_VERSION}` as const;
