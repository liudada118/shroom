/**
 * 压强标定函数模块（V2.7.67）
 *
 * 当前标定链路：
 * - 有效点数 ≤ 300：先由排序区间均值拟合目标平均压强，再按各有效点基础曲线响应比例分配 P(ADCᵢ)。
 * - 有效点数 > 300：全部有效点逐点进入对应基础公式，逐点乘传感器独立动态系数 k。
 * - 坐垫显示与标定输入改为逐帧补偿后ADC，节点已做等价坐标变换；靠背因补偿文件未提供系数而保持原ADC域。
 * - 双传感器使用处理版第一张工作表E/G列凸分段线性：连续严格递增，且分段斜率逐段增大。
 * - 砝码段严格保证 AVG(Pᵢ)=拟合平均压强，最大压强取 MAX(Pᵢ)，归一化后不二次钳制。
 * - 真人段保持逐点基础公式 × 传感器独立 k，平均/最大压强分别取逐点结果的算术平均/最大值。
 */

export interface PressureSegment {
  lo: number;
  hi: number;
  a: number;
  b: number;
  c: number;
  /** 存在 d 时使用局部坐标 dx = ADC - lo 的三次公式。 */
  d?: number;
}

export interface CalibrationProfile {
  key: "seat" | "backrest";
  name: string;
  xAxis: string;
  /** 砝码段ADC降序排序后的起始名次（1起计，含）。 */
  topStartRank: number;
  /** 砝码段ADC降序排序后的结束名次（1起计，含）。 */
  topEndRank: number;
  segments: readonly PressureSegment[];
  /** 低于首节点时的处理：过原点、过补偿偏移原点或延用首段。 */
  lowMode: "zero-origin" | "offset-origin" | "first-segment";
  /** lowMode=offset-origin时对应原始ADC=0在补偿后ADC域中的位置。 */
  lowAdcOrigin?: number;
  leftSlope: number;
  pHi: number;
  rightSlope: number;
  /** 基础分段Praw在最终钳位前的整体倍率；默认1。 */
  outputScale?: number;
  /** 定义时表示基础公式高端直接钳制，不再执行右侧外推。 */
  highPressureClampKPa?: number;
  calibrationId: string;
  modelName: string;
  formula: string;
  r2: string;
  validationNote: string;
}

export interface FitInfo {
  name: string;
  formula: string;
  range: string;
  r2: string;
  note: string;
}

export type PressureCalibrationBranch = "weight" | "human";

/** 传感器专属输入摘要；指定排序区间均值同时保留给砝码段显示和导出。 */
export interface PressureInputSummary {
  topMean: number;
  topCount: number;
  validCount: number;
  max: number;
}

/** 矩阵压强摘要，包含本帧实际采用的标定分支与动态系数。 */
export interface PressureMetrics extends PressureInputSummary {
  avgPressureKPa: number | null;
  maxPressureKPa: number | null;
  calibrationBranch: PressureCalibrationBranch;
  humanCoefficient: number | null;
  pointPressureCount: number;
  /** 砝码段归一化后的全部有效点压强；真人段不返回此数组。 */
  pointPressuresKPa?: number[];
  /** 与输入矩阵同形状的砝码段逐点压强矩阵；无效点为0。 */
  pressureMatrixKPa?: number[][];
  /** 砝码段基础曲线响应 F(ADCᵢ) 的平均值。 */
  curveResponseMeanKPa?: number | null;
  /** 砝码段比例归一化系数：拟合平均压强 / 曲线响应平均值。 */
  normalizationScale?: number | null;
  /** 砝码段实际逐点平均值与目标平均值之差。 */
  meanConservationErrorKPa?: number | null;
  /** 砝码段异常回退模式。 */
  pointPressureFallbackMode?: "none" | "no-valid-points" | "all-zero" | "equal-distribution" | null;
}

export interface WeightPointPressureDistribution extends PressureInputSummary {
  targetAveragePressureKPa: number | null;
  actualAveragePressureKPa: number | null;
  maxPressureKPa: number | null;
  pointPressuresKPa: number[];
  pressureMatrixKPa: number[][];
  curveResponseMeanKPa: number;
  normalizationScale: number | null;
  meanConservationErrorKPa: number | null;
  fallbackMode: "none" | "no-valid-points" | "all-zero" | "equal-distribution";
}

/** 保留给采集状态判断使用。 */
export const MIN_VALID_POINTS = 3;

/** 真人段严格在有效点数大于 300 时启用。 */
export const HUMAN_VALID_POINT_THRESHOLD = 300;
export const DEFAULT_HUMAN_COEFFICIENT = 2.2;
export const MIN_HUMAN_COEFFICIENT = 1;
export const MAX_HUMAN_COEFFICIENT = 6;
export const HUMAN_COEFFICIENT_STEP = 0.1;
const NORMALIZATION_EPSILON = 1e-12;

export const CALIBRATION_VERSION = "V2.7.67" as const;

/**
 * 坐垫基础标定：V2.7.63原曲线严格换算到补偿后ADC坐标域。
 * 原始ADC先执行ADC'=1.0069947916666666×ADC+6.018421875，再由本曲线标定；压力结果与换算前在机器精度内等价。
 */
export const SEAT_SEGMENTS: readonly PressureSegment[] = [
  { lo: 60.2350214583333, hi: 67.7811886783854, a: 2.2732, b: 0.059583227735165, c: 0, d: 0 },
  { lo: 67.7811886783854, hi: 75.3273558984375, a: 2.722825, b: 0.0633830683108733, c: 0, d: 0 },
  { lo: 75.3273558984375, hi: 82.8735231184896, a: 3.20112423239383, b: 0.0663622296976314, c: 0, d: 0 },
  { lo: 82.8735231184896, hi: 90.4196903385417, a: 3.70190471478767, b: 0.0693413910843896, c: 0, d: 0 },
  { lo: 90.4196903385417, hi: 97.9658575585938, a: 4.2251664471815, b: 0.0723205524711478, c: 0, d: 0 },
  { lo: 97.9658575585938, hi: 105.512024778646, a: 4.77090942957533, b: 0.075299713857906, c: 0, d: 0 },
  { lo: 105.512024778646, hi: 113.058191998698, a: 5.33913366196916, b: 0.0782788752446643, c: 0, d: 0 },
  { lo: 113.058191998698, hi: 120.60435921875, a: 5.929839144363, b: 0.125356717547255, c: 0, d: 0 },
  { lo: 120.60435921875, hi: 128.150526438802, a: 6.87580189713142, b: 0.128335878934012, c: 0, d: 0 },
  { lo: 128.150526438802, hi: 135.696693658854, a: 7.84424589989983, b: 0.155522523731217, c: 0, d: 0 },
  { lo: 135.696693658854, hi: 143.242860878906, a: 9.01784487046011, b: 0.158501685117975, c: 0, d: 0 },
  { lo: 143.242860878906, hi: 150.789028098958, a: 10.2139250910204, b: 0.336096346245174, c: 0, d: 0 },
  { lo: 150.789028098958, hi: 158.33519531901, a: 12.750164321835, b: 0.339075507631933, c: 0, d: 0 },
  { lo: 158.33519531901, hi: 165.881362539062, a: 15.3088848026496, b: 0.342054669018692, c: 0, d: 0 },
  { lo: 165.881362539062, hi: 173.427529759115, a: 17.8900865334642, b: 0.480599177497908, c: 0, d: 0 },
  { lo: 173.427529759115, hi: 180.973696979167, a: 21.5167682926829, b: 0.72662472847762, c: 0, d: 0 },
];

/** 靠背基础标定：斜率逐段增大的凸19节点18段线性；斜率由0.0400逐段增加到0.5141kPa/ADC；ADC=189.43达到27.00kPa后钳位。 */
export const BACKREST_SEGMENTS: readonly PressureSegment[] = [
  { lo: 64.93, hi: 77.99578947368421, a: 2.171199999999999, b: 0.04000000000000015, c: 0, d: 0 },
  { lo: 77.99578947368421, hi: 107.9942105263158, a: 2.693831578947369, b: 0.07152099258507517, c: 0, d: 0 },
  { lo: 107.9942105263158, hi: 116.5842105263158, a: 4.839348428616596, b: 0.07452099258507523, c: 0, d: 0 },
  { lo: 116.5842105263158, hi: 128.00263157894736, a: 5.479483754922392, b: 0.14953903662226653, c: 0, d: 0 },
  { lo: 128.00263157894736, hi: 135.86894736842106, a: 7.186983438880322, b: 0.1525390366222664, c: 0, d: 0 },
  { lo: 135.86894736842106, hi: 142.54315789473685, a: 8.386903671173163, b: 0.15553903662226615, c: 0, d: 0 },
  { lo: 142.54315789473685, hi: 148.77052631578945, a: 9.42500394665051, b: 0.15853903662226654, c: 0, d: 0 },
  { lo: 148.77052631578945, hi: 154.32736842105265, a: 10.412284936816114, b: 0.2465713823659119, c: 0, d: 0 },
  { lo: 154.32736842105265, hi: 159.07789473684213, a: 11.782443176299966, b: 0.2495713823659125, c: 0, d: 0 },
  { lo: 159.07789473684213, hi: 162.78105263157894, a: 12.96803859589719, b: 0.39822322147755757, c: 0, d: 0 },
  { lo: 162.78105263157894, hi: 165.38210526315788, a: 14.442722062379335, b: 0.4012232214775568, c: 0, d: 0 },
  { lo: 165.38210526315788, hi: 170.20105263157893, a: 15.486324778454113, b: 0.40422322147755524, c: 0, d: 0 },
  { lo: 170.20105263157893, hi: 173.70842105263156, a: 17.434255207848057, b: 0.44139613105542036, c: 0, d: 0 },
  { lo: 173.70842105263156, hi: 175.1836842105263, a: 18.982394059086648, b: 0.5020594652919378, c: 0, d: 0 },
  { lo: 175.1836842105263, hi: 178.69052631578947, a: 19.72306389130418, b: 0.5050594652919369, c: 0, d: 0 },
  { lo: 178.69052631578947, hi: 180.56894736842105, a: 21.49422768985164, b: 0.5080594652919352, c: 0, d: 0 },
  { lo: 180.56894736842105, hi: 181.79736842105265, a: 22.448577285444756, b: 0.5110594652919322, c: 0, d: 0 },
  { lo: 181.79736842105265, hi: 189.43, a: 23.076373491756016, b: 0.514059465291931, c: 0, d: 0 },
];

export const SEAT_CALIBRATION: CalibrationProfile = {
  key: "seat",
  name: "坐垫",
  xAxis: "补偿后有效 ADC 降序第 5—70 位均值",
  topStartRank: 5,
  topEndRank: 70,
  segments: SEAT_SEGMENTS,
  lowMode: "offset-origin",
  lowAdcOrigin: 6.018421875000001,
  leftSlope: 0.04192811827872,
  pHi: 27,
  rightSlope: 0,
  highPressureClampKPa: 27,
  calibrationId: "SeatAdcCompensatedConvexIncreasing27Linear17Node-20260901",
  modelName: "逐帧ADC补偿后凸线性17节点16段",
  formula: "P=F(ADC')；ADC'由当前坐垫补偿模块输出；ADC'>180.974时P=27.00",
  r2: "全40帧 R²=0.9882；LOPO R²=0.9843",
  validationNote: "标定输入ADC'始终来自当前坐垫补偿模块，模块可独立启停并修改倍率/偏移；随后ADC'≤30过滤为0，显示与标定共用同一矩阵。节点基于默认JSON参数换算到补偿后ADC域；关闭或修改补偿参数会直接改变标定输入。ADC'=180.974后钳位27.00kPa。",
};

export const BACKREST_CALIBRATION: CalibrationProfile = {
  key: "backrest",
  name: "靠背",
  xAxis: "有效 ADC 最高 TOP46 均值",
  topStartRank: 1,
  topEndRank: 46,
  segments: BACKREST_SEGMENTS,
  lowMode: "zero-origin",
  leftSlope: 0.033439088248883412,
  pHi: 27,
  rightSlope: 0,
  outputScale: 1,
  highPressureClampKPa: 27,
  calibrationId: "BackrestProcessedConvexIncreasing27Linear19Node-20260901",
  modelName: "处理版E/G斜率逐段增大凸线性19节点18段",
  formula: "P=a+b·ΔADC；0.0400≤b₁<b₂<…<b₁₈≤0.5141；TOP46均值ADC>189.430时P=27.00",
  r2: "全50帧 R²=0.9846；LOPO R²=0.9808",
  validationNote: "基于《靠背处理版.xlsx》50帧/5位置组执行凸约束拟合：压强连续严格上升，18段斜率由0.0400逐段增加到0.5141kPa/ADC，相邻斜率至少增加0.0030。全50帧RMSE=0.891kPa、最大误差=2.490kPa，50/50满足±2.50kPa。留一位置RMSE=0.994kPa，49/50满足±2.50kPa，位置组4最坏2.579kPa，建议独立复测。TOP46均值ADC=189.430后钳位27.00kPa。",
};

function isBackrestSensor(sensorType?: string): boolean {
  return sensorType === "new-backrest-32x25" || sensorType === "backrest-32x25" || sensorType === "backrest";
}

function getProfile(sensorType?: string): CalibrationProfile {
  return isBackrestSensor(sensorType) ? BACKREST_CALIBRATION : SEAT_CALIBRATION;
}

/** 将真人段动态系数限制在产品允许范围内，非法输入回退到默认值。 */
export function normalizeHumanCoefficient(value?: number): number {
  if (!Number.isFinite(value)) return DEFAULT_HUMAN_COEFFICIENT;
  return Math.min(MAX_HUMAN_COEFFICIENT, Math.max(MIN_HUMAN_COEFFICIENT, Number(value)));
}

/** 返回当前传感器砝码段排序区间的理论选点数量：坐垫66点、靠背46点。 */
export function getPressureTopCount(sensorType?: string): number {
  const profile = getProfile(sensorType);
  return profile.topEndRank - profile.topStartRank + 1;
}

/** 返回当前传感器砝码段ADC输入的降序排序区间标签。 */
export function getPressureInputLabel(sensorType?: string): string {
  const profile = getProfile(sensorType);
  if (profile.topStartRank === 1) return `TOP${profile.topEndRank}`;
  return `第${profile.topStartRank}—${profile.topEndRank}位`;
}

/**
 * 从已过滤的插值矩阵中取传感器专属排序区间均值。
 * 有效 ADC 降序排序后，坐垫取第5—70位，靠背取最高TOP46；
 * 坐垫不足第5位时退回全部有效点；靠背不足46点时取全部有效点。
 */
export function getPressureInputFromMatrix(
  matrix: ReadonlyArray<ReadonlyArray<number>>,
  sensorType?: string,
): PressureInputSummary {
  const profile = getProfile(sensorType);
  const values: number[] = [];
  for (const row of matrix) {
    for (const value of row) {
      if (Number.isFinite(value) && value > 0) values.push(value);
    }
  }
  values.sort((a, b) => b - a);
  const startIndex = values.length >= profile.topStartRank ? profile.topStartRank - 1 : 0;
  const endExclusive = Math.min(profile.topEndRank, values.length);
  const selectedValues = values.slice(startIndex, endExclusive);
  const topCount = selectedValues.length;
  const topMean = topCount > 0
    ? selectedValues.reduce((sum, value) => sum + value, 0) / topCount
    : 0;
  return { topMean, topCount, validCount: values.length, max: values[0] ?? 0 };
}

/**
 * 实时显示、采集快照和 CSV/XLSX 导出共用的矩阵压强计算入口。
 * 有效点数 ≤ 300 使用指定排序区间的砝码链路；有效点数 > 300 进入真人段逐点链路。
 */
export function calculatePressureMetricsFromMatrix(
  matrix: ReadonlyArray<ReadonlyArray<number>>,
  sensorType?: string,
  humanCoefficient: number = DEFAULT_HUMAN_COEFFICIENT,
): PressureMetrics {
  const input = getPressureInputFromMatrix(matrix, sensorType);
  const profile = getProfile(sensorType);

  if (input.validCount > HUMAN_VALID_POINT_THRESHOLD) {
    const coefficient = normalizeHumanCoefficient(humanCoefficient);
    let pressureSum = 0;
    let pressureMax = 0;
    let pointPressureCount = 0;
    const pointPressuresKPa: number[] = [];
    const pressureMatrixKPa = matrix.map((row) => row.map(() => 0));

    for (let rowIndex = 0; rowIndex < matrix.length; rowIndex++) {
      for (let columnIndex = 0; columnIndex < matrix[rowIndex].length; columnIndex++) {
        const value = matrix[rowIndex][columnIndex];
        if (!Number.isFinite(value) || value <= 0) continue;
        const pointPressure = calculateWeightPressure(value, profile);
        if (pointPressure === null) continue;
        const scaledPressure = pointPressure * coefficient;
        pressureSum += scaledPressure;
        if (scaledPressure > pressureMax) pressureMax = scaledPressure;
        pointPressuresKPa.push(scaledPressure);
        pressureMatrixKPa[rowIndex][columnIndex] = scaledPressure;
        pointPressureCount++;
      }
    }

    return {
      ...input,
      avgPressureKPa: pointPressureCount > 0 ? roundPressure(pressureSum / pointPressureCount) : null,
      maxPressureKPa: pointPressureCount > 0 ? roundPressure(pressureMax) : null,
      calibrationBranch: "human",
      humanCoefficient: coefficient,
      pointPressureCount,
      pointPressuresKPa,
      pressureMatrixKPa,
    };
  }

  const distribution = calculateWeightPointPressuresFromMatrix(matrix, sensorType);
  return {
    ...input,
    avgPressureKPa: distribution.targetAveragePressureKPa === null
      ? null
      : roundPressure(distribution.targetAveragePressureKPa),
    maxPressureKPa: distribution.maxPressureKPa === null
      ? null
      : roundPressure(distribution.maxPressureKPa),
    calibrationBranch: "weight",
    humanCoefficient: null,
    pointPressureCount: distribution.pointPressuresKPa.length,
    pointPressuresKPa: distribution.pointPressuresKPa,
    pressureMatrixKPa: distribution.pressureMatrixKPa,
    curveResponseMeanKPa: distribution.curveResponseMeanKPa,
    normalizationScale: distribution.normalizationScale,
    meanConservationErrorKPa: distribution.meanConservationErrorKPa,
    pointPressureFallbackMode: distribution.fallbackMode,
  };
}

function roundPressure(value: number): number {
  return Number(Math.max(0, value).toFixed(2));
}

function clampProfilePressure(value: number, profile: CalibrationProfile): number {
  const scaledValue = value * (profile.outputScale ?? 1);
  const zeroClamped = Math.max(0, scaledValue);
  return profile.highPressureClampKPa === undefined
    ? zeroClamped
    : Math.min(profile.highPressureClampKPa, zeroClamped);
}

/** 执行传感器对应的基础分段标定，再按各自 profile 执行0—27kPa高端钳位。 */
function calculateWeightPressure(adc: number, profile: CalibrationProfile): number | null {
  if (adc <= 0 || profile.segments.length === 0) return null;

  const first = profile.segments[0];
  const last = profile.segments[profile.segments.length - 1];
  if (adc <= first.lo) {
    if (profile.lowMode === "zero-origin") {
      return clampProfilePressure(profile.leftSlope * adc, profile);
    }
    if (profile.lowMode === "offset-origin") {
      return clampProfilePressure(profile.leftSlope * Math.max(0, adc - (profile.lowAdcOrigin ?? 0)), profile);
    }
    const dx = adc - first.lo;
    return clampProfilePressure(first.a + first.b * dx + first.c * dx * dx + (first.d ?? 0) * dx * dx * dx, profile);
  }
  if (adc > last.hi) {
    if (profile.highPressureClampKPa !== undefined) return profile.highPressureClampKPa;
    return clampProfilePressure(profile.pHi + profile.rightSlope * (adc - last.hi), profile);
  }

  for (const segment of profile.segments) {
    if (adc <= segment.hi) {
      if (segment.d !== undefined) {
        const dx = adc - segment.lo;
        return clampProfilePressure(segment.a + segment.b * dx + segment.c * dx * dx + segment.d * dx * dx * dx, profile);
      }
      return clampProfilePressure(segment.a * adc * adc + segment.b * adc + segment.c, profile);
    }
  }
  return null;
}

/**
 * 砝码段逐点压强比例归一化。
 *
 * P̄ = F(X)，qᵢ = F(ADCᵢ)，Pᵢ = P̄ × qᵢ / AVG(q)。
 * 最后一个有效点仅修正浮点累计误差，从而在机器精度内严格满足 AVG(Pᵢ)=P̄。
 * 归一化后的 Pᵢ 不再执行各自基础曲线高端上限的二次钳制，否则会破坏均值守恒。
 */
export function calculateWeightPointPressuresFromMatrix(
  matrix: ReadonlyArray<ReadonlyArray<number>>,
  sensorType?: string,
): WeightPointPressureDistribution {
  const input = getPressureInputFromMatrix(matrix, sensorType);
  if (input.validCount > HUMAN_VALID_POINT_THRESHOLD) {
    throw new RangeError(`砝码段逐点压强仅适用于有效点数≤${HUMAN_VALID_POINT_THRESHOLD}`);
  }

  const profile = getProfile(sensorType);
  const pressureMatrixKPa = matrix.map((row) => row.map(() => 0));
  const validPoints: Array<{ row: number; column: number; response: number }> = [];

  for (let row = 0; row < matrix.length; row++) {
    for (let column = 0; column < matrix[row].length; column++) {
      const adc = matrix[row][column];
      if (!Number.isFinite(adc) || adc <= 0) continue;
      const response = calculateWeightPressure(adc, profile);
      validPoints.push({ row, column, response: response === null ? 0 : Math.max(0, response) });
    }
  }

  if (validPoints.length === 0) {
    return {
      ...input,
      targetAveragePressureKPa: null,
      actualAveragePressureKPa: null,
      maxPressureKPa: null,
      pointPressuresKPa: [],
      pressureMatrixKPa,
      curveResponseMeanKPa: 0,
      normalizationScale: null,
      meanConservationErrorKPa: null,
      fallbackMode: "no-valid-points",
    };
  }

  const fittedAverage = calculateWeightPressure(input.topMean, profile);
  if (fittedAverage === null || !Number.isFinite(fittedAverage)) {
    throw new RangeError("基础公式无法为排序ADC均值计算砝码段目标平均压强");
  }
  const targetAveragePressureKPa = Math.max(0, fittedAverage);
  const curveResponseMeanKPa = validPoints.reduce((sum, point) => sum + point.response, 0) / validPoints.length;

  let pointPressuresKPa: number[];
  let normalizationScale: number | null = null;
  let fallbackMode: WeightPointPressureDistribution["fallbackMode"] = "none";
  if (targetAveragePressureKPa <= NORMALIZATION_EPSILON) {
    pointPressuresKPa = validPoints.map(() => 0);
    normalizationScale = curveResponseMeanKPa > NORMALIZATION_EPSILON ? 0 : null;
    fallbackMode = "all-zero";
  } else if (curveResponseMeanKPa <= NORMALIZATION_EPSILON) {
    pointPressuresKPa = validPoints.map(() => targetAveragePressureKPa);
    fallbackMode = "equal-distribution";
  } else {
    normalizationScale = targetAveragePressureKPa / curveResponseMeanKPa;
    pointPressuresKPa = validPoints.map((point) => point.response * normalizationScale!);
  }

  const targetSum = targetAveragePressureKPa * pointPressuresKPa.length;
  const currentSum = pointPressuresKPa.reduce((sum, value) => sum + value, 0);
  pointPressuresKPa[pointPressuresKPa.length - 1] += targetSum - currentSum;

  for (let index = 0; index < validPoints.length; index++) {
    const point = validPoints[index];
    pressureMatrixKPa[point.row][point.column] = pointPressuresKPa[index];
  }
  const actualAveragePressureKPa = pointPressuresKPa.reduce((sum, value) => sum + value, 0) / pointPressuresKPa.length;
  return {
    ...input,
    targetAveragePressureKPa,
    actualAveragePressureKPa,
    maxPressureKPa: Math.max(...pointPressuresKPa),
    pointPressuresKPa,
    pressureMatrixKPa,
    curveResponseMeanKPa,
    normalizationScale,
    meanConservationErrorKPa: actualAveragePressureKPa - targetAveragePressureKPa,
    fallbackMode,
  };
}

/**
 * 标量基础平均压强兼容入口；砝码段整帧逐点归一化必须使用 calculatePressureMetricsFromMatrix。
 * 真人段必须基于完整矩阵逐点计算，因此仅由 calculatePressureMetricsFromMatrix 派发。
 */
function estimatePressureForProfile(
  adcAvg: number,
  _nonZeroCount: number | undefined,
  profile: CalibrationProfile,
): number | null {
  if (adcAvg <= 0) return null;
  const weightPressure = calculateWeightPressure(adcAvg, profile);
  return weightPressure === null ? null : roundPressure(weightPressure);
}

function estimateMaximumForProfile(
  adcMax: number,
  nonZeroCount: number | undefined,
  profile: CalibrationProfile,
  adcAvg: number | undefined,
): number | null {
  if (adcMax <= 0 || adcAvg === undefined || adcAvg <= 0) return null;
  const avgPressure = estimatePressureForProfile(adcAvg, nonZeroCount, profile);
  if (avgPressure === null || avgPressure <= 0) return null;
  const proportionalMaximum = avgPressure * (adcMax / adcAvg);
  return roundPressure(
    profile.highPressureClampKPa !== undefined
      ? Math.min(profile.highPressureClampKPa, proportionalMaximum)
      : proportionalMaximum,
  );
}

/** 兼容坐垫调用的平均压强入口。 */
export function estimateAvgPressure(avg: number, nonZeroCount?: number): number | null {
  return estimatePressureForProfile(avg, nonZeroCount, SEAT_CALIBRATION);
}

/** 旧版坐垫标量最大压强兼容入口；不代表当前砝码段 MAX(Pᵢ) 整帧结果。 */
export function estimateMaxPressure(max: number, nonZeroCount?: number, avg?: number): number | null {
  return estimateMaximumForProfile(max, nonZeroCount, SEAT_CALIBRATION, avg);
}

/** 兼容靠背调用的平均压强入口。 */
export function estimateBackrestAvgPressure(avg: number, nonZeroCount?: number): number | null {
  return estimatePressureForProfile(avg, nonZeroCount, BACKREST_CALIBRATION);
}

/** 旧版靠背标量最大压强兼容入口；不代表当前砝码段 MAX(Pᵢ) 整帧结果。 */
export function estimateBackrestMaxPressure(max: number, nonZeroCount?: number, avg?: number): number | null {
  return estimateMaximumForProfile(max, nonZeroCount, BACKREST_CALIBRATION, avg);
}

/** 按传感器类型派发砝码段平均压强标量公式。 */
export function estimateAvgPressureAuto(
  avg: number,
  nonZeroCount?: number,
  sensorType?: string,
): number | null {
  return estimatePressureForProfile(avg, nonZeroCount, getProfile(sensorType));
}

/** 旧版最大压强标量兼容入口；当前砝码段必须使用矩阵入口计算 MAX(Pᵢ)。 */
export function estimateMaxPressureAuto(
  max: number,
  nonZeroCount?: number,
  sensorType?: string,
  avg?: number,
): number | null {
  return estimateMaximumForProfile(max, nonZeroCount, getProfile(sensorType), avg);
}

function getAverageFitInfo(
  profile: CalibrationProfile,
  nonZeroCount?: number,
  humanCoefficient: number = DEFAULT_HUMAN_COEFFICIENT,
): FitInfo {
  const first = profile.segments[0];
  const last = profile.segments[profile.segments.length - 1];
  if ((nonZeroCount ?? 0) > HUMAN_VALID_POINT_THRESHOLD) {
    const coefficient = normalizeHumanCoefficient(humanCoefficient);
    return {
      name: `${profile.name}真人段平均压强（逐点用户公式 × k）`,
      formula: `P_avg = mean(F(ADCᵢ) × ${coefficient.toFixed(1)})`,
      range: `有效点数 > ${HUMAN_VALID_POINT_THRESHOLD}`,
      r2: profile.r2,
      note: profile.highPressureClampKPa !== undefined
        ? `每个有效点分别使用${profile.modelName}；基础结果先钳位到0—${profile.highPressureClampKPa.toFixed(2)} kPa，再乘动态系数 k=${coefficient.toFixed(1)}，最后对全部逐点压强取算术平均。`
        : `每个有效点分别使用${profile.modelName}及范围外线性外推，再乘动态系数 k=${coefficient.toFixed(1)}，最后对全部逐点压强取算术平均。`,
    };
  }
  return {
    name: `${profile.name}砝码段逐点压强（${profile.modelName} · ${profile.calibrationId}）`,
    formula: "P̄=F(X)；qᵢ=F(ADCᵢ)；Pᵢ=P̄×qᵢ/AVG(q)；P_avg=AVG(Pᵢ)=P̄",
    range: profile.highPressureClampKPa !== undefined
      ? `${profile.xAxis} ∈ [${first.lo.toFixed(3)}, ${last.hi.toFixed(3)}]；高于上限时钳制 ${profile.highPressureClampKPa.toFixed(2)} kPa`
      : `${profile.xAxis} ∈ [${first.lo.toFixed(3)}, ${last.hi.toFixed(3)}]；范围外线性外推`,
    r2: profile.r2,
    note: profile.highPressureClampKPa !== undefined
      ? `${profile.xAxis} 是目标平均压强公式输入；过滤后全部有效点分别计算基础曲线响应，再按比例归一化，严格保持 AVG(Pᵢ)=P̄。基础曲线响应钳位到0—${profile.highPressureClampKPa.toFixed(2)} kPa；归一化后的Pᵢ不二次钳制。${profile.validationNote}`
      : `${profile.xAxis} 是公式输入；过滤后有效 ADC 先按降序排序，再取第${profile.topStartRank}—${profile.topEndRank}位均值。有效点不足第${profile.topStartRank}位时取全部有效点，达到第${profile.topStartRank}位但不足第${profile.topEndRank}位时取至最后一位。低端斜率 ${profile.leftSlope.toFixed(9)}，高端从 ${profile.pHi.toFixed(2)} kPa 按斜率 ${profile.rightSlope.toFixed(6)} 外推。${profile.validationNote}`,
  };
}

function getMaximumFitInfo(
  profile: CalibrationProfile,
  nonZeroCount?: number,
  humanCoefficient: number = DEFAULT_HUMAN_COEFFICIENT,
): FitInfo {
  if ((nonZeroCount ?? 0) > HUMAN_VALID_POINT_THRESHOLD) {
    const coefficient = normalizeHumanCoefficient(humanCoefficient);
    return {
      name: `${profile.name}真人段最大压强（逐点用户公式 × k）`,
      formula: `P_max = max(F(ADCᵢ) × ${coefficient.toFixed(1)})`,
      range: `有效点数 > ${HUMAN_VALID_POINT_THRESHOLD}`,
      r2: profile.r2,
      note: profile.highPressureClampKPa !== undefined
        ? `每个有效点分别使用${profile.modelName}；基础结果先钳位到0—${profile.highPressureClampKPa.toFixed(2)} kPa，再乘动态系数 k=${coefficient.toFixed(1)}，最大压强取全部逐点结果中的最大值。`
        : `每个有效点分别使用${profile.modelName}及范围外线性外推，再乘动态系数 k=${coefficient.toFixed(1)}，最大压强取全部逐点结果中的最大值。`,
    };
  }
  return {
    name: `${profile.name}砝码段最大压强（逐点归一化 · ${profile.calibrationId}）`,
    formula: "P_max = MAX(Pᵢ) = P̄ × MAX(F(ADCᵢ)) / AVG(F(ADCᵢ))",
    range: `有效点数 ≤ ${HUMAN_VALID_POINT_THRESHOLD}；P̄ 由同一 ${profile.calibrationId} 排序输入拟合`,
    r2: "—",
    note: profile.highPressureClampKPa !== undefined
      ? `先按全部有效点的基础曲线响应比例分配Pᵢ，再取MAX(Pᵢ)。为保持AVG(Pᵢ)=P̄，归一化后的Pᵢ与P_max不再执行${profile.highPressureClampKPa.toFixed(2)} kPa二次钳制。`
      : `最大压强不单独拟合，使用平均压强与 ADC 最大值/第${profile.topStartRank}—${profile.topEndRank}位均值的比例关系计算。`,
  };
}

export function getAvgFitInfo(): FitInfo {
  return getAverageFitInfo(SEAT_CALIBRATION);
}

export function getMaxFitInfo(): FitInfo {
  return getMaximumFitInfo(SEAT_CALIBRATION);
}

export function getBackrestAvgFitInfo(): FitInfo {
  return getAverageFitInfo(BACKREST_CALIBRATION);
}

export function getBackrestMaxFitInfo(): FitInfo {
  return getMaximumFitInfo(BACKREST_CALIBRATION);
}

export function getAvgFitInfoAuto(
  sensorType?: string,
  nonZeroCount?: number,
  humanCoefficient?: number,
): FitInfo {
  return getAverageFitInfo(getProfile(sensorType), nonZeroCount, humanCoefficient);
}

export function getMaxFitInfoAuto(
  sensorType?: string,
  nonZeroCount?: number,
  humanCoefficient?: number,
): FitInfo {
  return getMaximumFitInfo(getProfile(sensorType), nonZeroCount, humanCoefficient);
}
