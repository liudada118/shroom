/**
 * 日志面板组件
 * 显示串口通信日志，支持过滤、暂停、导出
 * 
 * 原版结构: 
 * - 接收 isOpen/onToggle props（由父组件管理展开状态）
 * - 展开时 h-64，折叠时 h-9
 * - 图标: CircleDot
 * - 展开/折叠: ChevronDown(展开时) / ChevronUp(折叠时)
 */

import { memo, useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { LogEntry } from "@/hooks/useSerial";
import {
  CircleDot,
  Pause,
  Play,
  Download,
  Trash2,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const LOG_LEVELS: Record<string, { color: string; bg: string; label: string }> = {
  info: { color: "text-sky-400", bg: "bg-sky-400/10", label: "INFO" },
  warn: { color: "text-amber-400", bg: "bg-amber-400/10", label: "WARN" },
  error: { color: "text-red-400", bg: "bg-red-400/10", label: "ERROR" },
  data: { color: "text-emerald-400", bg: "bg-emerald-400/10", label: "DATA" },
};

interface LogPanelProps {
  logs: LogEntry[];
  isOpen: boolean;
  onToggle: () => void;
  onClear: () => void;
}

const ROW_HEIGHT = 20;
const OVERSCAN = 4;

const LogRow = memo(function LogRow({ log }: { log: LogEntry }) {
  const time = useMemo(() => new Date(log.timestamp).toLocaleTimeString("zh-CN", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }), [log.timestamp]);
  const style = LOG_LEVELS[log.level] || LOG_LEVELS.info;
  return (
    <div data-testid="serial-log-row"
      className="flex gap-2 hover:bg-accent/20 rounded px-1 -mx-1 overflow-hidden"
      style={{ height: ROW_HEIGHT }} title={`${log.message}${log.detail ? " | " + log.detail : ""}`}>
      <span className="text-muted-foreground/40 shrink-0">{time}</span>
      <span className={`${style.color} shrink-0 w-10`}>[{style.label}]</span>
      <span className="text-foreground/80 truncate shrink-0 max-w-[65%]">{log.message}</span>
      {log.detail && <span className="text-muted-foreground/40 truncate min-w-0">{log.detail}</span>}
    </div>
  );
});

export default memo(function LogPanel({ logs, isOpen, onToggle, onClear }: LogPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [filter, setFilter] = useState<string | null>(null);
  const [scrollTop, setScrollTop] = useState(0);

  // 日志数组不变时复用计数和过滤结果，串口实时帧不再遍历历史日志。
  const { counts, filteredLogs } = useMemo(() => {
    const counts: Record<string, number> = { info: 0, warn: 0, error: 0, data: 0 };
    const filteredLogs: LogEntry[] = [];
    for (const log of logs) {
      counts[log.level] = (counts[log.level] ?? 0) + 1;
      if (!filter || log.level === filter) filteredLogs.push(log);
    }
    return { counts, filteredLogs };
  }, [logs, filter]);

  useLayoutEffect(() => {
    if (!isOpen || !scrollRef.current) return;
    if (autoScroll) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    setScrollTop(scrollRef.current.scrollTop);
  }, [filteredLogs, autoScroll, isOpen]);

  const handleScroll = useCallback(() => {
    if (!scrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    setScrollTop(scrollTop);
    const atBottom = scrollHeight - scrollTop - clientHeight < 30;
    if (autoScroll && !atBottom) {
      setAutoScroll(false);
    }
  }, [autoScroll]);

  const viewportHeight = scrollRef.current?.clientHeight || 220;
  const visibleCount = Math.ceil(viewportHeight / ROW_HEIGHT) + OVERSCAN * 2;
  const first = Math.min(
    Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN),
    Math.max(0, filteredLogs.length - visibleCount),
  );
  const visibleLogs = filteredLogs.slice(first, first + visibleCount);

  const handleExport = useCallback(() => {
    const text = logs
      .map((l) => {
        const time = new Date(l.timestamp).toLocaleTimeString("zh-CN", {
          hour12: false,
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          fractionalSecondDigits: 3,
        } as any);
        return `[${time}] [${l.level.toUpperCase()}] ${l.message}${l.detail ? " | " + l.detail : ""}`;
      })
      .join("\n");

    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sensor_log_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [logs]);

  return (
    <div
      className={`flex-none border-t border-border/50 bg-card transition-all duration-300 ${
        isOpen ? "h-64" : "h-9"
      }`}
    >
      {/* 标题栏 */}
      <div
        className="h-9 flex items-center justify-between px-4 cursor-pointer hover:bg-accent/30 transition-colors select-none"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <CircleDot className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              日志
            </span>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground/60">
            {logs.length} 条
          </span>
          <div className="flex items-center gap-2 ml-2">
            {(["info", "warn", "error", "data"] as const).map((level) => {
              const count = counts[level];
              if (count === 0) return null;
              const style = LOG_LEVELS[level];
              return (
                <button
                  key={level}
                  onClick={(e) => {
                    e.stopPropagation();
                    setFilter(filter === level ? null : level);
                  }}
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors ${
                    filter === level
                      ? `${style.bg} ${style.color} ring-1 ring-current/30`
                      : `text-muted-foreground/50 hover:${style.color}`
                  }`}
                >
                  {style.label}:{count}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {isOpen && (
            <>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                onClick={(e) => {
                  e.stopPropagation();
                  setAutoScroll(!autoScroll);
                }}
                title={autoScroll ? "暂停自动滚动" : "恢复自动滚动"}
              >
                {autoScroll ? (
                  <Pause className="w-3 h-3" />
                ) : (
                  <Play className="w-3 h-3" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                onClick={(e) => {
                  e.stopPropagation();
                  handleExport();
                }}
                title="导出日志"
              >
                <Download className="w-3 h-3" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                onClick={(e) => {
                  e.stopPropagation();
                  onClear();
                }}
                title="清空日志"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </>
          )}
          {isOpen ? (
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          ) : (
            <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" />
          )}
        </div>
      </div>

      {/* 日志内容 */}
      {isOpen && (
        <div
          ref={scrollRef}
          data-testid="serial-log-viewport"
          onScroll={handleScroll}
          className="h-[calc(100%-2.25rem)] overflow-y-auto overflow-x-hidden px-4 py-1 font-mono text-[11px] leading-5"
        >
          {filteredLogs.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground/40 text-xs">
              {filter
                ? `没有 ${LOG_LEVELS[filter]?.label} 级别的日志`
                : "暂无日志，连接串口后将显示数据"}
            </div>
          ) : (
            <div style={{ height: filteredLogs.length * ROW_HEIGHT, position: "relative" }}>
              {visibleLogs.map((log, offset) => (
                <div key={first + offset}
                  style={{ position: "absolute", top: (first + offset) * ROW_HEIGHT, left: 0, right: 0 }}>
                  <LogRow log={log} />
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
});
