/** Backrest-only calibration of single and side-by-side 9 cm circular contacts. */
export const BACKREST_AREA_VERSION = "backrest-multi-circle-adc-20261027";
export const BACKREST_AREA_COEFFICIENTS = Object.freeze({
  intercept: -0.2788578690374113,
  sum: 0.013666650182785223,
  q25: 0.23633443664476672,
  median: -0.281475003736231,
  q75: -0.06981573297046449,
  sd: -0.6500942371305325,
});
/** Feature order: intercept, sum, Q10, Q25, median, Q75, Q90, SD, peak, mean. */
export const BACKREST_MULTI_AREA_COEFFICIENTS = Object.freeze([
  4.006433149280155, 0.011278636128405855, 0,
  -0.19356239328011732, -0.34670014469369137, 0.1697147409966558,
  0, -1.3301730244194698, 0.07086671836615253, 0.2887439727461515,
]);

export interface BackrestAreaSelection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

export interface BackrestAreaFeatures {
  sum: number;
  q10: number;
  q25: number;
  median: number;
  q75: number;
  q90: number;
  sd: number;
  peak: number;
  mean: number;
  countAbove30: number;
}

export interface BackrestAreaRegion {
  index: number;
  seedRow: number;
  seedCol: number;
  thresholdAdc: number;
  positiveCellCount: number;
  supportAbove5: number;
  countAbove30: number;
  /** Final retained count in this region, restricted by any requested selection. */
  retainedCellCount: number;
  features: BackrestAreaFeatures | null;
}

export interface BackrestAreaFrame {
  version: typeof BACKREST_AREA_VERSION;
  modelVersion: typeof BACKREST_AREA_VERSION;
  algorithmId: "backrest-multi-circle-adc-threshold";
  algorithmLabel: "靠背多圆独立标定";
  sensorType: "new-backrest-32x25";
  status: "no_contact" | "outside_calibration" | "candidate_requires_validation";
  unit: "cm²";
  rows: number;
  cols: number;
  cellSideCm: 1;
  cellAreaCm2: 1;
  areaCm2: number;
  retainedCellCount: number;
  /** Mean of local thresholds for legacy summaries; filtering uses regionThresholds. */
  thresholdAdc: number;
  thresholdRangeAdc: [number, number];
  regionThresholds: number[];
  regions: BackrestAreaRegion[];
  seeds: [number, number][];
  seedCount: number;
  features: BackrestAreaFeatures | null;
  maximumAdc: number;
  positiveCellCount: number;
  retainedMask: boolean[][];
  areaMatrixCm2: number[][];
  regionCount: number;
  warnings: string[];
  inputMatrixMode: "source-interpolated";
  calibrationScope: "single-and-multiple-9cm-circles";
}

type Seed = [number, number];

function quantile(sorted: number[], fraction: number): number {
  const p = (sorted.length - 1) * fraction;
  const lo = Math.floor(p), hi = Math.ceil(p);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (p - lo);
}

function describe(values: number[]): BackrestAreaFeatures | null {
  if (!values.length) return null;
  values.sort((a, b) => a - b);
  const sum = values.reduce((a, b) => a + b, 0), mean = sum / values.length;
  const sd = Math.sqrt(values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length);
  return {
    sum, q10: quantile(values, .1), q25: quantile(values, .25),
    median: quantile(values, .5), q75: quantile(values, .75), q90: quantile(values, .9),
    sd, peak: values[values.length - 1], mean, countAbove30: values.length,
  };
}

/** scipy.ndimage's half-sample symmetric (reflect) boundary convention. */
function reflect(index: number, length: number): number {
  while (index < 0 || index >= length) index = index < 0 ? -index - 1 : 2 * length - index - 1;
  return index;
}

/** Separable Gaussian, axis 0 then 1, matching sigma and truncate=4 in scipy. */
function gaussian(input: Float64Array, rows: number, cols: number, sigma: number): Float64Array {
  const radius = Math.floor(4 * sigma + .5), kernel: number[] = [];
  let total = 0;
  for (let x = -radius; x <= radius; x++) {
    const value = Math.exp(-.5 * x * x / (sigma * sigma));
    kernel.push(value); total += value;
  }
  for (let i = 0; i < kernel.length; i++) kernel[i] /= total;
  const vertical = new Float64Array(input.length), output = new Float64Array(input.length);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let sum = 0;
    for (let offset = -radius; offset <= radius; offset++) {
      sum += input[reflect(r + offset, rows) * cols + c] * kernel[offset + radius];
    }
    vertical[r * cols + c] = sum;
  }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let sum = 0;
    for (let offset = -radius; offset <= radius; offset++) {
      sum += vertical[r * cols + reflect(c + offset, cols)] * kernel[offset + radius];
    }
    output[r * cols + c] = sum;
  }
  return output;
}

function findSeeds(input: Float64Array, rows: number, cols: number, sigma: number, separation: number): Seed[] {
  const smooth = gaussian(input, rows, cols, sigma);
  let maximum = 0;
  for (let i = 0; i < smooth.length; i++) if (smooth[i] > maximum) maximum = smooth[i];
  const cutoff = Math.max(15, maximum * .2), candidates: { seed: Seed; value: number }[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const value = smooth[r * cols + c];
    if (value < cutoff) continue;
    let isMaximum = true;
    for (let dr = -1; dr <= 1 && isMaximum; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (smooth[reflect(r + dr, rows) * cols + reflect(c + dc, cols)] > value) {
        isMaximum = false; break;
      }
    }
    if (isMaximum) candidates.push({ seed: [r, c], value });
  }
  candidates.sort((a, b) => b.value - a.value || a.seed[0] - b.seed[0] || a.seed[1] - b.seed[1]);
  const seeds: Seed[] = [], minimumSquared = separation * separation;
  for (const { seed } of candidates) {
    if (seeds.every(other => (seed[0] - other[0]) ** 2 + (seed[1] - other[1]) ** 2 >= minimumSquared)) seeds.push(seed);
  }
  return seeds;
}

/** Closest seed; exact distance ties keep the first seed, as numpy.argmin does. */
function partition(seeds: Seed[], rows: number, cols: number): Int32Array {
  const labels = new Int32Array(rows * cols);
  if (!seeds.length) { labels.fill(-1); return labels; }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let best = 0, bestDistance = Infinity;
    for (let i = 0; i < seeds.length; i++) {
      const distance = (r - seeds[i][0]) ** 2 + (c - seeds[i][1]) ** 2;
      if (distance < bestDistance) { best = i; bestDistance = distance; }
    }
    labels[r * cols + c] = best;
  }
  return labels;
}

function supportCounts(input: Float64Array, labels: Int32Array, count: number): number[] {
  const supports = Array<number>(count).fill(0);
  for (let i = 0; i < input.length; i++) if (input[i] > 5 && labels[i] >= 0) supports[labels[i]]++;
  return supports;
}

function splitContacts(input: Float64Array, rows: number, cols: number): { seeds: Seed[]; labels: Int32Array } {
  let seeds = findSeeds(input, rows, cols, 1.5, 6);
  if (!seeds.length) return { seeds, labels: partition(seeds, rows, cols) };
  const fineSeeds = findSeeds(input, rows, cols, .75, 5);
  for (let round = 0; round < 3; round++) {
    const labels = partition(seeds, rows, cols), supports = supportCounts(input, labels, seeds.length);
    const next: Seed[] = [];
    let changed = false;
    for (let i = 0; i < seeds.length; i++) {
      const options = fineSeeds.filter(seed => labels[seed[0] * cols + seed[1]] === i);
      if (supports[i] > 150 && options.length > 1) { next.push(...options); changed = true; }
      else next.push(seeds[i]);
    }
    seeds = next;
    if (!changed) break;
  }
  for (let round = 0; round < 3; round++) {
    const labels = partition(seeds, rows, cols), supports = supportCounts(input, labels, seeds.length);
    const next = seeds.filter((_, i) => supports[i] >= 60);
    if (!next.length || next.length === seeds.length) break;
    seeds = next;
  }
  return { seeds, labels: partition(seeds, rows, cols) };
}

function localThreshold(features: BackrestAreaFeatures | null, multipleContacts: boolean): number {
  if (!features) return 30;
  let threshold: number;
  if (multipleContacts) {
    const vector = [1, features.sum, features.q10, features.q25, features.median,
      features.q75, features.q90, features.sd, features.peak, features.mean];
    threshold = vector.reduce((sum, value, i) => sum + value * BACKREST_MULTI_AREA_COEFFICIENTS[i], 0);
  } else {
    const co = BACKREST_AREA_COEFFICIENTS;
    threshold = co.intercept + co.sum * features.sum + co.q25 * features.q25
      + co.median * features.median + co.q75 * features.q75 + co.sd * features.sd;
  }
  return Math.max(0, Math.round(threshold * 1000) / 1000);
}

/** Count retained 8-connected regions for presentation without changing the mask. */
function countRegions(mask: boolean[][]): number {
  const rows = mask.length, cols = mask[0].length, seen = new Uint8Array(rows * cols);
  let count = 0;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const start = r * cols + c;
    if (!mask[r][c] || seen[start]) continue;
    count++; seen[start] = 1;
    const stack = [start];
    while (stack.length) {
      const index = stack.pop()!, row = Math.floor(index / cols), col = index % cols;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const nr = row + dr, nc = col + dc;
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols || (!dr && !dc)) continue;
        const next = nr * cols + nc;
        if (!seen[next] && mask[nr][nc]) { seen[next] = 1; stack.push(next); }
      }
    }
  }
  return count;
}

/**
 * Fit independent local ADC thresholds from the complete interpolated source frame.
 * Every retained 1 cm × 1 cm cell contributes exactly 1 cm². Selection only restricts
 * the final mask: it never changes seeds, local features, or local thresholds.
 */
export function analyzeBackrestArea(
  matrix: number[][],
  options: { validMask?: boolean[][] | null; selection?: BackrestAreaSelection | null } = {},
): BackrestAreaFrame {
  if (!Array.isArray(matrix) || !matrix.length || !Array.isArray(matrix[0]) || !matrix[0].length) {
    throw new TypeError("A nonempty interpolated backrest ADC matrix is required.");
  }
  const rows = matrix.length, cols = matrix[0].length;
  if (!((rows === 50 && cols === 64) || (rows === 64 && cols === 50))) {
    throw new TypeError("Only backrest grids 50×64 or 64×50 are supported.");
  }
  const { validMask, selection } = options;
  if (validMask && (!Array.isArray(validMask) || validMask.length !== rows)) throw new TypeError("Invalid backrest mask dimensions.");
  const input = new Float64Array(rows * cols), values: number[] = [];
  let positiveCellCount = 0, maximumAdc = 0;
  for (let r = 0; r < rows; r++) {
    if (!Array.isArray(matrix[r]) || matrix[r].length !== cols ||
        (validMask && (!Array.isArray(validMask[r]) || validMask[r].length !== cols))) {
      throw new TypeError("Backrest matrix and mask must be rectangular and aligned.");
    }
    for (let c = 0; c < cols; c++) {
      const value = matrix[r][c];
      if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 255) {
        throw new TypeError("Backrest ADC values must be finite numbers from 0 through 255.");
      }
      if (validMask && typeof validMask[r][c] !== "boolean") throw new TypeError("Mask cells must be boolean.");
      if (validMask && !validMask[r][c]) continue;
      input[r * cols + c] = value;
      if (value > 0) positiveCellCount++;
      if (value > maximumAdc) maximumAdc = value;
      if (value > 30) values.push(value);
    }
  }
  const { seeds, labels } = splitContacts(input, rows, cols);
  const localValues = seeds.map(() => [] as number[]), positiveCounts = seeds.map(() => 0);
  const supports = supportCounts(input, labels, seeds.length);
  for (let i = 0; i < input.length; i++) {
    const index = labels[i];
    if (index < 0) continue;
    if (input[i] > 0) positiveCounts[index]++;
    if (input[i] > 30) localValues[index].push(input[i]);
  }
  const regionThresholds: BackrestAreaRegion[] = seeds.map((seed, index) => {
    const features = describe(localValues[index]);
    return { index, seedRow: seed[0], seedCol: seed[1], thresholdAdc: localThreshold(features, seeds.length > 1),
      positiveCellCount: positiveCounts[index], supportAbove5: supports[index],
      countAbove30: localValues[index].length, retainedCellCount: 0, features };
  });
  let retainedCellCount = 0;
  const retainedMask = matrix.map((row, r) => row.map((value, c) => {
    const index = labels[r * cols + c];
    const inSelection = !selection || (r >= selection.startRow && r <= selection.endRow && c >= selection.startCol && c <= selection.endCol);
    const keep = index >= 0 && (!validMask || validMask[r][c]) && inSelection && value > regionThresholds[index].thresholdAdc;
    if (keep) { retainedCellCount++; regionThresholds[index].retainedCellCount++; }
    return keep;
  }));
  const localThresholds = regionThresholds.map(region => region.thresholdAdc);
  const thresholdAdc = localThresholds.length ? localThresholds.reduce((a, b) => a + b, 0) / localThresholds.length : 30;
  const thresholdRangeAdc: [number, number] = localThresholds.length ? [Math.min(...localThresholds), Math.max(...localThresholds)] : [30, 30];
  // Range checks are per contact, so total area and point counts can grow naturally.
  const outsideObservedRange = !seeds.length || seeds.length > 5 || regionThresholds.some(region => {
    const local = region.features;
    return !local || local.peak < (seeds.length > 1 ? 57 : 121) || local.peak > (seeds.length > 1 ? 185 : 249) ||
      local.countAbove30 < (seeds.length > 1 ? 46 : 58) || local.countAbove30 > (seeds.length > 1 ? 89 : 97);
  });
  const warnings = ["仅标定当前靠背的 9 cm 单圆及一至五个平铺圆面；人体、其他形状和面积需要另行验证。"];
  if (!positiveCellCount) warnings.unshift("未检测到接触信号。");
  else if (outsideObservedRange) warnings.unshift("当前接触区信号超出已有靠背砝码数据的标定范围。");
  return {
    version: BACKREST_AREA_VERSION, modelVersion: BACKREST_AREA_VERSION,
    algorithmId: "backrest-multi-circle-adc-threshold", algorithmLabel: "靠背多圆独立标定",
    sensorType: "new-backrest-32x25",
    status: !positiveCellCount ? "no_contact" : outsideObservedRange ? "outside_calibration" : "candidate_requires_validation",
    unit: "cm²", rows, cols, cellSideCm: 1, cellAreaCm2: 1,
    areaCm2: retainedCellCount, retainedCellCount, thresholdAdc, thresholdRangeAdc,
    regionThresholds: localThresholds, regions: regionThresholds, seeds, seedCount: seeds.length, features: describe(values), maximumAdc, positiveCellCount,
    retainedMask, areaMatrixCm2: retainedMask.map(row => row.map(keep => keep ? 1 : 0)),
    regionCount: countRegions(retainedMask), warnings, inputMatrixMode: "source-interpolated",
    calibrationScope: "single-and-multiple-9cm-circles",
  };
}
