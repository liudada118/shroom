/** Current-frame spatial denoise, calibrated contour, then exact 1 cm² grid count. */
import { predictSeatAreaCountThreshold, SEAT_AREA_COUNT_MODEL_VERSION } from "./seatAreaCountModel";

export const SEAT_AREA_VERSION = "seat-spatial-denoised-grid-count-20261030";

export interface SeatAreaSelection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

export interface SeatAreaFeatures {
  sum: number;
  q10: number;
  q25: number;
  median: number;
  q75: number;
  q90: number;
  sd: number;
  peak: number;
  mean: number;
  countAbove30: number;
  positiveCount: number;
  supportAbove5: number;
  positiveSum: number;
  sumSquares: number;
}

export interface SeatAreaRegion {
  index: number;
  seedRow: number;
  seedCol: number;
  thresholdAdc: number;
  positiveCellCount: number;
  supportAbove5: number;
  countAbove30: number;
  /** Final retained count in this region, restricted by any requested selection. */
  retainedCellCount: number;
  areaCm2: number;
  features: SeatAreaFeatures | null;
}

export interface SeatAreaFrame {
  version: typeof SEAT_AREA_VERSION;
  modelVersion: typeof SEAT_AREA_VERSION;
  algorithmId: "seat-spatial-denoised-grid-count";
  algorithmLabel: "坐垫空间去噪格数面积";
  sensorType: "endi-23x23";
  status: "no_contact" | "outside_calibration" | "candidate_requires_validation";
  unit: "cm²";
  rows: number;
  cols: number;
  cellSideCm: 1;
  cellAreaCm2: 1;
  areaCm2: number;
  retainedCellCount: number;
  /** Mean of local thresholds for legacy summaries; filtering uses regionThresholds. */
  thresholdAdc: number;
  thresholdRangeAdc: [number, number];
  regionThresholds: number[];
  regions: SeatAreaRegion[];
  seeds: [number, number][];
  seedCount: number;
  features: SeatAreaFeatures | null;
  maximumAdc: number;
  positiveCellCount: number;
  retainedMask: boolean[][];
  areaMatrixCm2: number[][];
  regionCount: number;
  warnings: string[];
  inputMatrixMode: "source-interpolated";
  calibrationScope: "reference-circle-grid-contours";
  areaMeaning: "spatial_denoised_grid_count";
  denoiseMethod: "median3_reflect_current_frame";
  sourceGridCellAreaCm2: 1;
  /** Calibration ground truth only; never a count quota or inference input. */
  calibrationReferenceAreaCm2: 63.2;
  countModelVersion: typeof SEAT_AREA_COUNT_MODEL_VERSION;
}

type Seed = [number, number];

function quantile(sorted: number[], fraction: number): number {
  const p = (sorted.length - 1) * fraction;
  const lo = Math.floor(p), hi = Math.ceil(p);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (p - lo);
}

function describe(all: number[]): SeatAreaFeatures | null {
  const values = all.filter(v => v > 30);
  if (!values.length) return null;
  values.sort((a, b) => a - b);
  const sum = values.reduce((a, b) => a + b, 0), mean = sum / values.length;
  const sd = Math.sqrt(values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length);
  return {
    sum, q10: quantile(values, .1), q25: quantile(values, .25),
    median: quantile(values, .5), q75: quantile(values, .75), q90: quantile(values, .9),
    sd, peak: values[values.length - 1], mean, countAbove30: values.length,
    positiveCount: all.filter(v => v > 0).length, supportAbove5: all.filter(v => v > 5).length,
    positiveSum: all.reduce((s,v) => s + v, 0), sumSquares: values.reduce((s,v) => s + v*v, 0),
  };
}

export type SeatAreaSnapshotMetadata = Pick<SeatAreaFrame,
  "algorithmId" | "modelVersion" | "areaMeaning" | "denoiseMethod" | "sourceGridCellAreaCm2" |
  "calibrationReferenceAreaCm2" | "countModelVersion" | "retainedCellCount" | "cellAreaCm2" |
  "seedCount" | "regionThresholds" | "status">;

/** Copy the exact area frame used for this force/pressure snapshot. */
export function snapshotSeatAreaMetadata(area: SeatAreaFrame): SeatAreaSnapshotMetadata {
  const { algorithmId, modelVersion, areaMeaning, denoiseMethod, sourceGridCellAreaCm2,
    calibrationReferenceAreaCm2, countModelVersion, retainedCellCount, cellAreaCm2,
    seedCount, regionThresholds, status } = area;
  return { algorithmId, modelVersion, areaMeaning, denoiseMethod, sourceGridCellAreaCm2,
    calibrationReferenceAreaCm2, countModelVersion, retainedCellCount, cellAreaCm2,
    seedCount, regionThresholds: [...regionThresholds], status };
}

/** scipy.ndimage's half-sample symmetric (reflect) boundary convention. */
function reflect(index: number, length: number): number {
  while (index < 0 || index >= length) index = index < 0 ? -index - 1 : 2 * length - index - 1;
  return index;
}

/** Separable Gaussian, axis 0 then 1, matching sigma and truncate=4 in scipy. */
function gaussian(input: Float64Array, rows: number, cols: number, sigma: number): Float64Array {
  const radius = Math.floor(4 * sigma + .5), kernel: number[] = [];
  let total = 0;
  for (let x = -radius; x <= radius; x++) {
    const value = Math.exp(-.5 * x * x / (sigma * sigma));
    kernel.push(value); total += value;
  }
  for (let i = 0; i < kernel.length; i++) kernel[i] /= total;
  const vertical = new Float64Array(input.length), output = new Float64Array(input.length);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let sum = 0;
    for (let offset = -radius; offset <= radius; offset++) {
      sum += input[reflect(r + offset, rows) * cols + c] * kernel[offset + radius];
    }
    vertical[r * cols + c] = sum;
  }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let sum = 0;
    for (let offset = -radius; offset <= radius; offset++) {
      sum += vertical[r * cols + reflect(c + offset, cols)] * kernel[offset + radius];
    }
    output[r * cols + c] = sum;
  }
  return output;
}

function findSeeds(input: Float64Array, rows: number, cols: number, sigma: number, separation: number): Seed[] {
  const smooth = gaussian(input, rows, cols, sigma);
  let maximum = 0;
  for (let i = 0; i < smooth.length; i++) if (smooth[i] > maximum) maximum = smooth[i];
  const cutoff = Math.max(15, maximum * .2), candidates: { seed: Seed; value: number }[] = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const value = smooth[r * cols + c];
    if (value < cutoff) continue;
    let isMaximum = true;
    for (let dr = -1; dr <= 1 && isMaximum; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (smooth[reflect(r + dr, rows) * cols + reflect(c + dc, cols)] > value) {
        isMaximum = false; break;
      }
    }
    if (isMaximum) candidates.push({ seed: [r, c], value });
  }
  candidates.sort((a, b) => b.value - a.value || a.seed[0] - b.seed[0] || a.seed[1] - b.seed[1]);
  const seeds: Seed[] = [], minimumSquared = separation * separation;
  for (const { seed } of candidates) {
    if (seeds.every(other => (seed[0] - other[0]) ** 2 + (seed[1] - other[1]) ** 2 >= minimumSquared)) seeds.push(seed);
  }
  return seeds;
}

/** Closest seed; exact distance ties keep the first seed, as numpy.argmin does. */
function partition(seeds: Seed[], rows: number, cols: number): Int32Array {
  const labels = new Int32Array(rows * cols);
  if (!seeds.length) { labels.fill(-1); return labels; }
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let best = 0, bestDistance = Infinity;
    for (let i = 0; i < seeds.length; i++) {
      const distance = (r - seeds[i][0]) ** 2 + (c - seeds[i][1]) ** 2;
      if (distance < bestDistance) { best = i; bestDistance = distance; }
    }
    labels[r * cols + c] = best;
  }
  return labels;
}

function supportCounts(input: Float64Array, labels: Int32Array, count: number): number[] {
  const supports = Array<number>(count).fill(0);
  for (let i = 0; i < input.length; i++) if (input[i] > 5 && labels[i] >= 0) supports[labels[i]]++;
  return supports;
}

function splitContacts(input: Float64Array, rows: number, cols: number): { seeds: Seed[]; labels: Int32Array } {
  let seeds = findSeeds(input, rows, cols, 1.5, 7);
  if (!seeds.length) return { seeds, labels: partition(seeds, rows, cols) };
  const fineSeeds = findSeeds(input, rows, cols, .75, 5);
  for (let round = 0; round < 3; round++) {
    const labels = partition(seeds, rows, cols), supports = supportCounts(input, labels, seeds.length);
    const next: Seed[] = [];
    let changed = false;
    for (let i = 0; i < seeds.length; i++) {
      const options = fineSeeds.filter(seed => labels[seed[0] * cols + seed[1]] === i);
      if (supports[i] > 150 && options.length > 1) { next.push(...options); changed = true; }
      else next.push(seeds[i]);
    }
    seeds = next;
    if (!changed) break;
  }
  for (let round = 0; round < 3; round++) {
    const labels = partition(seeds, rows, cols), supports = supportCounts(input, labels, seeds.length);
    const next = seeds.filter((_, i) => supports[i] >= 70);
    if (!next.length || next.length === seeds.length) break;
    seeds = next;
  }
  return { seeds, labels: partition(seeds, rows, cols) };
}

/** Current-frame 3×3 median; no temporal history or additional frame delay. */
function median3Reflect(input: Float64Array, rows: number, cols: number): Float64Array {
  const output = new Float64Array(input.length), window = Array<number>(9);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    let n = 0;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      window[n++] = input[reflect(r + dr, rows) * cols + reflect(c + dc, cols)];
    }
    window.sort((a, b) => a - b);
    output[r * cols + c] = window[4];
  }
  return output;
}

/** Count retained 8-connected regions for presentation without changing the mask. */
function countRegions(mask: boolean[][]): number {
  const rows = mask.length, cols = mask[0].length, seen = new Uint8Array(rows * cols);
  let count = 0;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const start = r * cols + c;
    if (!mask[r][c] || seen[start]) continue;
    count++; seen[start] = 1;
    const stack = [start];
    while (stack.length) {
      const index = stack.pop()!, row = Math.floor(index / cols), col = index % cols;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const nr = row + dr, nc = col + dc;
        if (nr < 0 || nr >= rows || nc < 0 || nc >= cols || (!dr && !dc)) continue;
        const next = nr * cols + nc;
        if (!seen[next] && mask[nr][nc]) { seen[next] = 1; stack.push(next); }
      }
    }
  }
  return count;
}

/** Fit the full-frame contour before clipping the final counted cells to a selection. */
function analyzeNativeSeatArea(
  matrix: number[][],
  options: { validMask?: boolean[][] | null; selection?: SeatAreaSelection | null } = {},
): SeatAreaFrame {
  if (!Array.isArray(matrix) || !matrix.length || !Array.isArray(matrix[0]) || !matrix[0].length) {
    throw new TypeError("A nonempty interpolated seat ADC matrix is required.");
  }
  const rows = matrix.length, cols = matrix[0].length;
  if (!(rows === 46 && cols === 46)) {
    throw new TypeError("Only seat grids 46×46 are supported.");
  }
  const { validMask, selection } = options;
  if (validMask && (!Array.isArray(validMask) || validMask.length !== rows)) throw new TypeError("Invalid seat mask dimensions.");
  const input = new Float64Array(rows * cols), values: number[] = [];
  let positiveCellCount = 0, maximumAdc = 0;
  for (let r = 0; r < rows; r++) {
    if (!Array.isArray(matrix[r]) || matrix[r].length !== cols ||
        (validMask && (!Array.isArray(validMask[r]) || validMask[r].length !== cols))) {
      throw new TypeError("Seat matrix and mask must be rectangular and aligned.");
    }
    for (let c = 0; c < cols; c++) {
      const value = matrix[r][c];
      if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 255) {
        throw new TypeError("Seat ADC values must be finite numbers from 0 through 255.");
      }
      if (validMask && typeof validMask[r][c] !== "boolean") throw new TypeError("Mask cells must be boolean.");
      if (validMask && !validMask[r][c]) continue;
      input[r * cols + c] = value;
      if (value > 0) positiveCellCount++;
      if (value > maximumAdc) maximumAdc = value;
      if (value > 0) values.push(value);
    }
  }
  // Contact seeds and partitions use the original masked ADC, unchanged.
  const { seeds, labels } = splitContacts(input, rows, cols);
  const denoised = median3Reflect(input, rows, cols);
  const localValues = seeds.map(() => [] as number[]), positiveCounts = seeds.map(() => 0);
  const medianValues = seeds.map(() => [] as number[]);
  const regionRows = seeds.map(() => [] as number[]), regionCols = seeds.map(() => [] as number[]);
  const supports = supportCounts(input, labels, seeds.length);
  for (let i = 0; i < input.length; i++) {
    const index = labels[i];
    if (index < 0) continue;
    if (input[i] > 0) { positiveCounts[index]++; localValues[index].push(input[i]); }
    // All partition cells, including zero and invalid-mask cells, describe its contour.
    medianValues[index].push(denoised[i]);
    regionRows[index].push(Math.floor(i / cols)); regionCols[index].push(i % cols);
  }
  const regionThresholds: SeatAreaRegion[] = seeds.map((seed, index) => {
    const features = describe(localValues[index]);
    return { index, seedRow: seed[0], seedCol: seed[1],
      thresholdAdc: predictSeatAreaCountThreshold(medianValues[index], regionRows[index], regionCols[index]),
      positiveCellCount: positiveCounts[index], supportAbove5: supports[index],
      countAbove30: features?.countAbove30 ?? 0, retainedCellCount: 0, areaCm2: 0, features };
  });
  let retainedCellCount = 0;
  const areaMatrixCm2 = matrix.map((row,r) => row.map((_,c) => {
    const offset = r * cols + c, index = labels[offset], value = denoised[offset];
    const inSelection = !selection || (r >= selection.startRow && r <= selection.endRow && c >= selection.startCol && c <= selection.endCol);
    if (index < 0 || (validMask && !validMask[r][c]) || !inSelection || value <= 0 || value < regionThresholds[index].thresholdAdc) return 0;
    retainedCellCount++; regionThresholds[index].retainedCellCount++; regionThresholds[index].areaCm2++;
    return 1;
  }));
  const retainedMask = areaMatrixCm2.map(row => row.map(area => area === 1));
  const areaCm2 = regionThresholds.reduce((sum,region) => sum+region.areaCm2, 0);
  const localThresholds = regionThresholds.map(region => region.thresholdAdc);
  const thresholdAdc = localThresholds.length ? localThresholds.reduce((a, b) => a + b, 0) / localThresholds.length : 8;
  const thresholdRangeAdc: [number, number] = localThresholds.length ? [Math.min(...localThresholds), Math.max(...localThresholds)] : [8, 8];
  const outsideObservedRange = seeds.length > 5;
  const warnings = ["面积为当前帧3×3空间中值去噪后保留格数，每格1 cm²；63.2 cm²仅作标定参考，不强制固定面积。",
    "轮廓阈值基于已有圆形接触数据；其他形状、位置和噪声情况仍需实测验证。"];
  if (!seeds.length) warnings.unshift("未检测到接触区域。");
  else if (outsideObservedRange) warnings.unshift("接触区域数量超出已有1至5个平铺落点的标定范围。");
  return {
    version: SEAT_AREA_VERSION, modelVersion: SEAT_AREA_VERSION,
    algorithmId: "seat-spatial-denoised-grid-count", algorithmLabel: "坐垫空间去噪格数面积",
    sensorType: "endi-23x23",
    status: !seeds.length || areaCm2 === 0 ? "no_contact" : outsideObservedRange ? "outside_calibration" : "candidate_requires_validation",
    unit: "cm²", rows, cols, cellSideCm: 1, cellAreaCm2: 1,
    areaCm2, retainedCellCount, thresholdAdc, thresholdRangeAdc,
    regionThresholds: localThresholds, regions: regionThresholds, seeds, seedCount: seeds.length, features: describe(values), maximumAdc, positiveCellCount,
    retainedMask, areaMatrixCm2,
    regionCount: countRegions(retainedMask), warnings, inputMatrixMode: "source-interpolated",
    calibrationScope: "reference-circle-grid-contours", areaMeaning: "spatial_denoised_grid_count",
    denoiseMethod: "median3_reflect_current_frame", sourceGridCellAreaCm2: 1,
    calibrationReferenceAreaCm2: 63.2, countModelVersion: SEAT_AREA_COUNT_MODEL_VERSION,
  };
}

function rotate<T>(matrix:T[][], times:number):T[][] {
  let result = matrix;
  for(let i=0;i<times;i++) result=result[0].map((_,c)=>result.map(row=>row[c]).reverse());
  return result;
}
function rotatePoint(row:number,col:number,times:number):[number,number] {
  for(let i=0;i<times;i++){const next=col;col=45-row;row=next;}
  return [row,col];
}
/** Rotation records the displayed orientation relative to native serial ADC.
 * Fit once in native coordinates; rotate only the result, so ties and selections
 * cannot cause a different calibrated area when the user rotates the heatmap. */
export function analyzeSeatArea(matrix:number[][], options:{validMask?:boolean[][]|null;selection?:SeatAreaSelection|null;rotation?:number}={}):SeatAreaFrame {
  if (!Number.isInteger(options.rotation ?? 0)) throw new TypeError('Rotation must be integer quarter-turns');
  const turns=((options.rotation??0)%4+4)%4, undo=(4-turns)%4;
  let selection=options.selection;
  if(selection&&turns){
    const corners=[[selection.startRow,selection.startCol],[selection.startRow,selection.endCol],[selection.endRow,selection.startCol],[selection.endRow,selection.endCol]].map(([r,c])=>rotatePoint(r,c,undo));
    selection={startRow:Math.min(...corners.map(p=>p[0])),endRow:Math.max(...corners.map(p=>p[0])),startCol:Math.min(...corners.map(p=>p[1])),endCol:Math.max(...corners.map(p=>p[1]))};
  }
  const native=turns?rotate(matrix,undo):matrix;
  const frame=analyzeNativeSeatArea(native,{validMask:options.validMask&&turns?rotate(options.validMask,undo):options.validMask,selection});
  if(!turns)return frame;
  return {...frame,retainedMask:rotate(frame.retainedMask,turns),areaMatrixCm2:rotate(frame.areaMatrixCm2,turns),seeds:frame.seeds.map(([r,c])=>rotatePoint(r,c,turns)),regions:frame.regions.map(region=>{
    const [seedRow,seedCol]=rotatePoint(region.seedRow,region.seedCol,turns);return {...region,seedRow,seedCol};
  })};
}
