import { SEAT_LOAD_RECOGNITION } from "./seatLoadRecognition.generated";

export interface RecognitionForest {
  id: string;
  massKg: number[];
  forceN: number[];
  mask: number[];
  trees: { f: number[]; t: number[]; l: number[]; r: number[]; root: number }[];
  heldoutCorrect: number;
  heldoutPositiveFrames: number;
  validationScope: string;
  sourceSha256: string;
  uncertaintyHeuristic: { minimumTopVote: number; minimumVoteMargin: number };
  outputInterpretation: string;
  input: string;
}

export interface SeatLoadRecognition {
  recognizedMassKg: number;
  nominalForceN: number;
  scores: number[];
  topScore: number;
  scoreMargin: number;
  uncertain: boolean;
  noContact: boolean;
  modelId: string;
}

const mask = new Set(SEAT_LOAD_RECOGNITION.mask);
const powers = [0.5, 1, 1.5, 2, 3, 4];
const thresholds = [1, 4, 8, 16, 32, 64, 96, 128, 160, 192, 224, 240, 252];

function quantile(ascending: number[], fraction: number): number {
  const index = (ascending.length - 1) * fraction;
  const lo = Math.floor(index);
  const hi = Math.ceil(index);
  return ascending[lo] + (ascending[hi] - ascending[lo]) * (index - lo);
}

/** Same104 label-free ADC/geometry features as the audited Python forest. */
export function seatLoadRecognitionFeatures(matrix: readonly (readonly number[])[]): number[] {
  if (matrix.length !== 23 || matrix.some(row => row.length !== 23)) {
    throw new Error("Expected native23x23 ADC matrix");
  }
  const values: number[] = [];
  const cells: { row: number; col: number; value: number }[] = [];
  for (let row = 0; row < 23; row++) {
    for (let col = 0; col < 23; col++) {
      const value = matrix[row][col];
      if (!Number.isFinite(value) || value < 0 || value > 255) throw new Error("Expected finite ADC0..255");
      if (mask.has(row * 23 + col) && value > 0) {
        values.push(value);
        cells.push({ row, col, value });
      }
    }
  }
  if (values.length === 0) return Array<number>(104).fill(0);
  const sum = values.reduce((a, b) => a + b, 0);
  const rowCenter = cells.reduce((s, c) => s + c.row * c.value, 0) / sum;
  const colCenter = cells.reduce((s, c) => s + c.col * c.value, 0) / sum;
  const powerSums = powers.map(power => values.reduce((s, v) => s + Math.pow(v / 255, power), 0));
  const sorted = [...values].sort((a, b) => a - b);
  const quantiles = [0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 1].map(q => quantile(sorted, q));
  const counts = thresholds.map(t => values.filter(v => v >= t).length);
  const descending = [...sorted].reverse();
  const top = Array.from({ length: 64 }, (_, i) => descending[i] ?? 0);
  let minRow = 23, maxRow = -1, minCol = 23, maxCol = -1;
  let covRR = 0, covCC = 0, covRC = 0, unweightedRow = 0, unweightedCol = 0;
  let radiusSum = 0, maxRadius = 0, entropy = 0, squaredFractions = 0;
  for (const cell of cells) {
    minRow = Math.min(minRow, cell.row); maxRow = Math.max(maxRow, cell.row);
    minCol = Math.min(minCol, cell.col); maxCol = Math.max(maxCol, cell.col);
    const dr = cell.row - rowCenter, dc = cell.col - colCenter;
    covRR += cell.value * dr * dr; covCC += cell.value * dc * dc; covRC += cell.value * dr * dc;
    unweightedRow += cell.row; unweightedCol += cell.col;
    const radius = Math.hypot(dr, dc);
    radiusSum += radius; maxRadius = Math.max(maxRadius, radius);
    const fraction = cell.value / sum;
    entropy -= fraction * Math.log(fraction); squaredFractions += fraction * fraction;
  }
  covRR /= sum; covCC /= sum; covRC /= sum;
  const trace = covRR + covCC;
  const discriminant = Math.hypot(covRR - covCC, 2 * covRC);
  const shape = [values.length, maxRow - minRow + 1, maxCol - minCol + 1,
    Math.max(0, (trace - discriminant) / 2), Math.max(0, (trace + discriminant) / 2),
    unweightedRow / values.length - rowCenter, unweightedCol / values.length - colCenter,
    radiusSum / values.length, maxRadius, entropy, descending[0] / sum, squaredFractions];
  return [...powerSums.map(Math.log1p), ...[...quantiles, ...counts, ...top].map(v => v / 255),
    ...shape, rowCenter, colCenter];
}

/** Class votes are recognition scores; they are not calibrated probabilities. */
export function recognizeSeatLoad(matrix: readonly (readonly number[])[]): SeatLoadRecognition {
  const forest = SEAT_LOAD_RECOGNITION;
  const features = seatLoadRecognitionFeatures(matrix);
  const noContact = features[1] === 0;
  if (noContact) return { recognizedMassKg: 0, nominalForceN: 0, scores: Array(6).fill(0),
    topScore: 0, scoreMargin: 0, uncertain: false, noContact, modelId: forest.id };
  const input = features.map(Math.fround);
  const votes = Array<number>(6).fill(0);
  for (const tree of forest.trees) {
    let node = tree.root;
    while (node >= 0) node = input[tree.f[node]] <= tree.t[node] ? tree.l[node] : tree.r[node];
    votes[-node - 1] += 1;
  }
  const scores = votes.map(v => v / forest.trees.length);
  const chosen = votes.indexOf(Math.max(...votes));
  const ranked = [...scores].sort((a, b) => b - a);
  const topScore = ranked[0], scoreMargin = ranked[0] - ranked[1];
  return { recognizedMassKg: forest.massKg[chosen], nominalForceN: forest.forceN[chosen], scores,
    topScore, scoreMargin, uncertain: topScore < forest.uncertaintyHeuristic.minimumTopVote ||
      scoreMargin < forest.uncertaintyHeuristic.minimumVoteMargin, noContact: false, modelId: forest.id };
}

export const SEAT_LOAD_RECOGNITION_VALIDATION = {
  correct: SEAT_LOAD_RECOGNITION.heldoutCorrect,
  positiveFrames: SEAT_LOAD_RECOGNITION.heldoutPositiveFrames,
  label: "六档识别试用；留出新落点57.8%、旧文件76.2%，仍有错档",
};
