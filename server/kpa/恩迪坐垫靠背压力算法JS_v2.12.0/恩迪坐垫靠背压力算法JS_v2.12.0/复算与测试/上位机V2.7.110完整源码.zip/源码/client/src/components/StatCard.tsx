/**
 * 统计卡片组件
 * 显示单个统计指标，带有彩色图标和数值
 * 支持鼠标悬停展示详情（用于压强拟合公式展示）
 * 
 * 设计风格: 深色卡片，左侧彩色指示器
 */

import { useState, useRef, useEffect, type ReactNode } from "react";
import { Info } from "lucide-react";

interface StatCardProps {
  label: ReactNode;
  value: ReactNode;
  unit?: string;
  icon: ReactNode;
  accent?: string;
  /** 鼠标悬停时展示的详情内容 */
  detail?: ReactNode;
}

export default function StatCard({ label, value, unit, icon, accent, detail }: StatCardProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  const handleEnter = () => {
    if (hideTimer.current) clearTimeout(hideTimer.current);
    setShowTooltip(true);
  };

  const handleLeave = () => {
    hideTimer.current = setTimeout(() => setShowTooltip(false), 200);
  };

  // 清理定时器
  useEffect(() => {
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, []);

  return (
    <div
      className="rounded-lg border border-border/50 bg-card/50 transition-colors hover:bg-card/80 relative"
      style={{ borderLeftColor: accent, borderLeftWidth: accent ? 3 : undefined }}
    >
      <div className="p-3">
        <div className="flex items-center gap-2 mb-1">
          <span style={{ color: accent }} className="opacity-80">
            {icon}
          </span>
          <span className="text-[11px] font-medium text-muted-foreground flex-1">{label}</span>
          {detail && (
            <button
              ref={triggerRef}
              onMouseEnter={handleEnter}
              onMouseLeave={handleLeave}
              onClick={() => setShowTooltip(!showTooltip)}
              className="w-4 h-4 flex items-center justify-center rounded hover:bg-muted/50 text-muted-foreground/60 hover:text-foreground transition-colors"
              title="查看拟合公式"
            >
              <Info className="w-3 h-3" />
            </button>
          )}
        </div>
        <div className="font-mono text-xl font-semibold text-foreground">
          {value}
          {unit && <span className="text-xs text-muted-foreground ml-1">{unit}</span>}
        </div>
      </div>

      {/* Hover tooltip */}
      {detail && showTooltip && (
        <div
          ref={tooltipRef}
          onMouseEnter={handleEnter}
          onMouseLeave={handleLeave}
          className="absolute left-0 top-full mt-1 z-50 w-[360px] max-w-[90vw] bg-popover border border-border rounded-lg shadow-xl p-3 animate-in fade-in-0 zoom-in-95 duration-150"
          style={{ transformOrigin: 'top left' }}
        >
          {/* 小三角箭头 */}
          <div className="absolute -top-1.5 left-4 w-3 h-3 bg-popover border-l border-t border-border rotate-45" />
          <div className="relative">
            {detail}
          </div>
        </div>
      )}
    </div>
  );
}
