import { analyzeBackrestArea, type BackrestAreaFrame } from "./backrestArea";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";

export const BACKREST_TAXEL_PRESSURE_VERSION = "backrest-cell-force-sum-region-pressure-mean-g9p8-20261029" as const;

/** Keep the existing area partition. Add calibrated cell forces within each region. */
export function calculateBackrestTaxelPressure(
  source: number[][],
  physical: number[][],
  cellForceMapN: number[][],
  area: BackrestAreaFrame = analyzeBackrestArea(source),
): BackrestRegionPressureFrame {
  const rows = physical.length, cols = physical[0]?.length;
  if (!((rows === 25 && cols === 32) || (rows === 32 && cols === 25)) ||
      source.length !== rows * 2 || source.some(row => row.length !== cols * 2) ||
      area.rows !== rows * 2 || area.cols !== cols * 2 ||
      physical.some(row => row.length !== cols || row.some(v => !Number.isFinite(v) || v < 0 || v > 255)) ||
      cellForceMapN.length !== rows || cellForceMapN.some(row => row.length !== cols || row.some(v => !Number.isFinite(v) || v < 0)) ||
      area.seeds.length !== area.regions.length) {
    throw new TypeError("Aligned original backrest ADC, cell forces and existing area required");
  }
  const adcSums = area.seeds.map(() => 0), forces = area.seeds.map(() => 0);
  let rawAdcSum = 0, totalForceN = 0;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const adc = physical[r][c], force = cellForceMapN[r][c];
    rawAdcSum += adc; totalForceN += force;
    if (!area.seeds.length || (adc === 0 && force === 0)) continue;
    let nearest = 0, best = Infinity;
    area.seeds.forEach(([sr, sc], i) => {
      const distance = (2 * r - sr) ** 2 + (2 * c - sc) ** 2;
      if (distance < best) { nearest = i; best = distance; }
    });
    adcSums[nearest] += adc;
    forces[nearest] += force;
  }
  const regions = area.regions.map((region, i) => {
    const areaCm2 = region.retainedCellCount, estimatedForceN = forces[i];
    return { index: i, center: [region.seedRow, region.seedCol] as [number, number],
      rawAdcSum: adcSums[i], forceShare: totalForceN > 0 ? estimatedForceN / totalForceN : 0,
      estimatedForceN, areaCm2,
      estimatedPressureKPa: areaCm2 > 0 ? 10 * estimatedForceN / areaCm2 : null };
  });
  const noContact = rawAdcSum === 0 && totalForceN === 0;
  const complete = regions.length > 0 && regions.every(region => region.estimatedPressureKPa !== null);
  return { version: BACKREST_TAXEL_PRESSURE_VERSION, method: "per_cell_force_sum_then_region_arithmetic_mean",
    status: noContact ? "no_contact" : complete ? "estimated" : "incomplete", scope: "complete_frame",
    independentlyValidated: false, totalForceN, areaCm2: area.areaCm2, rawAdcSum,
    assignedRawAdcSum: adcSums.reduce((sum, value) => sum + value, 0), regions,
    averagePressureKPa: !noContact && complete
      ? regions.reduce((sum, region) => sum + region.estimatedPressureKPa!, 0) / regions.length : null,
    globalAreaMeanPressureKPa: area.areaCm2 > 0 ? 10 * totalForceN / area.areaCm2 : null };
}
