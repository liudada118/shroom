/**
 * 恩迪靠背（new-backrest-32x25）面积与压力算法 —— 上位机接入层
 * ----------------------------------------------------------------------------
 * 替换原靠背链路（逐格分段曲线 / 标准砝码锚点区间连续估算、原靠背面积模型、面积 ≥ 600 cm² 真人分支）。
 * 算法核心 endiBackrest/endiBackrestCore.js 由靠背拟合任务交付的 endi_backrest_algorithm.js v1.0.0
 * 生成（函数体逐字保留），参数由 44 个位置 × 2 组 × 1–5 块（1.625–8.125 kg）实测数据拟合。本文件只负责：
 *   1. 方向：串口 wireMap 原生物理矩阵（32 行 × 25 列）→ 转置 → 算法方向（25 行 × 32 列）。
 *      算法方向 = 采集 CSV 中“插值前原始物理矩阵（25×32）”的方向，已用原始字节逐帧核对（8800/8800 帧一致）。
 *      显示旋转设置不影响算法输入。
 *   2. 输入：未做 ADC 补偿的原始物理 ADC（sourcePhysical），与拟合数据口径一致。
 *   3. 实时会话：每个 streamId 一个有状态实例；同一帧对象只处理一次；时间戳保持严格递增，
 *      时间倒退（如 CSV 回放跳转）由核心自动重置。
 *   4. 输出映射为上位机 ContinuousForceFrame：总力、面积、各区压强及区域平均压强。
 *   5. V2.7.103 超量程：核心按基准估算力与连续拟合估算力均 > 90 N（超过 5 块砝码）启动超量程估算（压力 ×2，面积取 T39 轮廓，
 *      任一回落 ≤ 90 N 持续 500 ms 后取消），
 *      原 m_fit / 峰值 / λ 门限已删除；靠背不使用真人估算系数。
 *   6. V2.7.108：超量程估算面积 ×2（核心 overrangeAreaMultiplier），面积 = T39 轮廓 × 2，区压强 = 2F / 2S = F / S；
 *      框选面积中超量程区的轮廓格每格按 1.30 × 2 = 2.60 cm² 计。
 */
import {
  EndiBackrestAlgorithm, DEFAULT_CONFIG, CALIB, ENDI_BACKREST_CORE_VERSION, ENDI_BACKREST_CORE_SOURCE_SHA256,
  type EndiBackrestAlgorithmInstance, type EndiBackrestFrameOutput, type EndiBackrestRegionOutput,
} from "./endiBackrest/endiBackrestCore.js";
import type { BackrestRegionPressureFrame } from "./backrestRegionPressure";
import { pressureKPaFromForceArea, roundAreaCm2, roundForceN, roundPressureKPa } from "./pressureUnits";
import type { ContinuousForceFrame } from "./sensorForce";

type Matrix = number[][];

export const ENDI_BACKREST_ALGORITHM_ID = "endi-backrest-anchor-state-machine-g9p8" as const;
export const ENDI_BACKREST_ALGORITHM_LABEL = "恩迪靠背实测拟合算法（位置锚点＋相对档位状态机，g=9.8）" as const;
export const ENDI_BACKREST_MODEL_VERSION = `endi-backrest-${ENDI_BACKREST_CORE_VERSION}-fit-${CALIB.fittedOn.replace(/-/g, "")}`;
export const ENDI_BACKREST_PRESSURE_VERSION = "endi-backrest-region-pressure-mean-g9p8-20261109" as const;
export const ENDI_BACKREST_CONTACT_VERSION = "endi-backrest-orientation-transpose-adc1-8conn-min3-20261109" as const;
export const ENDI_BACKREST_AREA_VERSION = "endi-backrest-t39-contour-count-20261109" as const;
export const ENDI_BACKREST_CALCULATION_MODE = "endi_backrest_fitted" as const;
export const ENDI_BACKREST_CORE_SHA256 = ENDI_BACKREST_CORE_SOURCE_SHA256;

/** 原生（wireMap 解码）物理矩阵尺寸：32 行 × 25 列。 */
const NATIVE_ROWS = 32;
const NATIVE_COLS = 25;
/** 算法方向物理矩阵尺寸：25 行 × 32 列。 */
const ALG_ROWS = DEFAULT_CONFIG.rows;
const ALG_COLS = DEFAULT_CONFIG.cols;
export const ENDI_BACKREST_GRAVITY = DEFAULT_CONFIG.g;
export const ENDI_BACKREST_UNIT_MASS_KG = DEFAULT_CONFIG.blockMassKg;
export const ENDI_BACKREST_BASE_AREA_CM2 = DEFAULT_CONFIG.baseAreaCm2;
export const ENDI_BACKREST_AREA_THRESHOLD_ADC = DEFAULT_CONFIG.areaThreshold;
export const ENDI_BACKREST_CELL_AREA_CM2 = DEFAULT_CONFIG.interpCellAreaCm2;
export const ENDI_BACKREST_OVER_RANGE_GAIN = DEFAULT_CONFIG.overrangeMultiplier;
/** V2.7.108：超量程估算面积倍率（规定值 2）：超量程区面积 = T39 轮廓面积 × 2。 */
export const ENDI_BACKREST_OVER_RANGE_AREA_GAIN = DEFAULT_CONFIG.overrangeAreaMultiplier;
/** V2.7.103：超量程启动门限——接触区基准估算力 > 90 N（超过 5 块砝码）；超量程时压力 ×2、面积 = T39 轮廓 × 2（V2.7.108）。 */
export const ENDI_BACKREST_OVER_RANGE_FORCE_THRESHOLD_N = DEFAULT_CONFIG.ovrForceInN;
export const ENDI_BACKREST_POSITION_COUNT = CALIB.nodeIds.length;

const MODE_LABEL: Record<EndiBackrestRegionOutput["mode"], EndiBackrestRegionDiagnostics["mode"]> = {
  standard: "标准档", estimate: "估算", overrange: "超量程估算",
};
const STATE_LABEL: Record<EndiBackrestRegionOutput["state"], EndiBackrestRegionDiagnostics["state"]> = {
  first_contact: "首次接触确认中", tentative: "暂定档", confirmed: "已确认", judging: "加减块判断中",
  estimate: "估算", overrange: "超量程估算",
};

/** 每个接触区的诊断信息（与输出同帧）。字段与坐垫诊断一致，界面共用同一明细表。 */
export interface EndiBackrestRegionDiagnostics {
  track: number;
  mode: "标准档" | "估算" | "超量程估算";
  state: "首次接触确认中" | "暂定档" | "已确认" | "加减块判断中" | "估算" | "超量程估算";
  /** 已确认标准档块数（尚未定档时为 0）。 */
  level: number;
  tentativeLevel: number | null;
  addCount: number;
  massKg: number;
  forceN: number;
  areaCm2: number;
  pressureKPa: number | null;
  footprint: boolean;
  contourAreaCm2: number;
  fitMassKg: number;
  peakAdc: number;
  overRange: boolean;
  /** 算法方向物理格坐标 [行, 列]（25×32）。 */
  center: [number, number];
  adcSum: number;
  cells: number;
}

export interface EndiBackrestDiagnostics {
  version: string;
  coreVersion: string;
  coreSourceSha256: string;
  gravityMS2: number;
  unitMassKg: number;
  baseAreaCm2: number;
  areaThresholdAdc: number;
  cellAreaCm2: number;
  inputOrientation: "native-transposed";
  massKg: number;
  regions: EndiBackrestRegionDiagnostics[];
}

/** 框选 / 采集留档用的 T39 轮廓格数面积（每格 10 mm × 13 mm = 1.30 cm²）。 */
export interface EndiBackrestAreaFrame {
  version: typeof ENDI_BACKREST_AREA_VERSION;
  modelVersion: typeof ENDI_BACKREST_AREA_VERSION;
  algorithmId: "endi-backrest-t39-contour-count";
  algorithmLabel: "恩迪靠背T39轮廓格数面积";
  sensorType: "new-backrest-32x25";
  status: "no_contact" | "measured";
  unit: "cm²";
  scope: "full_frame" | "selection";
  rows: number;
  cols: number;
  cellAreaCm2: number;
  areaCm2: number;
  retainedCellCount: number;
  thresholdAdc: number;
}

function isAdcMatrix(m: unknown, rows: number, cols: number): m is Matrix {
  if (!Array.isArray(m) || m.length !== rows) return false;
  for (const row of m) {
    if (!Array.isArray(row) || row.length !== cols) return false;
    for (const v of row) if (typeof v !== "number" || !Number.isFinite(v) || v < 0 || v > 255) return false;
  }
  return true;
}

/** 原生 wireMap 方向（32×25）→ 算法方向（25×32）：转置，out[r][c] = native[c][r]。 */
export function endiBackrestNativeToAlgorithm(native: Matrix): Matrix {
  const out: Matrix = new Array(ALG_ROWS);
  for (let r = 0; r < ALG_ROWS; r++) {
    const row = new Array<number>(ALG_COLS);
    for (let c = 0; c < ALG_COLS; c++) row[c] = native[c][r];
    out[r] = row;
  }
  return out;
}

function regionLabel(r: EndiBackrestRegionDiagnostics): string {
  if (r.mode === "标准档") {
    return r.level > 0 ? `${r.level}块（${(r.level * ENDI_BACKREST_UNIT_MASS_KG).toFixed(3)} kg，${r.state}）` : `标准档（${r.state}）`;
  }
  return `${r.mode} ${r.massKg.toFixed(2)} kg`;
}

const SCOPE_NOTE = "恩迪靠背实测拟合算法：未补偿原始物理ADC（原生32×25）转置为25×32进入算法方向；接触区=ADC≥1八邻域连通（≥3格），"
  + "响应量R=Σ−ln(1−ADC/256)取120ms时间平均，按44个位置锚点（σ=35mm）与相对档位状态机识别标准砝码块数（每块1.625kg），"
  + "非砝码轮廓按连续拟合m=e^c0×(g·ΣADC²)^k估算，基准估算力与连续拟合估算力均>90N（超过5块，V2.7.103）按超量程估算压力×2、面积×2（V2.7.108，区压强=2F/2S=F/S；回落≤90N持续500ms取消）；F=9.8m。面积=50×64插值矩阵T39轮廓："
  + "标准档每区取砝码底面63.62cm²，估算按轮廓格数×1.30cm²，超量程估算按轮廓格数×1.30cm²×2；各区Fⱼ取2位小数，Pⱼ=Fⱼ/Sⱼ（N/cm²，3位小数，内部存kPa=10Fⱼ/Sⱼ），总力=ΣFⱼ。"
  + "逐格压强 Pᵢ=P区×ADCᵢ/mean(ADC区)（ADC取热力图显示值，按0.001N/cm²保和取整，区内格子平均=P区），"
  + "平均压强=全部压强格子的平均值，最大压强=MAX(Pᵢ)，见 pointPressure。";

function toForceFrame(out: EndiBackrestFrameOutput, algInput: Matrix): ContinuousForceFrame {
  let rawAdcSum = 0;
  for (const row of algInput) for (const v of row) rawAdcSum += v;
  const adcSums = out.regions.map(r => regionAdcSum(algInput, r));
  const regions: EndiBackrestRegionDiagnostics[] = out.regions.map((r, i) => ({
    track: r.trackId, mode: MODE_LABEL[r.mode], state: STATE_LABEL[r.state], level: r.blocks,
    tentativeLevel: r.tentativeBlocks, addCount: r.addCount, massKg: r.massKg, forceN: r.forceN, areaCm2: r.areaCm2,
    pressureKPa: r.pressureKPa, footprint: r.footprint, contourAreaCm2: r.contourAreaCm2, fitMassKg: r.massFitKg,
    peakAdc: r.peak, overRange: r.mode === "overrange", center: [r.center.r, r.center.c], adcSum: adcSums[i], cells: r.cells,
  }));
  const noContact = regions.length === 0;
  // V2.7.101：各区压力取 2 位小数，面积 2 位小数，压强 Pⱼ = Fⱼ/Sⱼ（N/cm²）取 3 位小数（内部 kPa = 10Fⱼ/Sⱼ，0.01 kPa 取整）；
  // 总力 = Σ 各区（取整后）压力，界面上各区压力相加等于总力。
  const regionF = regions.map(r => roundForceN(r.forceN));
  const regionS = regions.map(r => roundAreaCm2(r.areaCm2));
  const regionP = regions.map((r, i) => (r.pressureKPa === null ? null : pressureKPaFromForceArea(regionF[i], regionS[i])));
  const totalF = roundForceN(regionF.reduce((s, v) => s + v, 0));
  const totalS = roundAreaCm2(out.totalAreaCm2);
  const complete = !noContact && regionP.every(p => p !== null);
  const arithmeticMeanP = complete ? roundPressureKPa(regionP.reduce((s, p) => s + p!, 0) / regionP.length) : null;
  const contactPressure: BackrestRegionPressureFrame = {
    version: ENDI_BACKREST_PRESSURE_VERSION, method: "endi_region_force_over_region_area_then_arithmetic_mean",
    status: noContact ? "no_contact" : complete ? "estimated" : "incomplete", scope: "complete_frame",
    independentlyValidated: false, totalForceN: totalF, areaCm2: totalS, rawAdcSum,
    assignedRawAdcSum: adcSums.reduce((s, v) => s + v, 0),
    regions: regions.map((r, i) => ({
      index: i, center: r.center, rawAdcSum: r.adcSum,
      forceShare: totalF > 0 ? regionF[i] / totalF : 0,
      estimatedForceN: regionF[i], areaCm2: regionS[i], estimatedPressureKPa: regionP[i],
    })),
    // 各区算术平均；接入逐格压强后（attachEndiPointPressure）改为全部压强格子的平均值。
    averagePressureKPa: arithmeticMeanP,
    globalAreaMeanPressureKPa: totalS > 0 ? pressureKPaFromForceArea(totalF, totalS) : null,
  };
  const anyOver = regions.some(r => r.overRange);
  const anyEstimate = regions.some(r => r.mode !== "标准档");
  const diagnostics: EndiBackrestDiagnostics = {
    version: ENDI_BACKREST_MODEL_VERSION, coreVersion: ENDI_BACKREST_CORE_VERSION, coreSourceSha256: ENDI_BACKREST_CORE_SOURCE_SHA256,
    gravityMS2: ENDI_BACKREST_GRAVITY, unitMassKg: ENDI_BACKREST_UNIT_MASS_KG, baseAreaCm2: ENDI_BACKREST_BASE_AREA_CM2,
    areaThresholdAdc: ENDI_BACKREST_AREA_THRESHOLD_ADC, cellAreaCm2: ENDI_BACKREST_CELL_AREA_CM2,
    inputOrientation: "native-transposed", massKg: out.totalMassKg, regions,
  };
  return {
    algorithmId: ENDI_BACKREST_ALGORITHM_ID, algorithmLabel: ENDI_BACKREST_ALGORITHM_LABEL, modelVersion: ENDI_BACKREST_MODEL_VERSION,
    status: noContact ? "no_contact" : anyOver ? "over_range_estimate" : anyEstimate ? "estimated" : "standard_recognized",
    forceN: totalF, averagePressureKPa: arithmeticMeanP, areaCm2: totalS, contactPressure,
    seedCount: regions.length, regionForcesN: regionF, forceAggregation: "regional_sum",
    regionCenters: regions.map(r => r.center),
    contactDetectionVersion: ENDI_BACKREST_CONTACT_VERSION, forceEstimateComplete: true,
    calibratedSeedCount: regions.length, detectedContactCount: regions.length,
    detectedContactCenters: regions.map(r => r.center),
    inputMode: "native-uncompensated-physical-adc-32x25-transposed-25x32",
    accepted: false, independentlyValidated: false,
    forceMeaning: ENDI_BACKREST_CALCULATION_MODE, calculationMode: ENDI_BACKREST_CALCULATION_MODE,
    loadLabel: noContact ? "无接触" : regions.map(regionLabel).join("；"),
    scopeNote: SCOPE_NOTE,
    endiBackrest: diagnostics,
  };
}

/**
 * 区域原始 ADC 总和：核心不输出格子列表，这里按与核心相同的规则（ADC≥1、八邻域、≥3 格）
 * 重新连通标记，并按 ADC 加权中心匹配到核心输出的区域（同一连通区中心相同，取最近者）。
 */
function regionAdcSum(a: Matrix, region: EndiBackrestRegionOutput): number {
  let best = 0, bd = Infinity;
  for (const c of componentSums(a)) {
    const d = Math.hypot(c.r - region.center.r, c.c - region.center.c);
    if (d < bd) { bd = d; best = c.sum; }
  }
  return bd < 0.01 ? best : 0;
}

const componentCache = new WeakMap<Matrix, { r: number; c: number; sum: number }[]>();
function componentSums(a: Matrix): { r: number; c: number; sum: number }[] {
  const hit = componentCache.get(a);
  if (hit) return hit;
  const R = a.length, C = a[0].length;
  const lab = new Int32Array(R * C);
  const out: { r: number; c: number; sum: number }[] = [];
  const stack: number[] = [];
  let id = 0;
  for (let s = 0; s < R * C; s++) {
    const sr = (s / C) | 0, sc = s - sr * C;
    if (a[sr][sc] < 1 || lab[s]) continue;
    id++;
    lab[s] = id; stack.push(s);
    let n = 0, sum = 0, wr = 0, wc = 0;
    while (stack.length) {
      const p = stack.pop()!;
      const pr = (p / C) | 0, pc = p - pr * C, v = a[pr][pc];
      n++; sum += v; wr += v * pr; wc += v * pc;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const rr = pr + dr, cc = pc + dc;
        if ((dr === 0 && dc === 0) || rr < 0 || rr >= R || cc < 0 || cc >= C) continue;
        const q = rr * C + cc;
        if (a[rr][cc] >= 1 && !lab[q]) { lab[q] = id; stack.push(q); }
      }
    }
    if (n >= 3) out.push({ r: wr / sum, c: wc / sum, sum });
  }
  componentCache.set(a, out);
  return out;
}

export interface EndiBackrestStreamContext {
  timestampMs?: number;
  streamId?: string;
  /** 静态复算：使用独立实例，不推进实时会话状态。 */
  static?: boolean;
}

interface LiveState {
  streamId: string;
  alg: EndiBackrestAlgorithmInstance;
  lastRawT: number | null;
  lastT: number | null;
  results: WeakMap<Matrix, ContinuousForceFrame>;
}

let live: LiveState | null = null;

/** 清空实时会话（切换数据源、传感器或重置显示时调用）。 */
export function resetLiveEndiBackrest(): void {
  live = null;
}

/**
 * 计算靠背一帧的力、面积与压强。
 * @param native 串口 wireMap 解码的原生方向 32×25 物理 ADC（未补偿）
 */
export function calculateEndiBackrestForce(native: Matrix | null | undefined, context?: EndiBackrestStreamContext): ContinuousForceFrame | null {
  if (!isAdcMatrix(native, NATIVE_ROWS, NATIVE_COLS)) return null;
  const input = endiBackrestNativeToAlgorithm(native);
  const isLive = !!context && !context.static && typeof context.streamId === "string" && Number.isFinite(context.timestampMs);
  if (!isLive) {
    const out = new EndiBackrestAlgorithm().process(input, 0);
    return toForceFrame(out, input);
  }
  if (!live || live.streamId !== context!.streamId) {
    live = { streamId: context!.streamId!, alg: new EndiBackrestAlgorithm(), lastRawT: null, lastT: null, results: new WeakMap() };
  }
  const cached = live.results.get(native);
  if (cached) return cached;
  const rawT = context!.timestampMs!;
  let t = rawT;
  // 同一毫秒内到达的多帧保持严格递增；时间真正倒退时交由核心重置。
  if (live.lastRawT !== null && live.lastT !== null && rawT >= live.lastRawT) t = Math.max(rawT, live.lastT + 0.001);
  const out = live.alg.process(input, t);
  live.lastRawT = rawT;
  live.lastT = t;
  const frame = toForceFrame(out, input);
  live.results.set(native, frame);
  return frame;
}

/**
 * T39 轮廓格数面积：在补偿前插值矩阵（原生方向 64×50，或随显示旋转后的 50×64）上统计 ADC ≥ 39 的格子，
 * 每格 1.30 cm²。设备插值与算法插值逐格一致且与转置可交换，因此与算法内部轮廓同口径；用于框选统计与采集留档。
 */
export function analyzeEndiBackrestArea(
  sourceMatrix: Matrix,
  options: { selection?: { startRow: number; startCol: number; endRow: number; endCol: number } | null } = {},
): EndiBackrestAreaFrame {
  const R = Array.isArray(sourceMatrix) ? sourceMatrix.length : 0;
  const C = R ? sourceMatrix[0]?.length ?? 0 : 0;
  const okShape = (R === 2 * NATIVE_ROWS && C === 2 * NATIVE_COLS) || (R === 2 * NATIVE_COLS && C === 2 * NATIVE_ROWS);
  if (!okShape || !isAdcMatrix(sourceMatrix, R, C)) throw new TypeError("需要 64×50 或 50×64 补偿前插值 ADC 矩阵");
  const T = ENDI_BACKREST_AREA_THRESHOLD_ADC;
  const sel = options.selection;
  const r0 = sel ? Math.max(0, Math.min(sel.startRow, sel.endRow)) : 0;
  const r1 = sel ? Math.min(R - 1, Math.max(sel.startRow, sel.endRow)) : R - 1;
  const c0 = sel ? Math.max(0, Math.min(sel.startCol, sel.endCol)) : 0;
  const c1 = sel ? Math.min(C - 1, Math.max(sel.startCol, sel.endCol)) : C - 1;
  let count = 0;
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) if (sourceMatrix[r][c] >= T) count++;
  const areaCm2 = Math.round(count * ENDI_BACKREST_CELL_AREA_CM2 * 1e6) / 1e6;
  return {
    version: ENDI_BACKREST_AREA_VERSION, modelVersion: ENDI_BACKREST_AREA_VERSION,
    algorithmId: "endi-backrest-t39-contour-count", algorithmLabel: "恩迪靠背T39轮廓格数面积",
    sensorType: "new-backrest-32x25", status: count > 0 ? "measured" : "no_contact", unit: "cm²",
    scope: sel ? "selection" : "full_frame", rows: R, cols: C, cellAreaCm2: ENDI_BACKREST_CELL_AREA_CM2,
    areaCm2, retainedCellCount: count, thresholdAdc: T,
  };
}
