/** Supplement force contacts only. Frozen area seeds stay in their exact order.
 * Absolute ADC/local support thresholds avoid suppressing a weak contact when a
 * stronger stack arrives. Area calculation and calibration coefficients do not
 * use the supplemented list. This detector does not establish force accuracy.
 */
export type BackrestForceSeed = [number, number];
function reflect(i:number,n:number):number {while(i<0||i>=n)i=i<0?-i-1:2*n-i-1;return i;}
function gaussian(a:number[][],sigma=1.5):number[][] {
 const rows=a.length,cols=a[0].length,radius=Math.floor(4*sigma+.5),k:number[]=[];let total=0;
 for(let d=-radius;d<=radius;d++){const w=Math.exp(-.5*d*d/(sigma*sigma));k.push(w);total+=w;}for(let i=0;i<k.length;i++)k[i]/=total;
 const v=a.map(row=>row.map(()=>0)),out=a.map(row=>row.map(()=>0));
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)for(let d=-radius;d<=radius;d++)v[r][c]+=a[reflect(r+d,rows)][c]*k[d+radius];
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)for(let d=-radius;d<=radius;d++)out[r][c]+=v[r][reflect(c+d,cols)]*k[d+radius];
 return out;
}
function valueAt(a:number[][],r:number,c:number):number {
 r=Math.max(0,Math.min(a.length-1,r));c=Math.max(0,Math.min(a[0].length-1,c));const r0=Math.floor(r),c0=Math.floor(c),r1=Math.min(a.length-1,r0+1),c1=Math.min(a[0].length-1,c0+1),fr=r-r0,fc=c-c0;
 return a[r0][c0]*(1-fr)*(1-fc)+a[r1][c0]*fr*(1-fc)+a[r0][c1]*(1-fr)*fc+a[r1][c1]*fr*fc;
}
export function supplementBackrestForceSeeds(source:number[][],areaSeeds:BackrestForceSeed[]):BackrestForceSeed[] {
 const rows=source.length,cols=source[0].length,seeds=areaSeeds.map(p=>[p[0],p[1]] as BackrestForceSeed),smooth=gaussian(source),seen=new Uint8Array(rows*cols),candidates:{seed:BackrestForceSeed;value:number}[]=[];
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
  const start=r*cols+c;if(seen[start]||source[r][c]<=10)continue;
  const stack=[start],component:number[]=[];seen[start]=1;let peak=0;
  while(stack.length){const index=stack.pop()!,rr=Math.floor(index/cols),cc=index%cols;component.push(index);peak=Math.max(peak,source[rr][cc]);
   for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=rr+dr,nc=cc+dc;if(nr<0||nr>=rows||nc<0||nc>=cols)continue;const next=nr*cols+nc;if(!seen[next]&&source[nr][nc]>10){seen[next]=1;stack.push(next);}}
  }
  if(component.length<20||peak<25)continue;
  const local=source.map(row=>row.map(()=>0));for(const i of component)local[Math.floor(i/cols)][i%cols]=source[Math.floor(i/cols)][i%cols];const z=gaussian(local);let bestR=0,bestC=0,bestValue=-Infinity;
  for(let rr=0;rr<rows;rr++)for(let cc=0;cc<cols;cc++)if(z[rr][cc]>bestValue){bestValue=z[rr][cc];bestR=rr;bestC=cc;}
  candidates.push({seed:[bestR,bestC],value:bestValue});
 }
 const peaks:{seed:BackrestForceSeed;value:number}[]=[];
 for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
  const v=smooth[r][c];if(v<5)continue;let maximum=true;
  for(let dr=-1;dr<=1&&maximum;dr++)for(let dc=-1;dc<=1;dc++)if(smooth[reflect(r+dr,rows)][reflect(c+dc,cols)]>v){maximum=false;break;}
  if(maximum)peaks.push({seed:[r,c],value:v});
 }
 const sort=(a:{seed:BackrestForceSeed;value:number},b:{seed:BackrestForceSeed;value:number})=>b.value-a.value||a.seed[0]-b.seed[0]||a.seed[1]-b.seed[1];peaks.sort(sort);
 const separated:BackrestForceSeed[]=[];for(const p of peaks)if(separated.every(q=>(q[0]-p.seed[0])**2+(q[1]-p.seed[1])**2>=36)){separated.push(p.seed);candidates.push(p);}
 candidates.sort(sort);
 for(const {seed:q} of candidates){
  let nearest=-1,dist=Infinity;for(let i=0;i<seeds.length;i++){const d=Math.hypot(q[0]-seeds[i][0],q[1]-seeds[i][1]);if(d<dist){dist=d;nearest=i;}}
  if(dist<6)continue;
  let support=0,physicalSupport=0,sum=0,peak=0;
  for(let r=Math.max(0,q[0]-5);r<=Math.min(rows-1,q[0]+5);r++)for(let c=Math.max(0,q[1]-5);c<=Math.min(cols-1,q[1]+5);c++)if((r-q[0])**2+(c-q[1])**2<=20.25){const v=source[r][c];sum+=v;peak=Math.max(peak,v);if(v>10){support++;if(r%2===0&&c%2===0)physicalSupport++;}}
  if(support<20||physicalSupport<4||sum<400||peak<25)continue;
  if(nearest>=0&&dist<13){const other=seeds[nearest],steps=Math.max(3,Math.ceil(dist*2));let saddle=Infinity;for(let i=0;i<steps;i++){const t=i/(steps-1);saddle=Math.min(saddle,valueAt(smooth,q[0]*(1-t)+other[0]*t,q[1]*(1-t)+other[1]*t));}if(saddle>Math.min(smooth[q[0]][q[1]],smooth[other[0]][other[1]])*.78)continue;}
  seeds.push(q);
 }
 return seeds;
}

// Force-only supplementation. It does not change the calibrated ADC-to-force model or area calculation.
export function supplementSeatForceContacts(source:number[][],existing:number[][]):number[][] {
  const rows=source.length,cols=source[0]?.length??0,result=existing.map(p=>p.slice());
  if(!result.length||!rows||!cols)return result;
  const index=(r:number,c:number)=>r*cols+c;
  // Recover disconnected, locally significant patches without a global-maximum-relative cutoff.
  const components=new Int32Array(rows*cols);let component=0;
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++) {
    if(source[r][c]<=20||components[index(r,c)])continue;
    component++;const queue:number[][]=[[r,c]],points:number[][]=[];components[index(r,c)]=component;let maximum=0;
    for(let head=0;head<queue.length;head++) {
      const p=queue[head];points.push(p);maximum=Math.max(maximum,source[p[0]][p[1]]);
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++) {
        const nr=p[0]+dr,nc=p[1]+dc;
        if(nr<0||nr>=rows||nc<0||nc>=cols||source[nr][nc]<=20||components[index(nr,nc)])continue;
        components[index(nr,nc)]=component;queue.push([nr,nc]);
      }
    }
    if(points.length<32||maximum<40||result.some(p=>components[index(p[0],p[1])]===component))continue;
    // The ADC-weighted centre is deterministic; tiny isolated spikes cannot satisfy the support test.
    let total=0,rs=0,cs=0;for(const p of points){const w=source[p[0]][p[1]]**2;total+=w;rs+=p[0]*w;cs+=p[1]*w;}
    const mean=[rs/total,cs/total];let best=points[0],distance=Infinity;
    for(const p of points){const d=(p[0]-mean[0])**2+(p[1]-mean[1])**2;if(d<distance||(d===distance&&(p[0]<best[0]||(p[0]===best[0]&&p[1]<best[1])))){distance=d;best=p;}}
    if(result.every(p=>(p[0]-best[0])**2+(p[1]-best[1])**2>=36))result.push(best.slice());
  }
  // Split only broad, elongated support. Repeat over each partition so the number of contacts is unrestricted.
  let changed=true;
  while(changed) {
    changed=false;const labels=new Int32Array(rows*cols);
    for(let r=0;r<rows;r++)for(let c=0;c<cols;c++) {
      let best=0,distance=Infinity;
      for(let j=0;j<result.length;j++){const d=(r-result[j][0])**2+(c-result[j][1])**2;if(d<distance){distance=d;best=j;}}
      labels[index(r,c)]=best;
    }
    for(let j=0;j<result.length;j++) {
      const points:number[][]=[];let total=0,rs=0,cs=0;
      for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)if(labels[index(r,c)]===j&&source[r][c]>30){const w=source[r][c]**2;points.push([r,c,w]);total+=w;rs+=r*w;cs+=c*w;}
      if(points.length<120||total<=0)continue;
      const row=rs/total,col=cs/total;let vr=0,vc=0,cov=0;
      for(const p of points){vr+=p[2]*(p[0]-row)**2;vc+=p[2]*(p[1]-col)**2;cov+=p[2]*(p[0]-row)*(p[1]-col);}vr/=total;vc/=total;cov/=total;
      const disc=Math.sqrt((vr-vc)**2+4*cov*cov),small=(vr+vc-disc)/2,large=(vr+vc+disc)/2;
      if(large<2*Math.max(small,1e-12))continue;
      let axis:number[];
      if(Math.abs(cov)>1e-12){axis=[cov,large-vr];const norm=Math.hypot(...axis);axis=axis.map(v=>v/norm);}
      else axis=vr>=vc?[1,0]:[0,1];
      if(axis[0]<0||(axis[0]===0&&axis[1]<0))axis=axis.map(v=>-v);
      let means:number[][]=[],valid=true;
      for(let k=0;k<2;k++) {
        let weight=0,rSum=0,cSum=0;
        for(const p of points)if((((p[0]-row)*axis[0]+(p[1]-col)*axis[1])>0?1:0)===k){weight+=p[2];rSum+=p[0]*p[2];cSum+=p[1]*p[2];}
        if(weight<=0){valid=false;break;}means.push([rSum/weight,cSum/weight]);
      }
      if(!valid)continue;
      let assignments:number[]=[];
      for(let iteration=0;iteration<12;iteration++) {
        assignments=points.map(p=>(p[0]-means[0][0])**2+(p[1]-means[0][1])**2<=(p[0]-means[1][0])**2+(p[1]-means[1][1])**2?0:1);
        const next:number[][]=[];
        for(let k=0;k<2;k++) {
          let weight=0,rSum=0,cSum=0;
          points.forEach((p,i)=>{if(assignments[i]===k){weight+=p[2];rSum+=p[0]*p[2];cSum+=p[1]*p[2];}});
          if(weight<=0){valid=false;break;}next.push([rSum/weight,cSum/weight]);
        }
        if(!valid)break;means=next;
      }
      if(!valid||assignments.filter(k=>k===0).length<35||assignments.filter(k=>k===1).length<35||Math.hypot(means[0][0]-means[1][0],means[0][1]-means[1][1])<5)continue;
      const seeds:number[][]=[];
      for(let k=0;k<2;k++) {
        let best:number[]|null=null,distance=Infinity;
        points.forEach((p,i)=>{if(assignments[i]!==k)return;const d=(p[0]-means[k][0])**2+(p[1]-means[k][1])**2;if(d<distance){distance=d;best=p;}});
        if(best)seeds.push((best as number[]).slice(0,2));
      }
      if(seeds.length!==2||(seeds[0][0]-seeds[1][0])**2+(seeds[0][1]-seeds[1][1])**2<25)continue;
      result.splice(j,1,...seeds);changed=true;break;
    }
  }
  return result;
}
