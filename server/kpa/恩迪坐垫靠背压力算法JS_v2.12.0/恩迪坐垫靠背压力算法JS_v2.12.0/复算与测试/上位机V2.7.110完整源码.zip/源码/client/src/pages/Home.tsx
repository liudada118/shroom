/**
 * 设计提醒：遵循“工业仪表盘保真迁移”原则；以低干扰深色工作台承托热力图，保留源代码的数据可读性、操作密度与状态反馈。
 * 矩桥标定软件 V2.7.110 - 主页面
 *
 * V2.7.110 更新（2026-11-14）：
 * - 坐垫真人估算区逐格压强最大值 ×1.5：进入真人估算档后，真人区格子压强改为 Pᵢ = P区 × ADCᵢ^γ / mean(ADC区^γ)，
 *   γ ≥ 1 自动求解使最大格 = 原比例分配最大格 × 1.5；按 0.001 N/cm² 保和取整，区内格子平均仍 = P区，
 *   平均压强仍 = 全部压强格子的平均值（与热力图格子同步）；进入/退出按 120 ms 过渡。标准档、超量程、靠背不变。
 * - 最大压强在热力图上标注：最大压强格加红框并显示“最大 x.xxx N/cm²”标签（ADC 与压强两种显示都标注，
 *   框选时标框内最大格），与“最大压强”卡片同一格同一值；放大镜内同一格标“最大”。工具栏“最大标注”可开关（默认开）。
 *
 * V2.7.109 更新（2026-11-14）：
 * - 热力图放大镜：工具栏“放大镜”开关 + 5×5 / 7×7 / 9×9 / 11×11 范围选择（默认 7×7，热力图上滚动滚轮也可调整）；
 *   打开后鼠标移到热力图上，跟随鼠标显示以当前格为中心的放大窗口，格内完整显示压强（N/cm² 3 位小数）或 ADC，
 *   主图上用青色框标出放大范围；与主热力图同一矩阵、同一帧，只读显示，不改变任何面积、压力、压强计算。
 *
 * V2.7.108 更新（2026-11-13）：
 * - 靠背（背垫）超量程估算面积 ×2：超量程区面积 = T39 轮廓面积 × 2（压力 ×2 不变），区压强 = 2F / 2S = F / S；
 *   触发与取消条件（基准力与拟合力均 > 90 N，任一回落 ≤ 90 N 持续 500 ms 取消）、120 ms 过渡、平均压强 = 压强格子平均均不变；
 *   框选面积中超量程区每格按 2.60 cm²；明细“识别”列显示“超量程估算 · 压力×2 面积×2”。坐垫不变。
 *
 * V2.7.107 更新（2026-11-13）：
 * - 坐垫真人估算面积系数 0.8 → 0.9（压力系数 0.4 不变，压强 = 0.4F / 0.9S ≈ 0.444 × 基准压强）；
 *   触发条件、与超量程互斥、500 ms 退出防抖、120 ms 过渡、平均压强 = 压强格子平均均不变；框选面积中真人区每格按 0.9 cm²。
 *
 * V2.7.106 更新（2026-11-13）：
 * - 坐垫真人估算压力系数 1 → 0.4（面积系数 0.8 不变，压强 = 0.4F / 0.8S = 0.5 × 基准压强）；
 *   触发条件（全帧基准面积 > 600 cm² 且基准力 > 300 N）、与超量程互斥、500 ms 退出防抖、120 ms 过渡不变；平均压强 = 压强格子平均。
 *
 * V2.7.105 更新（2026-11-13）：
 * - 坐垫真人估算压力系数 0.4 → 1（压力不折算；面积系数 0.8 不变，压强 = F / 0.8S = 1.25 × 基准压强）；
 *   触发条件、与超量程互斥（真人区不乘 ×2）、500 ms 退出防抖、120 ms 过渡不变；平均压强仍 = 压强格子平均。
 *
 * V2.7.104 更新（2026-11-13）：
 * - 坐垫真人估算压力系数 0.3 → 0.4（面积系数 0.8 不变，压强 = 0.4F / 0.8S = 0.5 × 基准压强）。
 * - 平均压强 = 热力图全部压强格子的平均值，与格子显示的压强同步（同一帧、同一 0.001 N/cm² 取整）；
 *   个别接触区压强缺失时也按格子平均显示，不再出现卡片“--”而格子有值。
 *
 * V2.7.103 更新（2026-11-13）：
 * - 删除原超量程判定（坐垫 m_fit>9.6kg/峰值>185/λ>5.5/档位>5，靠背 m_fit>9.4kg/峰值>184/λ>5.5）与 V2.7.102 真人判定（非砝码轮廓且 T29>131 格）。
 * - 超量程估算（坐垫+靠背）：接触区基准估算力 > 90 N 且连续拟合估算力 > 90 N（双重确认超过 5 块砝码）时启动，压力 ×2，面积取轮廓；
 *   任一回落 ≤ 90 N 连续 500 ms 后取消。
 * - 真人估算（仅坐垫）：全帧基准面积 > 600 cm² 且全帧基准力 > 300 N 时启动，非标准档接触区压力 ×0.3（V2.7.104 起 ×0.4，V2.7.105 起 ×1，V2.7.106 起 ×0.4）、面积 ×0.8（V2.7.107 起 ×0.9）；
 *   条件连续不满足 500 ms 后退出（无接触立即退出）；
 *   真人估算与超量程互斥（真人区不再乘 ×2）。系数切换按 120 ms S 曲线过渡。
 *
 * V2.7.102 更新（2026-11-13）：
 * - 坐垫（恩迪 23×23）真人估算：非砝码轮廓（footprint=false，核心“估算/超量程估算”分支）且 T29 轮廓 > 131 格的接触区压力 ×0.3、面积 ×0.8，
 *   压强 = 0.3F / 0.8S；砝码标准档与砝码叠放超量程不变；靠背不变。逐格压强、最大压强、平均压强随区压强同步；
 *   框选面积中真人估算区的格子按 ×0.8 折算；接触区明细“识别”列标注“真人估算 · 压力×0.3 面积×0.8”。
 *
 * V2.7.101 更新（2026-11-13）：
 * - 压强单位改为 N/cm²，保留 3 位小数（平均压强、最大压强、接触区明细、热力图格子/悬停/框选统计、色标、切换按钮“压强 N/cm²”）；
 *   内部字段仍为 kPa（1 N/cm² = 10 kPa），按 0.01 kPa = 0.001 N/cm² 取整，显示与内部数值一致。
 * - 压力保留 2 位小数：恩迪坐垫/靠背各区压力先取 2 位小数，总力 = Σ 各区压力；各区压强 Pⱼ = Fⱼ/Sⱼ。
 * - 逐格压强改为 Pᵢ = P区 × ADCᵢ / mean(ADC区)，按 0.001 N/cm² 保和取整（最大余数法），区内格子压强平均值 = P区；
 *   平均压强 = 全部压强格子的平均值，热力图格子上显示的压强平均值与“平均压强”卡片一致（单个接触区时即该区 Fⱼ/Sⱼ）。
 *
 * V2.7.100 更新（2026-11-09）：
 * - 热力图工具栏新增“格子显示：ADC | 压强 kPa”切换按钮；切到压强后每个插值格子直接显示该格逐格压强（自动打开数值，
 *   零格显示 0，非零保留 1 位小数；格子太窄时（靠背 64 列）≥10 kPa 显示整数，文字超宽时横向压缩/缩小字号；悬停读数 2 位小数），
 *   恩迪坐垫/靠背空载时保持压强显示（全 0），不再弹回 ADC。
 * - 撤销 V2.7.99 对接触区明细的改动：恢复面积列（与 V2.7.98 相同）。逐格压强算法、最大压强（逐格）卡片与采集记录不变。
 *
 * V2.7.99 更新（2026-11-09）：
 * - 坐垫与靠背新增逐格压强（lib/endiPointPressure.ts）：每个接触区 Pᵢ = P区 × ADCᵢ / median(ADC区)，
 *   P区为恩迪算法同一帧的接触区平均压强，ADCᵢ为热力图显示的插值ADC（补偿后），区内格子与算法面积口径相同（坐垫T29、靠背T39轮廓格）。
 * - 最大压强卡片改为逐格压强最大值（框选时取框内）；热图“压强 kPa”显示同一套逐格压强；采集记录的最大压强与压强热图同步改用逐格压强。
 * - 接触区明细的面积列替换为压强点位（点位数、ADC中位数、点压强范围）；物理矩阵对照面板不再显示原独立标定的最大压强。
 *
 * V2.7.98 更新（2026-11-09）：
 * - 靠背（new-backrest-32x25）面积与压力算法替换为“恩迪靠背实测拟合算法”（lib/endiBackrestForce.ts + lib/endiBackrest/）：
 *   位置锚点＋相对档位状态机，参数由44位置×1–5块标准砝码实测拟合；输入未补偿原始物理ADC（原生32×25转置为25×32）。
 * - 靠背面积、总力、各区压强与平均压强全部来自该算法同一帧；原靠背逐格曲线/区间估算、原靠背面积模型、面积≥600真人分支不再参与计算。
 * - 计算设置中移除靠背力值算法切换；接触区明细增加识别方式与质量；框选面积改为同口径T39轮廓格数（1.30 cm²/格）。
 * - 坐垫算法（V2.7.97）、逐点热图与最大压强、采集与导出格式保持原样。
 *
 * V2.7.97 更新（2026-11-09）：
 * - 坐垫（恩迪23×23）面积与压力算法替换为“恩迪坐垫实测拟合算法”（lib/endiSeatForce.ts + lib/endiCushion/）：
 *   位置锚点＋相对档位状态机，参数由31位置×1–5块标准砝码实测拟合；输入未补偿原始物理ADC（原生方向顺时针90°）。
 * - 坐垫面积、总力、各区压强与平均压强全部来自该算法同一帧；原坐垫区间估算、原面积模型、面积≥600真人分支不再参与坐垫计算。
 * - 计算设置中移除坐垫力值算法切换与稳定显示选项；接触区明细增加识别方式与质量；框选面积改为同口径T29轮廓格数。
 * - 靠背算法、逐点热图与最大压强、采集与导出格式保持原样。
 *
 * V2.7.96 更新（2026-11-02）：
 * - 移除旧过滤、ADC补偿、结果标定与真人k调参控件、提示及其持久化；使用现有标定默认值。
 * - 主分区连续估算、面积600真人分支和最大压强显示规则保持原样。
 *
 * V2.7.90 更新（2026-10-30）：
 * - 坐垫默认按原始23×23 ADC逐接触区识别六档砝码，主力值与平均压强共用标称力；保留旧算法可切换。
 * - 采集重用实时因果计算快照，原始ADC字节与拟合导出保持原格式；靠背算法保持V2.7.87。
 *
 * V2.7.81 更新（2026-10-29）：
 * - 坐垫分区分段曲线试用，可切回V80补偿；面积、总力、区域平均压强同步稳定显示，精度未通过验收。
 * - 坐垫高载荷实测修正，目标±3N；保留原面积、区域平均压强与快速显示滤波。
 * - 每个完整输入帧参与力值显示计算；加载直接跟随、小回落轻滤波，每20ms发布并保留区间峰值。
 * - 靠背逐格ADC求力后按区域求和，采用g=9.8；保留原面积和坐垫算法。
 * - 靠背总力接入原始物理ADC的12特征模型；原面积算法保持不变。
 * - 总力模型使用独立显示平滑轨迹，采集保留逐帧未经平滑的力值。
 *
 * V2.7.67 更新（2026-09-16）：
 * - 采集缓存恢复保存数据源原始字节、插值前物理矩阵及补偿前插值矩阵。
 * - CSV/XLSX恢复原始数据统计与逐帧明细；补偿后显示、压强标定和归一化仍只读取补偿后过滤矩阵。
 *
 * V2.7.66 更新（2026-09-03）：
 * - 删除坐垫一致性校正、网格/区域辅助线和噪点检测；热力图保留数值、框选、锁定及物理点定位。
 * - 采集不再持久化原始字节/物理矩阵，CSV/XLSX仅导出补偿后统计与压强结果，不再输出ADC矩阵明细。
 * - ADC补偿重构为坐垫/靠背独立模块，可分别启停、编辑倍率和偏移并持久化；每帧锁定补偿快照。
 * - 砝码段逐点比例归一化保持生效，实时与导出明确显示scale及AVG(Pᵢ)-P̄均值守恒误差。
 *
 * V2.7.65 更新（2026-09-03）：
 * - 核实实时统计、排序区间ADC均值和压力标定均来自补偿后且过滤30的同一矩阵。
 * - 将实时统计卡、物理矩阵对照和单位统一标为“补偿后ADC”，修复链路已生效但字段说明不完整的问题。
 *
 * V2.7.64 更新（2026-09-01）：
 * - 每帧统一执行：一致性校正 → 坐垫JSON一次函数补偿（靠背恒等）→ 补偿后ADC≤30过滤 → 显示 → 压强标定。
 * - 坐垫凸分段节点等价换算到补偿后ADC域，补偿前后压力函数最大数值差1.42×10⁻¹⁴kPa；靠背公式不变。
 * - 串口、CSV、演示、实时统计、采集缓存和CSV/XLSX导出共用补偿后矩阵；Sheet1/Sheet2结构保持不变。
 *
 * V2.7.63 更新（2026-09-01）：
 * - 双传感器重新拟合为凸分段线性，压强严格上升且每一段斜率都大于前一段，不再出现平台或斜率回落。
 * - 全部处理版真实E/G记录绝对误差≤2.49kPa；坐垫留一位置亦全部≤2.50kPa，靠背留一位置49/50≤2.50kPa。
 * - 27kPa钳位、TOP取点、砝码归一化、真人段k、热力图、采集和导出保持不变。
 *
 * V2.7.62 更新（2026-09-01）：
 * - 修复V2.7.61分段公式的水平段：双传感器全部分段斜率至少0.010kPa/ADC，27kPa钳位前压强随ADC严格上升。
 * - 固定原ADC节点和27kPa边界，仅小幅调整节点压强；处理版E/G全部记录仍满足±2.70kPa。
 * - TOP取点、砝码归一化、真人段k、热力图、采集和导出保持不变。
 *
 * V2.7.61 更新（2026-09-01）：
 * - 双传感器低中压段保持V2.7.60，仅对高压区受约束上拉，使高ADC输出继续分开上升到27kPa后再钳位。
 * - 坐垫在ADC=173.740达到27kPa；靠背TOP46均值在ADC=189.430达到27kPa，均保持处理版E/G全样本±2.70kPa达标。
 * - TOP取点、砝码归一化、真人段k、热力图、采集和导出保持不变。
 *
 * V2.7.60 更新（2026-09-01）：
 * - 坐垫、靠背分别按《坐垫处理版.xlsx》《靠背处理版.xlsx》第一张工作表E列输入、G列真实压强重拟合。
 * - 坐垫采用17节点16段线性，ADC>173.740钳位25kPa；靠背采用18节点17段线性，TOP46均值ADC>181.797368钳位25kPa。
 * - 双传感器全样本及留一位置组均100%满足27kPa满量程±10%；TOP取点、砝码归一化、真人段k、热力图、采集和导出保持不变。
 *
 * V2.7.59 更新（2026-09-01）：
 * - 双传感器基础曲线和高端上限分别按新上传工作簿第一张工作表E列输入、G列真实压强重新拟合。
 * - 坐垫为17节点16段满量程约束线性，ADC>176.79钳位25kPa；靠背为60%分位九段线性，TOP46均值ADC>186.616钳位25kPa。
 * - 27kPa继续作为满量程±10%误差参考；G列最高真值为25kPa，不再把25—27kPa容差区间当作真值曲线。
 * - 排序取点、砝码逐点归一化、真人段k、热力图、采集与导出保持不变。
 *
 * V2.7.58 更新（2026-09-01）：
 * - 坐垫和靠背整曲线分位节点小幅右移，并将22.5—25kPa末段ADC宽度扩大30%。
 * - 新增连续25—27kPa宽尾段；坐垫27kPa边界ADC=185.87664，靠背边界ADC=189.562375。
 * - 排序取点、砝码逐点归一化、真人段k、热力图、采集与导出保持不变。
 *
 * V2.7.57 更新（2026-09-01）：
 * - 靠背基础标定改为《靠背处理后数据.xlsx》Sheet1 E列输入、G列真实压强的70%分位节点九段线性公式。
 * - 留一位置RMSE由6.538降至3.281kPa；ADC高于186.660时基础压强钳制25.00kPa。
 * - 坐垫、排序取点、砝码逐点归一化、真人段k、压强热力图、采集与导出保持不变。
 *
 * V2.7.56 更新（2026-09-01）：
 * - 坐垫基础标定改为《坐垫处理后数据.xlsx》Sheet1 E列输入、G列真实压强的55%分位节点九段线性公式。
 * - 留一位置RMSE由4.030降至2.942kPa；ADC高于180.618时基础压强钳制25.00kPa。
 * - 靠背、排序取点、砝码逐点归一化、真人段k、压强热力图、采集与导出保持不变。
 *
 * V2.7.55 更新（2026-08-30）：
 * - 修复压强热力图中0—1色阶输入触发色谱负索引并导致页面崩溃的问题。
 * - 压强模式对非有限矩阵值安全回退为0；噪点检测开启时仍显示kPa悬停信息。
 * - 逐点压强矩阵不可用时自动回到ADC模式；停止演示时保留最后一帧供复核。
 *
 * V2.7.54 更新（2026-08-30）：
 *   新增ADC/逐点压强热力图切换；砝码段显示归一化Pᵢ，真人段显示k×F(ADCᵢ)，同步动态色标、格内数值和悬停单位。
 *
 * V2.7.53 更新（2026-08-30）：
 *   写入附件双版本标定：坐垫V2.7.46六段PCHIP、靠背V2.7.52 TOP46七段线性；砝码段新增逐点曲线响应比例归一化，AVG(Pᵢ)=拟合平均压强，最大压强取MAX(Pᵢ)。
 *
 * V2.7.52 更新（2026-08-28）：
 *   锁定靠背Sheet1 63帧/9组TOP46中位数节点七段线性公式及留一组验证标识，计算系数与V2.7.51一致。
 *
 * V2.7.51 更新（2026-08-28）：
 *   靠背写入基于63帧TOP46真实数据的新七段线性公式，移除旧0.95修正，196.982608696后钳制18.5kPa。
 *
 * V2.7.50 更新（2026-08-28）：
 *   靠背砝码段输入由降序第5—46位均值改为最高TOP46平均；坐垫与真人段调用结构不变。
 *
 * V2.7.49 更新（2026-08-28）：
 *   靠背Praw整体倍率由0.90调整为0.95（整体下降5%），18.5kPa钳位边界同步重算；坐垫与其他链路不变。
 *
 * V2.7.48 更新（2026-08-28）：
 *   最新用户公式将靠背七段线性Praw整体乘0.90后再钳位0—18.5kPa；坐垫、取点、真人段独立k和采集导出保持不变。
 *
 * V2.7.47 更新（2026-08-28）：
 *   坐垫与靠背基础标定严格替换为用户提供的七段线性公式，统一执行0—18.5kPa钳位；取点、真人段独立k和采集导出结构保持不变。
 *
 * V2.7.46 更新（2026-08-28）：
 *   坐垫纳入补充D–F列真实数据并采用受约束6段PCHIP，留一位置RMSE/MAE/最大误差均下降；靠背补充数据复核后保留泛化更好的V2.7.45节点。
 *
 * V2.7.45 更新（2026-08-28）：
 *   坐垫与靠背均按各自工作簿D–F列重拟合为6段PCHIP；高于最高节点时基础压强钳制18.50kPa，真人段逐点执行对应基础公式后乘独立k。
 *
 * V2.7.44 更新（2026-08-27）：
 *   新增浏览器会话内连续采集：每个完整数据帧均保存；连续帧单独导出至XLSX新增工作表，既有Sheet1/Sheet2不变。
 *
 * V2.7.43 更新（2026-08-13）：
 *   坐垫基础公式替换为新采集的5段PCHIP；ADC高于154.001111时基础压强钳制16.00kPa，真人段逐点先执行基础公式再乘k。
 *
 * V2.7.42 更新（2026-08-13）：
 *   砝码段有效 ADC 降序排序后，坐垫取第5—70位、靠背取最高TOP46的均值进入各自用户公式。
 *
 * V2.7.41 更新（2026-07-22）：
 *   有效点数 > 300 时进入真人段，对全部有效点逐点套用九段公式后乘传感器独立动态系数 k；
 *   真人段平均压强取逐点结果均值、最大压强取逐点结果最大值，k 默认 2.2、范围 1.0–6.0。
 *
 * V2.6.2 更新：
 * - 新增「坐垫传感器 23×23 单点一致性标定」：在原始 ADC 进入压强拟合公式之前，
 *   先用 23×23 一致性系数矩阵（V2.6.2、原始数据集 667 帧）逐点归一化。
 *   使同一砥码放置任何点位后归一化 ADC 都接近目标值 115，点位间 CV 0.58%。
 * - 新增「一致性标定」工具栏开关（仅 23×23 可用，默认开启）；关闭后走原始流程以便对比。
 * - handleFrame 重算 max/min/avg/nonZeroMin/sum/nonZeroCount，避免上下游拿到未同步的统计。
 *
 * V2.5.0 更新：
 * - 靠背传感器(32×25)压强标定完成：三次多项式 R²=0.9972
 * - 10个标定点（50帧数据，5个位置×10级砝码）
 *
 * V2.4.0 更新：
 * - 简化标定：去掉A/B/C多模式，只保留"压强标定"开关
 * - 压强标定使用过滤后非零总和(sum)三次多项式拟合
 * - 基于2026-04-17更新的 11 组标定点数据（共计60帧）
 * - 压强标定: 稳态sum三次多项式 R²=0.9991
 *
 * V1.0.7 更新：
 * - 自动采集的清零判断考虑过滤阈值，低于阈值的残留值视为已清零
 * - 未清零点位提示只显示超过过滤阈值的点位
 *
 * V1.0.6 更新：
 * - 取消自动锁定点位的默认行为，改为采集前用户选择是否启用锁定
 * - 新增“点位锁定”开关（默认关闭），启用后可选择自动/手动锁定模式
 * - 关闭锁定时自动清除已有的锁定点位
 *
 * V1.0.5 更新：
 * - 过滤功能增强：被过滤数据不显示不计算，导出时显示为*
 *
 * V1.0.4 更新：
 * - 去掉模式1/2/4/5，恢复V1.0.2原始数据压强标定公式
 * - 新增热力图框选统计功能
 * V1.0.3 更新：
 * - 座垫传感器压强重新标定（V2数据，5组×多次测量，三次多项式拟合，R²=0.9935）
 * - 清空所有压强标定数据（座椅和靠背），等待重新标定
 * - 导出表头简化为：采集时间、帧序号、原始数据总和、原始数据点数
 *
 * V0.4.0 更新：
 * - 去掉4个统计字段：最小值（含零）、非零最小值、预计压强、覆盖率
 * - 新增"最大值坐标"字段：显示原始数值非零最大值的位置坐标（左下角为原点）
 * - 靠背5段拟合压力区间标签更新为0~5kPa/5.01~10kPa/10.01~15kPa/15.01~20kPa/20.01~25kPa
 *
 * V0.3.8 更新：
 * - 靠背传感器压强拟合从11段简化为5段（0/5/10/15/20/25 KPa锚点）
 *
 * V0.3.6 更新：
 * - 锁定点位可视化：热力图上非锁定点位半透明遮罩，锁定区域青色边框标记
 * - 锁定延迟可配置：0.5~5秒，默认1秒
 * - 手动锁定模式：在热力图上拖拽框选区域锁定点位
 * - 自动/手动锁定模式切换按钮
 * - 清除锁定按钮
 *
 * V0.3.5 更新：
 * - 新增导出设置面板：可自选导出模式（原始数据/模式1-8）
 * - 可选是否包含矩阵数据、偏差率分析、子表格
 * - 每区域点位数可配置（1~20）
 * - CSV和XLSX导出均支持自选选项
 *
 * V0.3.3 更新：
 * - 靠背拟合锚点更新：红色帧也纳入有效数据，数据量从248帧增加到399帧
 * - 仅剔除3倍IQR极端异常值，平均误差0.3%
 *
 * V0.3.2 更新：
 * - 全新靠背拟合方法：每帧25×25矩阵→去0值→IQR核心区域→4个最接近值→中位数基准
 * - 基于248条有效帧，平均误差0.3%
 *
 * V0.3.1 更新：
 * - 靠背压强拟合锚点修正（基于276条有效数据，剔除红色无效帧）
 * - 1~10砝码中位数误差均≤1.1%
 *
 * V0.3.0 更新：
 * - 坐垫和靠背都改为每区域2个点位（CSV和XLSX导出同步修改）
 * - 靠背拟合公式修正：基于960+48帧数据，采用简化线性方案
 * - XLSX导出红色规则调整：区域红色 = 2个点位都红
 * 
 * V0.2.9 更新：
 * - 基于24区域×2点×10级砂码标定数据（960帧）拟合靠背传感器专用压强公式
 * - 使用IQR方法剔陇47个异常帧，分段线性插值（10个中位数锚点）
 * - 靠背传感器压强公式不区分标定模式，所有模式共用同一套拟合参数
 * - 座椅传感器压强公式完全不受影响
 * - 新增靠背传感器‘24区域布局（4行×6列，区域1在右下角，区域24在左下角）
 * - 统一压强估算入口estimatePressureAuto，根据sensorType自动选择公式
 * 
 * V0.2.8 更新：
 * - 修复靠背传感器wireMap映射：帧大小从4096改为1024字节，stride从64改为32
 * - 基于线序文档(endiBack1024)实现正确的行列映射和180度旋转
 * - 靠背传感器砝码位置现在正确显示
 * 
 * V0.2.7 更新：
 * - 压强单位从Pa改为KPa，保留两位小数
 * - 修复导出中预计压强与实时压强值一致的bug，预计压强现使用采集时的锁定值
 * - 分离“清空帧”和“清空本地缓存”：清空帧只清内存，本地缓存保留
 * - 新增本地缓存状态显示和独立清空缓存按钮
 * - 预计压强锁定后均值大幅上升(>1.5倍)时直接重新2秒计时更新，无需先清零
 * 
 * V0.2.6 更新：
 * - 原“预计压强”改名为“实时压强”，跟随每帧实时变化
 * - 新增“预计压强”字段：检测到数据大幅上升2秒后锁定显示，有效点数=0时归零
 * - 实时压强和预计压强均纳入XLSX和CSV导出
 * 
 * V0.2.4 更新：
 * - 重新拟合：基于16区域×2帧实测数据+1~10砂码标定数据，采用多段分段线性拟合（11段/模式）
 * - 鼠标悬停“预计压强”卡片右上角i图标可查看当前模式的全部分段拟合公式
 * - 修复预计压强在某些模式下显示为0或极端值的bug
 * 
 * V0.2.3 更新：
 * - 修复预计压强显示为0的bug（多项式负值回退到线性插值）
 * - 修复传感器褶皱时显示50KPa的bug（有效点数<3时不计算）
 * - 单位从KPa改为Pa
 * - 新增拟合公式可视化展示
 * 
 * V0.2.2 更新：
 * - 新增“预计压强”实时统计字段
 * - 基于1~10个砂码标定数据，对每个标定模式进行3阶多项式拟合
 * - 传感器均值实时转换为压强值
 * 
 * V0.2.1 更新：
 * - 模式1~7改为自适应百分比区间模式（15%~90%到75%~90%）
 * - 模式8基于V0.2.0综合优化方案，结合近三天数据自主优化
 * - 版本号升级至V0.2.1
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Hash,
  Zap,
  Play,
  Square,
  Pause,
  Upload,
  Camera,
  Trash2,
  Download,
  ArrowUp,
  ArrowDown,
  TrendingUp,
  Gauge,
  Activity,
  Eye,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Info,
  Grid3X3,
  Target,
  Crosshair,
  Circle,
  Dot,
  Maximize2,
  Minimize2,
  Settings2,
  X,
  Timer,
  RotateCcw,
  RotateCw,
  Lock,
  BoxSelect,
  Weight,
  ZoomIn,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Heatmap, { type AreaSelection } from "@/components/Heatmap";
import { DEFAULT_MAGNIFIER_SIZE, MAGNIFIER_SIZES } from "@/components/HeatmapMagnifier";
import CaptureHistory from "@/components/CaptureHistory";
import StatCard from "@/components/StatCard";
import DraggablePanel from "@/components/DraggablePanel";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import LogPanel from "@/components/LogPanel";
import { useDemo, type FrameData } from "@/hooks/useDemo";
import { useSerial, type LogEntry } from "@/hooks/useSerial";
import { getSensorConfig, SENSOR_LIST } from "@/lib/sensorConfig";
import { parseCsvContent } from "@/lib/csvParser";
import { applyFilter, type CalibrationMode, type FilteredStats } from "@/lib/dataFilter";
import { ADC_POST_COMPENSATION_FILTER_THRESHOLD, compensateAndFilterAdcMatrix, createDefaultAdcCompensationSettings, getAdcCompensationFingerprint, getAdcCompensationProfile, hasAdcCompensationMarker, summarizeAdcMatrix } from "@/lib/adcCompensation";
import { calculatePressureMetricsFromMatrix, DEFAULT_HUMAN_COEFFICIENT, estimateAvgPressure, estimateAvgPressureAuto, estimateMaxPressureAuto, getAvgFitInfoAuto, getMaxFitInfoAuto, getPressureInputLabel, MIN_VALID_POINTS, type PressureCalibrationBranch } from "@/lib/pressureFit";
import { attachEndiPointPressure, endiContourOwnerMatrix, endiPointPressureMatrix, endiSeatSelectionHumanAreaDeduction, endiSelectionAreaFactorAdjustment, maxPressureCellInSelection } from "@/lib/endiPointPressure";
import { PRESSURE_DISPLAY_UNIT, formatPressureNcm2, kPaToNcm2 } from "@/lib/pressureUnits";
import { computeMatrixSummary } from "@/lib/statistics";
import { calculateDisplayedArea } from "@/lib/displayArea";
import { calculateLiveSensorForce, resetLiveSeatForce, resetLiveBackrestForce, type ContinuousForceFrame } from "@/lib/sensorForce";
import {
  ENDI_SEAT_MODEL_VERSION, type EndiSeatRegionDiagnostics, ENDI_SEAT_HUMAN_FORCE_FACTOR, ENDI_SEAT_HUMAN_AREA_FACTOR,
  ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2, ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N, ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N, ENDI_SEAT_OVER_RANGE_GAIN,
  ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN,
} from "@/lib/endiSeatForce";
import { ENDI_BACKREST_CELL_AREA_CM2, ENDI_BACKREST_MODEL_VERSION, ENDI_BACKREST_OVER_RANGE_AREA_GAIN, ENDI_BACKREST_OVER_RANGE_FORCE_THRESHOLD_N, ENDI_BACKREST_OVER_RANGE_GAIN, type EndiBackrestRegionDiagnostics } from "@/lib/endiBackrestForce";

/** 恩迪坐垫单区识别结果的简短说明（接触区明细表用）。 */
function describeEndiRegion(region: EndiSeatRegionDiagnostics | EndiBackrestRegionDiagnostics): string {
  // V2.7.103：坐垫真人估算（全帧面积 > 600 cm² 且力 > 300 N）与超量程（基准力 > 90 N）互斥。
  if ("humanEstimate" in region && region.humanEstimate) {
    return `真人估算 · 压力×${ENDI_SEAT_HUMAN_FORCE_FACTOR} 面积×${ENDI_SEAT_HUMAN_AREA_FACTOR} 最大压强×${ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN}`;
  }
  if (region.mode === "超量程估算") {
    // V2.7.108：靠背超量程面积同样 ×2（坐垫超量程面积不乘）。
    if ("factorKind" in region) return `超量程估算 · 压力×${ENDI_SEAT_OVER_RANGE_GAIN}`;
    return `超量程估算 · 压力×${ENDI_BACKREST_OVER_RANGE_GAIN} 面积×${ENDI_BACKREST_OVER_RANGE_AREA_GAIN}`;
  }
  if (region.mode === "标准档") return `${region.level > 0 ? `标准档 ${region.level} 块` : "标准档"} · ${region.state}`;
  return region.mode;
}
import type { BackrestForceMethod } from "@/lib/backrestForce";
import type { SeatForceMethod } from "@/lib/seatTotalForceFrame";
import { capturedAveragePressureKPa } from "@/lib/backrestRegionPressure";
import { ForceReadout, captureForceReadout, type CapturedForceReadout, type ForceReadoutSnapshot } from "@/lib/forceReadout";
import { CAPTURE_MATRIX_ROW_ORDER, orientCaptureMatrix, CAPTURE_MATRIX_COLUMN_ORDER, heatmapColumnIndex } from "@/lib/captureOrientation";
import { APP_VERSION } from "@/lib/version";
import { exportToXlsx, type ExportOptions } from "@/lib/xlsxExport";
import { buildCaptureCsv } from "@/lib/csvExport";
import {
  saveFrameAndSession,
  deleteStoredFrame,
  getAllFrames,
  getFrameCount,
  clearAll as clearAllDB,
  hasUnfinishedSession,
  type StoredCapturedFrame,
  type CapturedAreaMetrics,
  type CapturedForceMetrics,
  type CaptureSession,
} from "@/lib/captureStorage";

const MAX_FRAMES = 2000;

// Fixed calibration defaults. Removed toolbar values and legacy storage cannot
// override active measurements; historical frame metadata remains readable.
const filterThreshold = ADC_POST_COMPENSATION_FILTER_THRESHOLD;
const resultScale = 1;
const adcCompensationSettings = createDefaultAdcCompensationSettings();
const activeHumanCoefficient = DEFAULT_HUMAN_COEFFICIENT;
/** 统计字段定义 */
interface StatField {
  key: string;
  label: string;
  icon: React.ReactNode;
  accent: string;
}

type CapturedFrameData = Omit<FrameData, "physical" | "sourceMatrix" | "sourcePhysical" | "raw"> & {
  /** 补偿后、按采集方向旋转并与热力图从上到下行序一致的矩阵。 */
  matrix: number[][];
  /** 数据源提供的原始字节序列。 */
  raw?: number[];
  /** 与本帧当前模式热力图完全一致，按屏幕方向排列。 */
  heatmapMatrix?: number[][];
  /** 插值前原始ADC物理矩阵；新采集按热力图方向旋转并上下翻转。 */
  physical?: number[][];
  /** ADC补偿前、按采集方向旋转并上下翻转的插值矩阵。 */
  sourceMatrix?: number[][];
};

interface CapturedFrame {
  id: number;
  /** standard为既有手动/自动采集；continuous仅导出至新增连续采集工作表。 */
  captureKind?: "standard" | "continuous";
  /** 连续采集在当前会话内从1开始的帧序号。 */
  continuousSequence?: number;
  /** 同时保存原始字节/矩阵与补偿后显示矩阵；压强计算只读取matrix。 */
  data: CapturedFrameData;
  capturedAt: Date;
  sensorType: string;
  /** 采集时的过滤后统计数据（当前模式） */
  filteredStats?: FilteredStats;
  areaMetrics?: CapturedAreaMetrics;
  forceMetrics?: CapturedForceMetrics;
  /** 当时屏幕上的平滑显示快照，含其原帧时间；不替代本帧forceMetrics。 */
  forceDisplayMetrics?: CapturedForceReadout;
  /** 采集时的配置 */
  captureConfig?: {
    filterThreshold: number;
    resultScale: number;
    visibleFields: string[];
    /** 有此标记的矩阵已按热力图行序保存，导出/恢复时直接读取。 */
    matrixRowOrder?: typeof CAPTURE_MATRIX_ROW_ORDER;
    matrixColumnOrder?: typeof CAPTURE_MATRIX_COLUMN_ORDER;
    /** 采集时的矩阵旋转状态。 */
    matrixRotation?: number;
    heatmapValueMode?: "adc" | "pressure";
    heatmapValueUnit?: "ADC" | "kPa";
    adcCompensationVersion?: string;
    adcCompensation?: {
      sensor: "seat" | "backrest";
      enabled: boolean;
      scale: number;
      offset: number;
      fingerprint: string;
    };
  };
  /** 采集时的锁定压强值(KPa)，用于导出中的"预计压强"字段 */
  lockedPressureKPa?: number | null;
  /** 采集时的平均压强(KPa) */
  avgPressureKPa?: number | null;
  /** 采集时的最大压强(KPa) */
  maxPressureKPa?: number | null;
  /** 采集时用于砝码段压强公式的插值矩阵排序区间均值 ADC。 */
  pressureInputAdc?: number;
  /** 采集时参与排序区间均值的有效点数。 */
  pressureInputTopCount?: number;
  /** 采集时实际采用的砝码段 / 真人段。 */
  calibrationBranch?: PressureCalibrationBranch;
  /** 采集时真人段使用的传感器独立动态系数。 */
  humanCoefficient?: number | null;
  /** 砝码段逐点压强比例归一化系数。 */
  pressureNormalizationScale?: number | null;
  /** 砝码段基础曲线响应平均值。 */
  pressureCurveResponseMeanKPa?: number | null;
  /** 砝码段逐点平均值与拟合目标平均值之差。 */
  pressureMeanConservationErrorKPa?: number | null;
  /** 实际逐点计算数量。 */
  pointPressureCount?: number;
  /** 砝码段异常回退状态。 */
  pointPressureFallbackMode?: "none" | "no-valid-points" | "all-zero" | "equal-distribution" | null;
  /** 采集时的最大值坐标 */
  maxCoordStr?: string;
}

/** 压强拟合公式详情展示组件（鼠标悬停tooltip） */
function PressureFormulaDetail({
  sensorType,
  nonZeroCount,
  humanCoefficient,
  backrestMethod,
  seatMethod,
  which,
}: {
  sensorType?: string;
  nonZeroCount?: number;
  humanCoefficient?: number;
  backrestMethod?: BackrestForceMethod;
  seatMethod?: SeatForceMethod;
  which?: "avg" | "max" | "both";
}) {
  const mode = which ?? "both";
  const avgInfo = getAvgFitInfoAuto(sensorType, nonZeroCount, humanCoefficient);
  const maxInfo = getMaxFitInfoAuto(sensorType, nonZeroCount, humanCoefficient);
  const regionAverage = sensorType === "new-backrest-32x25" ? {
    name: "靠背接触区平均压强（恩迪靠背实测拟合）", formula: "Fⱼ=9.8×mⱼ（标准档 mⱼ=1.625kg×λⱼ，λⱼ为位置锚点换算的连续档位；非砝码轮廓按连续拟合；基准估算力与连续拟合估算力均>90N（超过5块）为超量程，Fⱼ×2）；Sⱼ=63.62cm²（标准档）或T39轮廓格数×1.30cm²（超量程×2，V2.7.108）；Fⱼ取2位小数，Pⱼ=Fⱼ/Sⱼ（N/cm²，3位小数）；平均压强=全部压强格子的平均值（N/cm²）",
    range: "44个位置×1–5块（1.625–8.125kg）实测拟合；单个接触区时平均压强=该区Pⱼ；框选不改变此值", r2: "不适用（锚点识别＋连续拟合）",
    note: "总力、面积、各区压强与平均压强来自同一算法同一帧；输入为未补偿原始物理ADC（原生32×25转置为25×32）。逐格压强 Pᵢ=P区×ADCᵢ/mean(ADC区)，每个区内格子压强的平均值=P区，热力图格子上显示的压强平均值=平均压强；最大压强=MAX(Pᵢ)。",
  } : sensorType === "endi-23x23" ? {
    name: "坐垫接触区平均压强（恩迪坐垫实测拟合）", formula: "Fⱼ=9.8×mⱼ（标准档 mⱼ=1.625kg×λⱼ，λⱼ为位置锚点换算的连续档位；非砝码轮廓按连续拟合；基准估算力与连续拟合估算力均>90N（超过5块）为超量程，Fⱼ×2）；Sⱼ=63.62cm²（标准档）或T29轮廓格数×1cm²；真人估算（全帧面积>600cm²且力>300N，与超量程互斥）非标准档区Fⱼ×0.4、Sⱼ×0.9（压强=0.4F/0.9S），逐格最大压强×1.5；Fⱼ取2位小数，Pⱼ=Fⱼ/Sⱼ（N/cm²，3位小数）；平均压强=全部压强格子的平均值（N/cm²）",
    range: "31个位置×1–5块（1.625–8.125kg）实测拟合；单个接触区时平均压强=该区Pⱼ；框选不改变此值", r2: "不适用（锚点识别＋连续拟合）",
    note: "总力、面积、各区压强与平均压强来自同一算法同一帧；输入为未补偿原始物理ADC。逐格压强 Pᵢ=P区×ADCᵢ/mean(ADC区)（真人估算区改为按ADCᵢ^γ分配，最大格=原比例最大格×1.5），每个区内格子压强的平均值=P区，热力图格子上显示的压强平均值=平均压强；最大压强=MAX(Pᵢ)。",
  } : avgInfo;
  const endiPointMax = sensorType === "new-backrest-32x25" || sensorType === "endi-23x23" ? {
    name: "最大压强（恩迪逐格压强）",
    formula: `各接触区：Pᵢ=P区×ADCᵢ/mean(ADC区)，按0.001 N/cm²保和取整（区内格子平均=P区）；ADCᵢ为热力图显示的插值ADC（补偿后），区内格子为${sensorType === "endi-23x23" ? "T29" : "T39"}轮廓格${sensorType === "endi-23x23" ? "；坐垫真人估算区：Pᵢ=P区×ADCᵢ^γ/mean(ADC区^γ)，γ≥1使最大格=原比例分配最大格×1.5（区内格子平均仍=P区）" : ""}；最大压强=MAX(Pᵢ)（N/cm²），热力图上红框标出最大格`,
    range: "全帧取所有接触区格子的最大值；框选时取框内格子的最大值", r2: "不适用（按区平均压强与ADC比例分配）",
    note: "P区为恩迪实测拟合算法同一帧的接触区压强（Fⱼ/Sⱼ）；某格ADC比本区平均ADC高（低）x%，该格压强就高（低）x%；区外格子为0。热力图“格子显示”切到“压强 N/cm²”后，每个格子显示的就是这套逐格压强（3位小数）",
  } : maxInfo;
  const items = mode === "avg" ? [regionAverage] : mode === "max" ? [endiPointMax] : [regionAverage, endiPointMax];
  if (!items[0]) return <div className="text-[10px] text-muted-foreground">无拟合数据</div>;
  return (
    <div className="space-y-2">
      {items.map((info, idx) => info && (
        <div key={idx} className="space-y-1">
          <div className="text-[10px] text-muted-foreground font-medium">{info.name}</div>
          <div className="bg-background/60 rounded px-2 py-1.5 font-mono text-[8px] text-foreground/90 leading-relaxed overflow-x-auto">
            <div className="mb-1">公式: {info.formula}</div>
            <div className="mb-1">范围: {info.range}</div>
            <div>R² = {info.r2}</div>
          </div>
          <div className="text-[8px] text-muted-foreground/50 leading-tight">
            {info.note}
          </div>
        </div>
      ))}
    </div>
  );
}

const formatHeatmapAdc = (value: number) => String(Math.round(value));
/** V2.7.101：压强热图数值单位 N/cm²，保留 3 位小数（热图矩阵已换算为 N/cm²）。 */
const formatHeatmapPressure = (value: number) => value.toFixed(3);
/** V2.7.101：格内压强文字——零格（接触区外）显示 0，非零保留 3 位小数（N/cm²）。 */
const formatHeatmapPressureCell = (value: number) => (value > 0 ? value.toFixed(3) : "0");
/** V2.7.101：格子太窄时（如靠背 64 列）仍保留 3 位小数，仅省略整数位的 0（0.854 → .854），其余靠横向压缩/缩小字号；放大热力图后恢复完整写法。 */
const formatHeatmapPressureCellCompact = (value: number) => (value > 0 ? value.toFixed(3).replace(/^0\./, ".") : "0");
const DISPLAY_FRAME_INTERVAL_MS = 50;

export default function Home() {
  // 传感器类型
  const [sensorType, setSensorType] = useState("endi-23x23");
  const usesRegionMeanPressure = sensorType === "new-backrest-32x25" || sensorType === "endi-23x23";
  // 坐垫与靠背均使用恩迪实测拟合算法（面积、力、各区压强与平均压强同源）。
  const endiFittedSensor = sensorType === "endi-23x23" || sensorType === "new-backrest-32x25";
  const config = getSensorConfig(sensorType);
  const totalPoints = config.rows * config.cols;

  // 当前帧数据（原始）
  const [currentFrame, setCurrentFrame] = useState<FrameData | null>(null);

  // 显示选项
  const [showValues, setShowValues] = useState(true); // 默认开启数值显示
  // V2.7.109：热力图放大镜（开关与每边格数）
  const [magnifierEnabled, setMagnifierEnabled] = useState(false);
  const [magnifierSize, setMagnifierSize] = useState<number>(DEFAULT_MAGNIFIER_SIZE);
  // V2.7.110：热力图最大压强格标注开关（默认开）。
  const [maxMarkerEnabled, setMaxMarkerEnabled] = useState(true);
  const [heatmapValueMode, setHeatmapValueMode] = useState<"adc" | "pressure">("adc");
  const activeAdcCompensation = getAdcCompensationProfile(sensorType, adcCompensationSettings);

  // 矩阵旋转角度（0=原始, 1=顺时针90°, 2=180°, 3=顺时针270°即逆时针90°）
  // V2.7.15: useSerial 内部不再做 rotate180，matrix/physical 同源；默认 3 = 顺时针 270°，
  // 等价于「先 180° 后顺时针 90°」，保持与 V2.7.5 显示方向一致，且小面板与大图天然同方向。
  const [matrixRotation, setMatrixRotation] = useState(3);

  // V2.3.0: 标定始终启用
  const calibrationMode: CalibrationMode = "pressure";

  // 暂停状态
  const [isPaused, setIsPaused] = useState(false);
  const pausedRef = useRef(false);

  // CSV 模式
  const [csvFrames, setCsvFrames] = useState<any[]>([]);
  const [csvMode, setCsvMode] = useState(false);
  const [csvIndex, setCsvIndex] = useState(0);
  const [csvPlaying, setCsvPlaying] = useState(false);
  const csvIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const csvFileRef = useRef<HTMLInputElement>(null);

  // 帧采集
  const [capturedFrames, setCapturedFrames] = useState<CapturedFrame[]>([]);
  // 连续采集帧独立保存；V2.7.67同时导出统计、原始字节和原始矩阵明细。
  const [continuousFrames, setContinuousFrames] = useState<CapturedFrame[]>([]);
  const [continuousCapturing, setContinuousCapturing] = useState(false);
  const captureIdRef = useRef(0);
  const continuousSequenceRef = useRef(0);
  const continuousActiveRef = useRef(false);
  const [continuousFrameLimit, setContinuousFrameLimit] = useState(10);
  const continuousRoundLimitRef = useRef(10);
  const continuousRoundCountRef = useRef(0);
  const [continuousRoundCount, setContinuousRoundCount] = useState(0);
  const continuousFramesRef = useRef<CapturedFrame[]>([]);
  // Only UI publication is batched. Every incoming frame is saved immediately.
  const continuousPublishTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const publishContinuousFrames = useCallback(() => {
    if (continuousPublishTimerRef.current !== null) clearTimeout(continuousPublishTimerRef.current);
    continuousPublishTimerRef.current = null;
    setContinuousFrames([...continuousFramesRef.current]);
    setContinuousRoundCount(continuousRoundCountRef.current);
  }, []);
  const standardFrameCountRef = useRef(0);
  const continuousFrameCountRef = useRef(0);
  const lastFrameRef = useRef<FrameData | null>(null);
  const forceReadoutRef = useRef(new ForceReadout());
  const forceReadoutSnapshotRef = useRef<ForceReadoutSnapshot | null>(null);
  const forceSourceEpochRef = useRef(0);
  const [forceSmoothingEnabled, setForceSmoothingEnabled] = useState(true);
  // 坐垫自 V2.7.97 起固定使用恩迪坐垫实测拟合算法；该值仅保留在会话标识中，不再提供切换。
  const [seatForceMethod] = useState<SeatForceMethod>("fixed_load_recognition");
  // 靠背自 V2.7.98 起固定使用恩迪靠背实测拟合算法；该值仅保留在会话标识中，不再提供切换。
  const [backrestPressureMethod] = useState<BackrestForceMethod>("fixed_load_recognition");
  const backrestRecognitionMode = sensorType === "new-backrest-32x25" && backrestPressureMethod === "fixed_load_recognition";
  const seatRecognitionMode = sensorType === "endi-23x23" && seatForceMethod === "fixed_load_recognition";
  const fixedLoadRecognitionMode = backrestRecognitionMode || seatRecognitionMode;
  const [forceReadoutSnapshot, setForceReadoutSnapshot] = useState<ForceReadoutSnapshot | null>(null);
  const forceReadoutTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const receiveForceFrameRef = useRef<(frame: FrameData) => void>(() => {});
  const displayTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // 本地缓存帧数（IndexedDB中的帧数）
  const [cachedFrameCount, setCachedFrameCount] = useState(0);
  const cacheRevisionRef = useRef(0);
  const cacheWriteErrorShownRef = useRef(false);

  // 自动采集帧（放置检测模式）
  const [autoCapturing, setAutoCapturing] = useState(false); // 是否处于自动采集监测中
  const [autoCaptureInterval, setAutoCaptureInterval] = useState(5); // 采集间隔（秒）
  const [framesPerRound, setFramesPerRound] = useState(10); // 每轮采集帧数

  // 采集面板显示控制；左侧统计常显。
  const [showCapturePanel, setShowCapturePanel] = useState(true);
  useEffect(() => {
    if (sensorType === "new-backrest-32x25" || sensorType === "endi-23x23") {
      setShowCapturePanel(false);
    }
  }, [sensorType]);

  // 导出进度
  const [exportProgress, setExportProgress] = useState<number | null>(null);
  const exportBusyRef = useRef(false);

  // 统计字段顺序
  const [statFieldOrder] = useState<string[]>(["area", "force", "avgPressure", "max", "maxCoord", "avg", "maxPressure", "sum", "nonZeroCount"]);
  const [expectedNonZero, setExpectedNonZero] = useState(25); // 期望有效点位数
  const [nonZeroTolerance, setNonZeroTolerance] = useState(2); // 有效点位允差范围
  const [autoPaused, setAutoPaused] = useState(false); // 自动采集是否暂停
  const autoPausedRef = useRef(false);
  type AutoState = "idle" | "waiting" | "stabilizing" | "collecting" | "round_done" | "zeroing" | "invalid";
  // idle: 未启动, waiting: 等待放置, stabilizing: 数据上升后等待稳定
  // collecting: 采集中(每隔N秒采一帧), round_done: 本轮采完提示重新放置
  // zeroing: 等待传感器清零, invalid: 无效放置
  const [autoState, setAutoState] = useState<AutoState>("idle");
  const [autoTimer, setAutoTimer] = useState(0); // 当前计时（秒）
  const [autoMessage, setAutoMessage] = useState(""); // 状态提示消息
  const [roundFrameCount, setRoundFrameCount] = useState(0); // 本轮已采帧数
  const [roundNumber, setRoundNumber] = useState(0); // 当前轮次
  const autoTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoStateRef = useRef<AutoState>("idle");
  const zeroingWarningShownRef = useRef(false); // 是否已显示清零提醒
  const autoTimerCountRef = useRef(0);
  const timerStartRef = useRef(0); // 计时开始的绝对时间戳(ms)
  const roundFrameCountRef = useRef(0); // 本轮已采帧数ref
  const roundNumberRef = useRef(0); // 当前轮次ref
  const lastSuccessNonZeroCountRef = useRef<number | null>(null); // 上一次成功采集的有效点位数
  const baselineNonZeroCountRef = useRef(0); // 基线有效点位数（无物品时）
  const placementDetectedRef = useRef(false); // 是否已检测到放置
  const framesPerRoundRef = useRef(10);
  const captureFrameRef = useRef<((kind?: "standard" | "continuous", sequence?: number, incomingFrame?: FrameData) => CapturedFrame | undefined) | null>(null);

  // 点位锁定：数据上涨后1秒锁定有效点位，后续只计算锁定点位内的值
  const lockedPositionsRef = useRef<Set<string> | null>(null); // 锁定的点位坐标集合 "row,col"
  const positionLockDoneRef = useRef(false); // 本轮是否已完成点位锁定
  const [lockedPositionCount, setLockedPositionCount] = useState<number | null>(null); // UI显示锁定点位数
  const [lockEnabled, setLockEnabled] = useState(false); // V1.0.6: 是否启用点位锁定，默认关闭
  const lockEnabledRef = useRef(false);
  const [lockDelay, setLockDelay] = useState(1); // 锁定延迟（秒），默认1秒
  const [lockMode, setLockMode] = useState<'auto' | 'manual'>('auto'); // 锁定模式：auto自动/manual手动
  const lockDelayRef = useRef(1);
  const lockModeRef = useRef<'auto' | 'manual'>('auto');

  // 数据恢复相关
  const [showRecoveryDialog, setShowRecoveryDialog] = useState(false);
  const [recoveryInfo, setRecoveryInfo] = useState<{ session: CaptureSession; frameCount: number } | null>(null);
  const [isRecovering, setIsRecovering] = useState(false);

  // 日志
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logOpen, setLogOpen] = useState(false);
  const pendingLogsRef = useRef<LogEntry[]>([]);
  const logFlushTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // 悬停信息
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number; value: number } | null>(null);

  // 框选统计
  const [areaSelectMode, setAreaSelectMode] = useState(false);
  const [areaSelection, setAreaSelection] = useState<AreaSelection | null>(null);

  // 全屏模式
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showOriginalPoints, setShowOriginalPoints] = useState(false);
  const [hoveredPhysical, setHoveredPhysical] = useState<{ pr: number; pc: number } | null>(null);

  // 统计字段保持当前默认值，采集和导出沿用同一配置。
  const [statFieldVisibility] = useState<Record<string, boolean>>({
    area: true,
    force: true,
    max: true,
    maxCoord: true,
    avg: true,
    avgPressure: true,
    maxPressure: true,
    sum: true,
    nonZeroCount: true,
  });

  // 统计字段定义
  const pressureInputLabel = getPressureInputLabel(sensorType);
  const statFields: StatField[] = useMemo(() => [
    { key: "area", label: "面积", icon: <BoxSelect className="w-4 h-4" />, accent: "#34d399" },
    { key: "force", label: "压力", icon: <Gauge className="w-4 h-4" />, accent: "#fbbf24" },
    { key: "max", label: "最大值（补偿后ADC）", icon: <ArrowUp className="w-4 h-4" />, accent: "#f87171" },
    { key: "maxCoord", label: "最大值坐标（补偿后）", icon: <Crosshair className="w-4 h-4" />, accent: "#60a5fa" },
    { key: "avg", label: `${pressureInputLabel} 补偿后ADC均值`, icon: <Gauge className="w-4 h-4" />, accent: "#10b981" },
    { key: "avgPressure", label: "平均压强", icon: <Target className="w-4 h-4" />, accent: "#f472b6" },
    { key: "maxPressure", label: sensorType === "endi-23x23" || sensorType === "new-backrest-32x25" ? "最大压强（逐格）" : "最大压强（补偿后标定）", icon: <Target className="w-4 h-4" />, accent: "#e879f9" },
    { key: "sum", label: "补偿后ADC总和", icon: <Zap className="w-4 h-4" />, accent: "#fbbf24" },
    { key: "nonZeroCount", label: "补偿后有效点数（>30）", icon: <Activity className="w-4 h-4" />, accent: "#a78bfa" },
  ], [pressureInputLabel, sensorType, fixedLoadRecognitionMode, usesRegionMeanPressure]);

  // 矩阵旋转函数：将矩阵顺时针旋转 times 次 90°
  const rotateMatrix = useCallback((matrix: number[][], times: number): number[][] => {
    const t = ((times % 4) + 4) % 4;
    if (t === 0) return matrix;
    let result = matrix;
    for (let i = 0; i < t; i++) {
      const rows = result.length;
      const cols = result[0].length;
      const rotated: number[][] = Array.from({ length: cols }, () => new Array(rows));
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          rotated[c][rows - 1 - r] = result[r][c];
        }
      }
      result = rotated;
    }
    return result;
  }, []);

  // 旋转后的当前帧数据
  const rotatedFrame = useMemo<FrameData | null>(() => {
    if (!currentFrame) return null;
    if (matrixRotation === 0) return currentFrame;
    const rotatedMatrix = rotateMatrix(currentFrame.matrix, matrixRotation);
    // 物理矩阵也同步旋转，以便对比图方向与主图一致
    const rotatedPhysical = currentFrame.physical
      ? rotateMatrix(currentFrame.physical, matrixRotation)
      : undefined;
    // 重新计算统计值（旋转不影响统计值，但矩阵引用需要更新）
    return {
      ...currentFrame, matrix: rotatedMatrix, physical: rotatedPhysical,
      sourceMatrix: currentFrame.sourceMatrix ? rotateMatrix(currentFrame.sourceMatrix, matrixRotation) : undefined,
      sourcePhysical: currentFrame.sourcePhysical ? rotateMatrix(currentFrame.sourcePhysical, matrixRotation) : undefined,
    };
  }, [currentFrame, matrixRotation, rotateMatrix]);

  // V2.7.15：旋转后的有效区域掩码（bool[][] → 0/1 矩阵进旋转 → 回 bool[][]）
  const rotatedValidMask = useMemo<boolean[][] | null>(() => {
    if (!config.validMask) return null;
    if (matrixRotation === 0) return config.validMask;
    const numMatrix = config.validMask.map((row) => row.map((v) => (v ? 1 : 0)));
    const rotated = rotateMatrix(numMatrix, matrixRotation);
    return rotated.map((row) => row.map((v) => v === 1));
  }, [config.validMask, matrixRotation, rotateMatrix]);

  const rotatedPhysicalValidMask = useMemo<boolean[][] | null>(() => {
    if (!config.physicalValidMask) return null;
    if (matrixRotation === 0) return config.physicalValidMask;
    const numMatrix = config.physicalValidMask.map((row) => row.map((v) => (v ? 1 : 0)));
    const rotated = rotateMatrix(numMatrix, matrixRotation);
    return rotated.map((row) => row.map((v) => v === 1));
  }, [config.physicalValidMask, matrixRotation, rotateMatrix]);

  // 原始物理矩阵（23×23 / 32×25）实时统计
  // V2.7.5：同步应用 resultScale，保证与主图 displayStats 严格同口径
  // （插值后 matrix 走了 Math.round(v×scale)，这里也走同样公式。
  const physicalStats = useMemo(() => {
    const phys = rotatedFrame?.physical;
    if (!phys || phys.length === 0) return null;
    const rows = phys.length;
    const cols = phys[0]?.length ?? 0;
    if (cols === 0) return null;
    // V2.7.15：有效区域掩码（旋转后同步），不规则传感器时跳过无效格
    const mask = rotatedPhysicalValidMask;
    let max = 0, min = 255, sum = 0, nonZeroCount = 0, nonZeroMin = 255;
    let maxR = 0, maxC = 0;
    let validTotal = 0; // V2.7.15：只统计有效格数，用于平均值
    for (let r = 0; r < rows; r++) {
      const row = phys[r];
      for (let c = 0; c < cols; c++) {
        if (mask && mask[r] && mask[r][c] === false) continue;
        validTotal++;
        const raw = row[c];
        let v = raw > 0 ? Math.max(0, Math.round(raw * resultScale)) : 0;
        // V2.7.15：过滤阈值对原始矩阵统计同步生效，低于等于阈值的值视为 0
        if (filterThreshold > 0 && v > 0 && v <= filterThreshold) v = 0;
        if (v > max) { max = v; maxR = r; maxC = c; }
        if (v < min) min = v;
        sum += v;
        if (v > 0) {
          nonZeroCount++;
          if (v < nonZeroMin) nonZeroMin = v;
        }
      }
    }
    if (nonZeroCount === 0) nonZeroMin = 0;
    const total = validTotal; // V2.7.15：total 只算有效点
    const avg = total > 0 ? Math.round((sum / total) * 100) / 100 : 0;
    const avgNonZero = nonZeroCount > 0 ? Math.round((sum / nonZeroCount) * 100) / 100 : 0;
    return { rows, cols, total, max, min, sum, nonZeroCount, nonZeroMin, avg, avgNonZero, maxR, maxC };
  }, [rotatedFrame?.physical, resultScale, filterThreshold, rotatedPhysicalValidMask]);

  // 应用过滤后的数据（V1.0.3: 恢复标定模式）
  // V2.7.15：不规则传感器时，先把 validMask=false 的位置强制置 0，避免它们参与 displayStats 统计。
  const filteredData = useMemo<FilteredStats | null>(() => {
    if (!rotatedFrame) return null;
    let matrixForFilter = rotatedFrame.matrix;
    if (rotatedValidMask) {
      matrixForFilter = rotatedFrame.matrix.map((row, r) =>
        row.map((v, c) => (rotatedValidMask[r]?.[c] === false ? 0 : v))
      );
    }
    return applyFilter(matrixForFilter, {
      threshold: filterThreshold,
      calibrationMode,
      resultScale,
    });
  }, [rotatedFrame, filterThreshold, calibrationMode, resultScale, rotatedValidMask]);

  // Force/area values use exactly the same matrices as the displayed area path.
  // Cache by complete frame so ingesting every serial frame does not recompute it
  // when React later paints the heatmap at its independent refresh rate.
  const frameForceCache = useMemo(() => new WeakMap<FrameData, ContinuousForceFrame | null>(),
    [sensorType, matrixRotation, filterThreshold, resultScale, config.validMask, seatForceMethod, backrestPressureMethod]);
  const calculateFrameForce = useCallback((frame: FrameData): ContinuousForceFrame | null => {
    if (frameForceCache.has(frame)) return frameForceCache.get(frame)!;
    let force: ContinuousForceFrame | null;
    if (sensorType === "endi-23x23" || sensorType === "new-backrest-32x25") {
      // 坐垫（V2.7.97）与靠背（V2.7.98）：恩迪实测拟合算法直接使用未补偿的原生物理 ADC（sourcePhysical），
      // 面积、总力、各区压强与平均压强均由该算法给出；显示旋转、过滤阈值与补偿不进入计算。
      force = calculateLiveSensorForce(sensorType, frame.sourceMatrix, frame.sourcePhysical, undefined, undefined, seatForceMethod,
        { timestampMs: frame.timestamp, streamId: `${sensorType}|${forceSourceEpochRef.current}` });
      // V2.7.99：逐格压强 Pᵢ = P区 × ADCᵢ / median(ADC区)；ADC 取本帧热力图显示矩阵（补偿后、原生方向），与力值同一帧。
      attachEndiPointPressure(force, sensorType, frame.sourcePhysical, frame.matrix);
    } else {
      const area = calculateDisplayedArea(frame.matrix, config.validMask ?? null, null, { sensorType, sourceMatrix: frame.sourceMatrix });
      force = calculateLiveSensorForce(sensorType, frame.sourceMatrix, frame.sourcePhysical, area?.areaCm2,
        undefined, seatForceMethod, { timestampMs: frame.timestamp, streamId: `${sensorType}|${forceSourceEpochRef.current}`, method: backrestPressureMethod });
    }
    frameForceCache.set(frame, force);
    return force;
  }, [frameForceCache, sensorType, matrixRotation, rotateMatrix, rotatedValidMask, filterThreshold, calibrationMode, resultScale, config.validMask, seatForceMethod, backrestPressureMethod]);

  // 帧回调
  const handleFrame = useCallback(
    (frame: FrameData) => {
      let processed = frame;
      // V2.7.67：先锁定原始字节/矩阵快照，再执行可配置ADC补偿和固定过滤30。
      // 原始快照只用于采集缓存与导出，显示和压强标定始终读取补偿后matrix。
      const sourceMatrix = (frame.sourceMatrix ?? frame.matrix).map((row) => [...row]);
      const sourcePhysical = (frame.sourcePhysical ?? frame.physical)?.map((row) => [...row]);
      const sourceRaw = new Uint8Array(frame.raw);
      const compensatedMatrix = compensateAndFilterAdcMatrix(processed.matrix, sensorType, adcCompensationSettings);
      const compensatedPhysical = processed.physical
        ? compensateAndFilterAdcMatrix(processed.physical, sensorType, adcCompensationSettings)
        : undefined;
      const compensatedStats = summarizeAdcMatrix(compensatedMatrix);
      processed = {
        ...processed,
        matrix: compensatedMatrix,
        physical: compensatedPhysical,
        sourceMatrix,
        sourcePhysical,
        raw: sourceRaw,
        ...compensatedStats,
      };

      lastFrameRef.current = processed;
      // Pausing painting must not discard observed contact history.
      if (sensorType === "new-backrest-32x25" || sensorType === "endi-23x23") calculateFrameForce(processed);
      if (!pausedRef.current) receiveForceFrameRef.current(processed);
      // Capture each decoded input frame, independent of display pause/paint rate.
      if (continuousActiveRef.current) {
        const nextSequence = continuousSequenceRef.current + 1;
        if (captureFrameRef.current?.("continuous", nextSequence, processed)) {
          continuousSequenceRef.current = nextSequence;
          continuousRoundCountRef.current++;
          if (continuousRoundCountRef.current >= continuousRoundLimitRef.current) {
            // Stop synchronously inside ingest, before another frame in this burst.
            continuousActiveRef.current = false;
            setContinuousCapturing(false);
            publishContinuousFrames();
            toast.success(`本次已采集 ${continuousRoundCountRef.current} 帧，已自动停止，可导出CSV或XLSX`);
          }
        }
      }
      // 接收与采集始终读取最新完整帧；界面最多每50ms更新一次，不排队播放旧帧。
      if (!pausedRef.current && displayTimerRef.current === null) {
        displayTimerRef.current = setTimeout(() => {
          displayTimerRef.current = null;
          if (!pausedRef.current) setCurrentFrame(lastFrameRef.current);
        }, DISPLAY_FRAME_INTERVAL_MS);
      }
    },
    [sensorType, adcCompensationSettings, publishContinuousFrames, calculateFrameForce]
  );

  const flushLogs = useCallback(() => {
    if (logFlushTimerRef.current !== null) clearTimeout(logFlushTimerRef.current);
    logFlushTimerRef.current = null;
    const batch = pendingLogsRef.current;
    pendingLogsRef.current = [];
    if (batch.length === 0) return;
    setLogs((prev) => {
      const next = [...prev, ...batch];
      return next.length > MAX_FRAMES ? next.slice(next.length - MAX_FRAMES) : next;
    });
  }, []);

  // 高频诊断按批追加；告警和错误立即显示，清空时同时取消尚未显示的日志。
  const handleLog = useCallback((entry: LogEntry) => {
    pendingLogsRef.current.push(entry);
    if (pendingLogsRef.current.length > MAX_FRAMES) pendingLogsRef.current.shift();
    if (entry.level === "warn" || entry.level === "error") flushLogs();
    else if (logFlushTimerRef.current === null) {
      logFlushTimerRef.current = setTimeout(flushLogs, 250);
    }
  }, [flushLogs]);

  const clearLogs = useCallback(() => {
    if (logFlushTimerRef.current !== null) clearTimeout(logFlushTimerRef.current);
    logFlushTimerRef.current = null;
    pendingLogsRef.current = [];
    setLogs([]);
  }, []);
  const toggleLogPanel = useCallback(() => setLogOpen(open => !open), []);

  const resetFrameDisplay = useCallback(() => {
    if (displayTimerRef.current !== null) clearTimeout(displayTimerRef.current);
    displayTimerRef.current = null;
    if (forceReadoutTimerRef.current !== null) clearTimeout(forceReadoutTimerRef.current);
    forceReadoutTimerRef.current = null;
    lastFrameRef.current = null;
    forceSourceEpochRef.current++;
    resetLiveBackrestForce();
    resetLiveSeatForce();
    forceReadoutRef.current.reset();
    forceReadoutSnapshotRef.current = null;
    setForceReadoutSnapshot(null);
    setCurrentFrame(null);
  }, []);

  useEffect(() => () => {
    if (displayTimerRef.current !== null) clearTimeout(displayTimerRef.current);
    if (forceReadoutTimerRef.current !== null) clearTimeout(forceReadoutTimerRef.current);
    forceReadoutTimerRef.current = null;
    forceReadoutRef.current.reset();
    if (logFlushTimerRef.current !== null) clearTimeout(logFlushTimerRef.current);
    pendingLogsRef.current = [];
  }, []);

  // 串口连接
  const { state: serialState, connect, disconnect } = useSerial(sensorType, handleFrame, handleLog);

  // 演示模式
  const { isRunning: demoRunning, start: startDemo, stop: stopDemo } = useDemo(sensorType, handleFrame);
  const forceSourceEpoch = `${sensorType}|${serialState.isConnected ? "serial" : demoRunning ? "demo" : csvMode ? "csv" : "none"}|${forceSourceEpochRef.current}|rotation:${matrixRotation}|method:${seatForceMethod}|backrest:${backrestPressureMethod}|stable:${forceSmoothingEnabled}|threshold:${filterThreshold}|scale:${resultScale}`;
  useEffect(() => {
    // Reset causal contact history when the input session changes.
    resetLiveBackrestForce();
    resetLiveSeatForce();
  }, [sensorType, serialState.isConnected, demoRunning, csvMode]);

  // CSV 导入
  const handleCsvImport = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const result = parseCsvContent(content);
        if (result.error) { toast.error(`CSV 解析失败: ${result.error}`); return; }
        setCsvFrames(result.frames);
        setCsvMode(true);
        setCsvIndex(0);
        setCsvPlaying(false);
        toast.success(`成功导入 ${result.totalFrames} 帧数据`);
      } catch (err: any) { toast.error(`文件读取失败: ${err}`); }
    };
    reader.readAsText(file);
  }, []);

  // CSV 帧同步
  useEffect(() => {
    if (csvMode && csvFrames.length > 0 && csvIndex < csvFrames.length) {
      const frame = csvFrames[csvIndex];
      const rawData = frame.rawData || frame.matrix.flat();
      const stats = {
        max: frame.maxValue || Math.max(...rawData),
        min: Math.min(...rawData),
        avg: Math.round((rawData.reduce((a: number, b: number) => a + b, 0) / rawData.length) * 100) / 100,
        nonZeroMin: Math.min(...rawData.filter((v: number) => v > 0)) || 0,
        sum: frame.sum || rawData.reduce((a: number, b: number) => a + b, 0),
        nonZeroCount: rawData.filter((v: number) => v > 0).length,
      };
      handleFrame({ matrix: frame.matrix, raw: new Uint8Array(rawData), timestamp: Date.now(), ...stats });
    }
  }, [csvMode, csvFrames, csvIndex, handleFrame]);

  // CSV 自动播放
  useEffect(() => {
    if (csvPlaying && csvFrames.length > 0) {
      csvIntervalRef.current = setInterval(() => {
        setCsvIndex((prev) => {
          const next = prev + 1;
          if (next >= csvFrames.length) { setCsvPlaying(false); return prev; }
          return next;
        });
      }, 80);
    }
    return () => { if (csvIntervalRef.current) clearInterval(csvIntervalRef.current); };
  }, [csvPlaying, csvFrames]);

  // 传感器类型切换
  const handleSensorChange = (type: string) => {
    if (serialState.isConnected || demoRunning || csvMode) {
      toast.error("请先断开连接、停止演示模式或退出 CSV 模式，再切换传感器类型");
      return;
    }
    setSensorType(type);
    resetFrameDisplay();
    toast.info(`已切换到 ${getSensorConfig(type).name}`);
  };

  // 退出CSV模式
  const exitCsvMode = useCallback(() => {
    setCsvMode(false); setCsvFrames([]); setCsvIndex(0); setCsvPlaying(false); resetFrameDisplay();
    toast.info("已退出 CSV 模式");
  }, [resetFrameDisplay]);

  // 暂停/继续
  const togglePause = useCallback(() => {
    const paused = !pausedRef.current;
    pausedRef.current = paused;
    setIsPaused(paused);
    if (displayTimerRef.current !== null) clearTimeout(displayTimerRef.current);
    displayTimerRef.current = null;
    if (!paused) setCurrentFrame(lastFrameRef.current);
  }, []);

  // 帧采集：原始字节/矩阵用于留档；补偿后matrix用于显示、统计、压力和归一化。
  const captureFrame = useCallback((kind: "standard" | "continuous" = "standard", sequence?: number, incomingFrame?: FrameData) => {
    if (exportBusyRef.current) return;
    const frame = incomingFrame ?? lastFrameRef.current;
    if (!frame) { toast.error("暂无数据可采集，请先连接传感器或启动演示模式"); return; }
    captureIdRef.current++;

    // 应用旋转后的矩阵
    const matrixToUse = matrixRotation === 0 ? frame.matrix : rotateMatrix(frame.matrix, matrixRotation);
    const sourceMatrix = frame.sourceMatrix ?? frame.matrix;
    const sourceMatrixToUse = matrixRotation === 0 ? sourceMatrix : rotateMatrix(sourceMatrix, matrixRotation);
    const sourcePhysicalToUse = frame.sourcePhysical
      ? (matrixRotation === 0 ? frame.sourcePhysical : rotateMatrix(frame.sourcePhysical, matrixRotation))
      : undefined;

    // Match the live heatmap path exactly: rotate, mask, threshold and scale.
    const captureValidMask = rotatedValidMask;
    const matrixForFilter = captureValidMask
      ? matrixToUse.map((row, r) => row.map((v, c) => captureValidMask[r]?.[c] === false ? 0 : v))
      : matrixToUse;
    const processedStats = applyFilter(matrixForFilter, {
      threshold: filterThreshold,
      calibrationMode,
      resultScale,
    });

    const captureArea = calculateDisplayedArea(processedStats.filteredMatrix, captureValidMask, null, {
      sensorType,
      sourceMatrix: sourceMatrixToUse,
      sourceRotation: matrixRotation,
    });
    const captureForce = sensorType === "new-backrest-32x25" || sensorType === "endi-23x23" ? calculateFrameForce(frame)
      : calculateLiveSensorForce(sensorType, frame.sourceMatrix, frame.sourcePhysical, captureArea?.areaCm2,
      undefined, seatForceMethod,
      { timestampMs: frame.timestamp, streamId: `${sensorType}|${forceSourceEpochRef.current}`, method: backrestPressureMethod, static: true });

    // 获取当前可见的统计字段
    const visibleFields = Object.entries(statFieldVisibility)
      .filter(([, visible]) => visible)
      .map(([key]) => key);

    // V2.7.41：采集压强按本帧有效点数自动派发，并锁定采集时的传感器独立 k。
    const capturePressureMetrics = calculatePressureMetricsFromMatrix(
      processedStats.filteredMatrix,
      sensorType,
      activeHumanCoefficient,
    );
    // V2.7.99：恩迪坐垫/靠背的采集压强热图与最大压强取本帧逐格压强（旋转到与采集矩阵相同的显示方向）。
    const captureEndiPoint = captureForce ? endiPointPressureMatrix(captureForce) : null;
    const captureEndiPointDisplay = captureEndiPoint ? (matrixRotation === 0 ? captureEndiPoint : rotateMatrix(captureEndiPoint, matrixRotation)) : null;
    const capturePressureMode = heatmapValueMode === "pressure" && (captureEndiPointDisplay !== null
      || (processedStats.nonZeroCount > 0 && Boolean(capturePressureMetrics.pressureMatrixKPa?.length)));
    const captureHeatmapMatrix = capturePressureMode ? (captureEndiPointDisplay ?? capturePressureMetrics.pressureMatrixKPa!) : processedStats.filteredMatrix;
    const captureAvgP = captureForce?.contactPressure
      ? capturedAveragePressureKPa({ forceMetrics: captureForce }, null)
      : capturePressureMetrics.avgPressureKPa;
    const captureMaxP = captureEndiPointDisplay ? (captureForce?.pointPressure?.maxPressureKPa ?? null) : capturePressureMetrics.maxPressureKPa;
    // 计算最大值坐标
    let captureMaxCoord = "--";
    {
      const mat = matrixToUse;
      let mxVal = 0, mxR = 0, mxC = 0;
      for (let r = 0; r < mat.length; r++) {
        for (let c = 0; c < mat[r].length; c++) {
          if (mat[r][c] > mxVal) { mxVal = mat[r][c]; mxR = r; mxC = c; }
        }
      }
      if (mxVal > 0) { captureMaxCoord = `(${heatmapColumnIndex(mxC, mat[0].length, sensorType) + 1}, ${mxR + 1})`; }
    }
    const captured: CapturedFrame = {
      id: captureIdRef.current,
      captureKind: kind,
      continuousSequence: kind === "continuous" ? sequence : undefined,
      data: {
        matrix: orientCaptureMatrix(matrixToUse, sensorType),
        raw: Array.from(frame.raw),
        heatmapMatrix: orientCaptureMatrix(
          captureHeatmapMatrix,
          sensorType,
        ),
        physical: sourcePhysicalToUse ? orientCaptureMatrix(sourcePhysicalToUse, sensorType) : undefined,
        sourceMatrix: orientCaptureMatrix(sourceMatrixToUse, sensorType),
        timestamp: frame.timestamp,
        max: frame.max,
        min: frame.min,
        avg: frame.avg,
        nonZeroMin: frame.nonZeroMin,
        sum: frame.sum,
        nonZeroCount: frame.nonZeroCount,
      },
      capturedAt: new Date(),
      sensorType,
      // 先用实时矩阵坐标完成锁定点统计，再翻转保存快照，避免锁定索引错位。
      filteredStats: {
        ...processedStats,
        filteredMatrix: orientCaptureMatrix(processedStats.filteredMatrix, sensorType),
      },
      areaMetrics: captureArea ? {
        algorithmId: captureArea.algorithmId,
        algorithmLabel: captureArea.algorithmLabel,
        areaCm2: captureArea.areaCm2,
        retainedCellCount: captureArea.retainedCellCount,
        cellAreaCm2: captureArea.cellAreaCm2,
        thresholdAdc: captureArea.thresholdAdc,
        ...("seedCount" in captureArea ? {
          modelVersion: captureArea.modelVersion,
          seedCount: captureArea.seedCount,
          regionThresholds: captureArea.regionThresholds,
        } : {}),
        status: captureArea.status,
        ...(captureArea.algorithmId === "seat-spatial-denoised-grid-count" ? {
          areaMeaning: captureArea.areaMeaning,
          denoiseMethod: captureArea.denoiseMethod,
          sourceGridCellAreaCm2: captureArea.sourceGridCellAreaCm2,
          calibrationReferenceAreaCm2: captureArea.calibrationReferenceAreaCm2,
          countModelVersion: captureArea.countModelVersion,
        } : {}),
      } : undefined,
      forceMetrics: captureForce ?? undefined,
      forceDisplayMetrics: captureForce?.modelVersion === forceReadoutSnapshotRef.current?.modelVersion
        && captureForce?.contactDetectionVersion === forceReadoutSnapshotRef.current?.contactDetectionVersion
        && captureForce?.status === forceReadoutSnapshotRef.current?.frame.status
        && captureForce?.forceEstimateComplete === forceReadoutSnapshotRef.current?.forceEstimateComplete
        && forceReadoutSnapshotRef.current?.sourceEpoch === forceSourceEpoch
        ? captureForceReadout(forceReadoutSnapshotRef.current) : undefined,
      captureConfig: {
        filterThreshold,
        resultScale,
        visibleFields,
        matrixRowOrder: CAPTURE_MATRIX_ROW_ORDER,
        matrixColumnOrder: CAPTURE_MATRIX_COLUMN_ORDER,
        matrixRotation,
        heatmapValueMode: capturePressureMode ? "pressure" : "adc",
        heatmapValueUnit: capturePressureMode ? "kPa" : "ADC",
        adcCompensationVersion: getAdcCompensationFingerprint(adcCompensationSettings),
        adcCompensation: {
          sensor: activeAdcCompensation.sensor,
          enabled: activeAdcCompensation.enabled,
          scale: activeAdcCompensation.scale,
          offset: activeAdcCompensation.offset,
          fingerprint: getAdcCompensationFingerprint(adcCompensationSettings),
        },
      },
      lockedPressureKPa: lockedPressure,
      avgPressureKPa: captureAvgP,
      maxPressureKPa: captureMaxP,
      pressureInputAdc: capturePressureMetrics.topMean,
      pressureInputTopCount: capturePressureMetrics.topCount,
      calibrationBranch: capturePressureMetrics.calibrationBranch,
      humanCoefficient: capturePressureMetrics.humanCoefficient,
      pressureNormalizationScale: capturePressureMetrics.normalizationScale ?? null,
      pressureCurveResponseMeanKPa: capturePressureMetrics.curveResponseMeanKPa ?? null,
      pressureMeanConservationErrorKPa: capturePressureMetrics.meanConservationErrorKPa ?? null,
      pointPressureCount: captureEndiPointDisplay ? (captureForce?.pointPressure?.pointCount ?? 0) : capturePressureMetrics.pointPressureCount,
      pointPressureFallbackMode: capturePressureMetrics.pointPressureFallbackMode ?? null,
      maxCoordStr: captureMaxCoord,
    };
    const persistCapturedFrame = (standardFrameCount: number, continuousFrameCount: number) => {
      // 异步保存到 IndexedDB（不阻塞 UI）
      const storedFrame: StoredCapturedFrame = {
        id: captured.id,
        captureKind: captured.captureKind,
        continuousSequence: captured.continuousSequence,
        data: {
          matrix: captured.data.matrix,
          heatmapMatrix: captured.data.heatmapMatrix,
          raw: captured.data.raw ? [...captured.data.raw] : undefined,
          physical: captured.data.physical?.map((row) => [...row]),
          sourceMatrix: captured.data.sourceMatrix?.map((row) => [...row]),
          max: captured.data.max,
          min: captured.data.min,
          nonZeroMin: captured.data.nonZeroMin,
          avg: captured.data.avg,
          sum: captured.data.sum,
          nonZeroCount: captured.data.nonZeroCount,
          timestamp: captured.data.timestamp,
        },
        capturedAt: captured.capturedAt.toISOString(),
        sensorType: captured.sensorType,
        filteredStats: captured.filteredStats,
        areaMetrics: captured.areaMetrics,
        forceMetrics: captured.forceMetrics,
        forceDisplayMetrics: captured.forceDisplayMetrics,
        captureConfig: captured.captureConfig,
        lockedPressureKPa: captured.lockedPressureKPa,
        avgPressureKPa: captured.avgPressureKPa,
        maxPressureKPa: captured.maxPressureKPa,
        pressureInputAdc: captured.pressureInputAdc,
        pressureInputTopCount: captured.pressureInputTopCount,
        calibrationBranch: captured.calibrationBranch,
        humanCoefficient: captured.humanCoefficient,
        pressureNormalizationScale: captured.pressureNormalizationScale,
        pressureCurveResponseMeanKPa: captured.pressureCurveResponseMeanKPa,
        pressureMeanConservationErrorKPa: captured.pressureMeanConservationErrorKPa,
        pointPressureCount: captured.pointPressureCount,
        pointPressureFallbackMode: captured.pointPressureFallbackMode,
        maxCoordStr: captured.maxCoordStr,
      };
      // 更新会话信息
      const sessionData: CaptureSession = {
        id: "current",
        sensorType,
        filterThreshold,
        resultScale,
        expectedNonZero,
        nonZeroTolerance,
        autoCaptureInterval,
        matrixRotation,
        lastCaptureId: captureIdRef.current,
        frameCount: standardFrameCount,
        continuousFrameCount,
        startedAt: standardFrameCount + continuousFrameCount === 1 ? new Date().toISOString() : (recoveryInfo?.session.startedAt ?? new Date().toISOString()),
        updatedAt: new Date().toISOString(),
        isCompleted: false,
      };
      const revision = cacheRevisionRef.current;
      saveFrameAndSession(storedFrame, sessionData).then(count => {
        if (cacheRevisionRef.current === revision) setCachedFrameCount(count);
      }).catch((e) => {
        console.error("保存采集数据到IndexedDB失败:", e);
        if (!cacheWriteErrorShownRef.current) {
          cacheWriteErrorShownRef.current = true;
          toast.error("本地缓存写入失败；已采集数据仍在当前页面，请及时导出Excel");
        }
      });
    };
    if (kind === "continuous") {
      continuousFrameCountRef.current++;
      continuousFramesRef.current.push(captured);
      if (continuousPublishTimerRef.current === null) {
        continuousPublishTimerRef.current = setTimeout(publishContinuousFrames, 100);
      }
    } else {
      standardFrameCountRef.current++;
      setCapturedFrames(prev => [...prev, captured]);
    }
    // 持久化属于采集事件，不能放进可能重放的React state updater。
    persistCapturedFrame(standardFrameCountRef.current, continuousFrameCountRef.current);
    return captured;
  }, [sensorType, forceSourceEpoch, config.validMask, filterThreshold, resultScale, activeHumanCoefficient, activeAdcCompensation, adcCompensationSettings, statFieldVisibility, matrixRotation, rotateMatrix, expectedNonZero, nonZeroTolerance, autoCaptureInterval, recoveryInfo, seatForceMethod, backrestPressureMethod, rotatedValidMask, calibrationMode, heatmapValueMode, publishContinuousFrames, calculateFrameForce]);

  // 保持captureFrame的最新引用，避免useEffect依赖导致interval重建
  captureFrameRef.current = captureFrame;

  // 手动采集帧（带toast提示）
  const manualCaptureFrame = useCallback(() => {
    const result = captureFrame();
    if (result) toast.success(`已采集第 ${captureIdRef.current} 帧`);
  }, [captureFrame]);

  // Continuous capture follows decoded frames; no timer reuses the last frame.
  const startContinuousCapture = useCallback(() => {
    if (exportBusyRef.current) return;
    if (continuousActiveRef.current) return;
    if (autoCapturing) { toast.error("请先停止自动采集，再启动连续采集"); return; }
    if (!(serialState.isConnected || demoRunning || csvMode)) {
      toast.error("请先连接传感器、启动演示模式或播放CSV数据");
      return;
    }
    continuousRoundCountRef.current = 0;
    continuousRoundLimitRef.current = continuousFrameLimit;
    setContinuousRoundCount(0);
    continuousActiveRef.current = true;
    setContinuousCapturing(true);
    toast.success(`连续采集已启动：从下一帧开始，采满 ${continuousFrameLimit} 帧自动停止`);
  }, [autoCapturing, serialState.isConnected, demoRunning, csvMode, continuousFrameLimit]);

  const stopContinuousCapture = useCallback(() => {
    const wasActive = continuousActiveRef.current;
    continuousActiveRef.current = false;
    publishContinuousFrames();
    if (wasActive) toast.info(`连续采集已停止，共已采集 ${continuousFrameCountRef.current} 帧`);
    setContinuousCapturing(false);
  }, [publishContinuousFrames]);

  useEffect(() => () => {
    continuousActiveRef.current = false;
    if (continuousPublishTimerRef.current !== null) clearTimeout(continuousPublishTimerRef.current);
  }, []);

  const clearCaptures = useCallback(() => {
    if (exportBusyRef.current) return;
    setCapturedFrames([]); standardFrameCountRef.current = 0;
    continuousFramesRef.current = [];
    setContinuousFrames([]); continuousFrameCountRef.current = 0; continuousSequenceRef.current = 0;
    continuousRoundCountRef.current = 0; setContinuousRoundCount(0);
    // 本地缓存保留时继续使用唯一帧号，防止下一次采集覆盖已有记录。
    continuousActiveRef.current = false;
    if (continuousPublishTimerRef.current !== null) clearTimeout(continuousPublishTimerRef.current);
    continuousPublishTimerRef.current = null;
    setContinuousCapturing(false);
    // 停止自动采集
    if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
    setAutoCapturing(false); setAutoPaused(false); autoPausedRef.current = false;
    setAutoState("idle"); autoStateRef.current = "idle";
    setAutoTimer(0); setAutoMessage("");
    lastSuccessNonZeroCountRef.current = null;
    baselineNonZeroCountRef.current = 0;
    placementDetectedRef.current = false;
    zeroingWarningShownRef.current = false;
    // 注意：清空帧不清除IndexedDB本地缓存
    toast.info("已清空当前采集帧（本地缓存保留）");
  }, []);

  // 清空本地缓存（IndexedDB）
  const clearCache = useCallback(async () => {
    if (exportBusyRef.current) return;
    try {
      cacheRevisionRef.current++;
      await clearAllDB();
      setCachedFrameCount(0);
      toast.info("已清空本地缓存");
    } catch (e) {
      console.error("清除IndexedDB失败:", e);
      toast.error("清空缓存失败");
    }
  }, []);

  // 自动采集 - 开始监测
  const startAutoCapture = useCallback(() => {
    if (exportBusyRef.current) return;
    if (continuousCapturing) { toast.error("请先停止连续采集，再启动自动采集"); return; }
    if (!lastFrameRef.current) { toast.error("暂无数据，请先连接传感器或启动演示模式"); return; }
    const frame = lastFrameRef.current;
    let baseCount = 0;
    let baseSum = 0;
    for (let r = 0; r < frame.matrix.length; r++)
      for (let c = 0; c < frame.matrix[r].length; c++) {
        const val = frame.matrix[r][c];
        baseSum += val;
        if (val > filterThreshold) baseCount++;
      }

    const minValid = expectedNonZero - nonZeroTolerance;
    const maxValid = expectedNonZero + nonZeroTolerance;

    lastSuccessNonZeroCountRef.current = null;
    baselineNonZeroCountRef.current = 0;
    zeroingWarningShownRef.current = false;
    setAutoCapturing(true);
    timerStartRef.current = 0;
    setAutoTimer(0);
    // 初始化轮次
    roundFrameCountRef.current = 0;
    setRoundFrameCount(0);
    roundNumberRef.current = 1;
    setRoundNumber(1);
    framesPerRoundRef.current = framesPerRound;

    // V1.0.7: 清零判断考虑过滤阈值
    const startIsZeroed = filterThreshold > 0
      ? (() => { for (let r = 0; r < frame.matrix.length; r++) for (let c = 0; c < frame.matrix[r].length; c++) if (frame.matrix[r][c] > filterThreshold) return false; return true; })()
      : baseSum === 0;

    if (baseCount >= minValid && baseCount <= maxValid) {
      // 物品已放置且有效点位在范围内，直接进入稳定检测
      placementDetectedRef.current = true;
      timerStartRef.current = Date.now();
      setAutoTimer(0);
      setAutoState("stabilizing"); autoStateRef.current = "stabilizing";
      setAutoMessage(`第1轮 | 检测到放置（点位:${baseCount}），等待稳定...`);
      toast.success(`自动采集已启动，检测到物品已放置（有效点位: ${baseCount}），等待稳定后开始采集`);
    } else if (startIsZeroed) {
      // 传感器已清零（考虑过滤阈值），直接进入等待放置
      placementDetectedRef.current = false;
      setAutoState("waiting"); autoStateRef.current = "waiting";
      setAutoMessage("第1轮 | 等待放置物品...");
      toast.success("自动采集已启动，请将物品放置到传感器上");
    } else {
      // 传感器有残留数据且超过过滤阈值，先进入清零状态
      const nonZeroPoints: string[] = [];
      for (let r = 0; r < frame.matrix.length; r++)
        for (let c = 0; c < frame.matrix[r].length; c++) {
          const v = frame.matrix[r][c];
          if (v > filterThreshold) nonZeroPoints.push(`R${r}C${c}=${v}`);
        }
      const pointsInfo = nonZeroPoints.length <= 8
        ? nonZeroPoints.join(", ")
        : nonZeroPoints.slice(0, 8).join(", ") + ` ...等${nonZeroPoints.length}个`;

      placementDetectedRef.current = false;
      setAutoState("zeroing"); autoStateRef.current = "zeroing";
      setAutoMessage(`等待清零... 超阈值点位(${nonZeroPoints.length}个): ${pointsInfo}`);
      toast.warning(`传感器有超过过滤阈值的残留数据，请先清零。未清零: ${pointsInfo}`);
    }
  }, [continuousCapturing, filterThreshold, expectedNonZero, nonZeroTolerance, framesPerRound]);

  // 自动采集 - 结束监测
  const stopAutoCapture = useCallback(() => {
    if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
    setAutoCapturing(false);
    setAutoPaused(false); autoPausedRef.current = false;
    setAutoState("idle"); autoStateRef.current = "idle";
    setAutoTimer(0); timerStartRef.current = 0;
    setAutoMessage("");
    setRoundFrameCount(0); roundFrameCountRef.current = 0;
    setRoundNumber(0); roundNumberRef.current = 0;
    lastSuccessNonZeroCountRef.current = null;
    placementDetectedRef.current = false;
    zeroingWarningShownRef.current = false;
    // 清除锁定点位
    lockedPositionsRef.current = null;
    positionLockDoneRef.current = false;
    setLockedPositionCount(null);
    toast.info("自动采集已结束");
  }, []);

  // 自动采集 - 暂停
  const pauseAutoCapture = useCallback(() => {
    setAutoPaused(true); autoPausedRef.current = true;
    setAutoMessage(prev => `⏸ 已暂停 | ${prev}`);
    toast.info("自动采集已暂停");
  }, []);

  // 自动采集 - 继续
  const resumeAutoCapture = useCallback(() => {
    if (exportBusyRef.current) return;
    setAutoPaused(false); autoPausedRef.current = false;
    const st = autoStateRef.current;
    const rn = roundNumberRef.current;
    const rfc = roundFrameCountRef.current;
    const fpr = framesPerRoundRef.current;
    setAutoMessage(
      st === "stabilizing" ? `第${rn}轮 | 继续等待稳定...` :
      st === "collecting" ? `第${rn}轮 | 采集中 (${rfc}/${fpr})...` :
      st === "round_done" ? `第${rn}轮已完成，请重新放置物品` :
      st === "waiting" ? `第${rn}轮 | 等待放置物品...` :
      st === "zeroing" ? `等待传感器清零...` :
      st === "invalid" ? "放置无效，请重新放置" : ""
    );
    toast.info("自动采集已继续");
  }, []);

  // 删除单帧
  const deleteFrame = useCallback((frameId: number) => {
    if (exportBusyRef.current) return;
    setCapturedFrames(prev => prev.filter(f => f.id !== frameId));
    standardFrameCountRef.current = Math.max(0, standardFrameCountRef.current - 1);
    const revision = cacheRevisionRef.current;
    deleteStoredFrame(frameId).then(() => getFrameCount()).then(count => {
      if (cacheRevisionRef.current === revision) setCachedFrameCount(count);
    }).catch((e) => console.error("删除IndexedDB帧失败:", e));
    toast.info(`已删除第 ${frameId} 帧`);
  }, []);

  // 自动采集 - 放置检测和采集循环（新状态机）
  // 状态流转: waiting -> stabilizing -> collecting(N帧) -> 停止，下一组由用户再次启动。
  // ★ 关键设计：用 Date.now() 绝对时间戳计时，不依赖 setInterval 的累加精度
  // ★ setAutoTimer 只在值变化超过0.1s时才更新，减少不必要的重渲染
  // ★ setAutoMessage 只在状态切换时更新，不在每次tick中更新
  useEffect(() => {
    if (!autoCapturing) {
      if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
      return;
    }

    const minValid = expectedNonZero - nonZeroTolerance;
    const maxValid = expectedNonZero + nonZeroTolerance;
    const STABILIZE_TIME = 2; // 稳定等待时间(秒)
    let lastDisplayedTimer = -1; // 上次显示的计时值，用于减少setState调用

    // 每200ms检测一次数据变化
    autoTimerRef.current = setInterval(() => {
      // 暂停时跳过检测，但要更新计时起点以补偿暂停时间
      if (autoPausedRef.current) {
        // 暂停时持续推进起始时间，这样恢复后计时不会突然跳跃
        if (timerStartRef.current > 0) {
          timerStartRef.current += 200;
        }
        return;
      }

      const frame = lastFrameRef.current;
      if (!frame) return;

      // 计算当前有效点位数和总和
      let currentNonZero = 0;
      let currentSum = 0;
      for (let r = 0; r < frame.matrix.length; r++)
        for (let c = 0; c < frame.matrix[r].length; c++) {
          const val = frame.matrix[r][c];
          currentSum += val;
          if (val > filterThreshold) currentNonZero++;
        }

      const state = autoStateRef.current;
      const rn = roundNumberRef.current;
      const fpr = framesPerRoundRef.current;

      // 检查有效点位是否在允许范围内
      const isInValidRange = currentNonZero >= minValid && currentNonZero <= maxValid;
      // V1.0.7: 清零判断考虑过滤阈值，所有值≤filterThreshold即视为清零
      const ft = filterThreshold;
      const isZeroed = ft > 0
        ? (() => { for (let r = 0; r < frame.matrix.length; r++) for (let c = 0; c < frame.matrix[r].length; c++) if (frame.matrix[r][c] > ft) return false; return true; })()
        : currentSum === 0;
      const placementThreshold = Math.max(3, Math.floor(minValid * 0.5));
      const isPlaced = currentNonZero >= placementThreshold && currentSum > 0;

      // ★ 用绝对时间计算已经过的秒数
      const now = Date.now();
      const elapsed = timerStartRef.current > 0 ? (now - timerStartRef.current) / 1000 : 0;

      // ★ 只在显示值变化超过0.05s时才更新UI，减少重渲染
      const displayTimer = Math.round(elapsed * 10) / 10;
      const shouldUpdateTimer = Math.abs(displayTimer - lastDisplayedTimer) >= 0.1;

      if (state === "zeroing") {
        if (isZeroed) {
          zeroingWarningShownRef.current = false;
          placementDetectedRef.current = false;
          setAutoState("waiting"); autoStateRef.current = "waiting";
          setAutoMessage(`第${rn}轮 | 传感器已清零，等待放置物品...`);
          toast.success("传感器已清零，请放置下一个物品");
        } else {
          // V1.0.7: 未清零点位只显示超过过滤阈值的
          const nonZeroPoints: string[] = [];
          for (let r = 0; r < frame.matrix.length; r++)
            for (let c = 0; c < frame.matrix[r].length; c++) {
              const v = frame.matrix[r][c];
              if (v > ft) nonZeroPoints.push(`R${r}C${c}=${v}`);
            }
          const pointsInfo = nonZeroPoints.length <= 8
            ? nonZeroPoints.join(", ")
            : nonZeroPoints.slice(0, 8).join(", ") + ` ...等${nonZeroPoints.length}个`;
          if (!zeroingWarningShownRef.current) {
            zeroingWarningShownRef.current = true;
            toast.warning(`请先移除物品，让传感器数据归零。未清零: ${pointsInfo}`);
          }
          setAutoMessage(`等待清零... 超阈值点位(${nonZeroPoints.length}个): ${pointsInfo}`);
        }
      } else if (state === "waiting") {
        if (isPlaced && isInValidRange) {
          placementDetectedRef.current = true;
          timerStartRef.current = Date.now(); // ★ 记录稳定计时起点
          lastDisplayedTimer = 0;
          setAutoTimer(0);
          setAutoState("stabilizing"); autoStateRef.current = "stabilizing";
          setAutoMessage(`第${rn}轮 | 检测到放置（点位:${currentNonZero}），等待稳定(${STABILIZE_TIME}s)...`);
        } else if (isPlaced && !isInValidRange) {
          setAutoState("invalid"); autoStateRef.current = "invalid";
          setAutoMessage(`放置无效！有效点位 ${currentNonZero}，不在允许范围 ${minValid}~${maxValid} 内，请重新放置`);
          toast.warning(`放置无效！有效点位 ${currentNonZero}，允许范围 ${minValid}~${maxValid}`);
          placementDetectedRef.current = true;
        }
      } else if (state === "stabilizing") {
        // ★ 用绝对时间差计时
        if (shouldUpdateTimer) {
          lastDisplayedTimer = displayTimer;
          setAutoTimer(displayTimer);
        }

        if (!isInValidRange) {
          // 放置无效时清除锁定点位
          lockedPositionsRef.current = null;
          positionLockDoneRef.current = false;
          setLockedPositionCount(null);
          setAutoState("invalid"); autoStateRef.current = "invalid";
          setAutoMessage(`放置无效！有效点位 ${currentNonZero}，不在允许范围 ${minValid}~${maxValid} 内，请重新放置`);
          toast.warning(`放置无效！有效点位 ${currentNonZero}，允许范围 ${minValid}~${maxValid}`);
          timerStartRef.current = 0;
          setAutoTimer(0);
          lastDisplayedTimer = -1;
          return;
        }

        // ★ 延迟后锁定有效点位：记录当前所有非零点位的坐标
        // 注意：必须对旋转后的矩阵进行锁定，因为captureFrame中用的是旋转后的矩阵
        // V1.0.6: 仅在用户启用锁定且选择自动模式时才执行自动锁定
        if (lockEnabledRef.current && lockModeRef.current === 'auto' && elapsed >= lockDelayRef.current && !positionLockDoneRef.current) {
          const matForLock = matrixRotation === 0 ? frame.matrix : rotateMatrix(frame.matrix, matrixRotation);
          const locked = new Set<string>();
          for (let r = 0; r < matForLock.length; r++) {
            for (let c = 0; c < matForLock[r].length; c++) {
              if (matForLock[r][c] > filterThreshold) {
                locked.add(`${r},${c}`);
              }
            }
          }
          lockedPositionsRef.current = locked;
          positionLockDoneRef.current = true;
          setLockedPositionCount(locked.size);
          toast.info(`已自动锁定 ${locked.size} 个有效点位（延迟${lockDelayRef.current}s）`);
        }

        if (elapsed >= STABILIZE_TIME) {
          // 稳定完成，采集第一帧
          const result = captureFrameRef.current?.();
          if (result) {
            lastSuccessNonZeroCountRef.current = currentNonZero;
            roundFrameCountRef.current = 1;
            setRoundFrameCount(1);
            toast.success(`✅ 第${rn}轮 第1/${fpr}帧已采集（有效点位: ${currentNonZero}）`);
          }

          if (roundFrameCountRef.current >= fpr) {
            timerStartRef.current = 0;
            setAutoTimer(0);
            lastDisplayedTimer = -1;
            setAutoState("idle"); autoStateRef.current = "idle";
            if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
            setAutoCapturing(false);
            setAutoPaused(false); autoPausedRef.current = false;
            lockedPositionsRef.current = null;
            positionLockDoneRef.current = false;
            setLockedPositionCount(null);
            setAutoMessage(`已采集 ${fpr} 帧并自动停止`);
            toast.success(`本次自动采集已完成 ${fpr} 帧，已自动停止，可导出CSV或XLSX`);
          } else {
            // ★ 重置计时器为下一帧的间隔计时
            timerStartRef.current = Date.now();
            lastDisplayedTimer = 0;
            setAutoTimer(0);
            setAutoState("collecting"); autoStateRef.current = "collecting";
            setAutoMessage(`第${rn}轮 | 采集中 (${roundFrameCountRef.current}/${fpr})，${autoCaptureInterval}秒后采集下一帧...`);
          }
        }
      } else if (state === "collecting") {
        // ★ 用绝对时间差计时
        if (shouldUpdateTimer) {
          lastDisplayedTimer = displayTimer;
          setAutoTimer(displayTimer);
        }

        if (!isInValidRange) {
          // 采集中断时清除锁定点位
          lockedPositionsRef.current = null;
          positionLockDoneRef.current = false;
          setLockedPositionCount(null);
          setAutoState("invalid"); autoStateRef.current = "invalid";
          setAutoMessage(`采集中断！有效点位 ${currentNonZero}，不在允许范围 ${minValid}~${maxValid} 内，请重新放置`);
          toast.warning(`采集中断！有效点位 ${currentNonZero}，允许范围 ${minValid}~${maxValid}`);
          timerStartRef.current = 0;
          setAutoTimer(0);
          lastDisplayedTimer = -1;
          return;
        }

        if (elapsed >= autoCaptureInterval) {
          // ★ 间隔到达，采集一帧
          const result = captureFrameRef.current?.();
          if (result) {
            lastSuccessNonZeroCountRef.current = currentNonZero;
            roundFrameCountRef.current += 1;
            setRoundFrameCount(roundFrameCountRef.current);
            toast.success(`✅ 第${rn}轮 第${roundFrameCountRef.current}/${fpr}帧已采集（有效点位: ${currentNonZero}）`);
          }

          if (roundFrameCountRef.current >= fpr) {
            timerStartRef.current = 0;
            setAutoTimer(0);
            lastDisplayedTimer = -1;
            setAutoState("idle"); autoStateRef.current = "idle";
            if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
            setAutoCapturing(false);
            setAutoPaused(false); autoPausedRef.current = false;
            lockedPositionsRef.current = null;
            positionLockDoneRef.current = false;
            setLockedPositionCount(null);
            setAutoMessage(`已采集 ${fpr} 帧并自动停止`);
            toast.success(`本次自动采集已完成 ${fpr} 帧，已自动停止，可导出CSV或XLSX`);
          } else {
            // ★ 重置计时器为下一帧的间隔计时
            timerStartRef.current = Date.now();
            lastDisplayedTimer = 0;
            setAutoTimer(0);
            setAutoMessage(`第${rn}轮 | 采集中 (${roundFrameCountRef.current}/${fpr})，${autoCaptureInterval}秒后采集下一帧...`);
          }
        }
      } else if (state === "round_done") {
        if (isZeroed) {
          roundNumberRef.current += 1;
          setRoundNumber(roundNumberRef.current);
          roundFrameCountRef.current = 0;
          setRoundFrameCount(0);
          zeroingWarningShownRef.current = false;
          placementDetectedRef.current = false;
          // 清除锁定点位，新一轮重新锁定
          lockedPositionsRef.current = null;
          positionLockDoneRef.current = false;
          setLockedPositionCount(null);
          setAutoState("waiting"); autoStateRef.current = "waiting";
          setAutoMessage(`第${roundNumberRef.current}轮 | 等待放置物品...`);
          toast.success(`进入第${roundNumberRef.current}轮，请放置新物品`);
        } else {
          setAutoMessage(`第${rn}轮已完成(${fpr}帧)，请移除物品并等待传感器清零...`);
        }
      } else if (state === "invalid") {
        if (isZeroed) {
          placementDetectedRef.current = false;
          // 清除锁定点位
          lockedPositionsRef.current = null;
          positionLockDoneRef.current = false;
          setLockedPositionCount(null);
          setAutoState("waiting"); autoStateRef.current = "waiting";
          setAutoMessage(`第${rn}轮 | 等待放置物品...`);
        } else if (isPlaced && isInValidRange) {
          // 重新进入稳定检测，清除之前的锁定
          lockedPositionsRef.current = null;
          positionLockDoneRef.current = false;
          setLockedPositionCount(null);
          timerStartRef.current = Date.now(); // ★ 用绝对时间
          lastDisplayedTimer = 0;
          setAutoTimer(0);
          setAutoState("stabilizing"); autoStateRef.current = "stabilizing";
          setAutoMessage(`第${rn}轮 | 放置生效（点位:${currentNonZero}），等待稳定...`);
          toast.info("放置已生效，等待稳定后开始采集");
        }
      }
    }, 200);

    return () => {
      if (autoTimerRef.current) { clearInterval(autoTimerRef.current); autoTimerRef.current = null; }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoCapturing, autoCaptureInterval, expectedNonZero, nonZeroTolerance, filterThreshold]);

  // The browser can acknowledge download submission, not the user's save dialog.
  // Only successful generation/submission clears frames; failures retain them.
  const finishExportAndClear = useCallback(async (): Promise<boolean> => {
    cacheRevisionRef.current++;
    try {
      // clearAll drains pending writes before clearing both stores atomically.
      await clearAllDB();
    } catch (error) {
      console.error("导出后清理本地缓存失败", error);
      toast.error("文件已提交下载，但自动清理失败；采集帧已保留，请重试清理");
      return false;
    }
    setCapturedFrames([]); standardFrameCountRef.current = 0;
    continuousFramesRef.current = [];
    setContinuousFrames([]); continuousFrameCountRef.current = 0;
    continuousSequenceRef.current = 0;
    continuousRoundCountRef.current = 0; setContinuousRoundCount(0);
    if (continuousPublishTimerRef.current !== null) clearTimeout(continuousPublishTimerRef.current);
    continuousPublishTimerRef.current = null;
    captureIdRef.current = 0;
    setCachedFrameCount(0);
    cacheWriteErrorShownRef.current = false;
    setRecoveryInfo(null); setShowRecoveryDialog(false);
    return true;
  }, []);

  const beginExport = useCallback(() => {
    if (exportBusyRef.current) return false;
    if (continuousActiveRef.current || autoCapturing) {
      toast.info("请先完成或停止采集，再导出本批数据");
      return false;
    }
    exportBusyRef.current = true;
    setExportProgress(0);
    return true;
  }, [autoCapturing]);

  // CSV and XLSX freeze the same completed batch, including continuous-only rounds.
  const exportCaptures = useCallback(async () => {
    const standardExportFrames = [...capturedFrames];
    const continuousExportFrames = [...continuousFramesRef.current];
    const exportFrames = [...standardExportFrames, ...continuousExportFrames];
    if (exportFrames.length === 0) { toast.error("暂无采集数据可导出"); return; }
    if (!beginExport()) return;
    try {
      await new Promise(resolve => setTimeout(resolve, 50));
      const visibleFields = Object.entries(statFieldVisibility).filter(([, v]) => v).map(([k]) => k);
      const csv = buildCaptureCsv(exportFrames, {
        name: config.name, rows: config.rows, cols: config.cols, totalPoints,
        filterThreshold, resultScale, exportedAt: new Date(),
      }, visibleFields);
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `sensor_capture_${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.csv`;
      document.body.appendChild(a);
      try { a.click(); } finally { a.remove(); URL.revokeObjectURL(url); }
      setExportProgress(100);
      if (await finishExportAndClear()) {
        toast.success(`CSV已提交下载：标准 ${standardExportFrames.length} 帧、连续 ${continuousExportFrames.length} 帧；采集帧和本地缓存已自动清空`);
      }
    } catch (error) {
      console.error("CSV导出失败", error);
      toast.error("CSV导出失败，采集帧和缓存已保留：" + (error instanceof Error ? error.message : String(error)));
    } finally {
      exportBusyRef.current = false;
      setExportProgress(null);
    }
  }, [capturedFrames, config, totalPoints, statFieldVisibility, beginExport, finishExportAndClear]);

  const exportXlsx = useCallback(async () => {
    const standardExportFrames = [...capturedFrames];
    const continuousExportFrames = [...continuousFramesRef.current];
    if (standardExportFrames.length === 0 && continuousExportFrames.length === 0) { toast.error("暂无采集数据可导出"); return; }
    if (!beginExport()) return;
    try {
      await new Promise(resolve => setTimeout(resolve, 50));
      const visibleFields = Object.entries(statFieldVisibility).filter(([, v]) => v).map(([k]) => k);
      const exportOpts: ExportOptions = { continuousFrames: continuousExportFrames };
      await exportToXlsx(
        standardExportFrames,
        { name: config.name, matrixSize: config.rows, totalPoints, filterThreshold, resultScale },
        visibleFields,
        percent => setExportProgress(percent),
        false,
        exportOpts,
      );
      setExportProgress(100);
      if (await finishExportAndClear()) {
        toast.success(`XLSX已提交下载：标准 ${standardExportFrames.length} 帧、连续 ${continuousExportFrames.length} 帧；采集帧和本地缓存已自动清空`);
      }
    } catch (error) {
      console.error("XLSX导出失败", error);
      toast.error("XLSX导出失败，采集帧和缓存已保留：" + (error instanceof Error ? error.message : String(error)));
    } finally {
      exportBusyRef.current = false;
      setExportProgress(null);
    }
  }, [capturedFrames, config, totalPoints, statFieldVisibility, beginExport, finishExportAndClear]);

  // V2.3.0: 标定始终启用，无需开关

  // 全屏切换
  const toggleFullscreen = useCallback(() => setIsFullscreen((prev) => !prev), []);

  // ESC 退出全屏
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === "Escape" && isFullscreen) setIsFullscreen(false); };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isFullscreen]);

  // 启动时检测未完成的采集会话并初始化缓存帧数
  useEffect(() => {
    (async () => {
      try {
        // 初始化缓存帧数
        const count = await getFrameCount();
        setCachedFrameCount(count);
        // 检测未完成会话
        const { hasSession, session, frameCount } = await hasUnfinishedSession();
        if (hasSession && session && frameCount > 0) {
          setRecoveryInfo({ session, frameCount });
          setShowRecoveryDialog(true);
        }
      } catch (e) {
        console.error("检测未完成会话失败:", e);
      }
    })();
  }, []);

  // 恢复采集数据
  const recoverCapturedData = useCallback(async () => {
    if (!recoveryInfo) return;
    setIsRecovering(true);
    try {
      const storedFrames = await getAllFrames();
      if (storedFrames.length === 0) {
        toast.error("没有找到可恢复的帧数据");
        setShowRecoveryDialog(false);
        setIsRecovering(false);
        return;
      }

      // 将存储的帧数据转换为 CapturedFrame。V2.7.64以前的帧没有补偿版本标记，恢复时只迁移一次。
      const restoredFrames: CapturedFrame[] = storedFrames.map((sf) => {
        const alreadyCompensated = hasAdcCompensationMarker(sf.captureConfig?.adcCompensationVersion);
        const frameThreshold = Math.max(
          ADC_POST_COMPENSATION_FILTER_THRESHOLD,
          Number.isFinite(sf.captureConfig?.filterThreshold) ? sf.captureConfig!.filterThreshold : ADC_POST_COMPENSATION_FILTER_THRESHOLD,
        );
        const frameScale = Number.isFinite(sf.captureConfig?.resultScale) ? sf.captureConfig!.resultScale : 1;
        const matrix = alreadyCompensated
          ? sf.data.matrix.map((row) => [...row])
          : compensateAndFilterAdcMatrix(sf.data.matrix, sf.sensorType, adcCompensationSettings);
        const frameStats = summarizeAdcMatrix(matrix);
        const filteredStats = applyFilter(matrix, {
          threshold: frameThreshold,
          calibrationMode: "none",
          resultScale: frameScale,
        });
        const pressureMetrics = calculatePressureMetricsFromMatrix(
          filteredStats.filteredMatrix,
          sf.sensorType,
          sf.humanCoefficient ?? DEFAULT_HUMAN_COEFFICIENT,
        );

        return {
          id: sf.id,
          captureKind: sf.captureKind ?? "standard",
          continuousSequence: sf.continuousSequence,
          data: {
            ...frameStats,
            matrix,
            heatmapMatrix: sf.data.heatmapMatrix?.map((row) => [...row]),
            raw: sf.data.raw ? [...sf.data.raw] : undefined,
            physical: sf.data.physical?.map((row) => [...row]),
            sourceMatrix: sf.data.sourceMatrix?.map((row) => [...row]),
            timestamp: sf.data.timestamp,
          },
          capturedAt: new Date(sf.capturedAt),
          sensorType: sf.sensorType,
          filteredStats: alreadyCompensated && sf.filteredStats ? sf.filteredStats : filteredStats,
          areaMetrics: sf.areaMetrics,
          forceMetrics: sf.forceMetrics,
          forceDisplayMetrics: sf.forceDisplayMetrics,
          captureConfig: {
            filterThreshold: frameThreshold,
            resultScale: frameScale,
            visibleFields: sf.captureConfig?.visibleFields ?? [],
            matrixRowOrder: sf.captureConfig?.matrixRowOrder,
            matrixColumnOrder: sf.captureConfig?.matrixColumnOrder,
            matrixRotation: sf.captureConfig?.matrixRotation,
            adcCompensationVersion: sf.captureConfig?.adcCompensationVersion
              ?? getAdcCompensationFingerprint(adcCompensationSettings),
            adcCompensation: sf.captureConfig?.adcCompensation ?? {
              sensor: getAdcCompensationProfile(sf.sensorType, adcCompensationSettings).sensor,
              enabled: getAdcCompensationProfile(sf.sensorType, adcCompensationSettings).enabled,
              scale: getAdcCompensationProfile(sf.sensorType, adcCompensationSettings).scale,
              offset: getAdcCompensationProfile(sf.sensorType, adcCompensationSettings).offset,
              fingerprint: getAdcCompensationFingerprint(adcCompensationSettings),
            },
          },
          lockedPressureKPa: sf.lockedPressureKPa,
          avgPressureKPa: capturedAveragePressureKPa(sf, pressureMetrics.avgPressureKPa),
          // V2.7.99：带逐格压强摘要的恩迪帧沿用采集时的逐格最大压强（原始物理矩阵复算需要算法状态，不在此重算）。
          maxPressureKPa: sf.forceMetrics?.pointPressure ? (sf.forceMetrics.pointPressure.maxPressureKPa ?? null) : pressureMetrics.maxPressureKPa,
          pressureInputAdc: pressureMetrics.topMean,
          pressureInputTopCount: pressureMetrics.topCount,
          calibrationBranch: pressureMetrics.calibrationBranch,
          humanCoefficient: pressureMetrics.humanCoefficient,
          pressureNormalizationScale: pressureMetrics.normalizationScale,
          pressureCurveResponseMeanKPa: pressureMetrics.curveResponseMeanKPa,
          pressureMeanConservationErrorKPa: pressureMetrics.meanConservationErrorKPa,
          pointPressureCount: sf.forceMetrics?.pointPressure ? sf.forceMetrics.pointPressure.pointCount : pressureMetrics.pointPressureCount,
          pointPressureFallbackMode: pressureMetrics.pointPressureFallbackMode,
          maxCoordStr: sf.maxCoordStr,
        };
      });

      // 恢复状态：连续帧独立保存，避免其改变既有标准采集列表及Sheet1/Sheet2。
      const restoredStandardFrames = restoredFrames.filter((frame) => frame.captureKind !== "continuous");
      const restoredContinuousFrames = restoredFrames.filter((frame) => frame.captureKind === "continuous");
      setCapturedFrames(restoredStandardFrames);
      continuousFramesRef.current = [...restoredContinuousFrames];
      setContinuousFrames(restoredContinuousFrames);
      standardFrameCountRef.current = restoredStandardFrames.length;
      continuousFrameCountRef.current = restoredContinuousFrames.length;
      continuousSequenceRef.current = restoredContinuousFrames.reduce(
        (maximum, frame) => Math.max(maximum, frame.continuousSequence ?? 0),
        0,
      );
      captureIdRef.current = Math.max(
        recoveryInfo.session.lastCaptureId,
        ...restoredFrames.map((frame) => frame.id),
      );

      // 恢复配置（V2.7.15：老 backrest-32x25 已废弃，兼容映射到 new-backrest-32x25）
      const s = recoveryInfo.session;
      const restoredSensorType = s.sensorType === 'backrest-32x25' ? 'new-backrest-32x25' : s.sensorType;
      setSensorType(restoredSensorType);
      setExpectedNonZero(s.expectedNonZero);
      setNonZeroTolerance(s.nonZeroTolerance);
      setAutoCaptureInterval(s.autoCaptureInterval ?? s.autoCaptureDelay ?? 5);
      setMatrixRotation(s.matrixRotation);

      setShowRecoveryDialog(false);
      toast.success(`已恢复标准采集 ${restoredStandardFrames.length} 帧、连续采集 ${restoredContinuousFrames.length} 帧`);
    } catch (e) {
      console.error("恢复数据失败:", e);
      toast.error("恢复数据失败: " + (e instanceof Error ? e.message : String(e)));
    } finally {
      setIsRecovering(false);
    }
  }, [recoveryInfo]);

  // 放弃恢复，清除旧数据
  const discardRecovery = useCallback(async () => {
    try {
      await clearAllDB();
      setShowRecoveryDialog(false);
      setRecoveryInfo(null);
      toast.info("已放弃上次采集数据");
    } catch (e) {
      console.error("清除数据失败:", e);
    }
  }, []);

  // 是否有活跃数据源
  const hasActiveSource = serialState.isConnected || demoRunning || csvMode;
  // CSV和XLSX均可导出标准帧与连续帧。
  const hasExportableFrames = capturedFrames.length > 0 || continuousFrames.length > 0;

  // 数据源停止时自动终止连续采集，避免按旧帧持续写入缓存。
  useEffect(() => {
    if (!continuousCapturing || hasActiveSource) return;
    continuousActiveRef.current = false;
    publishContinuousFrames();
    setContinuousCapturing(false);
    toast.warning("数据源已停止，连续采集已自动结束");
  }, [continuousCapturing, hasActiveSource, publishContinuousFrames]);

  // 用于显示的统计数据和矩阵
  // 框选区域统计：如果有框选区域，基于框选区域内的数据重新计算统计值
  const areaStats = useMemo<FilteredStats | null>(() => {
    if (!areaSelection || !rotatedFrame) return null;
    const { startRow, startCol, endRow, endCol } = areaSelection;
    const matrix = rotatedFrame.matrix;
    // 提取框选区域的子矩阵
    const subMatrix: number[][] = [];
    for (let r = startRow; r <= endRow; r++) {
      const row: number[] = [];
      for (let c = startCol; c <= endCol; c++) {
        row.push(matrix[r]?.[c] ?? 0);
      }
      subMatrix.push(row);
    }
    return applyFilter(subMatrix, {
      threshold: filterThreshold,
      calibrationMode,
      resultScale,
    });
  }, [areaSelection, rotatedFrame, filterThreshold, calibrationMode, resultScale]);

  const displayStats = areaSelection ? areaStats : filteredData;
  const displayMatrix = filteredData?.filteredMatrix ?? rotatedFrame?.matrix ?? null;

  const displayArea = useMemo(
    () => calculateDisplayedArea(displayMatrix, rotatedValidMask, areaSelection, {
      sensorType,
      sourceMatrix: rotatedFrame?.sourceMatrix,
      sourceRotation: matrixRotation,
    }),
    [displayMatrix, rotatedValidMask, areaSelection, sensorType, rotatedFrame?.sourceMatrix, matrixRotation],
  );

  const rawDisplayForce = useMemo(() => currentFrame ? calculateFrameForce(currentFrame) : null,
    [currentFrame, calculateFrameForce]);

  const receiveForceFrame = useCallback((frame: FrameData) => {
    const rawForce = calculateFrameForce(frame);
    if (!rawForce) return;
    if (forceReadoutTimerRef.current !== null) clearTimeout(forceReadoutTimerRef.current);
    forceReadoutTimerRef.current = null;
    const snapshot = forceReadoutRef.current.update(forceSourceEpoch, frame, rawForce,
      Date.now(), frame.timestamp, forceSmoothingEnabled && !csvMode);
    if (snapshot) {
      forceReadoutSnapshotRef.current = snapshot;
      setForceReadoutSnapshot(snapshot);
    }
    const schedulePending = () => {
      const deadline = forceReadoutRef.current.pendingPublishAt();
      if (deadline === null) return;
      forceReadoutTimerRef.current = setTimeout(() => {
        forceReadoutTimerRef.current = null;
        const pending = forceReadoutRef.current.flush(Date.now());
        if (pending) {
          forceReadoutSnapshotRef.current = pending;
          setForceReadoutSnapshot(pending);
        }
        schedulePending();
      }, Math.max(0, deadline - Date.now()));
    };
    schedulePending();
  }, [calculateFrameForce, forceSourceEpoch, forceSmoothingEnabled, csvMode]);
  receiveForceFrameRef.current = receiveForceFrame;

  useEffect(() => {
    // Live ingestion already sampled this object; ForceReadout ignores duplicates.
    // This path also covers imported frames and recalculation after setting changes.
    if (!csvMode && currentFrame && currentFrame !== lastFrameRef.current) return;
    if (currentFrame && rawDisplayForce) receiveForceFrame(currentFrame);
    else if (!lastFrameRef.current) {
      forceReadoutRef.current.reset();
      forceReadoutSnapshotRef.current = null;
      setForceReadoutSnapshot(null);
    }
  }, [currentFrame, rawDisplayForce, receiveForceFrame, csvMode]);
  const displayForce = forceReadoutSnapshot?.sourceEpoch === forceSourceEpoch
    // The force sample can be newer than the throttled heatmap, including a brief
    // contact while the heatmap is still empty. Its own frame supplies all metadata.
    && (!rawDisplayForce || forceReadoutSnapshot.modelVersion === rawDisplayForce.modelVersion)
    ? forceReadoutSnapshot.frame : rawDisplayForce;
  // Only the runtime may select this branch; labels follow its exact published frame.
  const humanEstimationActive = displayForce?.humanEstimation?.active === true;
  // The full-frame seat area uses the same display snapshot as force and pressure.
  // A selection keeps its original area calculation and never changes total force.
  // V2.7.102/103：坐垫框选时，选区内属于真人估算区的 T29 轮廓格按面积系数 0.8 折算（与全帧真人面积同口径）。
  const endiSeatContourOwnerNative = sensorType === "endi-23x23" && areaSelection ? endiContourOwnerMatrix(displayForce) : null;
  const endiSeatAreaFactors = sensorType === "endi-23x23" ? displayForce?.endiCushion?.regions.map(r => r.areaFactor) ?? null : null;
  const endiSeatSelectionHumanDeduction = useMemo(() => {
    if (!endiSeatContourOwnerNative || !endiSeatAreaFactors || !endiSeatAreaFactors.some(f => f < 1)) return 0;
    const owner = matrixRotation === 0 ? endiSeatContourOwnerNative : rotateMatrix(endiSeatContourOwnerNative, matrixRotation);
    return endiSeatSelectionHumanAreaDeduction(owner, endiSeatAreaFactors, areaSelection);
  }, [endiSeatContourOwnerNative, endiSeatAreaFactors?.join(","), matrixRotation, rotateMatrix, areaSelection]);
  // V2.7.108：靠背框选时，选区内属于超量程估算区的 T39 轮廓格按面积系数 2 计（每格 2.60 cm²，与全帧超量程面积同口径）。
  const endiBackrestContourOwnerNative = sensorType === "new-backrest-32x25" && areaSelection ? endiContourOwnerMatrix(displayForce) : null;
  const endiBackrestAreaFactors = sensorType === "new-backrest-32x25"
    ? displayForce?.endiBackrest?.regions.map(r => (r.overRange ? ENDI_BACKREST_OVER_RANGE_AREA_GAIN : 1)) ?? null
    : null;
  const endiBackrestSelectionOverRangeAddition = useMemo(() => {
    if (!endiBackrestContourOwnerNative || !endiBackrestAreaFactors || !endiBackrestAreaFactors.some(f => f !== 1)) return 0;
    const owner = matrixRotation === 0 ? endiBackrestContourOwnerNative : rotateMatrix(endiBackrestContourOwnerNative, matrixRotation);
    return endiSelectionAreaFactorAdjustment(owner, endiBackrestAreaFactors, areaSelection, ENDI_BACKREST_CELL_AREA_CM2);
  }, [endiBackrestContourOwnerNative, endiBackrestAreaFactors?.join(","), matrixRotation, rotateMatrix, areaSelection]);
  const endiSelectionAreaAdjustment = endiBackrestSelectionOverRangeAddition - endiSeatSelectionHumanDeduction;
  const displayAreaCm2 = (endiFittedSensor || humanEstimationActive) && !areaSelection && displayForce
    ? displayForce.areaCm2
    : displayArea && endiSelectionAreaAdjustment !== 0
      ? Math.max(0, Math.round((displayArea.areaCm2 + endiSelectionAreaAdjustment) * 100) / 100)
      : displayArea?.areaCm2;

  // V2.7.41：实时压强按有效点数自动派发砝码段 / 真人段，并使用当前传感器独立 k。
  const displayPressureMetrics = useMemo(() => {
    if (!displayStats || displayStats.nonZeroCount === 0) return null;
    return calculatePressureMetricsFromMatrix(displayStats.filteredMatrix, sensorType, activeHumanCoefficient);
  }, [displayStats, sensorType, activeHumanCoefficient]);
  // 热力图始终使用完整过滤矩阵；框选只影响统计卡，不裁剪图像数据源。
  const heatmapPressureMetrics = useMemo(() => {
    if (!filteredData || filteredData.nonZeroCount === 0) return null;
    if (!areaSelection) return displayPressureMetrics;
    return calculatePressureMetricsFromMatrix(filteredData.filteredMatrix, sensorType, activeHumanCoefficient);
  }, [filteredData, areaSelection, displayPressureMetrics, sensorType, activeHumanCoefficient]);
  // V2.7.99：恩迪坐垫/靠背的压强热图改用逐格压强（与 displayForce 同一帧，旋转到显示方向）。
  const endiPointPressureNative = endiFittedSensor ? endiPointPressureMatrix(displayForce) : null;
  const endiPointPressureDisplay = useMemo(() => {
    if (!endiPointPressureNative) return null;
    return matrixRotation === 0 ? endiPointPressureNative : rotateMatrix(endiPointPressureNative, matrixRotation);
  }, [endiPointPressureNative, matrixRotation, rotateMatrix]);
  // V2.7.100：恩迪传感器有帧但本帧无逐格压强（空载/无接触区）时用全 0 矩阵，切到“压强”后保持压强显示，不弹回 ADC。
  const endiZeroPressureRows = endiFittedSensor ? (displayMatrix?.length ?? 0) : 0;
  const endiZeroPressureCols = endiFittedSensor ? (displayMatrix?.[0]?.length ?? 0) : 0;
  const endiZeroPressure = useMemo(() => (endiZeroPressureRows > 0 && endiZeroPressureCols > 0
    ? Array.from({ length: endiZeroPressureRows }, () => new Array<number>(endiZeroPressureCols).fill(0))
    : null), [endiZeroPressureRows, endiZeroPressureCols]);
  const pressureHeatmapMatrixKPa = endiFittedSensor ? (endiPointPressureDisplay ?? endiZeroPressure) : heatmapPressureMetrics?.pressureMatrixKPa ?? null;
  // V2.7.101：压强热图以 N/cm² 显示（1 N/cm² = 10 kPa，按 0.001 N/cm² 取整，与逐格压强取整单位一致，无二次舍入）。
  const pressureHeatmapMatrix = useMemo(() => (pressureHeatmapMatrixKPa
    ? pressureHeatmapMatrixKPa.map(row => row.map(v => (Number.isFinite(v) && v > 0 ? kPaToNcm2(v) : 0)))
    : null), [pressureHeatmapMatrixKPa]);
  const pressureHeatmapAvailable = Boolean(pressureHeatmapMatrix && pressureHeatmapMatrix.length > 0);
  const showPressureHeatmap = heatmapValueMode === "pressure" && pressureHeatmapAvailable;
  useEffect(() => {
    if (heatmapValueMode === "pressure" && !pressureHeatmapAvailable) {
      setHeatmapValueMode("adc");
    }
  }, [heatmapValueMode, pressureHeatmapAvailable]);
  const pressureHeatmapColorMax = useMemo(() => {
    let maxValue = 1.85; // N/cm²（= 18.5 kPa）
    for (const row of pressureHeatmapMatrix ?? []) {
      for (const value of row) {
        if (Number.isFinite(value) && value > maxValue) maxValue = value;
      }
    }
    return maxValue;
  }, [pressureHeatmapMatrix]);
  // V2.7.101：恩迪传感器压强热图中全部压强格子（非零格）的平均值，按 0.001 N/cm² 显示；与“平均压强”卡片一致。
  const pressureCellMean = useMemo(() => {
    if (!endiFittedSensor || !pressureHeatmapMatrix) return null;
    let sum = 0, n = 0;
    for (const row of pressureHeatmapMatrix) for (const v of row) if (Number.isFinite(v) && v > 0) { sum += Math.round(v * 1000); n++; }
    return n > 0 ? { mean: Math.round(sum / n) / 1000, count: n } : null;
  }, [endiFittedSensor, pressureHeatmapMatrix]);
  const activeHeatmapMatrix = showPressureHeatmap
    ? pressureHeatmapMatrix!
    : (displayMatrix ?? rotatedFrame?.matrix ?? []);
  const activeHeatmapColorMax = showPressureHeatmap ? pressureHeatmapColorMax : Math.max(255, filteredData?.max ?? 0);
  const activeHeatmapValueFormatter = showPressureHeatmap
    ? formatHeatmapPressure
    : formatHeatmapAdc;
  const endiPressureCells = showPressureHeatmap && endiFittedSensor;
  const activeHeatmapCellFormatter = endiPressureCells ? formatHeatmapPressureCell : undefined;
  const activeHeatmapCompactCellFormatter = endiPressureCells ? formatHeatmapPressureCellCompact : undefined;
  const avgPressure = usesRegionMeanPressure
    ? (displayForce?.contactPressure?.averagePressureKPa == null ? null
      : Number(displayForce.contactPressure.averagePressureKPa.toFixed(2)))
    : displayPressureMetrics?.avgPressureKPa ?? null;
  // 补偿后物理矩阵实时对照与插值矩阵共用同一套砝码段 / 真人段自动派发；不进入采集持久化与导出。
  const physicalSummary = useMemo(() => {
    const phys = rotatedFrame?.physical;
    if (!phys || phys.length === 0) return null;
    // V2.7.15：过滤阈值对原始矩阵的压强计算同步生效
    const scaled: number[][] = phys.map((row) =>
      row.map((raw) => {
        let v = raw > 0 ? Math.max(0, Math.round(raw * resultScale)) : 0;
        if (filterThreshold > 0 && v > 0 && v <= filterThreshold) v = 0;
        return v;
      }),
    );
    return computeMatrixSummary(scaled, sensorType, rotatedPhysicalValidMask, activeHumanCoefficient);
  }, [rotatedFrame?.physical, resultScale, sensorType, filterThreshold, rotatedPhysicalValidMask, activeHumanCoefficient]);

  // Display-only adjustment: preserve calibrated metrics, matrices and saved captures.
  const maximumPressureDisplayKPa = (value: number | null | undefined): number | null =>
    value == null ? null : Number((sensorType === "endi-23x23" ? value * 2 : value / 3).toFixed(2));
  // V2.7.99：恩迪坐垫/靠背的最大压强 = 逐格压强最大值（框选时取框内），不再使用原独立标定及其×2/÷3显示换算。
  // V2.7.110：同时给出最大格位置，热力图红框标注与“最大压强”卡片同一格同一值。
  const endiMaxPressureCell = endiFittedSensor ? maxPressureCellInSelection(endiPointPressureDisplay, areaSelection) : null;
  const endiMaxPressureKPa = endiMaxPressureCell ? endiMaxPressureCell.valueKPa : null;
  const maxPressure = endiFittedSensor
    ? (endiMaxPressureKPa === null ? null : Number(endiMaxPressureKPa.toFixed(2)))
    : maximumPressureDisplayKPa(displayPressureMetrics?.maxPressureKPa);
  const physicalMaxPressure = maximumPressureDisplayKPa(physicalSummary?.maxPressureKPa);
  // V2.7.110：热力图最大压强格标注（与“最大压强”卡片同一格、同一显示值）。
  const maxMarkerRow = endiMaxPressureCell?.row ?? -1;
  const maxMarkerCol = endiMaxPressureCell?.col ?? -1;
  const heatmapMaxMarker = useMemo(() => (endiFittedSensor && maxMarkerEnabled && maxMarkerRow >= 0 && maxMarkerCol >= 0 && maxPressure !== null
    ? { row: maxMarkerRow, col: maxMarkerCol, label: `最大 ${formatPressureNcm2(maxPressure)} ${PRESSURE_DISPLAY_UNIT}` }
    : null), [endiFittedSensor, maxMarkerEnabled, maxMarkerRow, maxMarkerCol, maxPressure]);

  // 预计压强锁定状态机
  // 状态: idle(无数据) -> rising(检测到大幅上升，2秒计时) -> locked(锁定显示) -> idle(有效点数=0时归零)
  const [lockedPressure, setLockedPressure] = useState<number | null>(null);
  const [pressureLockState, setPressureLockState] = useState<"idle" | "rising" | "locked">("idle");
  const pressureLockTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevNonZeroCountRef = useRef<number>(0);
  const risingStartPressureRef = useRef<number | null>(null);

  // 预计压强锁定逻辑
  const lockedAvgRef = useRef<number>(0); // 记录锁定时的均值，用于检测后续大幅上升
  useEffect(() => {
    const nonZeroCount = displayStats?.nonZeroCount ?? 0;
      const currentAvg = displayPressureMetrics?.topMean ?? 0;
    const prevCount = prevNonZeroCountRef.current;
    prevNonZeroCountRef.current = nonZeroCount;

    // 有效点数降到0，归零并重置
    if (nonZeroCount === 0) {
      if (pressureLockState !== "idle" || lockedPressure !== null) {
        setLockedPressure(null);
        setPressureLockState("idle");
        lockedAvgRef.current = 0;
        if (pressureLockTimerRef.current) {
          clearTimeout(pressureLockTimerRef.current);
          pressureLockTimerRef.current = null;
        }
      }
      return;
    }

    // 检测大幅上升：从0跳到有效点数≥3，或有效点数突然增加超过50%
    const isInitialRising = (
      (prevCount < MIN_VALID_POINTS && nonZeroCount >= MIN_VALID_POINTS) ||
      (prevCount > 0 && nonZeroCount > prevCount * 1.5 && nonZeroCount >= MIN_VALID_POINTS)
    );

    // 已锁定状态下，检测均值是否大幅上升超过1.5倍（新物体放上）
    const isLockedRising = (
      pressureLockState === "locked" &&
      lockedAvgRef.current > 0 &&
      currentAvg > lockedAvgRef.current * 1.5 &&
      nonZeroCount >= MIN_VALID_POINTS
    );

    if ((pressureLockState === "idle" && isInitialRising) || isLockedRising) {
      // 检测到大幅上升，开始/重新2秒计时
      setPressureLockState("rising");
      setLockedPressure(null); // 清除旧的锁定值，等待2秒后重新锁定
      if (pressureLockTimerRef.current) clearTimeout(pressureLockTimerRef.current);
      pressureLockTimerRef.current = setTimeout(() => {
        // 2秒后锁定当前的实时压强值
        setPressureLockState("locked");
        pressureLockTimerRef.current = null;
      }, 2000);
    }
  }, [displayStats?.nonZeroCount, displayPressureMetrics?.topMean, pressureLockState, lockedPressure]);

  // 当状态变为locked时，捕获当前实时压强值并记录均值
  useEffect(() => {
    if (pressureLockState === "locked" && lockedPressure === null && avgPressure !== null) {
      setLockedPressure(avgPressure);
      lockedAvgRef.current = displayPressureMetrics?.topMean ?? 0;
    }
  }, [pressureLockState, lockedPressure, avgPressure, displayPressureMetrics?.topMean]);

  // 清理定时器
  useEffect(() => {
    return () => {
      if (pressureLockTimerRef.current) clearTimeout(pressureLockTimerRef.current);
    };
  }, []);

  // 获取统计字段的值
  // 计算原始矩阵（旋转后）中非零最大值的坐标，按左下角起始的1基坐标显示。
  const maxCoord = useMemo<string>(() => {
    if (!rotatedFrame) return "--";
    const matrix = rotatedFrame.matrix;
    const rows = matrix.length;
    let maxVal = 0;
    let maxR = 0;
    let maxC = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < matrix[r].length; c++) {
        if (matrix[r][c] > maxVal) {
          maxVal = matrix[r][c];
          maxR = r;
          maxC = c;
        }
      }
    }
    if (maxVal === 0) return "--";
    // 热力图将 row=0 绘制在最下行，坐标与显示方向一致：x=列号+1, y=行号+1。
    const x = heatmapColumnIndex(maxC, matrix[0].length, sensorType) + 1;
    const y = maxR + 1;
    return `(${x}, ${y})`;
  }, [rotatedFrame, sensorType]);

  // 框选区域内的最大值坐标
  const areaMaxCoord = useMemo<string>(() => {
    if (!areaSelection || !rotatedFrame) return maxCoord;
    const { startRow, startCol, endRow, endCol } = areaSelection;
    const matrix = rotatedFrame.matrix;
    let maxVal = 0, maxR = 0, maxC = 0;
    for (let r = startRow; r <= endRow; r++) {
      for (let c = startCol; c <= endCol; c++) {
        if ((matrix[r]?.[c] ?? 0) > maxVal) {
          maxVal = matrix[r][c];
          maxR = r;
          maxC = c;
        }
      }
    }
    if (maxVal === 0) return "--";
    const x = heatmapColumnIndex(maxC, matrix[0].length, sensorType) + 1;
    const y = maxR + 1;
    return `(${x}, ${y})`;
  }, [areaSelection, rotatedFrame, maxCoord, sensorType]);

  // Read the same published values that previously appeared below the heatmap.
  // These may update before the throttled heatmap statistics.
  const getStatValue = (key: string): string | number => {
    if (key === "area") return displayAreaCm2 === undefined ? "--" : displayAreaCm2.toFixed(2);
    if (key === "force") return displayForce && displayForce.forceEstimateComplete !== false ? displayForce.forceN.toFixed(2) : "--";
    if (key === "avgPressure") return formatPressureNcm2(avgPressure);
    if (!displayStats) return "--";
    const areaPointCount = areaSelection
      ? (areaSelection.endRow - areaSelection.startRow + 1) * (areaSelection.endCol - areaSelection.startCol + 1)
      : totalPoints;
    switch (key) {
      case "max": return displayStats.max;
      case "maxCoord": return areaSelection ? areaMaxCoord : maxCoord;
      case "avg": return displayPressureMetrics?.topCount
        ? Number(displayPressureMetrics.topMean.toFixed(2))
        : "--";
      case "maxPressure": return formatPressureNcm2(maxPressure);
      case "sum": return displayStats.sum;
      case "nonZeroCount": return `${displayStats.nonZeroCount} / ${areaPointCount}`;
      default: return "--";
    }
  };

  const getStatUnit = (key: string): string => {
    if (key === "area") return "cm²";
    if (key === "force") return "N";
    if (key === "avgPressure") return PRESSURE_DISPLAY_UNIT;
    if (key === "max" && displayStats?.max !== undefined) return "(补偿后ADC)";
    if (key === "maxPressure" && maxPressure !== null) return PRESSURE_DISPLAY_UNIT;
    return "";
  };

  // 可见的统计字段（按用户自定义顺序排列）
  const orderedStatFields = useMemo(() => {
    const fieldMap = new Map(statFields.map(f => [f.key, f]));
    return statFieldOrder.map(key => fieldMap.get(key)).filter(Boolean) as StatField[];
  }, [statFields, statFieldOrder]);
  const visibleStatFields = orderedStatFields.filter((f) => statFieldVisibility[f.key]);
  const primaryMetricIds: Record<string, { display: string; value: string }> = {
    area: { display: "area-display", value: "area-value" },
    force: { display: "force-display", value: "force-value" },
    avgPressure: { display: "region-average-pressure-display", value: "region-average-pressure-value" },
    maxPressure: { display: "max-pressure-display", value: "max-pressure-value" },
  };
  const renderStatValue = (key: string) => primaryMetricIds[key]
    ? <output data-testid={primaryMetricIds[key].value}>{getStatValue(key)}</output>
    : getStatValue(key);
  const renderStatLabel = (field: StatField) => field.key === "area"
    ? <>{field.label}<span className="ml-2 rounded border border-border px-1 text-[9px] text-muted-foreground">{areaSelection ? "当前框选" : "全图"}</span></>
    : field.label;

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      {/* 数据恢复对话框 */}
      {showRecoveryDialog && recoveryInfo && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-card border border-border rounded-2xl shadow-2xl shadow-black/40 p-6 max-w-md w-full mx-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center border border-amber-500/20">
                <RotateCcw className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground">检测到未完成的采集会话</h3>
                <p className="text-xs text-muted-foreground">上次采集可能因异常中断</p>
              </div>
            </div>

            <div className="bg-muted/30 rounded-lg p-3 mb-4 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">已采集帧数</span>
                <span className="font-bold text-primary font-mono">{recoveryInfo.frameCount} 帧</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">传感器类型</span>
                <span className="font-medium text-foreground">{recoveryInfo.session.sensorType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">开始时间</span>
                <span className="font-mono text-foreground">{new Date(recoveryInfo.session.startedAt).toLocaleString("zh-CN")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">最后更新</span>
                <span className="font-mono text-foreground">{new Date(recoveryInfo.session.updatedAt).toLocaleString("zh-CN")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">有效点位配置</span>
                <span className="font-mono text-foreground">{recoveryInfo.session.expectedNonZero} ± {recoveryInfo.session.nonZeroTolerance}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={recoverCapturedData}
                disabled={isRecovering}
                className="flex-1 gap-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white"
              >
                <RotateCcw className={`w-4 h-4 ${isRecovering ? "animate-spin" : ""}`} />
                {isRecovering ? "恢复中..." : "恢复数据并继续"}
              </Button>
              <Button
                onClick={discardRecovery}
                variant="outline"
                disabled={isRecovering}
                className="flex-1 gap-2 border-red-500/30 text-red-400 hover:bg-red-500/10"
              >
                <Trash2 className="w-4 h-4" />放弃并清除
              </Button>
            </div>

            <p className="text-[10px] text-muted-foreground/60 text-center mt-3">
              恢复后可继续采集更多帧数据，也可直接导出已有数据
            </p>
          </div>
        </div>
      )}

      {/* CSV模式条 */}
      {csvMode && (
        <div className="flex-none px-6 py-2 bg-blue-500/10 border-b border-blue-500/30 flex items-center justify-between">
          <div className="text-xs text-blue-400">
            CSV 模式 · 帧 {csvIndex + 1}/{csvFrames.length} · {csvFrames[csvIndex]?.absoluteTime}
          </div>
          <Button variant="ghost" size="sm" onClick={exitCsvMode} className="text-xs text-blue-400 hover:text-blue-300">
            退出 CSV 模式
          </Button>
        </div>
      )}

      {/* 顶部工具栏 header */}
      <header className="flex-none border-b border-border/50 bg-card/30 backdrop-blur-md">
        <div className="flex items-center justify-between px-5 py-2.5">
          {/* 左侧：标题 + 传感器类型 + 连接状态 */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center border border-primary/10 overflow-hidden">
                <img
                  src="/manus-storage/pressure-sensor-v2-logo_a704af79.png"
                  alt="压力传感器矩阵标志"
                  className="w-6 h-6 object-contain"
                />
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight text-foreground">矩桥标定软件</h1>
                <p className="text-[10px] text-muted-foreground font-mono">
                  {APP_VERSION} · {config.rows}×{config.cols} · {totalPoints} Points · 1Mbaud · {config.name}
                </p>
              </div>
            </div>

            <div className="w-px h-8 bg-border/50" />

            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">传感器类型:</span>
              <Select value={sensorType} onValueChange={handleSensorChange}>
                <SelectTrigger className="w-48 h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SENSOR_LIST.map((s) => (
                    <SelectItem key={s.type} value={s.type}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="w-px h-8 bg-border/50" />

            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${serialState.isConnected ? "bg-emerald-400 animate-pulse shadow-[0_0_6px_rgba(52,211,153,0.5)]" : "bg-muted-foreground/30"}`} />
              <span className="text-xs text-muted-foreground">{serialState.isConnected ? "已连接" : "未连接"}</span>
              <Button
                variant="outline" size="sm"
                onClick={serialState.isConnected ? disconnect : connect}
                disabled={serialState.isConnecting || demoRunning || csvMode}
                className={`gap-2 text-xs ${serialState.isConnected ? "border-emerald-500/50 text-emerald-400" : "border-emerald-500/50 text-emerald-400 bg-emerald-500/10"}`}
              >
                <Zap className="w-3 h-3" />
                {serialState.isConnected ? "断开连接" : "连接串口"}
              </Button>
            </div>
          </div>

          {/* 右侧操作按钮 */}
          <div className="flex items-center gap-2">
            <Button
              variant="outline" size="sm"
              onClick={toggleLogPanel}
              aria-expanded={logOpen}
              aria-controls="serial-log-panel"
              data-testid="serial-log-toggle"
              title={logOpen ? "隐藏日志" : "显示日志"}
              className={`gap-2 text-xs ${logOpen ? "border-primary/50 text-primary bg-primary/10" : "border-border"}`}
            >
              <Activity className="w-3 h-3" />日志
            </Button>
            {!csvMode && !serialState.isConnected && !demoRunning && (
              <>
                <input ref={csvFileRef} type="file" accept=".csv" onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) { handleCsvImport(file); if (csvFileRef.current) csvFileRef.current.value = ""; }
                }} className="hidden" />
                <Button variant="outline" size="sm" onClick={() => csvFileRef.current?.click()} className="gap-2 text-xs border-border">
                  <Upload className="w-3 h-3" />导入 CSV
                </Button>
              </>
            )}

            {csvMode && (
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setCsvIndex(Math.max(0, csvIndex - 1))} className="gap-1 text-xs border-border">
                  <ChevronLeft className="w-3 h-3" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => setCsvPlaying(!csvPlaying)}
                  className={`gap-2 text-xs ${csvPlaying ? "border-emerald-500/50 text-emerald-400" : "border-border"}`}>
                  {csvPlaying ? <><Square className="w-3 h-3" />停止</> : <><Play className="w-3 h-3" />播放</>}
                </Button>
                <Button variant="outline" size="sm" onClick={() => setCsvIndex(Math.min(csvFrames.length - 1, csvIndex + 1))} className="gap-1 text-xs border-border">
                  <ChevronRight className="w-3 h-3" />
                </Button>
              </div>
            )}

            {!serialState.isConnected && !csvMode && (
              <Button variant="outline" size="sm" onClick={demoRunning ? stopDemo : startDemo}
                className={`gap-2 text-xs ${demoRunning ? "border-amber-500/50 text-amber-400" : "border-border"}`}>
                {demoRunning ? <><Square className="w-3 h-3" />停止演示</> : <><Play className="w-3 h-3" />演示模式</>}
              </Button>
            )}

            {hasActiveSource && (
              <Button variant="outline" size="sm" onClick={togglePause}
                className={`gap-2 text-xs ${isPaused ? "border-amber-500/50 text-amber-400" : ""}`}>
                {isPaused ? <><Play className="w-3 h-3" />继续</> : <><Pause className="w-3 h-3" />暂停</>}
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧区域 */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* 第二行工具栏 */}
          <div className="flex-none px-5 py-2.5 border-b border-border/30 bg-card/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 flex-wrap">
                <Button variant="ghost" size="sm" onClick={() => setShowValues(!showValues)}
                  className={`gap-1.5 text-xs h-7 ${showValues ? "text-primary bg-primary/10" : "text-muted-foreground"}`}>
                  <Hash className="w-3.5 h-3.5" />数值
                </Button>
                {/* V2.7.100：格子显示切换——ADC / 压强；切到压强后每个插值格子显示该格压强（自动打开数值）。V2.7.101：单位 N/cm²，3 位小数。 */}
                <div
                  role="group"
                  aria-label="热力图格子显示"
                  data-testid="heatmap-value-toggle"
                  className="flex items-center h-7 gap-0.5 rounded-md border border-border/50 bg-background/40 p-0.5"
                  title={pressureHeatmapAvailable ? "切换热力图每个格子显示 ADC 或压强" : "获得有效数据后可切换为压强"}
                >
                  <span className="flex items-center gap-1 px-1.5 text-[11px] text-muted-foreground">
                    <Gauge className="w-3.5 h-3.5" />格子显示
                  </span>
                  <button
                    type="button"
                    data-testid="heatmap-mode-adc"
                    aria-pressed={heatmapValueMode === "adc"}
                    onClick={() => setHeatmapValueMode("adc")}
                    className={`h-6 px-2.5 rounded text-xs font-medium transition-colors ${heatmapValueMode === "adc" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    ADC
                  </button>
                  <button
                    type="button"
                    data-testid="heatmap-mode-pressure"
                    aria-pressed={heatmapValueMode === "pressure"}
                    disabled={!pressureHeatmapAvailable}
                    onClick={() => { setHeatmapValueMode("pressure"); setShowValues(true); }}
                    className={`h-6 px-2.5 rounded text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${heatmapValueMode === "pressure" ? "bg-cyan-500/20 text-cyan-300" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    压强 N/cm²
                  </button>
                </div>
                {/* V2.7.109：放大镜——鼠标移到热力图上显示放大窗口，格内完整数值；可选放大范围，热力图上滚动滚轮也可调整。 */}
                <div
                  role="group"
                  aria-label="热力图放大镜"
                  data-testid="heatmap-magnifier-controls"
                  className="flex items-center h-7 gap-0.5 rounded-md border border-border/50 bg-background/40 p-0.5"
                  title="打开后把鼠标移到热力图上，跟随鼠标显示放大窗口（格内完整显示压强或 ADC）；在热力图上滚动鼠标滚轮可调整放大范围"
                >
                  <button
                    type="button"
                    data-testid="heatmap-magnifier-toggle"
                    aria-pressed={magnifierEnabled}
                    onClick={() => setMagnifierEnabled(v => !v)}
                    className={`flex items-center gap-1 h-6 px-2 rounded text-xs font-medium transition-colors ${magnifierEnabled ? "bg-cyan-500/20 text-cyan-300" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <ZoomIn className="w-3.5 h-3.5" />放大镜
                  </button>
                  {magnifierEnabled && MAGNIFIER_SIZES.map(n => (
                    <button
                      key={n}
                      type="button"
                      data-testid={`heatmap-magnifier-size-${n}`}
                      aria-pressed={magnifierSize === n}
                      onClick={() => setMagnifierSize(n)}
                      title={`放大窗口显示 ${n}×${n} 格`}
                      className={`h-6 px-1.5 rounded text-[11px] font-mono transition-colors ${magnifierSize === n ? "bg-cyan-500/20 text-cyan-300" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      {n}×{n}
                    </button>
                  ))}
                </div>
                {/* V2.7.110：最大压强格标注开关（恩迪坐垫/靠背；与“最大压强”卡片同一格同一值）。 */}
                {endiFittedSensor && (
                  <button
                    type="button"
                    data-testid="heatmap-max-marker-toggle"
                    aria-pressed={maxMarkerEnabled}
                    onClick={() => setMaxMarkerEnabled(v => !v)}
                    title="在热力图上用红框标出最大压强格并显示数值（框选时标框内最大格），与“最大压强”卡片一致"
                    className={`flex items-center gap-1 h-7 px-2 rounded-md border text-xs font-medium transition-colors ${maxMarkerEnabled ? "border-red-500/40 bg-red-500/15 text-red-300" : "border-border/50 bg-background/40 text-muted-foreground hover:text-foreground"}`}
                  >
                    <Target className="w-3.5 h-3.5" />最大标注
                  </button>
                )}
                {showPressureHeatmap && (
                  <span className="text-[9px] font-mono text-cyan-300/80 px-1.5 py-0.5 rounded border border-cyan-500/20 bg-cyan-500/5">
                    色标 0—{pressureHeatmapColorMax.toFixed(3)} N/cm²
                  </span>
                )}
                {showPressureHeatmap && endiFittedSensor && (
                  <span data-testid="pressure-cell-mean" title="热力图上全部压强格子（接触区内格子）显示值的平均值，与“平均压强”一致" className="text-[9px] font-mono text-cyan-300/80 px-1.5 py-0.5 rounded border border-cyan-500/20 bg-cyan-500/5">
                    格子平均 {pressureCellMean ? `${pressureCellMean.mean.toFixed(3)} N/cm²（${pressureCellMean.count} 格）` : "--"}
                  </span>
                )}

                <div className="w-px h-4 bg-border/30 mx-0.5" />

                {/* 纵轴翻转后，矩阵旋转与屏幕旋转方向相反；按钮和角度按屏幕方向显示。 */}
                <div className="flex items-center gap-0.5">
                  <Button variant="ghost" size="sm" onClick={() => setMatrixRotation((matrixRotation + 1) % 4)}
                    className="gap-1 text-[10px] h-7 px-1.5 text-muted-foreground hover:text-primary" title="逆时针旋转90°">
                    <RotateCcw className="w-3.5 h-3.5" />
                  </Button>
                  <span className="text-[10px] font-mono text-muted-foreground min-w-[32px] text-center">
                    {((4 - matrixRotation) % 4) * 90}°
                  </span>
                  <Button variant="ghost" size="sm" onClick={() => setMatrixRotation((matrixRotation + 3) % 4)}
                    className="gap-1 text-[10px] h-7 px-1.5 text-muted-foreground hover:text-primary" title="顺时针旋转90°">
                    <RotateCw className="w-3.5 h-3.5" />
                  </Button>
                </div>

              </div>

              <div className="flex items-center gap-2 flex-shrink-0">

                {/* 框选统计 */}
                <Button variant={areaSelectMode ? "default" : "ghost"} size="sm"
                  onClick={() => {
                    if (areaSelectMode) {
                      setAreaSelectMode(false);
                      setAreaSelection(null);
                    } else {
                      setAreaSelectMode(true);
                    }
                  }}
                  className={`gap-1 text-[10px] h-7 px-2 ${areaSelectMode ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'text-muted-foreground hover:text-foreground'}`}
                  title="框选统计：在热力图上拖拽选择区域，实时统计选区内数据">
                  <BoxSelect className="w-3.5 h-3.5" />
                  {areaSelectMode ? '框选中' : '框选统计'}
                </Button>
                {areaSelection && (
                  <Button variant="ghost" size="sm"
                    onClick={() => setAreaSelection(null)}
                    className="gap-1 text-[10px] h-7 px-2 text-muted-foreground hover:text-red-400"
                    title="清除框选区域">
                    <X className="w-3 h-3" />
                    清除框选
                  </Button>
                )}
              </div>
            </div>



            {/* 主图定位、计算设置与接触区明细 */}
            <div data-testid="heatmap-tools" className="flex flex-wrap items-center gap-3 text-xs mt-2">
              <Button variant="ghost" size="sm" onClick={() => setShowOriginalPoints(!showOriginalPoints)}
                className={`gap-1 text-xs ${showOriginalPoints ? "text-amber-400" : "text-muted-foreground"}`}
                title="在大图上定位 23×23 / 32×25 补偿后物理 ADC 对应的格子">
                <Grid3X3 className="w-3 h-3" />
                {showOriginalPoints ? "退出物理点定位" : "物理点定位"}
              </Button>
              <Popover>
                <PopoverTrigger asChild>
                  <Button data-testid="force-calculation-settings-toggle" variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground">
                    <Settings2 className="w-3.5 h-3.5" />计算设置
                  </Button>
                </PopoverTrigger>
                <PopoverContent data-testid="force-calculation-settings" aria-label="计算设置" align="start" className="w-[min(28rem,calc(100vw-2rem))] max-h-[70vh] overflow-auto text-[11px]">
                  <div className="mb-2 text-xs font-semibold">计算设置</div>
            {sensorType === "endi-23x23" && (
              <div data-testid="seat-algorithm-info" className="mt-2 space-y-1.5 text-[11px] leading-relaxed text-muted-foreground">
                <div className="text-foreground">坐垫面积与压力算法：恩迪坐垫实测拟合算法（位置锚点＋相对档位状态机）</div>
                <div>模型版本 <span className="font-mono">{ENDI_SEAT_MODEL_VERSION}</span>；参数由 31 个位置 × 1–5 块标准砝码（每块 1.625 kg，底面 63.62 cm²）实测数据拟合。</div>
                <div>输入为未补偿的原始 23×23 物理 ADC（插值 46×46，10 mm 格，1 cm²/格）；显示旋转、过滤阈值与 ADC 补偿只影响热力图，不进入面积、压力与平均压强计算。</div>
                <div>标准档（砝码底面轮廓）：m = 1.625 kg × λ，λ 为按该位置锚点表换算的连续档位（放 n 块时 λ≈n），面积取底面 63.62 cm²/区；估算（非砝码轮廓）：按连续拟合估算，面积取 T29 轮廓格数。超量程估算：接触区基准估算力与连续拟合估算力均 &gt; {ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N} N（超过 5 块砝码）时启动，压力 ×{ENDI_SEAT_OVER_RANGE_GAIN}，面积取 T29 轮廓，任一回落 ≤ {ENDI_SEAT_OVER_RANGE_FORCE_THRESHOLD_N} N 持续 500 ms 后取消。真人估算：全帧基准面积 &gt; {ENDI_SEAT_HUMAN_AREA_THRESHOLD_CM2} cm² 且全帧基准力 &gt; {ENDI_SEAT_HUMAN_FORCE_THRESHOLD_N} N 时启动，非标准档接触区压力 ×{ENDI_SEAT_HUMAN_FORCE_FACTOR}、面积 ×{ENDI_SEAT_HUMAN_AREA_FACTOR}（压强 = F×{ENDI_SEAT_HUMAN_FORCE_FACTOR} ÷ (S×{ENDI_SEAT_HUMAN_AREA_FACTOR})），不再乘超量程倍率；条件连续不满足 500 ms 后退出；识别为标准砝码的接触区不乘系数；真人估算区逐格压强最大格 ×{ENDI_SEAT_HUMAN_PEAK_PRESSURE_GAIN}（按 ADC^γ 重新分配，区内格子平均不变）。系数切换按 120 ms 平滑过渡。各区 F = 9.8m（压力保留 2 位小数）、P = F/S（N/cm²，保留 3 位小数），平均压强为全部压强格子的平均值（单个接触区时即该区 P）。</div>
                <div>算法内部已做 3 帧中值滤波与切换平滑，显示不再二次平滑。框选面积按同口径 T29 轮廓格数统计（真人估算区的格子按 ×{ENDI_SEAT_HUMAN_AREA_FACTOR} 折算），不改变全帧力与压强。</div>
              </div>
            )}
            {sensorType === "new-backrest-32x25" && (
              <div data-testid="backrest-algorithm-info" className="mt-2 space-y-1.5 text-[11px] leading-relaxed text-muted-foreground">
                <div className="text-foreground">靠背面积与压力算法：恩迪靠背实测拟合算法（位置锚点＋相对档位状态机）</div>
                <div>模型版本 <span className="font-mono">{ENDI_BACKREST_MODEL_VERSION}</span>；参数由 44 个位置 × 1–5 块标准砝码（每块 1.625 kg，底面 63.62 cm²）实测数据拟合。</div>
                <div>输入为未补偿的原始 32×25 物理 ADC（转置为 25×32 进入算法；插值 50×64，10 mm × 13 mm 格，1.30 cm²/格）；显示旋转、过滤阈值与 ADC 补偿只影响热力图，不进入面积、压力与平均压强计算。</div>
                <div>标准档（砝码底面轮廓）：m = 1.625 kg × λ，λ 为按该位置锚点换算的连续档位（放 n 块时 λ≈n），面积取底面 63.62 cm²/区；估算（非砝码轮廓）：按连续拟合 m = e^c0·(g·ΣADC²)^k 估算，面积取 T39 轮廓格数 × 1.30 cm²。超量程估算：接触区基准估算力与连续拟合估算力均 &gt; {ENDI_BACKREST_OVER_RANGE_FORCE_THRESHOLD_N} N（超过 5 块砝码）时启动，压力 ×{ENDI_BACKREST_OVER_RANGE_GAIN}，面积 = T39 轮廓 ×{ENDI_BACKREST_OVER_RANGE_AREA_GAIN}（V2.7.108，区压强 = 2F / 2S = F / S），任一回落 ≤ {ENDI_BACKREST_OVER_RANGE_FORCE_THRESHOLD_N} N 持续 500 ms 后取消；靠背不使用真人估算系数。各区 F = 9.8m（压力保留 2 位小数）、P = F/S（N/cm²，保留 3 位小数），平均压强为全部压强格子的平均值（单个接触区时即该区 P）。</div>
                <div>算法内部已做 120 ms 时间平均与切换平滑，显示不再二次平滑。框选面积按同口径 T39 轮廓格数统计（超量程区每格按 1.30 cm² × {ENDI_BACKREST_OVER_RANGE_AREA_GAIN}），不改变全帧力与压强。</div>
              </div>
            )}
                  {sensorType !== "endi-23x23" && sensorType !== "new-backrest-32x25" && (
                    <p className="text-muted-foreground">当前传感器使用默认计算设置。</p>
                  )}
                </PopoverContent>
              </Popover>
              {usesRegionMeanPressure && (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button data-testid="region-pressure-details-toggle" variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground">
                      <BoxSelect className="w-3.5 h-3.5" />各接触区压强明细
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent data-testid="region-pressure-details" aria-label="各接触区压强明细" align="start" className="w-[min(48rem,calc(100vw-2rem))] max-h-[70vh] overflow-auto text-[11px] text-muted-foreground">
                    <div className="mb-2 text-xs font-semibold text-foreground">各接触区压强明细</div>
                {displayForce?.contactPressure?.status === "incomplete" && <p className="text-amber-400">存在缺失的接触区面积或ADC响应，本帧平均压强不可计算。</p>}
                <div className="max-h-40 overflow-auto">
                  <table className="mt-1 w-full text-right tabular-nums">
                    <thead><tr><th>区域</th>{endiFittedSensor && <><th>识别</th><th>质量 kg</th></>}<th>原始ADC总和</th><th>分力占比</th><th>{endiFittedSensor ? "力 N" : "估算力 N"}</th><th>{endiFittedSensor ? "面积 cm²" : "原面积 cm²"}</th><th>{endiFittedSensor ? "压强 N/cm²" : "估算压强 N/cm²"}</th></tr></thead>
                    <tbody>{displayForce?.contactPressure?.regions.map(region => {
                      const endiRegion = sensorType === "endi-23x23" ? displayForce?.endiCushion?.regions[region.index]
                        : sensorType === "new-backrest-32x25" ? displayForce?.endiBackrest?.regions[region.index] : undefined;
                      return (
                        <tr key={region.index} data-testid="region-pressure-row"><td>{region.index+1}</td>{endiFittedSensor && <><td data-testid="region-recognition">{endiRegion ? describeEndiRegion(endiRegion) : "--"}</td><td>{endiRegion ? endiRegion.massKg.toFixed(3) : "--"}</td></>}<td>{region.rawAdcSum}</td><td>{(100*region.forceShare).toFixed(2)}%</td><td>{region.estimatedForceN.toFixed(2)}</td><td>{region.areaCm2.toFixed(2)}</td><td>{formatPressureNcm2(region.estimatedPressureKPa)}</td></tr>
                      );
                    })}</tbody>
                  </table>
                </div>
                  </PopoverContent>
                </Popover>
              )}
            </div>

            {/* 悬停坐标显示 */}
            {hoveredCell && (
              <div className="text-[10px] text-muted-foreground font-mono mt-1">
                <Info className="w-3 h-3 inline mr-1" />
                R{activeHeatmapMatrix.length - 1 - hoveredCell.row} C{heatmapColumnIndex(hoveredCell.col, activeHeatmapMatrix[0]?.length ?? 0, sensorType)} = <span data-testid="heatmap-hover-value">{showPressureHeatmap ? hoveredCell.value.toFixed(3) : String(hoveredCell.value)}</span>{showPressureHeatmap ? ` ${PRESSURE_DISPLAY_UNIT}` : " ADC"}
              </div>
            )}
          </div>

          {/* 热力图区域 */}
          <div data-testid="heatmap-layout" className={`overflow-hidden flex items-stretch transition-all duration-300 ${
            isFullscreen ? "fixed inset-0 z-50 bg-background" : "relative flex-1 min-h-0"
          }`}>
              <aside data-testid="statistics-sidebar" className="w-[332px] shrink-0 min-h-0 self-stretch border-r border-border/50 bg-card/40 flex flex-col overflow-hidden">
                <div className="flex-1 min-h-0 overflow-y-auto">
          <div data-testid="realtime-statistics" className="p-3 space-y-2">
            {/* 框选区域提示 */}
            {areaSelection && (
              <div className="flex items-center gap-1.5 px-2 py-1.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px]">
                <BoxSelect className="w-3 h-3 flex-shrink-0" />
                <span>框选区域: ({areaSelection.startCol+1},{areaSelection.startRow+1}) → ({areaSelection.endCol+1},{areaSelection.endRow+1}) | {(areaSelection.endRow-areaSelection.startRow+1)}×{(areaSelection.endCol-areaSelection.startCol+1)}单元格</span>
                <button onClick={() => setAreaSelection(null)} className="ml-auto hover:text-red-400 transition-colors">
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
            {/* 插值后 (新矩阵) 字段列表 */}
            {(
              <div className="space-y-1.5">
                {visibleStatFields.map((field) => (
                  <div key={field.key} data-testid={primaryMetricIds[field.key]?.display}>
                  <StatCard icon={field.icon} label={renderStatLabel(field)}
                    value={renderStatValue(field.key)} unit={getStatUnit(field.key)} accent={field.accent}
                    detail={(field.key === "avgPressure" || field.key === "maxPressure") ? (
                      <PressureFormulaDetail
                        sensorType={sensorType}

                        nonZeroCount={displayPressureMetrics?.validCount}
                        humanCoefficient={activeHumanCoefficient}
                        backrestMethod={backrestPressureMethod}
                        seatMethod={seatForceMethod}
                        which={field.key === "avgPressure" ? "avg" : "max"}
                      />
                    ) : undefined}
                  />
                  </div>
                ))}
              </div>
            )}
            {/* 原始矩阵实时统计对照 */}
            {physicalStats && (
              <div className="mb-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-2.5 py-2">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Grid3X3 className="w-3 h-3 text-amber-400" />
                    <span className="text-[10px] font-semibold text-amber-300">
                      补偿后物理矩阵 ({physicalStats.rows}×{physicalStats.cols}) · 插值前 ADC
                    </span>
                  </div>
                  <span className="text-[9px] text-muted-foreground">{physicalStats.total} pts</span>
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[10px] tabular-nums">
                  <div className="flex justify-between"><span className="text-muted-foreground">补偿后ADC最大值</span><span className="text-amber-200 font-semibold">{physicalStats.max}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">补偿后最大值位置</span><span className="text-amber-200">({physicalStats.maxC + 1},{physicalStats.rows - physicalStats.maxR})</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">补偿后ADC均值</span><span className="text-amber-200 font-semibold">{physicalStats.avg}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">{pressureInputLabel} 补偿后ADC均值</span><span className="text-amber-200">{physicalSummary?.topCount ? physicalSummary.topMeanADC.toFixed(2) : "--"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">补偿后有效点数（&gt;30）</span><span className="text-amber-200">{physicalStats.nonZeroCount}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">补偿后ADC总和</span><span className="text-amber-200">{physicalStats.sum}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">非零最小</span><span className="text-amber-200">{physicalStats.nonZeroMin}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">有效占比</span><span className="text-amber-200">{((physicalStats.nonZeroCount / physicalStats.total) * 100).toFixed(1)}%</span></div>
                  {!endiFittedSensor && (<div className="flex justify-between"><span className="text-muted-foreground">最大压强（补偿后标定）</span><span className="text-amber-200 font-semibold">{formatPressureNcm2(physicalMaxPressure)}{physicalMaxPressure !== null ? ` ${PRESSURE_DISPLAY_UNIT}` : ""}</span></div>)}
                </div>
                {displayStats && (
                  <div className="mt-1.5 pt-1.5 border-t border-amber-500/20 text-[9px] text-muted-foreground/80 flex items-center justify-between">
                    <span>vs 插值后 {(rotatedFrame?.matrix.length ?? 0)}×{(rotatedFrame?.matrix[0]?.length ?? 0)}</span>
                    <span>
                      ΔTOP {((displayPressureMetrics?.topMean ?? 0) - (physicalSummary?.topMeanADC ?? 0)).toFixed(2)} ·
                      Δ点 {(displayStats.nonZeroCount ?? 0) - physicalStats.nonZeroCount}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
                </div>
              </aside>
            <div data-testid="heatmap-stage" className="relative flex-1 min-w-0 min-h-0 overflow-hidden flex items-center justify-center">
            {/* 全屏/退出全屏按钮 */}
            <Button variant="ghost" size="sm" onClick={toggleFullscreen}
              className={`absolute z-40 text-muted-foreground hover:text-foreground bg-background/60 backdrop-blur-sm border border-border/30 ${
                isFullscreen ? "top-4 right-4" : "top-2 right-2"
              }`}
              title={isFullscreen ? "退出全屏 (ESC)" : "全屏显示"}>
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>

            {rotatedFrame ? (
                <Heatmap
                        layoutKey={String(isFullscreen)}
                  data={{
                    ...rotatedFrame,
                    matrix: activeHeatmapMatrix,
                  }}
                  showValues={showValues}
                  colorMax={activeHeatmapColorMax}
                  valueFormatter={activeHeatmapValueFormatter}
                  cellValueFormatter={activeHeatmapCellFormatter}
                  fitCellText={endiPressureCells}
                  compactCellValueFormatter={activeHeatmapCompactCellFormatter}
                  valueUnit={showPressureHeatmap ? PRESSURE_DISPLAY_UNIT : ""}
                  magnifierEnabled={magnifierEnabled}
                  magnifierSize={magnifierSize}
                  onMagnifierSizeChange={setMagnifierSize}
                  maxMarker={heatmapMaxMarker}
                  sensorType={sensorType}
                        matrixRotation={matrixRotation}
                  onCellHover={(row, col, value) => setHoveredCell({ row, col, value })}
                  lockedPositions={lockedPositionsRef.current}
                  manualSelectMode={lockEnabled && lockMode === 'manual' && !autoCapturing}
                  onManualSelect={(positions) => {
                    lockedPositionsRef.current = positions;
                    positionLockDoneRef.current = true;
                    setLockedPositionCount(positions.size);
                    toast.success(`已手动锁定 ${positions.size} 个点位`);
                  }}
                  matrixIsFiltered={true}
                        filterThreshold={showPressureHeatmap ? 0 : filterThreshold}
                  areaSelectMode={areaSelectMode}
                  onAreaSelectionChange={(sel) => {
                    setAreaSelection(sel);
                    if (sel) {
                      const rows = sel.endRow - sel.startRow + 1;
                      const cols = sel.endCol - sel.startCol + 1;
                      toast.success(`已框选 ${rows}×${cols} = ${rows * cols} 个单元格`);
                    }
                  }}
                  areaSelection={areaSelection}
                  showOriginalPoints={!showPressureHeatmap && showOriginalPoints}
                  physicalRows={getSensorConfig(sensorType)?.physicalRows}
                  physicalCols={getSensorConfig(sensorType)?.physicalCols}
                  highlightedPhysical={hoveredPhysical}
                  onPhysicalHover={(pr, pc) => setHoveredPhysical({ pr, pc })}
                  validMask={rotatedValidMask}
                />
            ) : (
              <div className="text-center text-muted-foreground">
                <Grid3X3 className="w-12 h-12 mx-auto mb-3 opacity-20" />
                <p className="text-sm font-medium">等待数据...</p>
                <p className="text-xs mt-1 opacity-60">请连接串口设备或启动演示模式</p>
              </div>
            )}

            </div>
          </div>

        </div>

      </div>

      {/* 日志默认完全隐藏，工具栏按钮按需打开；隐藏时继续保留日志缓存。 */}
      {!isFullscreen && logOpen && (
        <div id="serial-log-panel" className="contents">
          <LogPanel logs={logs} isOpen={true} onToggle={toggleLogPanel} onClear={clearLogs} />
        </div>
      )}

      {/* === 可拖拽浮动面板 === */}

      {/* 帧采集浮动面板 */}
      {!isFullscreen && (
        <DraggablePanel
          title="帧采集"
          icon={<Camera className="w-3.5 h-3.5 text-primary" />}
          defaultPosition={{ x: window.innerWidth - 300, y: 450 }}
          width={270}
          maxHeight={600}
          visible={showCapturePanel}
          onClose={() => setShowCapturePanel(false)}
        >
          <div className="p-3 space-y-2.5">
            {/* 已采集帧数醒目显示 */}
            <div className="p-2.5 rounded-lg bg-gradient-to-r from-primary/15 to-primary/5 border border-primary/20">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground font-medium">已采集帧数</span>
                <span className="text-2xl font-black font-mono text-primary leading-none">{capturedFrames.length}</span>
              </div>
              <div className="w-full h-2 bg-muted/30 rounded-full overflow-hidden mt-2">
                <div className="h-full bg-gradient-to-r from-primary to-primary/70 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (capturedFrames.length / 50) * 100)}%` }} />
              </div>
            </div>

            {/* 手动采集 */}
            <Button onClick={manualCaptureFrame} className="w-full gap-2 text-xs bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70" disabled={!currentFrame}>
              <Camera className="w-3 h-3" />采集当前帧
            </Button>

            {/* 连续采集：独立写入新增Excel工作表，不改变既有手动/自动采集工作表。 */}
            <div className="border border-emerald-500/30 rounded-lg p-2.5 space-y-2 bg-emerald-500/[0.035]">
              <div className="flex items-center gap-1.5">
                <Timer className={`w-3.5 h-3.5 ${continuousCapturing ? "text-emerald-400 animate-pulse" : "text-emerald-500"}`} />
                <span className="text-[11px] font-semibold text-foreground">连续采集</span>
                <span className={`ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded ${
                  continuousCapturing ? "bg-emerald-500/20 text-emerald-300" : "bg-muted/50 text-muted-foreground"
                }`}>{continuousCapturing ? "采集中 · 逐帧保存" : "未启动"}</span>
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <span>连续帧数</span>
                <span className="font-mono text-emerald-300 font-semibold">{continuousFrames.length} 帧</span>
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <label htmlFor="continuous-frame-limit">每次采集帧数</label>
                <div className="flex items-center gap-1">
                  <input id="continuous-frame-limit" data-testid="continuous-frame-limit" type="number" min="1" max="1000" value={continuousFrameLimit}
                    onChange={(e) => setContinuousFrameLimit(Math.max(1, Math.min(1000, Math.floor(Number(e.target.value) || 10))))}
                    disabled={continuousCapturing}
                    className="w-14 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground disabled:opacity-50" />
                  <span>帧</span>
                </div>
              </div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <span>本次进度</span><span className="font-mono">{continuousRoundCount}/{continuousCapturing ? continuousRoundLimitRef.current : continuousFrameLimit} 帧</span>
              </div>
              <p className="text-[9px] leading-relaxed text-muted-foreground">默认每次采10帧后自动停止。CSV、XLSX仅保留拟合用原始字节、插值前原始物理ADC、补偿前插值ADC，以及帧信息和实际加载标注栏。</p>
              <Button
                data-testid="continuous-capture-toggle"
                onClick={continuousCapturing ? stopContinuousCapture : startContinuousCapture}
                disabled={(!hasActiveSource && !continuousCapturing) || autoCapturing}
                variant={continuousCapturing ? "outline" : "default"}
                className={`w-full gap-2 text-xs ${continuousCapturing ? "border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/10" : "bg-emerald-600 hover:bg-emerald-500"}`}
              >
                {continuousCapturing ? <><Square className="w-3 h-3" />停止连续采集</> : <><Play className="w-3 h-3" />开始连续采集（{continuousFrameLimit}帧）</>}
              </Button>
            </div>

            {/* 自动采集帧（放置检测模式） */}
            <div className="border border-border/30 rounded-lg p-2.5 space-y-2">
              <div className="flex items-center gap-1.5">
                <Timer className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px] font-semibold text-foreground">自动采集</span>
                {autoCapturing && (
                  <span className={`ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    autoPaused ? "bg-gray-500/20 text-gray-400" :
                    autoState === "zeroing" ? "bg-cyan-500/20 text-cyan-400 animate-pulse" :
                    autoState === "stabilizing" ? "bg-yellow-500/20 text-yellow-400 animate-pulse" :
                    autoState === "collecting" ? "bg-emerald-500/20 text-emerald-400 animate-pulse" :
                    autoState === "round_done" ? "bg-blue-500/20 text-blue-400" :
                    autoState === "invalid" ? "bg-red-500/20 text-red-400" :
                    "bg-amber-500/20 text-amber-400 animate-pulse"
                  }`}>
                    {autoPaused ? "已暂停" :
                     autoState === "zeroing" ? "等待清零" :
                     autoState === "waiting" ? "等待放置" :
                     autoState === "stabilizing" ? "稳定中" :
                     autoState === "collecting" ? `采集中 ${roundFrameCount}/${framesPerRound}` :
                     autoState === "round_done" ? `第${roundNumber}轮完成` :
                     autoState === "invalid" ? "放置无效" : "监测中"}
                  </span>
                )}
              </div>

              {/* 配置区域 */}
              <div className="bg-muted/20 rounded-md p-2 space-y-1.5">
                <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider">采集参数配置</p>
                
                {/* 采集间隔 */}
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-foreground/80">采集间隔</span>
                  <div className="flex items-center gap-1">
                    <input type="number" min="1" max="60" value={autoCaptureInterval}
                      onChange={(e) => setAutoCaptureInterval(Math.max(1, Math.min(60, Number(e.target.value) || 1)))}
                      disabled={autoCapturing}
                      className="w-11 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors disabled:opacity-50" />
                    <span className="text-[10px] text-muted-foreground">秒</span>
                  </div>
                </div>

                {/* 每轮帧数 */}
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-foreground/80">本次帧数（采满停止）</span>
                  <div className="flex items-center gap-1">
                    <input type="number" min="1" max="100" value={framesPerRound}
                      onChange={(e) => setFramesPerRound(Math.max(1, Math.min(100, Number(e.target.value) || 1)))}
                      disabled={autoCapturing}
                      className="w-11 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors disabled:opacity-50" />
                    <span className="text-[10px] text-muted-foreground">帧</span>
                  </div>
                </div>

                {/* 有效点位 */}
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-foreground/80">有效点位</span>
                  <div className="flex items-center gap-1">
                    <input type="number" min="1" max="999" value={expectedNonZero}
                      onChange={(e) => setExpectedNonZero(Math.max(1, Math.min(999, Number(e.target.value) || 1)))}
                      disabled={autoCapturing}
                      className="w-11 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors disabled:opacity-50" />
                    <span className="text-[10px] text-muted-foreground">个</span>
                  </div>
                </div>

                {/* 允差范围 */}
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-foreground/80">允差范围</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-muted-foreground">±</span>
                    <input type="number" min="0" max="100" value={nonZeroTolerance}
                      onChange={(e) => setNonZeroTolerance(Math.max(0, Math.min(100, Number(e.target.value) || 0)))}
                      disabled={autoCapturing}
                      className="w-11 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors disabled:opacity-50" />
                    <span className="text-[10px] text-muted-foreground">个</span>
                  </div>
                </div>

                {/* 有效范围提示 */}
                <div className="text-[9px] text-center py-0.5 px-1.5 rounded bg-background/50 border border-border/30 font-mono">
                  <span className="text-muted-foreground">有效范围: </span>
                  <span className="text-primary font-semibold">{expectedNonZero - nonZeroTolerance} ~ {expectedNonZero + nonZeroTolerance}</span>
                  <span className="text-muted-foreground"> 点位</span>
                </div>

                {/* 点位锁定配置 */}
                <div className="pt-1.5 mt-1.5 border-t border-border/30 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <p className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider">点位锁定</p>
                    <button
                      onClick={() => {
                        const next = !lockEnabled;
                        setLockEnabled(next);
                        lockEnabledRef.current = next;
                        if (!next) {
                          // 关闭锁定时清除已有的锁定点位
                          lockedPositionsRef.current = null;
                          positionLockDoneRef.current = false;
                          setLockedPositionCount(null);
                        }
                      }}
                      disabled={autoCapturing}
                      className={`px-2 h-5 text-[9px] rounded font-medium transition-colors ${
                        lockEnabled
                          ? 'bg-cyan-600 text-white'
                          : 'bg-muted/50 border border-border/50 text-muted-foreground hover:text-foreground'
                      } disabled:opacity-50`}
                    >{lockEnabled ? '已启用' : '已关闭'}</button>
                  </div>
                  
                  {/* 锁定启用后显示详细配置 */}
                  {lockEnabled && (
                    <>
                      {/* 锁定模式 */}
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] text-foreground/80">锁定模式</span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => { setLockMode('auto'); lockModeRef.current = 'auto'; }}
                            disabled={autoCapturing}
                            className={`px-2 h-5 text-[9px] rounded transition-colors ${
                              lockMode === 'auto'
                                ? 'bg-cyan-600 text-white'
                                : 'bg-background border border-border/50 text-muted-foreground hover:text-foreground'
                            } disabled:opacity-50`}
                          >自动</button>
                          <button
                            onClick={() => { setLockMode('manual'); lockModeRef.current = 'manual'; }}
                            disabled={autoCapturing}
                            className={`px-2 h-5 text-[9px] rounded transition-colors ${
                              lockMode === 'manual'
                                ? 'bg-amber-600 text-white'
                                : 'bg-background border border-border/50 text-muted-foreground hover:text-foreground'
                            } disabled:opacity-50`}
                          >手动</button>
                        </div>
                      </div>

                      {/* 锁定延迟（仅自动模式） */}
                      {lockMode === 'auto' && (
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] text-foreground/80">锁定延迟</span>
                          <div className="flex items-center gap-1">
                            <input type="number" min="0.5" max="5" step="0.5" value={lockDelay}
                              onChange={(e) => { const v = Math.max(0.5, Math.min(5, Number(e.target.value) || 1)); setLockDelay(v); lockDelayRef.current = v; }}
                              disabled={autoCapturing}
                              className="w-11 h-5 text-[10px] text-center bg-background border border-border/50 rounded px-1 font-mono text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-colors disabled:opacity-50" />
                            <span className="text-[10px] text-muted-foreground">秒</span>
                          </div>
                        </div>
                      )}

                      {/* 手动模式提示 */}
                      {lockMode === 'manual' && (
                        <div className="text-[9px] text-center py-0.5 px-1.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400">
                          在热力图上拖拽框选区域以锁定点位
                        </div>
                      )}

                      {/* 清除锁定按钮 */}
                      {lockedPositionCount !== null && (
                        <button
                          onClick={() => {
                            lockedPositionsRef.current = null;
                            positionLockDoneRef.current = false;
                            setLockedPositionCount(null);
                            toast.info('已清除点位锁定');
                          }}
                          className="w-full h-5 text-[9px] rounded bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-colors"
                        >清除锁定（当前 {lockedPositionCount} 个点位）</button>
                      )}
                    </>
                  )}

                  {/* 未启用时的提示 */}
                  {!lockEnabled && (
                    <div className="text-[9px] text-center py-0.5 px-1.5 rounded bg-muted/30 border border-border/20 text-muted-foreground">
                      采集时不锁定点位，所有非零点位均参与计算
                    </div>
                  )}
                </div>
              </div>

              {/* 状态显示 */}
              {autoCapturing && (
                <div className="space-y-1.5">
                  {/* 轮次和帧数进度 */}
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-muted-foreground">第 <span className="text-primary font-bold">{roundNumber}</span> 轮</span>
                    <span className="font-mono">
                      <span className="text-primary font-bold">{roundFrameCount}</span>
                      <span className="text-muted-foreground">/{framesPerRound} 帧</span>
                    </span>
                  </div>
                  {/* 轮次进度条 */}
                  <div className="w-full h-1.5 bg-muted/30 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-primary to-primary/70 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (roundFrameCount / framesPerRound) * 100)}%` }} />
                  </div>
                  {/* 计时进度条（稳定中或采集中时显示） */}
                  {(autoState === "stabilizing" || autoState === "collecting") && (
                    <div className="relative">
                      <div className="w-full h-5 bg-muted/30 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full transition-all duration-200 ${
                          autoState === "stabilizing" 
                            ? "bg-gradient-to-r from-yellow-500/60 to-yellow-400/60" 
                            : "bg-gradient-to-r from-emerald-500/60 to-emerald-400/60"
                        }`}
                          style={{ width: `${Math.min(100, (autoTimer / (autoState === "stabilizing" ? 2 : autoCaptureInterval)) * 100)}%` }} />
                      </div>
                      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-mono font-bold text-foreground">
                        {autoState === "stabilizing" 
                          ? `稳定中 ${autoTimer.toFixed(1)}s / 2s`
                          : `${autoTimer.toFixed(1)}s / ${autoCaptureInterval}s`
                        }
                      </span>
                    </div>
                  )}
                  <div className={`text-[10px] px-2 py-1.5 rounded border break-all leading-relaxed max-h-24 overflow-y-auto ${
                    autoState === "invalid" 
                      ? "bg-red-500/10 text-red-400 border-red-500/20" 
                      : autoState === "collecting"
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : autoState === "stabilizing"
                      ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                      : autoState === "round_done"
                      ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                      : autoState === "zeroing"
                      ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                      : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                  }`}>
                    {autoMessage}
                  </div>
                  {lockedPositionCount !== null && (
                    <div className="mt-1 text-[10px] px-2 py-0.5 rounded border bg-cyan-500/10 text-cyan-400 border-cyan-500/20">
                      🔒 已锁定 {lockedPositionCount} 个点位，仅计算锁定范围内数值
                    </div>
                  )}
                </div>
              )}

              {/* 控制按钮 */}
              <div className="flex gap-1.5">
                {!autoCapturing ? (
                  <Button onClick={startAutoCapture} size="sm" className="flex-1 gap-1.5 text-[10px] h-7 bg-amber-600 hover:bg-amber-500" disabled={!currentFrame}>
                    <Play className="w-3 h-3" />开始
                  </Button>
                ) : (
                  <>
                    {!autoPaused ? (
                      <Button onClick={pauseAutoCapture} variant="outline" size="sm" className="flex-1 gap-1.5 text-[10px] h-7 border-amber-500/50 text-amber-400 hover:bg-amber-500/10">
                        <Pause className="w-3 h-3" />暂停
                      </Button>
                    ) : (
                      <Button onClick={resumeAutoCapture} size="sm" className="flex-1 gap-1.5 text-[10px] h-7 bg-emerald-600 hover:bg-emerald-500">
                        <Play className="w-3 h-3" />继续
                      </Button>
                    )}
                    <Button onClick={stopAutoCapture} variant="outline" size="sm" className="flex-1 gap-1.5 text-[10px] h-7 border-red-500/50 text-red-400 hover:bg-red-500/10">
                      <Square className="w-3 h-3" />结束
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* 导出和清空 */}
            {hasExportableFrames && (
              <div className="space-y-1.5">
                {/* 导出进度条 */}
                {exportProgress !== null && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground">导出中...</span>
                      <span className="text-primary font-mono font-bold">{exportProgress}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted/30 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full transition-all duration-200"
                        style={{ width: `${exportProgress}%` }} />
                    </div>
                  </div>
                )}
                <div className="rounded-lg border border-border/30 bg-background/30 px-2 py-1.5 text-[9px] leading-relaxed text-muted-foreground">
                  CSV/XLSX导出原始字节、原始物理ADC、补偿前插值ADC及帧信息和标注栏。文件成功提交下载后，采集帧和本地缓存自动清空；导出失败则保留。
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <Button onClick={exportCaptures} variant="outline" className="gap-1.5 text-xs" disabled={exportProgress !== null || !hasExportableFrames} title="导出全部标准与连续帧的拟合用原始数据（CSV）">
                    <Download className="w-3 h-3" />{exportProgress !== null ? `${exportProgress}%` : "CSV"}
                  </Button>
                  <Button onClick={exportXlsx} variant="outline" className="gap-1.5 text-xs" disabled={exportProgress !== null}>
                    <Download className="w-3 h-3" />{exportProgress !== null ? `${exportProgress}%` : "XLSX"}
                  </Button>
                </div>
                <Button onClick={clearCaptures} variant="outline" className="w-full gap-2 text-xs text-destructive hover:text-destructive">
                  <Trash2 className="w-3 h-3" />清空帧
                </Button>
              </div>
            )}

            {/* 本地缓存状态 */}
            <div className="space-y-1 pt-1 border-t border-border/20">
              <div className="flex items-center justify-between">
                <p className="text-[10px] text-muted-foreground font-medium">本地缓存</p>
                <span className="text-[9px] text-muted-foreground font-mono">{cachedFrameCount} 帧</span>
              </div>
              {cachedFrameCount > 0 && (
                <Button onClick={clearCache} variant="outline" size="sm" className="w-full gap-2 text-[10px] h-7 text-orange-500 hover:text-orange-500 border-orange-500/30 hover:border-orange-500/50">
                  <Trash2 className="w-3 h-3" />清空本地缓存
                </Button>
              )}
            </div>

            {/* 采集记录 */}
            {capturedFrames.length > 0 && (
              <CaptureHistory frames={capturedFrames} onDelete={deleteFrame} />
            )}
          </div>
        </DraggablePanel>
      )}

      {/* CSV帧选择器浮动面板 */}
      {!isFullscreen && csvMode && csvFrames.length > 0 && (
        <DraggablePanel
          title="帧选择器"
          icon={<BarChart3 className="w-3.5 h-3.5 text-blue-400" />}
          defaultPosition={{ x: 20, y: 120 }}
          width={250}
        >
          <div className="p-3 space-y-2">
            <input type="range" min="0" max={csvFrames.length - 1} value={csvIndex}
              onChange={(e) => { setCsvIndex(Number(e.target.value)); setCsvPlaying(false); }} className="w-full h-1.5" />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>帧 {csvIndex + 1} / {csvFrames.length}</span>
              <span>{csvFrames[csvIndex]?.relativeTime.toFixed(2)}s</span>
            </div>
          </div>
        </DraggablePanel>
      )}

      {/* 采集面板重新打开入口 */}
      {!isFullscreen && !showCapturePanel && (
        <div className="fixed bottom-20 right-4 z-20 flex flex-col gap-1.5">
          {!isFullscreen && !showCapturePanel && (
            <Button variant="outline" size="sm" onClick={() => setShowCapturePanel(true)}
              className="gap-1.5 text-[10px] h-7 bg-card/90 backdrop-blur-sm shadow-lg">
              <Camera className="w-3 h-3" />采集
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
