import { memo, useRef, useState } from "react";
import { X } from "lucide-react";

interface HistoryFrame {
  id: number;
  capturedAt: Date;
  sensorType: string;
  data: { matrix: number[][]; max: number };
  filteredStats?: { filteredMatrix: number[][]; max: number };
}

interface CaptureHistoryProps {
  frames: readonly HistoryFrame[];
  onDelete: (id: number) => void;
}

const ROW_HEIGHT = 26;
const VIEWPORT_HEIGHT = 144;
const OVERSCAN = 3;

const HistoryRow = memo(function HistoryRow({ frame, onDelete }: {
  frame: HistoryFrame;
  onDelete: (id: number) => void;
}) {
  return (
    <div data-testid="capture-history-row" data-frame-id={frame.id}
      className="group text-[9px] bg-muted/20 rounded px-2 text-muted-foreground font-mono border border-border/20 hover:bg-muted/30 transition-colors flex items-center gap-1"
      style={{ height: ROW_HEIGHT - 2 }}>
      <div className="flex-1 min-w-0 truncate">
        <span className="text-primary font-bold">#{frame.id}</span> {frame.capturedAt.toLocaleTimeString("zh-CN")}
        <span className="opacity-70 ml-1">max={frame.filteredStats?.max ?? frame.data.max}</span>
      </div>
      <button onClick={() => onDelete(frame.id)}
        className="opacity-0 group-hover:opacity-100 shrink-0 w-4 h-4 flex items-center justify-center rounded hover:bg-red-500/20 text-red-400 transition-all"
        title={`删除第 ${frame.id} 帧`}>
        <X className="w-2.5 h-2.5" />
      </button>
    </div>
  );
});

/** 实时帧更新时复用历史列表；滚动仅绘制可见行，全部采集帧仍保留用于导出。 */
export default memo(function CaptureHistory({ frames, onDelete }: CaptureHistoryProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const visibleCount = Math.ceil(VIEWPORT_HEIGHT / ROW_HEIGHT) + OVERSCAN * 2;
  const first = Math.min(
    Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN),
    Math.max(0, frames.length - visibleCount),
  );
  const visible = frames.slice(first, first + visibleCount);

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <p className="text-[10px] text-muted-foreground font-medium">采集记录</p>
        <span className="text-[9px] text-muted-foreground font-mono">{frames.length} 帧</span>
      </div>
      <div ref={scrollRef} data-testid="capture-history" className="overflow-y-auto"
        style={{ height: Math.min(VIEWPORT_HEIGHT, frames.length * ROW_HEIGHT) }}
        onScroll={() => setScrollTop(scrollRef.current?.scrollTop ?? 0)}>
        <div style={{ height: frames.length * ROW_HEIGHT, position: "relative" }}>
          {visible.map((frame, offset) => (
            <div key={frame.id} style={{ position: "absolute", top: (first + offset) * ROW_HEIGHT, left: 0, right: 0 }}>
              <HistoryRow frame={frame} onDelete={onDelete} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
});
