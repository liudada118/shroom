import type { ContinuousForceFrame } from "@/lib/sensorForce";

/** Describes the runtime branch; it never calculates a threshold, force, or area. */
export default function HumanEstimatePanel({ forceFrame }: { forceFrame: ContinuousForceFrame | null }) {
  const estimate = forceFrame?.humanEstimation;
  return (
    <section data-testid="human-estimation-panel" data-active={estimate?.active ? "true" : "false"}
      className="mt-2 rounded border border-violet-500/25 bg-violet-500/5 px-3 py-2 text-[11px]">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="font-semibold text-violet-200">真人估算阈值</span>
        <span>原全帧面积 &gt;600 cm² 且 连续估算等效承载 &gt;20 kg</span>
        <span data-testid="human-estimation-status" role="status" className={estimate ? "text-amber-200" : "text-muted-foreground"}>
          {estimate ? "已触发真人估算" : "未触发，沿用档位识别"}
        </span>
      </div>
      {estimate && <>
        <div className="mt-1 flex flex-wrap gap-x-5 gap-y-1 font-mono text-violet-100">
          <span>原全帧面积 <output data-testid="human-estimation-area">{estimate.fullFrameAreaCm2.toFixed(2)}</output> cm²</span>
          <span>等效承载 <output data-testid="human-estimation-mass">{estimate.estimatedMassKg.toFixed(2)}</output> kg</span>
          <span>估算力 <output data-testid="human-estimation-force">{estimate.estimatedForceN.toFixed(2)}</output> N</span>
          <span>平均压强 <output data-testid="human-estimation-pressure">{estimate.averagePressureKPa?.toFixed(2) ?? "--"}</output> kPa</span>
        </div>
        <p className="mt-1 text-[10px] text-amber-200/85">沿用连续曲线估算力及原区域面积；超出砝码标定范围，尚未验证真人压力精度。等效承载按力÷9.8换算，不表示人体总重。</p>
      </>}
    </section>
  );
}
