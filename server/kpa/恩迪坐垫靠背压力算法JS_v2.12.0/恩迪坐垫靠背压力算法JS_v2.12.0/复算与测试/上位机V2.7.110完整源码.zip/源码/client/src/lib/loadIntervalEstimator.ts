import { LOAD_INTERVAL_CALIBRATION as calibration } from "./loadIntervalCalibration.generated";

type Point = [number, number];
type Matrix = readonly (readonly number[])[];
type Direction = "up" | "down";
export type IntervalSensor = "seat" | "backrest";
export interface PrimaryResponseCurve {
  id: string; location: string; direction: Direction; center: number[];
  signals: number[]; counts: number[]; anchorSources: string[];
  measuredSignals: (number | null)[]; rawMedianSignals: number[];
  minimumSignalGap: number; maximumIsotonicAdjustment: number; sequenceIds: string[];
}
export interface SensorResponseCalibration {
  rows: number; cols: number; responseKind: string; physicalValidMask: boolean[][];
  primary: PrimaryResponseCurve[];
  auxiliary: {center: number[]; massIndex: number; signal: number; count: number; file: string; direction: string}[];
}
export interface LoadIntervalCalibration {
  id: string; massKg: number[]; gravityMS2: number;
  seat: SensorResponseCalibration; backrest: SensorResponseCalibration;
}
export interface IntervalLoadEstimate {
  trackId: number; center: Point; estimatedMassKg: number; estimatedForceN: number;
  lowerMassKg: number; upperMassKg: number; intervalFraction: number;
  response: number; direction: Direction; outsideCalibration: boolean;
  event: "new_contact" | "position_change" | "direction_reversal" | "current_frame";
  referenceSignals: number[]; primaryDistanceCells: number;
}
export const LOAD_INTERVAL_VERSION = calibration.id;
const distance2 = (a: readonly number[], b: readonly number[]) => (a[0]-b[0])**2+(a[1]-b[1])**2;

/** Each cell contributes a continuous increasing response; no class votes enter. */
export function intervalResponse(matrix: Matrix, sensor: IntervalSensor): {response: number; center: Point} {
  const model = calibration[sensor];
  if (matrix.length !== model.rows || matrix.some(row => row.length !== model.cols)) throw new TypeError("Native interval ADC shape required");
  let response=0, sum=0, rowSum=0, colSum=0;
  for(let r=0;r<model.rows;r++)for(let c=0;c<model.cols;c++) {
    const adc=matrix[r][c];
    if(!Number.isFinite(adc)||adc<0||adc>255)throw new TypeError("Finite ADC in 0..255 required");
    if(!model.physicalValidMask[r][c])continue;
    response-=Math.log1p(-adc/256); sum+=adc; rowSum+=r*adc; colSum+=c*adc;
  }
  return {response,center:sum>0?[rowSum/sum,colSum/sum]:[0,0]};
}

function primarySignals(model: SensorResponseCalibration, center: readonly number[], direction: Direction): number[] {
  const curves=model.primary.filter(p=>p.direction===direction);
  const weights=curves.map(p=>1/(distance2(p.center,center)+.0225)**2);
  const total=weights.reduce((a,b)=>a+b,0);
  return calibration.massKg.map((_,j)=>curves.reduce((s,p,i)=>s+weights[i]*p.signals[j],0)/total);
}

/** Smooth spatial weighting; old moving captures retain unknown direction. */
export function spatialIntervalSignals(sensor: IntervalSensor, center: Point, direction: Direction): number[] {
  const model=calibration[sensor], signals=primarySignals(model,center,direction);
  const nearest=Math.min(...model.primary.map(p=>distance2(p.center,center)));
  // Near measured primary positions, their anchors dominate. Auxiliary captures
  // correct local sensitivity progressively away from the primary positions.
  const strength=.65*(1-Math.exp(-nearest/4));
  for(let j=1;j<signals.length;j++) {
    let weighted=0,total=0;
    for(const p of model.auxiliary)if(p.massIndex===j) {
      const d2=distance2(p.center,center), weight=Math.exp(-d2/8);
      if(weight<1e-7)continue;
      const up=primarySignals(model,p.center,"up")[j], down=primarySignals(model,p.center,"down")[j];
      const reference=(up+down)/2;
      const ratio=Math.max(.5,Math.min(2,p.signal/reference));
      weighted+=weight*Math.log(ratio);total+=weight;
    }
    if(total>0)signals[j]*=Math.exp(strength*weighted/total);
  }
  const gap=Math.max(1e-4,signals[signals.length-1]*.001);
  // The monotonic inverse is defined even where old samples overlap. All
  // original medians and calibration adjustments remain in the model provenance.
  for(let j=1;j<signals.length;j++)signals[j]=Math.max(signals[j],signals[j-1]+gap);
  return signals;
}

/** PCHIP: continuous value and first derivative, no overshoot at load anchors. */
export function monotoneIntervalValue(x: readonly number[], y: readonly number[], value: number): number {
  const n=x.length;
  if(!Number.isFinite(value)||x.some(v=>!Number.isFinite(v))||y.some(v=>!Number.isFinite(v)))throw new TypeError("Finite curve query required");
  if(n<2||n!==y.length)throw new TypeError("At least two aligned curve knots required");
  const h=x.slice(1).map((v,i)=>v-x[i]), delta=h.map((v,i)=>(y[i+1]-y[i])/v);
  if(h.some(v=>!Number.isFinite(v)||v<=0)||delta.some(v=>!Number.isFinite(v)||v<0))throw new TypeError("Monotone finite knots required");
  const slope=Array<number>(n).fill(0);
  slope[0]=delta[0];slope[n-1]=delta[n-2];
  for(let i=1;i<n-1;i++) {
    const w1=2*h[i]+h[i-1],w2=h[i]+2*h[i-1];
    slope[i]=delta[i-1]>0&&delta[i]>0?(w1+w2)/(w1/delta[i-1]+w2/delta[i]):0;
  }
  if(value<=x[0])return Math.max(0,y[0]+(value-x[0])*slope[0]);
  if(value>=x[n-1])return Math.max(0,y[n-1]+(value-x[n-1])*slope[n-1]);
  let k=0;while(k<n-2&&value>x[k+1])k++;
  const t=(value-x[k])/h[k],t2=t*t,t3=t2*t;
  return Math.max(0,(2*t3-3*t2+1)*y[k]+(t3-2*t2+t)*h[k]*slope[k]+(-2*t3+3*t2)*y[k+1]+(t3-t2)*h[k]*slope[k+1]);
}

interface Track {
  center: Point; direction: Direction; up: number[]; down: number[];
  x: number[]; y: number[]; signal: number; mass: number; extreme: number;
}

/** State belongs to one stream/session, never to the spatial calibration model. */
export class IntervalLoadEstimator {
  private tracks=new Map<number,Track>();
  private timestamp: number|null=null;
  constructor(private sensor: IntervalSensor) {}
  reset():void {this.tracks.clear();this.timestamp=null;}
  update(inputs: {trackId:number;matrix:Matrix}[], timestampMs:number):IntervalLoadEstimate[] {
    if(!Number.isFinite(timestampMs))throw new TypeError("Explicit finite timestamp required");
    if(this.timestamp!==null&&(timestampMs<=this.timestamp||timestampMs-this.timestamp>2000))this.reset();
    const next=new Map<number,Track>();
    const output=inputs.map(input=> {
      const {response,center}=intervalResponse(input.matrix,this.sensor);
      let previous=this.tracks.get(input.trackId);
      let event:IntervalLoadEstimate["event"]="current_frame";
      const moved=previous&&distance2(previous.center,center)>.75**2;
      if(!previous||moved) {
        const up=spatialIntervalSignals(this.sensor,center,"up"),down=spatialIntervalSignals(this.sensor,center,"down");
        previous={center,direction:"up",up,down,x:up,y:[...calibration.massKg],signal:response,
          mass:monotoneIntervalValue(up,calibration.massKg,response),extreme:response};
        event=moved?"position_change":"new_contact";
      }
      const track:Track={...previous};
      const threshold=Math.max(.12,track.extreme*.006);
      const reverse=track.direction==="up"?track.extreme-response>threshold:response-track.extreme>threshold;
      if(reverse) {
        track.direction=track.direction==="up"?"down":"up";
        const reference=track.direction==="up"?track.up:track.down;
        // Insert the previous measured state as a reversal pivot. Remove only
        // incompatible reference knots, preserving a monotonic connection to
        // the next compatible standard load. No clock-based output ramp.
        const knots=reference.map((x,i)=>({x,y:calibration.massKg[i]})).filter(p=>
          (p.x<track.signal&&p.y<track.mass)||(p.x>track.signal&&p.y>track.mass));
        if(track.signal>0&&track.mass>0)knots.push({x:track.signal,y:track.mass});
        knots.sort((a,b)=>a.x-b.x);
        if(knots.length>=2){track.x=knots.map(p=>p.x);track.y=knots.map(p=>p.y);}
        track.extreme=response;event="direction_reversal";
      }
      track.extreme=track.direction==="up"?Math.max(track.extreme,response):Math.min(track.extreme,response);
      const mass=response===0?0:monotoneIntervalValue(track.x,track.y,response);
      track.signal=response;track.mass=mass;next.set(input.trackId,track);
      let k=0;while(k<calibration.massKg.length-2&&mass>calibration.massKg[k+1])k++;
      const lowerMassKg=calibration.massKg[k],upperMassKg=calibration.massKg[k+1];
      return {trackId:input.trackId,center,estimatedMassKg:mass,estimatedForceN:mass*calibration.gravityMS2,
        lowerMassKg,upperMassKg,intervalFraction:(mass-lowerMassKg)/(upperMassKg-lowerMassKg),response,direction:track.direction,
        outsideCalibration:mass>calibration.massKg[calibration.massKg.length-1],event,
        referenceSignals:[...(track.direction==="up"?track.up:track.down)],
        primaryDistanceCells:Math.sqrt(Math.min(...calibration[this.sensor].primary.map(p=>distance2(p.center,center))))};
    });
    this.tracks=next;this.timestamp=timestampMs;return output;
  }
}
