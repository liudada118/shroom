/**
 * V2.7.109：热力图放大镜。
 *
 * 跟随鼠标显示以当前格子为中心的 N×N 格放大窗口（N = 5 / 7 / 9 / 11，默认 7）：
 * - 每格按与主热力图相同的色标着色，格内文字用与主热力图格内相同的格式完整显示
 *   （压强模式为 N/cm² 3 位小数、区外 0；ADC 模式为整数 ADC），不做横向压缩或省略整数位；
 * - 中心格加绿框，标题栏显示中心格坐标（R/C 与热力图下方悬停读数相同）与读数；
 * - 数据与主热力图同一矩阵、同一帧，实时刷新；只读显示，不参与任何计算；
 * - 以 DOM 网格渲染并挂到 document.body，窗口不会被热力图容器裁剪，文字在任何缩放下都清晰。
 * - V2.7.110：最大压强格（与主热力图同一格）加红框并在格内左上角标“最大”。
 */

import { createPortal } from "react-dom";
import { valueToColor } from "@/lib/colorMap";
import { heatmapCellIndex, heatmapCellValue } from "@/lib/captureOrientation";

/** 放大窗口可选格数（每边），从小到大 = 放大倍数从大到小。 */
export const MAGNIFIER_SIZES = [5, 7, 9, 11] as const;
export const DEFAULT_MAGNIFIER_SIZE = 7;
/** 各格数对应的单格像素与字号：7×7 时每格 58 px、字号 16 px（主热力图坐垫约 12–16 px/格）。 */
const CELL_PX: Record<number, number> = { 5: 76, 7: 58, 9: 48, 11: 40 };
const FONT_PX: Record<number, number> = { 5: 20, 7: 16, 9: 13.5, 11: 11.5 };
const POINTER_GAP = 24;
const EDGE_GAP = 8;
const HEADER_PX = 30;

/** 滚轮调整格数：dir > 0 扩大范围（格数增加），dir < 0 缩小范围（放大更多）。 */
export function nextMagnifierSize(size: number, dir: number): number {
  const sizes = MAGNIFIER_SIZES as readonly number[];
  const k = Math.max(0, sizes.indexOf(size));
  return sizes[Math.max(0, Math.min(sizes.length - 1, k + (dir > 0 ? 1 : -1)))];
}

export interface HeatmapMagnifierProps {
  matrix: number[][];
  numRows: number;
  numCols: number;
  sensorType?: string;
  validMask?: boolean[][] | null;
  threshold: number;
  colorMax: number;
  /** 每边格数（奇数）。 */
  size: number;
  /** 中心格（屏幕显示坐标：第 row 行自上而下、第 col 列自左而右）。 */
  center: { row: number; col: number };
  /** 鼠标的视口坐标。 */
  pointer: { x: number; y: number };
  /** 格内文字格式（与主热力图格内相同的完整格式）。 */
  cellFormatter: (value: number) => string;
  /** 标题栏中心格读数格式。 */
  valueFormatter: (value: number) => string;
  valueUnit?: string;
  lockedPositions?: Set<string> | null;
  /** V2.7.110：最大压强格（matrix 坐标）。 */
  markedCell?: { row: number; col: number } | null;
}

export default function HeatmapMagnifier({
  matrix, numRows, numCols, sensorType, validMask, threshold, colorMax, size, center, pointer,
  cellFormatter, valueFormatter, valueUnit = "", lockedPositions, markedCell = null,
}: HeatmapMagnifierProps) {
  if (typeof document === "undefined" || numRows <= 0 || numCols <= 0) return null;
  const n = (MAGNIFIER_SIZES as readonly number[]).includes(size) ? size : DEFAULT_MAGNIFIER_SIZE;
  const half = (n - 1) / 2;
  const cellPx = CELL_PX[n];
  const fontPx = FONT_PX[n];
  const gridPx = cellPx * n;
  const boxW = gridPx + 4;
  const boxH = gridPx + HEADER_PX + 4;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  let left = pointer.x + POINTER_GAP;
  if (left + boxW > vw - EDGE_GAP) left = pointer.x - POINTER_GAP - boxW;
  left = Math.max(EDGE_GAP, Math.min(left, vw - EDGE_GAP - boxW));
  let top = pointer.y + POINTER_GAP;
  if (top + boxH > vh - EDGE_GAP) top = pointer.y - POINTER_GAP - boxH;
  top = Math.max(EDGE_GAP, Math.min(top, vh - EDGE_GAP - boxH));
  const hasLock = !!lockedPositions && lockedPositions.size > 0;
  const norm = (v: number) => (Number.isFinite(colorMax) && colorMax > 0 ? Math.max(0, Math.min(255, (v / colorMax) * 255)) : 0);

  const centerCell = heatmapCellIndex(center.row, center.col, numRows, numCols, sensorType);
  const centerValue = centerCell ? heatmapCellValue(matrix, centerCell.row, centerCell.col, validMask, threshold) : null;
  const unit = valueUnit || "ADC";

  const cells = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const dr = center.row - half + i;
      const dc = center.col - half + j;
      const m = heatmapCellIndex(dr, dc, numRows, numCols, sensorType);
      const v = m ? heatmapCellValue(matrix, m.row, m.col, validMask, threshold) : null;
      const isCenter = i === half && j === half;
      if (!m || v === null) {
        cells.push(
          <div key={`${i},${j}`} data-testid="magnifier-cell" data-r={dr} data-c={dc} data-empty="1"
            style={{ background: "#0b1220", boxShadow: isCenter ? "inset 0 0 0 2px #34d399" : undefined }} />,
        );
        continue;
      }
      const nv = norm(v);
      const [r, g, b] = valueToColor(nv);
      const text = cellFormatter(v);
      const fs = Math.min(fontPx, (cellPx - 6) / (0.62 * Math.max(1, text.length)));
      const unlocked = hasLock && !lockedPositions!.has(`${m.row},${m.col}`);
      const isMax = !!markedCell && markedCell.row === m.row && markedCell.col === m.col;
      const ring = isMax
        ? (isCenter ? "inset 0 0 0 2px #34d399, inset 0 0 0 4px #ef4444" : "inset 0 0 0 3px #ef4444")
        : isCenter ? "inset 0 0 0 2px #34d399" : "inset 0 0 0 0.5px rgba(15,23,42,0.55)";
      cells.push(
        <div key={`${i},${j}`} data-testid="magnifier-cell" data-r={dr} data-c={dc} data-v={text} data-max={isMax ? "1" : undefined}
          style={{
            position: "relative", display: "flex", alignItems: "center", justifyContent: "center",
            background: `rgb(${r},${g},${b})`, color: nv > 128 ? "#000" : "#fff",
            fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: fs, lineHeight: 1,
            textShadow: nv > 128 ? "0 0 2px rgba(255,255,255,0.55)" : "0 0 2px rgba(0,0,0,0.85)",
            boxShadow: ring,
            opacity: unlocked ? 0.55 : 1,
          }}>
          {isMax && (
            <span style={{
              position: "absolute", left: 3, top: 2, fontSize: Math.max(9, fontPx * 0.6), lineHeight: 1,
              color: "#fff", background: "rgba(185,28,28,0.9)", borderRadius: 3, padding: "1px 3px",
              fontFamily: "'Inter', sans-serif", textShadow: "none",
            }}>最大</span>
          )}
          {text}
        </div>,
      );
    }
  }

  return createPortal(
    <div data-testid="heatmap-magnifier" data-size={n}
      style={{
        position: "fixed", left, top, width: boxW, zIndex: 9999, pointerEvents: "none",
        borderRadius: 10, border: "2px solid rgba(34,211,238,0.75)", background: "#0f172a",
        boxShadow: "0 12px 32px rgba(0,0,0,0.55)", overflow: "hidden",
      }}>
      <div style={{
        height: HEADER_PX, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
        padding: "0 10px", fontSize: 12, color: "#cbd5e1", fontFamily: "'JetBrains Mono', monospace",
        borderBottom: "1px solid rgba(148,163,184,0.25)", whiteSpace: "nowrap",
      }}>
        <span style={{ color: "#67e8f9", fontWeight: 600 }}>放大镜 {n}×{n} · 滚轮调范围</span>
        <span data-testid="magnifier-center" data-r={center.row} data-c={center.col}>
          R{center.row} C{center.col} = <b style={{ color: "#f8fafc" }}>{centerValue === null ? "--" : valueFormatter(centerValue)}</b> {unit}
        </span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${n}, ${cellPx}px)`, gridAutoRows: `${cellPx}px` }}>
        {cells}
      </div>
    </div>,
    document.body,
  );
}
