/**
 * 演示模式 Hook
 * 生成模拟的压力传感器数据
 * 使用 ref 确保 setInterval 回调始终使用最新的 config
 */

import { useCallback, useRef, useState } from "react";
import { getSensorConfig, lineInterp2x2 } from "@/lib/sensorConfig";

export interface FrameData {
  matrix: number[][];
  physical?: number[][]; // 原始物理矩阵（插值前，如 23×23 或 32×25）
  /** 补偿前插值矩阵快照；由统一帧入口保存，供采集缓存和导出留档。 */
  sourceMatrix?: number[][];
  /** 补偿前物理矩阵快照；由统一帧入口保存，供采集缓存和导出留档。 */
  sourcePhysical?: number[][];
  raw: Uint8Array;
  timestamp: number;
  max: number;
  min: number;
  avg: number;
  nonZeroMin: number;
  sum: number;
  nonZeroCount: number;
}

export function useDemo(
  sensorType: string,
  onFrame: (data: FrameData) => void
) {
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timeRef = useRef(0);

  // 使用 ref 保存最新的 config 和 onFrame，避免 setInterval 闭包捕获旧值
  const configRef = useRef(getSensorConfig(sensorType));
  const onFrameRef = useRef(onFrame);
  configRef.current = getSensorConfig(sensorType);
  onFrameRef.current = onFrame;

  const generateFrame = useCallback((): FrameData => {
    const config = configRef.current;
    const totalPoints = config.rows * config.cols;
    const t = timeRef.current;
    timeRef.current += 0.05;

    // V2.7.5：先生成原始物理矩阵 (physicalRows × physicalCols)，
    // 再走与主路径同一份 lineInterp2x2 得到大矩阵，
    // 从而保证小面板展示的 23×23/32×25 与主图 46×46/64×50 严格同源。
    const physRows = config.physicalRows;
    const physCols = config.physicalCols;
    const physical: number[][] = [];
    const cx = physCols / 2;
    const cy = physRows / 2;
    for (let r = 0; r < physRows; r++) {
      const row: number[] = [];
      for (let c = 0; c < physCols; c++) {
        const px1 = cx * 0.4 + cx * 0.3 * Math.sin(t * 0.7);
        const py1 = cy * 0.4 + cy * 0.3 * Math.cos(t * 0.5);
        const d1 = Math.sqrt((r - py1) ** 2 + (c - px1) ** 2);
        const v1 = Math.max(0, 220 - d1 * 12) * (0.7 + 0.3 * Math.sin(t * 2));
        const px2 = cx * 0.7 + cx * 0.2 * Math.cos(t * 0.3);
        const py2 = cy * 0.7 + cy * 0.2 * Math.sin(t * 0.6);
        const d2 = Math.sqrt((r - py2) ** 2 + (c - px2) ** 2);
        const v2 = Math.max(0, 180 - d2 * 11) * (0.6 + 0.4 * Math.cos(t * 1.5));
        const px3 = cx + cx * 0.3 * Math.sin(t * 0.4);
        const py3 = cy + cy * 0.3 * Math.cos(t * 0.8);
        const d3 = Math.sqrt((r - py3) ** 2 + (c - px3) ** 2);
        const v3 = Math.max(0, 150 - d3 * 10) * (0.5 + 0.5 * Math.sin(t * 3));
        const noise = Math.random() * 5;
        let value = Math.round(Math.max(v1, v2, v3) + noise);
        value = Math.max(0, Math.min(255, value));
        row.push(value);
      }
      physical.push(row);
    }
    // 插值到大矩阵（严格走官方 lineInterp）
    const matrix = lineInterp2x2(physical, physRows, physCols);
    // 重算大矩阵统计
    let max = 0, min = 255, sum = 0, nonZeroMin = 255, nonZeroCount = 0;
    for (let r = 0; r < config.rows; r++) {
      for (let c = 0; c < config.cols; c++) {
        const v = matrix[r][c];
        if (v > max) max = v;
        if (v < min) min = v;
        sum += v;
        if (v > 0) {
          if (v < nonZeroMin) nonZeroMin = v;
          nonZeroCount++;
        }
      }
    }
    if (nonZeroCount === 0) nonZeroMin = 0;
    const raw = new Uint8Array(config.frameSize);
    for (let i = 0; i < Math.min(raw.length, totalPoints); i++) {
      const r = Math.floor(i / config.cols);
      const c = i % config.cols;
      raw[i] = matrix[r][c];
    }

    return {
      matrix,
      physical,
      raw,
      timestamp: Date.now(),
      max,
      min,
      avg: Math.round((sum / totalPoints) * 100) / 100,
      nonZeroMin,
      sum,
      nonZeroCount,
    };
  }, []); // 无依赖项，通过 configRef 获取最新 config

  const start = useCallback(() => {
    if (intervalRef.current) return;
    setIsRunning(true);
    intervalRef.current = setInterval(() => {
      onFrameRef.current(generateFrame());
    }, 50);
  }, [generateFrame]);

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsRunning(false);
  }, []);

  return { isRunning, start, stop };
}
