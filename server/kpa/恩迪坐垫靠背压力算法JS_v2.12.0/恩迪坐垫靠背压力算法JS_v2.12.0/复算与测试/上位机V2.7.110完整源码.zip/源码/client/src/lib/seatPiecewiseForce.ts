import model from './seatPiecewiseForce.generated';
import {analyzeSeatArea} from './seatArea';
import type {SeatPressureContext} from './seatRegionPressure';
import {validateSeatAdc} from './seatTotalForce';

export const SEAT_PIECEWISE_FORCE_VERSION=model.version;
export interface SeatPiecewiseContactInput {rawAdcSum:number;centroidY:number;centroidX:number}
export interface SeatPiecewiseContactResult extends SeatPiecewiseContactInput {
  zoneKey:string;curveKey:string;forceN:number;globalFallback:boolean;outsideResponseRange:boolean;
}
export interface SeatPiecewiseForceDetails {
  forceN:number;contacts:SeatPiecewiseContactResult[];seedCount:number;
  globalFallbackRegions:number;outsideResponseRegions:number;
  reason:'applied'|'global_fallback'|'outside_response_range'|'no_contact'|'no_regions';
}
type Curve={x:number[];y:number[];minADC:number;maxADC:number};
const curves=model.curves as Record<string,Curve>;

/** Match frozen Python floor(clip(centroid,0,22.999999)/width). */
export function seatPiecewiseZoneKey(y:number,x:number):string {
  const clip=(v:number)=>Math.min(22.999999,Math.max(0,v));
  return `${Math.floor(clip(y)/model.width)}|${Math.floor(clip(x)/model.width)}`;
}

/** Frozen np.interp behavior: zero at/below the first knot; final endpoint
 * above support. This is a response endpoint, never a target-weight clamp. */
function curveForce(curve:Curve,x:number):number {
  if(x<curve.x[0])return 0;
  const last=curve.x.length-1;
  if(x>=curve.x[last])return curve.y[last];
  let low=0,high=last;
  while(high-low>1){const mid=Math.floor((low+high)/2);if(x<curve.x[mid])high=mid;else low=mid;}
  const fraction=(x-curve.x[low])/(curve.x[high]-curve.x[low]);
  return curve.y[low]+fraction*(curve.y[high]-curve.y[low]);
}

/** Raw contact force curves are intermediate inputs to a total-only model.
 * Existing pressure code still allocates this total by raw ADC shares. */
export function evaluateSeatPiecewiseContacts(contacts:SeatPiecewiseContactInput[]):SeatPiecewiseForceDetails {
  const parts=contacts.map(contact=>{
    const {rawAdcSum,centroidY,centroidX}=contact;
    if(![rawAdcSum,centroidY,centroidX].every(Number.isFinite)||rawAdcSum<0||centroidY<0||centroidY>22||centroidX<0||centroidX>22)throw new TypeError('Finite native contact ADC and centroid required');
    const zoneKey=seatPiecewiseZoneKey(centroidY,centroidX);
    const globalFallback=!Object.prototype.hasOwnProperty.call(curves,zoneKey);
    const curveKey=globalFallback?'global':zoneKey,curve=curves[curveKey],x=rawAdcSum/255;
    return {...contact,zoneKey,curveKey,forceN:curveForce(curve,x),globalFallback,outsideResponseRange:x>curve.maxADC};
  });
  const forceN=parts.reduce((sum,part)=>sum+part.forceN,0),globalFallbackRegions=parts.filter(p=>p.globalFallback).length;
  const outsideResponseRegions=parts.filter(p=>p.outsideResponseRange).length;
  const noContact=parts.every(p=>p.rawAdcSum===0);
  return {forceN,contacts:parts,seedCount:parts.length,globalFallbackRegions,outsideResponseRegions,
    reason:noContact?'no_contact':outsideResponseRegions?'outside_response_range':globalFallbackRegions?'global_fallback':'applied'};
}

export function nativeSeeds(source:number[][],context?:SeatPressureContext):[number,number][] {
  if(!context)return analyzeSeatArea(source).seeds;
  const turns=((context.rotation%4)+4)%4;
  if(!Number.isInteger(turns))throw new TypeError('Rotation must be integer quarter-turns');
  return context.area.seeds.map(([row,col])=>{
    if(context.mirrorColumns)col=45-col;
    for(let i=0;i<(4-turns)%4;i++){const next=col;col=45-row;row=next;}
    return [row,col];
  });
}

/** Original ADC matrices are only read; no temporal smoothing or display
 * threshold enters this force model. Contact partition is the original area
 * partition, including its nearest-seed tie order. */
export function predictSeatPiecewiseForce(source:number[][],physical:number[][],context?:SeatPressureContext):SeatPiecewiseForceDetails {
  validateSeatAdc(source,46);validateSeatAdc(physical,23);
  const totalAdc=physical.reduce((sum,row)=>sum+row.reduce((s,v)=>s+v,0),0);
  if(totalAdc===0)return {forceN:0,contacts:[],seedCount:0,globalFallbackRegions:0,outsideResponseRegions:0,reason:'no_contact'};
  const seeds=nativeSeeds(source,context);
  if(!seeds.length)return {forceN:0,contacts:[],seedCount:0,globalFallbackRegions:0,outsideResponseRegions:0,reason:'no_regions'};
  const regions=seeds.map(()=>({adc:0,y:0,x:0}));
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const adc=physical[r][c];if(adc===0)continue;
    let nearest=0,best=Infinity;
    seeds.forEach(([sr,sc],i)=>{const distance=(2*r-sr)**2+(2*c-sc)**2;if(distance<best){best=distance;nearest=i;}});
    const region=regions[nearest];region.adc+=adc;region.y+=r*adc;region.x+=c*adc;
  }
  return evaluateSeatPiecewiseContacts(regions.filter(r=>r.adc>0).map(r=>({rawAdcSum:r.adc,centroidY:r.y/r.adc,centroidX:r.x/r.adc})));
}
