/**
 * 统计计算工具
 */

export interface FrameStats {
  max: number;
  min: number;
  avg: number;
  sum: number;
  nonZeroCount: number;
  nonZeroMin: number;
  coverage: number;
}

/**
 * 计算一帧数据的统计信息
 */
export function computeStats(rawData: number[]): FrameStats {
  let min = Infinity;
  let max = -Infinity;
  let sum = 0;
  let nonZeroCount = 0;
  let nonZeroMin = Infinity;

  for (const val of rawData) {
    min = Math.min(min, val);
    max = Math.max(max, val);
    sum += val;
    if (val > 0) {
      nonZeroCount++;
      nonZeroMin = Math.min(nonZeroMin, val);
    }
  }

  const avg = Math.round((sum / rawData.length) * 100) / 100;
  const coverage = Math.round((nonZeroCount / rawData.length) * 1000) / 10;

  return {
    min,
    max,
    avg,
    sum,
    nonZeroCount,
    nonZeroMin: nonZeroMin === Infinity ? 0 : nonZeroMin,
    coverage,
  };
}

import {
  calculatePressureMetricsFromMatrix,
  type PressureCalibrationBranch,
} from "./pressureFit";

/**
 * V2.7.15：矩阵级 5 字段统计（用于"原始矩阵 vs 插值后矩阵"对比导出）
 *  - sum: ADC 总和
 *  - nonZeroCount: 有效点数（>0 的点）
 *  - avgNonZero: ADC 非零平均值（sum / nonZeroCount，保留两位）
 *  - topMeanADC: 传感器专属排序区间均值，保留用于砝码段与导出参考
 *  - avgPressureKPa / maxPressureKPa: 与主图共用砝码段 / 真人段自动派发
 */
export interface MatrixSummary {
  sum: number;
  nonZeroCount: number;
  avgNonZero: number;
  /** 坐垫第5—70位 / 靠背TOP46的降序 ADC 均值，用于砝码段压强公式。 */
  topMeanADC: number;
  /** 实际参与排序区间均值的有效点数。 */
  topCount: number;
  /** 用于压强外推的最大 ADC（保持原值，未做缩放） */
  max: number;
  avgPressureKPa: number | null;
  maxPressureKPa: number | null;
  calibrationBranch: PressureCalibrationBranch;
  humanCoefficient: number | null;
  pointPressureCount: number;
  /** 砝码段逐点比例归一化系数；真人段为空。 */
  normalizationScale: number | null;
  /** 砝码段全部基础曲线响应的平均值；真人段为空。 */
  curveResponseMeanKPa: number | null;
  /** 砝码段逐点压强实际平均值；应等于avgPressureKPa。 */
  pointPressureAverageKPa: number | null;
  /** 砝码段逐点平均值与目标拟合平均压强之差。 */
  meanConservationErrorKPa: number | null;
  /** 砝码段异常回退状态。 */
  pointPressureFallbackMode: "none" | "no-valid-points" | "all-zero" | "equal-distribution" | null;
}

/**
 * 计算单矩阵摘要（统一砝码段 / 真人段口径，便于 CSV/XLSX 与统计栏共享）。
 *
 * @param matrix    输入二维矩阵（已应用 resultScale / 一致性标定后的最终值）
 * @param sensorType 用于选择坐垫或靠背的独立 9 段标定公式
 * @param validMask 可选有效点掩模，无效点不参与统计与压强计算
 * @param humanCoefficient 当前传感器的真人段动态系数
 */
export function computeMatrixSummary(
  matrix: ReadonlyArray<ReadonlyArray<number>>,
  sensorType?: string,
  validMask?: ReadonlyArray<ReadonlyArray<boolean>> | null,
  humanCoefficient?: number,
): MatrixSummary {
  const eligibleMatrix = validMask
    ? matrix.map((row, r) => row.map((value, c) => (validMask[r]?.[c] === false ? 0 : value)))
    : matrix;
  let sum = 0;
  let nonZeroCount = 0;
  let max = 0;
  for (let r = 0; r < eligibleMatrix.length; r++) {
    const row = eligibleMatrix[r];
    for (let c = 0; c < row.length; c++) {
      const v = row[c];
      if (v > max) max = v;
      sum += v;
      if (v > 0) nonZeroCount++;
    }
  }
  const avgNonZero =
    nonZeroCount > 0 ? Math.round((sum / nonZeroCount) * 100) / 100 : 0;
  const pressureMetrics = calculatePressureMetricsFromMatrix(eligibleMatrix, sensorType, humanCoefficient);
  return {
    sum,
    nonZeroCount,
    avgNonZero,
    topMeanADC: pressureMetrics.topMean,
    topCount: pressureMetrics.topCount,
    max,
    avgPressureKPa: pressureMetrics.avgPressureKPa,
    maxPressureKPa: pressureMetrics.maxPressureKPa,
    calibrationBranch: pressureMetrics.calibrationBranch,
    humanCoefficient: pressureMetrics.humanCoefficient,
    pointPressureCount: pressureMetrics.pointPressureCount,
    normalizationScale: pressureMetrics.normalizationScale ?? null,
    curveResponseMeanKPa: pressureMetrics.curveResponseMeanKPa ?? null,
    pointPressureAverageKPa: pressureMetrics.pointPressuresKPa?.length
      ? pressureMetrics.pointPressuresKPa.reduce((sum, value) => sum + value, 0) / pressureMetrics.pointPressuresKPa.length
      : null,
    meanConservationErrorKPa: pressureMetrics.meanConservationErrorKPa ?? null,
    pointPressureFallbackMode: pressureMetrics.pointPressureFallbackMode ?? null,
  };
}
