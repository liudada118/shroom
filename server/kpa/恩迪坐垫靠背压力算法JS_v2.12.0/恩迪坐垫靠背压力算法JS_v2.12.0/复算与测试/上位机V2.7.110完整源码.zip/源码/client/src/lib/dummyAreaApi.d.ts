export as namespace DummyAreaV21036;
export = DummyAreaV21036;

declare namespace DummyAreaV21036 {
  type Matrix = ReadonlyArray<ReadonlyArray<number>>;
  type Mask = ReadonlyArray<ReadonlyArray<boolean>>;
  type CanonicalSensorType = 'dummy-body-27x12' | 'dummy-sleeve-2x18'
    | 'dummy-left-leg-32x6' | 'dummy-right-leg-32x6';
  type SensorType = CanonicalSensorType | 'body' | 'sleeve' | 'pants' | 'leg' | 'left-leg' | 'right-leg';
  interface AreaOptions { displayFilterThreshold?: number; }
  interface AreaRegion {
    id: number;
    positiveCellCount: number;
    featureCellCount: number;
    medianAdc: number;
    q75Adc: number;
    thresholdAdc: number;
    retainedCellCount: number;
    areaCm2: number;
  }
  interface AreaFrame {
    version: '2.10.36';
    modelVersion: string;
    sensorType: CanonicalSensorType | null;
    mode: 'display-cell-count';
    unit: 'cm²';
    rows: number;
    cols: number;
    cellSideCm: 1.25;
    cellAreaCm2: 1.5625;
    areaCm2: number;
    retainedCellCount: number;
    areaMatrixCm2: number[][];
    retainedMask: boolean[][];
    regionCount: number;
    regions: AreaRegion[];
    excludedNoiseRegionCount: number;
    displayFilterThreshold: number;
    adcMatrix: number[][];
    inputRows: number;
    inputCols: number;
    inputMatrixMode: 'physical' | 'interpolated-2x' | 'displayed';
    interpolationApplied: boolean;
    interpolationFactor: 1 | 2;
    pipeline: string;
    interpolatedAdcMatrix?: number[][];
    interpolatedValidMask?: boolean[][];
  }
  interface SensorDefinition {
    readonly sensorType: CanonicalSensorType;
    readonly part: 'body' | 'sleeve' | 'left_leg' | 'right_leg';
    readonly physicalRows: number;
    readonly physicalCols: number;
  }
  const VERSION: '2.10.36';
  const AREA_MODEL_VERSION: string;
  const INTERPOLATION_SOURCE_VERSION: '2.10.28';
  const CELL_SIDE_CM: 1.25;
  const CELL_AREA_CM2: 1.5625;
  const FEATURE_MIN_ADC: 25;
  const MIN_REGION_FEATURE_CELLS: 4;
  const AREA_COEFFICIENTS: Readonly<{ intercept: number; median: number; q75: number }>;
  const DUMMY_SENSOR_TYPES: readonly CanonicalSensorType[];
  const SENSOR_DEFINITIONS: Readonly<Record<CanonicalSensorType, SensorDefinition>>;
  function isDummySensorType(sensorType: string): boolean;
  function getVersion(): '2.10.36';
  function getAreaAdcThreshold(medianAdc: number, q75Adc: number): number;
  const getJacketAreaAdcThreshold: typeof getAreaAdcThreshold;
  function lineInterp(smallMat: number[], width: number, height: number, interp1: number, interp2: number): number[];
  function lineInterp2x2(matrix: Matrix, rows?: number, cols?: number): number[][];
  function calculateDummyRawAreaFrame(matrix: Matrix | null | undefined, sensorType: SensorType, validMask?: Mask | null, options?: AreaOptions): AreaFrame | null;
  function calculateDummyInterpolatedAreaFrame(matrix: Matrix | null | undefined, sensorType: SensorType, validMask?: Mask | null, options?: AreaOptions): AreaFrame | null;
  function calculateDummyAreaFrame(matrix: Matrix | null | undefined, sensorType: SensorType, validMask?: Mask | null, options?: AreaOptions): AreaFrame | null;
  function calculateDummyMatrixArea(matrix: Matrix | null | undefined, sensorType: SensorType, validMask?: Mask | null, options?: AreaOptions): number | null;
  function calculateDummyDisplayedAreaFrame(matrix: Matrix | null | undefined, validMask?: Mask | null, displayFilterThreshold?: number): AreaFrame | null;
  function calculateJacketGridArea(matrix: Matrix | null | undefined, validMask?: Mask | null, displayFilterThreshold?: number): number | null;
  function runSelfCheck(): { pass: boolean; passed: number; total: number; checks: Array<{ name: string; passed: boolean }> };
}
