import type { SeatAreaFrame } from "./seatArea";
export type { SeatAreaFrame } from "./seatArea";
import type DummyAreaApi from "./dummyAreaApi";
import type { BackrestAreaFrame } from "./backrestArea";
import { analyzeEndiSeatArea, type EndiSeatAreaFrame } from "./endiSeatForce";
export type { EndiSeatAreaFrame } from "./endiSeatForce";
import { analyzeEndiBackrestArea, type EndiBackrestAreaFrame } from "./endiBackrestForce";
export type { EndiBackrestAreaFrame } from "./endiBackrestForce";

declare global {
  interface Window {
    DummyAreaV21036?: typeof DummyAreaApi;
  }
}

export interface DisplayAreaSelection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

export type DisplayAreaFrame = SeatAreaFrame | BackrestAreaFrame | EndiSeatAreaFrame | EndiBackrestAreaFrame;

export interface DisplayAreaOptions {
  sensorType: string;
  sourceRotation?: number;
  /** Complete source ADC, aligned with the displayed matrix, mask and selection. */
  sourceMatrix?: number[][] | null;
}

/** Independent seat and backrest fits both use complete, aligned source ADC. */
export function calculateDisplayedArea(
  matrix: number[][] | null,
  validMask: boolean[][] | null,
  selection: DisplayAreaSelection | null,
  options: DisplayAreaOptions,
): DisplayAreaFrame | null {
  if (options.sensorType === "new-backrest-32x25") {
    if (!options.sourceMatrix?.length) return null;
    // 靠背（V2.7.98 起）：与恩迪靠背算法同口径的 T39 轮廓格数（补偿前插值矩阵 ADC ≥ 39，每格 1.30 cm²）。
    // 全图面积显示取算法输出（标准档每区 63.62 cm²）；此处结果用于框选统计与采集留档。
    try { return analyzeEndiBackrestArea(options.sourceMatrix, { selection }); }
    catch { return null; }
  }
  if (options.sensorType !== "endi-23x23" || !options.sourceMatrix?.length) return null;
  // 坐垫（V2.7.97 起）：与恩迪坐垫算法同口径的 T29 轮廓格数（补偿前插值矩阵 ADC ≥ 29，每格 1 cm²）。
  // 全图面积显示取算法输出（标准档每区 63.62 cm²）；此处结果用于框选统计与采集留档。
  try { return analyzeEndiSeatArea(options.sourceMatrix, { validMask, selection }); }
  catch { return null; }
}
