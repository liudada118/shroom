/**
 * 恩迪坐垫 / 靠背逐格压强（V2.7.99 起；V2.7.101 改为均值锚定 + 保和取整）。
 *
 * 每个接触区内，热力图格子 i 的压强：
 *   Pᵢ = P_区 × ADCᵢ / mean(ADC_区)
 * 即该区的平均压强 P_区（Fⱼ/Sⱼ，N/cm²）对应该区热力图 ADC 的平均值，
 * 某格 ADC 比平均值高（低）百分之几，该格压强就高（低）百分之几；因此区内格子压强的平均值 = P_区。
 *
 * - V2.7.101 取整：每格按 0.001 N/cm²（= 0.01 kPa）取整，用最大余数法保持区内总和不变
 *   （区内格子显示值之和 = P_区 × 格数），所以格子上显示的压强平均值与 P_区 完全一致；
 *   每个获得压强的格子至少 0.001 N/cm²，不会显示成 0。
 * - 平均压强 = 全部压强格子的平均值（单区时等于 P_区）；最大压强 = 取整后格子的最大值。
 *
 * - 区域格子：与算法面积口径相同——补偿前插值矩阵 ADC ≥ T（坐垫 29 / 靠背 39）的
 *   8 邻域连通块，按 ADC 加权中心归属最近的物理接触区（与算法核心逐行相同的规则）；
 * - ADCᵢ：同一帧热力图显示的插值 ADC（补偿与固定过滤之后，即 frame.matrix），只取 > 0 的格子；
 * - 区外格子压强为 0；最大压强 = 所有格子 Pᵢ 的最大值。
 *
 * - V2.7.110 坐垫真人估算区：最大压强 ×1.5。真人区（peakPressureGain = 1.5，切换期间按 120 ms 过渡）改为
 *     Pᵢ = P_区 × wᵢ / mean(w_区)，wᵢ = ADCᵢ^γ
 *   γ ≥ 1 按二分法自动求解，使 max(Pᵢ) = 1.5 × P_区 × max(ADC) / mean(ADC)（即原比例分配最大格 × 1.5）；
 *   同样保和取整，区内格子平均仍 = P_区，平均压强仍 = 格子平均；ADC 越大压强越大的顺序不变。
 *   γ 达到上限仍不够（如区内 ADC 全部相同）时取上限，实际倍数记入 peakGainApplied。其余区（标准档、超量程、靠背）不变。
 *
 * 输出矩阵为原生插值方向（与 frame.matrix 相同），界面显示时与热力图做同样的旋转。
 * 逐格矩阵不写入 forceMetrics（避免采集记录膨胀），只挂在本帧力值对象上（WeakMap）；
 * forceMetrics.pointPressure 只保存摘要（最大压强、各区点位数、ADC 中位数等）。
 */
import type { ContinuousForceFrame } from "./sensorForce";
import { PRESSURE_UNITS_PER_KPA, pressureUnitsFromKPa } from "./pressureUnits";
import { interpolate as seatInterpolate } from "./endiCushion/endiCushionCore";
import { interpolate as backrestInterpolate, DEFAULT_CONFIG as BACKREST_CONFIG } from "./endiBackrest/endiBackrestCore";
import { endiNativeToAlgorithm, ENDI_SEAT_AREA_THRESHOLD_ADC } from "./endiSeatForce";
import { endiBackrestNativeToAlgorithm, ENDI_BACKREST_AREA_THRESHOLD_ADC, ENDI_BACKREST_CELL_AREA_CM2 } from "./endiBackrestForce";

type Matrix = number[][];

export const ENDI_POINT_PRESSURE_VERSION = "endi-point-pressure-region-mean-ratio-sum-preserving-human-peak1.5-20261114" as const;
export const ENDI_POINT_PRESSURE_FORMULA = "Pᵢ = P_区 × ADCᵢ / mean(ADC_区)" as const;
/** V2.7.110：坐垫真人估算区逐格压强分配规则。 */
export const ENDI_POINT_PRESSURE_HUMAN_PEAK_RULE = "真人区 Pᵢ = P_区 × ADCᵢ^γ / mean(ADC_区^γ)，γ≥1 使 max(Pᵢ) = 1.5 × P_区 × max(ADC)/mean(ADC)" as const;
/** γ 上限（ADC^γ 以区内最大 ADC 归一化计算，不会溢出）。 */
const PEAK_GAMMA_MAX = 64;

export interface EndiPointPressureRegion {
  /** 与 contactPressure.regions[].index 相同 */
  index: number;
  /** 本区获得压强的热力图格子数（轮廓格中热力图 ADC > 0 的格子） */
  pointCount: number;
  /** 本区轮廓格数（补偿前插值 ADC ≥ T） */
  contourCells: number;
  /** 本区热力图 ADC 平均值（对应 P_区，V2.7.101 起的锚点） */
  meanAdc: number | null;
  /** 本区热力图 ADC 中位数（仅供对照） */
  medianAdc: number | null;
  /** 本区平均压强 P_区 = F/S（内部 kPa；界面 N/cm²） */
  regionPressureKPa: number | null;
  /** 本区格子压强（取整后）的平均值，= P_区 */
  meanPressureKPa: number | null;
  maxPressureKPa: number | null;
  minPressureKPa: number | null;
  /** V2.7.110：本区最大压强目标倍数（坐垫真人估算区 1.5，过渡中 1–1.5；其余 1） */
  peakGain: number;
  /** 实际达到的倍数 = 分配后精确最大值 ÷ 原比例分配精确最大值（正常 = peakGain） */
  peakGainApplied: number;
  /** 分配指数 γ（原比例分配为 1） */
  peakExponent: number;
  /** 原比例分配（Pᵢ = P_区 × ADCᵢ / mean(ADC_区)）下本区的最大格压强（精确值，kPa），供 ×1.5 对照 */
  baseMaxPressureKPa: number | null;
  /** heatmap：用热力图 ADC 分配；raw：本区热力图 ADC 全为 0 时退回补偿前插值 ADC */
  adcSource: "heatmap" | "raw" | "none";
}

export interface EndiPointPressureSummary {
  version: typeof ENDI_POINT_PRESSURE_VERSION;
  sensorType: "endi-23x23" | "new-backrest-32x25";
  formula: typeof ENDI_POINT_PRESSURE_FORMULA;
  /** V2.7.110：坐垫真人估算区分配规则（最大压强 ×1.5） */
  humanPeakRule: typeof ENDI_POINT_PRESSURE_HUMAN_PEAK_RULE;
  /** heatmap：热力图显示 ADC（补偿后）；raw：缺少热力图矩阵时退回补偿前插值 ADC */
  adcSource: "heatmap" | "raw";
  thresholdAdc: number;
  /** 原生插值方向的行列数（坐垫 46×46，靠背 64×50） */
  rows: number;
  cols: number;
  pointCount: number;
  /** 全部压强格子（取整后）的平均值 = 平均压强（kPa；按 0.01 kPa 取整） */
  meanPressureKPa: number | null;
  /** 全部压强格子（取整后）的总和（kPa），= Σ P_区 × 区格数 */
  sumPressureKPa: number;
  maxPressureKPa: number | null;
  /** 最大压强所在格（原生插值方向 [行, 列]） */
  maxCell: [number, number] | null;
  /** 各区轮廓格数是否与算法核心输出一致（区域归属自检） */
  membershipMatchesCore: boolean;
  regions: EndiPointPressureRegion[];
}

export interface EndiPointPressureResult {
  summary: EndiPointPressureSummary;
  /** 原生插值方向的逐格压强（kPa），区外为 0 */
  matrixKPa: Matrix;
  /** 原生插值方向的格子归属：获得压强的格子为接触区序号（0 起），其余为 -1（供核对与框选统计） */
  regionIndexMatrix: Matrix;
  /** 原生插值方向的轮廓格归属：补偿前插值 ADC ≥ T 的格子为接触区序号，其余为 -1（V2.7.102 框选面积真人系数用） */
  contourOwnerMatrix: Matrix;
}

interface Geometry {
  sensorType: "endi-23x23" | "new-backrest-32x25";
  /** 原生插值行列 */
  rows: number;
  cols: number;
  /** 算法方向插值行列 */
  algRows: number;
  algCols: number;
  threshold: number;
  /** 原生插值 (R, C) → 算法插值一维下标 */
  algIndex: (R: number, C: number) => number;
}

const SEAT: Geometry = {
  sensorType: "endi-23x23", rows: 46, cols: 46, algRows: 46, algCols: 46,
  threshold: ENDI_SEAT_AREA_THRESHOLD_ADC,
  // 算法方向 = 原生顺时针 90°：native[R][C] = alg[C][45 − R]
  algIndex: (R, C) => C * 46 + (45 - R),
};
const BACKREST: Geometry = {
  sensorType: "new-backrest-32x25", rows: 64, cols: 50, algRows: 50, algCols: 64,
  threshold: ENDI_BACKREST_AREA_THRESHOLD_ADC,
  // 算法方向 = 原生转置：native[R][C] = alg[C][R]
  algIndex: (R, C) => C * 64 + R,
};

const store = new WeakMap<object, EndiPointPressureResult>();

function flatten(m: Matrix): number[] {
  const out: number[] = [];
  for (const row of m) for (const v of row) out.push(v);
  return out;
}

/** 8 邻域连通区（与两个算法核心的 components 相同） */
function components8(mask: Uint8Array, rows: number, cols: number): number[][] {
  const lab = new Int32Array(rows * cols);
  const out: number[][] = [];
  const stack: number[] = [];
  let id = 0;
  for (let s = 0; s < rows * cols; s++) {
    if (!mask[s] || lab[s]) continue;
    id++;
    const cells: number[] = [];
    lab[s] = id;
    stack.push(s);
    while (stack.length) {
      const p = stack.pop()!;
      cells.push(p);
      const pr = (p / cols) | 0, pc = p - pr * cols;
      for (let dr = -1; dr <= 1; dr++) {
        const rr = pr + dr;
        if (rr < 0 || rr >= rows) continue;
        for (let dc = -1; dc <= 1; dc++) {
          const cc = pc + dc;
          if ((dr === 0 && dc === 0) || cc < 0 || cc >= cols) continue;
          const q = rr * cols + cc;
          if (mask[q] && !lab[q]) { lab[q] = id; stack.push(q); }
        }
      }
    }
    out.push(cells);
  }
  return out;
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

function isMatrix(m: Matrix | null | undefined, rows: number, cols: number): m is Matrix {
  return Array.isArray(m) && m.length === rows && m.every(row => Array.isArray(row) && row.length === cols);
}

interface RegionInput { center: [number, number]; pressureKPa: number | null; contourCells: number; peakGain: number }

/** P_区 取界面显示的接触区压强（contactPressure：Fⱼ 2 位小数、Pⱼ = Fⱼ/Sⱼ 取 0.001 N/cm²）；缺失时退回算法核心值。 */
function displayedRegionPressure(force: ContinuousForceFrame, k: number, fallback: number | null): number | null {
  const shown = force.contactPressure?.regions?.[k];
  return shown && shown.index === k ? shown.estimatedPressureKPa : fallback;
}

function regionInputs(force: ContinuousForceFrame, geom: Geometry): RegionInput[] | null {
  if (geom.sensorType === "endi-23x23") {
    const regs = force.endiCushion?.regions;
    if (!regs) return null;
    return regs.map((r, k) => ({
      center: r.center, pressureKPa: displayedRegionPressure(force, k, r.pressureKPa), contourCells: r.contourCells,
      peakGain: Number.isFinite(r.peakPressureGain) && r.peakPressureGain > 1 ? r.peakPressureGain : 1,
    }));
  }
  const regs = force.endiBackrest?.regions;
  if (!regs) return null;
  return regs.map((r, k) => ({
    center: r.center, pressureKPa: displayedRegionPressure(force, k, r.pressureKPa),
    contourCells: Math.round(r.contourAreaCm2 / ENDI_BACKREST_CELL_AREA_CM2), peakGain: 1,
  }));
}

/**
 * 保和取整（最大余数法）：weights 按比例分配 totalUnits 个整数单位，且每格至少 1 个单位。
 * 返回各格单位数，总和严格等于 totalUnits（totalUnits ≥ 格数时）。
 */
function apportionUnits(weights: number[], totalUnits: number): number[] {
  const n = weights.length;
  if (!n) return [];
  const wsum = weights.reduce((s, w) => s + w, 0);
  const exact = weights.map(w => (totalUnits * w) / wsum);
  const units = exact.map(v => Math.max(1, Math.floor(v)));
  let diff = totalUnits - units.reduce((s, u) => s + u, 0);
  // 余数从大到小补足；余数相同时 ADC 大者优先，再按格子顺序，结果确定。
  const order = exact.map((v, i) => i).sort((a, b) => {
    const ra = exact[a] - Math.floor(exact[a]), rb = exact[b] - Math.floor(exact[b]);
    return rb - ra || weights[b] - weights[a] || a - b;
  });
  for (let t = 0; diff > 0 && n > 0; t = (t + 1) % n) { units[order[t]] += 1; diff -= 1; }
  // 仅在“每格至少 1 单位”抬高后超出时回减：从余数最小、单位数 > 1 的格子开始。
  for (let t = n - 1, guard = 0; diff < 0 && guard < 4 * n; guard++, t = (t - 1 + n) % n) {
    const i = order[t];
    if (units[i] > 1) { units[i] -= 1; diff += 1; }
  }
  return units;
}

/**
 * V2.7.110 真人区最大压强倍数：权重 wᵢ = (ADCᵢ / max ADC)^γ，求 γ ∈ [1, 64] 使
 * max(w) / mean(w) = gain × max(ADC) / mean(ADC)。max(w)/mean(w) 随 γ 单调递增，二分求解；
 * 达不到时取 γ = 64。返回权重、γ 与实际倍数。
 */
function peakSharpenedWeights(adcs: number[], gain: number): { weights: number[]; gamma: number; applied: number } {
  const n = adcs.length;
  let amax = 0, sum = 0;
  for (const a of adcs) { sum += a; if (a > amax) amax = a; }
  const baseRatio = amax / (sum / n);
  const target = gain * baseRatio;
  const logs = adcs.map(a => Math.log(a / amax));
  const ratioAt = (g: number): number => {
    let ws = 0;
    for (const l of logs) ws += Math.exp(g * l);
    return n / ws;
  };
  let gamma: number;
  if (ratioAt(PEAK_GAMMA_MAX) <= target) {
    gamma = PEAK_GAMMA_MAX;
  } else {
    let lo = 1, hi = PEAK_GAMMA_MAX;
    for (let it = 0; it < 100 && hi - lo > 1e-12; it++) {
      const mid = (lo + hi) / 2;
      if (ratioAt(mid) < target) lo = mid; else hi = mid;
    }
    gamma = (lo + hi) / 2;
  }
  const weights = logs.map(l => Math.exp(gamma * l));
  return { weights, gamma, applied: ratioAt(gamma) / baseRatio };
}

/**
 * 计算逐格压强。
 * @param nativePhysical 本帧未补偿原生物理 ADC（坐垫 23×23；靠背 32×25，与算法输入相同）
 * @param heatmapNative  本帧热力图显示的插值 ADC（原生方向，补偿与过滤后；坐垫 46×46，靠背 64×50）
 * @param force          本帧恩迪算法输出（含 endiCushion / endiBackrest 诊断）
 */
export function calculateEndiPointPressure(
  sensorType: string,
  nativePhysical: Matrix | null | undefined,
  heatmapNative: Matrix | null | undefined,
  force: ContinuousForceFrame | null | undefined,
): EndiPointPressureResult | null {
  const geom = sensorType === "endi-23x23" ? SEAT : sensorType === "new-backrest-32x25" ? BACKREST : null;
  if (!geom || !force || !nativePhysical) return null;
  const regions = regionInputs(force, geom);
  if (!regions) return null;
  let b: ArrayLike<number>;
  if (geom === SEAT) {
    if (!isMatrix(nativePhysical, 23, 23)) return null;
    b = seatInterpolate(flatten(endiNativeToAlgorithm(nativePhysical)));
  } else {
    if (!isMatrix(nativePhysical, 32, 25)) return null;
    b = backrestInterpolate(flatten(endiBackrestNativeToAlgorithm(nativePhysical)), 25, 32);
  }
  const { rows, cols, algRows, algCols, threshold } = geom;
  const useHeatmap = isMatrix(heatmapNative, rows, cols);

  // 1) 轮廓连通块按中心归属最近接触区（与算法核心相同）
  const mask = new Uint8Array(algRows * algCols);
  for (let k = 0; k < mask.length; k++) mask[k] = b[k] >= threshold ? 1 : 0;
  const owner = new Int32Array(algRows * algCols).fill(-1);
  const assignedCells = new Array<number>(regions.length).fill(0);
  if (regions.length) {
    for (const cells of components8(mask, algRows, algCols)) {
      let w = 0, si = 0, sj = 0;
      for (const p of cells) {
        const i = (p / algCols) | 0, j = p - i * algCols, v = b[p];
        w += v; si += v * i; sj += v * j;
      }
      const ci = si / w, cj = sj / w;
      let best = 0, bd = Infinity;
      for (let k = 0; k < regions.length; k++) {
        const [cr, cc] = regions[k].center;
        const dd = geom === SEAT
          ? Math.hypot(ci / 2 - cr, (cj - 1) / 2 - cc)
          : Math.hypot((ci / 2 - cr) * BACKREST_CONFIG.pitchRowMm, (cj / 2 - cc) * BACKREST_CONFIG.pitchColMm);
        if (dd < bd) { bd = dd; best = k; }
      }
      for (const p of cells) owner[p] = best;
      assignedCells[best] += cells.length;
    }
  }
  const membershipMatchesCore = regions.every((r, k) => r.contourCells === assignedCells[k]);

  // 2) 各区热力图 ADC（原生方向）；某区热力图 ADC 全为 0 时退回补偿前插值 ADC（轮廓格均 ≥ T > 0）。
  const heatPts: { R: number; C: number; adc: number }[][] = regions.map(() => []);
  const rawPts: { R: number; C: number; adc: number }[][] = regions.map(() => []);
  for (let R = 0; R < rows; R++) {
    for (let C = 0; C < cols; C++) {
      const a = geom.algIndex(R, C);
      const k = owner[a];
      if (k < 0) continue;
      rawPts[k].push({ R, C, adc: b[a] });
      const adc = useHeatmap ? heatmapNative![R][C] : b[a];
      if (Number.isFinite(adc) && adc > 0) heatPts[k].push({ R, C, adc });
    }
  }

  // 3) Pᵢ = P_区 × ADCᵢ / mean(ADC_区)，按 0.01 kPa（0.001 N/cm²）保和取整：区内单位总和 = round(P_区) × 格数。
  const matrixKPa: Matrix = Array.from({ length: rows }, () => new Array<number>(cols).fill(0));
  const regionIndexMatrix: Matrix = Array.from({ length: rows }, () => new Array<number>(cols).fill(-1));
  const contourOwnerMatrix: Matrix = Array.from({ length: rows }, (_, R) =>
    Array.from({ length: cols }, (_, C) => owner[geom.algIndex(R, C)]));
  let maxUnits = 0;
  let maxCell: [number, number] | null = null;
  let pointCount = 0;
  let totalUnits = 0;
  const outRegions: EndiPointPressureRegion[] = regions.map((r, k) => {
    const usedHeat = heatPts[k].length > 0;
    const pts = usedHeat ? heatPts[k] : rawPts[k];
    const adcs = pts.map(p => p.adc);
    const meanAdc = adcs.length ? adcs.reduce((s, v) => s + v, 0) / adcs.length : null;
    const med = median(adcs);
    const P = r.pressureKPa;
    const base = { index: k, contourCells: assignedCells[k], meanAdc, medianAdc: med, regionPressureKPa: P, peakGain: r.peakGain };
    if (P === null || !Number.isFinite(P) || P <= 0 || meanAdc === null || meanAdc <= 0) {
      return {
        ...base, pointCount: 0, meanPressureKPa: null, maxPressureKPa: null, minPressureKPa: null,
        peakGainApplied: 1, peakExponent: 1, baseMaxPressureKPa: null, adcSource: "none" as const,
      };
    }
    const regionUnits = pressureUnitsFromKPa(P);
    const adcMax = adcs.reduce((m, v) => (v > m ? v : m), 0);
    const baseMaxPressureKPa = (regionUnits * adcMax) / meanAdc / PRESSURE_UNITS_PER_KPA;
    // V2.7.110：坐垫真人估算区（peakGain > 1）按 ADC^γ 重新分配，最大格 = 原比例分配最大格 × peakGain；其余区与原规则逐位相同。
    const sharpen = r.peakGain > 1 && pts.length > 1 ? peakSharpenedWeights(adcs, r.peakGain) : null;
    const units = apportionUnits(sharpen ? sharpen.weights : adcs, regionUnits * pts.length);
    let lo = Infinity, hi = -Infinity, sum = 0;
    pts.forEach((p, i) => {
      const u = units[i];
      matrixKPa[p.R][p.C] = u / PRESSURE_UNITS_PER_KPA;
      regionIndexMatrix[p.R][p.C] = k;
      sum += u;
      if (u < lo) lo = u;
      if (u > hi) hi = u;
      if (u > maxUnits) { maxUnits = u; maxCell = [p.R, p.C]; }
    });
    pointCount += pts.length;
    totalUnits += sum;
    return {
      ...base, pointCount: pts.length,
      meanPressureKPa: Math.round(sum / pts.length) / PRESSURE_UNITS_PER_KPA,
      maxPressureKPa: hi / PRESSURE_UNITS_PER_KPA, minPressureKPa: lo / PRESSURE_UNITS_PER_KPA,
      peakGainApplied: sharpen ? sharpen.applied : 1, peakExponent: sharpen ? sharpen.gamma : 1, baseMaxPressureKPa,
      adcSource: usedHeat ? (useHeatmap ? "heatmap" as const : "raw" as const) : "raw" as const,
    };
  });

  return {
    matrixKPa,
    regionIndexMatrix,
    contourOwnerMatrix,
    summary: {
      version: ENDI_POINT_PRESSURE_VERSION, sensorType: geom.sensorType, formula: ENDI_POINT_PRESSURE_FORMULA,
      humanPeakRule: ENDI_POINT_PRESSURE_HUMAN_PEAK_RULE,
      adcSource: useHeatmap ? "heatmap" : "raw", thresholdAdc: threshold, rows, cols,
      pointCount,
      meanPressureKPa: pointCount > 0 ? Math.round(totalUnits / pointCount) / PRESSURE_UNITS_PER_KPA : null,
      sumPressureKPa: totalUnits / PRESSURE_UNITS_PER_KPA,
      maxPressureKPa: pointCount > 0 ? maxUnits / PRESSURE_UNITS_PER_KPA : null,
      maxCell, membershipMatchesCore, regions: outRegions,
    },
  };
}

/**
 * 计算本帧逐格压强，摘要写入 force.pointPressure，矩阵挂在 force 对象上。
 * V2.7.101：平均压强（force.averagePressureKPa 与 contactPressure.averagePressureKPa）改为全部压强格子的平均值，
 * 使热力图格子上显示的压强平均值与“平均压强”一致（单区时与该区 Fⱼ/Sⱼ 相同）。
 * V2.7.104：只要本帧有接触就覆盖，不再限于 status = estimated：个别接触区压强缺失（status = incomplete）时
 * 平均压强同样等于格子平均；本帧没有任何压强格子时平均压强为空（显示 “--”，与全 0 格子一致）。
 * 因此任何状态下“平均压强”卡片 = 热力图压强格子（非零格）的平均值，二者同帧、同一 0.001 N/cm² 取整。
 */
export function attachEndiPointPressure(
  force: ContinuousForceFrame | null | undefined,
  sensorType: string,
  nativePhysical: Matrix | null | undefined,
  heatmapNative: Matrix | null | undefined,
): EndiPointPressureResult | null {
  if (!force) return null;
  const result = calculateEndiPointPressure(sensorType, nativePhysical, heatmapNative, force);
  if (result) {
    force.pointPressure = result.summary;
    store.set(force, result);
    const cp = force.contactPressure;
    const mean = result.summary.meanPressureKPa;
    if (cp && cp.status !== "no_contact") {
      if (cp.status === "incomplete" && mean !== null) cp.status = "estimated";
      cp.averagePressureKPa = mean;
      force.averagePressureKPa = mean;
    }
  }
  return result;
}

/** 取本帧逐格压强矩阵（原生插值方向）；没有则返回 null。 */
export function endiPointPressureMatrix(force: ContinuousForceFrame | null | undefined): Matrix | null {
  return force ? store.get(force)?.matrixKPa ?? null : null;
}

/** 取本帧轮廓格归属矩阵（原生插值方向）；没有则返回 null。 */
export function endiContourOwnerMatrix(force: ContinuousForceFrame | null | undefined): Matrix | null {
  return force ? store.get(force)?.contourOwnerMatrix ?? null : null;
}

/**
 * V2.7.102 坐垫框选面积的真人系数：选区（显示方向坐标）内属于真人估算区的轮廓格按面积系数折算，
 * 返回应从 T29 轮廓格数面积中扣除的面积（cm²，每格 1 cm²）。owner 为已旋转到显示方向的轮廓归属矩阵。
 */
export function endiSeatSelectionHumanAreaDeduction(
  owner: Matrix | null | undefined,
  areaFactors: ArrayLike<number> | null | undefined,
  selection?: { startRow: number; startCol: number; endRow: number; endCol: number } | null,
): number {
  if (!owner || !owner.length || !areaFactors || !selection) return 0;
  const r0 = Math.max(0, Math.min(selection.startRow, selection.endRow));
  const r1 = Math.min(owner.length - 1, Math.max(selection.startRow, selection.endRow));
  let deduction = 0;
  for (let r = r0; r <= r1; r++) {
    const row = owner[r];
    const c0 = Math.max(0, Math.min(selection.startCol, selection.endCol));
    const c1 = Math.min(row.length - 1, Math.max(selection.startCol, selection.endCol));
    for (let c = c0; c <= c1; c++) {
      const k = row[c];
      if (k >= 0 && k < areaFactors.length) deduction += 1 - areaFactors[k];
    }
  }
  return deduction;
}

/**
 * V2.7.108 通用框选面积系数修正：选区（显示方向坐标）内属于第 k 区的轮廓格按该区面积系数 areaFactors[k] 计面积，
 * 返回应加到“轮廓格数 × 每格面积”上的修正量 Σ(areaFactors[k] − 1) × cellAreaCm2（cm²，可正可负）。
 * 靠背超量程区系数为 2（每格 1.30 cm² → 2.60 cm²）；其余区系数为 1，不修正。
 */
export function endiSelectionAreaFactorAdjustment(
  owner: Matrix | null | undefined,
  areaFactors: ArrayLike<number> | null | undefined,
  selection: { startRow: number; startCol: number; endRow: number; endCol: number } | null | undefined,
  cellAreaCm2: number,
): number {
  if (!owner || !owner.length || !areaFactors || !selection) return 0;
  const r0 = Math.max(0, Math.min(selection.startRow, selection.endRow));
  const r1 = Math.min(owner.length - 1, Math.max(selection.startRow, selection.endRow));
  let adjustment = 0;
  for (let r = r0; r <= r1; r++) {
    const row = owner[r];
    const c0 = Math.max(0, Math.min(selection.startCol, selection.endCol));
    const c1 = Math.min(row.length - 1, Math.max(selection.startCol, selection.endCol));
    for (let c = c0; c <= c1; c++) {
      const k = row[c];
      if (k >= 0 && k < areaFactors.length) adjustment += (areaFactors[k] - 1) * cellAreaCm2;
    }
  }
  return adjustment;
}

/**
 * V2.7.110：选区（显示方向坐标）内最大逐格压强所在格（行优先扫描，取第一个最大值）；
 * 供热力图标出最大压强格，与“最大压强”卡片同一个值。
 */
export function maxPressureCellInSelection(
  matrix: Matrix | null | undefined,
  selection?: { startRow: number; startCol: number; endRow: number; endCol: number } | null,
): { row: number; col: number; valueKPa: number } | null {
  if (!matrix || !matrix.length) return null;
  const r0 = selection ? Math.max(0, Math.min(selection.startRow, selection.endRow)) : 0;
  const r1 = selection ? Math.min(matrix.length - 1, Math.max(selection.startRow, selection.endRow)) : matrix.length - 1;
  let best: { row: number; col: number; valueKPa: number } | null = null;
  for (let r = r0; r <= r1; r++) {
    const row = matrix[r];
    const c0 = selection ? Math.max(0, Math.min(selection.startCol, selection.endCol)) : 0;
    const c1 = selection ? Math.min(row.length - 1, Math.max(selection.startCol, selection.endCol)) : row.length - 1;
    for (let c = c0; c <= c1; c++) {
      const v = row[c];
      if (v > 0 && (best === null || v > best.valueKPa)) best = { row: r, col: c, valueKPa: v };
    }
  }
  return best;
}

/** 选区（显示方向坐标）内的最大逐格压强；matrix 为已旋转到显示方向的矩阵。 */
export function maxPressureInSelection(
  matrix: Matrix | null | undefined,
  selection?: { startRow: number; startCol: number; endRow: number; endCol: number } | null,
): number | null {
  if (!matrix || !matrix.length) return null;
  const r0 = selection ? Math.max(0, Math.min(selection.startRow, selection.endRow)) : 0;
  const r1 = selection ? Math.min(matrix.length - 1, Math.max(selection.startRow, selection.endRow)) : matrix.length - 1;
  let best: number | null = null;
  for (let r = r0; r <= r1; r++) {
    const row = matrix[r];
    const c0 = selection ? Math.max(0, Math.min(selection.startCol, selection.endCol)) : 0;
    const c1 = selection ? Math.min(row.length - 1, Math.max(selection.startCol, selection.endCol)) : row.length - 1;
    for (let c = c0; c <= c1; c++) {
      const v = row[c];
      if (v > 0 && (best === null || v > best)) best = v;
    }
  }
  return best;
}
