import model from './seatRegionalCompensation.generated';
import {analyzeSeatArea} from './seatArea';
import type {SeatPressureContext} from './seatRegionPressure';
import {predictSeatTotalForce, validateSeatAdc} from './seatTotalForce';

export const SEAT_REGIONAL_COMPENSATION_VERSION = model.version;
export interface SeatRegionalCompensationDetails {
  baseForceN:number;
  correctionN:number;
  forceN:number;
  regionalCorrectionsN:number[];
  applied:boolean;
  reason:'applied'|'no_contact'|'no_regions'|'outside_response_range'|'invalid_corrected_force';
}

function splineBasis(value:number):number[] {
  const knots=model.knots;
  if(value===knots[knots.length-1])return Array(knots.length-model.degree-2).fill(0).concat(1);
  let values:number[]=knots.slice(0,-1).map((start,i)=>start<=value&&value<knots[i+1]?1:0);
  for(let order=1;order<=model.degree;order++){
    values=Array.from({length:knots.length-order-1},(_,i)=>{
      const first=knots[i+order]-knots[i],second=knots[i+order+1]-knots[i+1];
      return (first?(value-knots[i])/first*values[i]:0)
        +(second?(knots[i+order+1]-value)/second*values[i+1]:0);
    });
  }
  return values;
}

function nativeSeeds(source:number[][],context?:SeatPressureContext):[number,number][] {
  if(!context)return analyzeSeatArea(source).seeds;
  const turns=((context.rotation%4)+4)%4;
  if(!Number.isInteger(turns))throw new TypeError('Rotation must be integer quarter-turns');
  return context.area.seeds.map(([r,c])=>{
    // Display mirror is applied after rotation; undo it before undoing rotation.
    if(context.mirrorColumns)c=45-c;
    for(let i=0;i<(4-turns)%4;i++){const next=c;c=45-r;r=next;}
    return [r,c];
  });
}

function interval(value:number):number {
  const axis=model.axis;
  for(let i=0;i<axis.length-1;i++)if(value<axis[i+1])return i;
  return axis.length-2;
}

/** Per-contact position/response corrections are summed to the original total.
 * Segmentation and areas are reused; final regional pressure still uses the
 * existing ADC-share allocation of the corrected total, not calibrated subforces.
 */
export function predictSeatRegionalCompensatedForce(
  source:number[][],physical:number[][],context?:SeatPressureContext,
):SeatRegionalCompensationDetails {
  validateSeatAdc(source,46);validateSeatAdc(physical,23);
  const baseForceN=predictSeatTotalForce(physical);
  const fallback=(reason:SeatRegionalCompensationDetails['reason']):SeatRegionalCompensationDetails=>
    ({baseForceN,correctionN:0,forceN:baseForceN,regionalCorrectionsN:[],applied:false,reason});
  const totalAdc=physical.reduce((sum,row)=>sum+row.reduce((s,v)=>s+v,0),0);
  if(totalAdc===0)return fallback('no_contact');
  const seeds=nativeSeeds(source,context);
  if(!seeds.length)return fallback('no_regions');
  const regions=seeds.map(()=>({adc:0,y:0,x:0}));
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const adc=physical[r][c];if(adc===0)continue;
    let nearest=0,best=Infinity;
    seeds.forEach(([sr,sc],i)=>{const d=(2*r-sr)**2+(2*c-sc)**2;if(d<best){best=d;nearest=i;}});
    const region=regions[nearest];region.adc+=adc;region.y+=r*adc;region.x+=c*adc;
  }
  const corrections:number[]=[],n=model.axis.length;
  for(const region of regions){
    if(region.adc===0){corrections.push(0);continue;}
    const u=Math.log1p(region.adc/255);
    if(u<model.knots[0]||u>model.knots[model.knots.length-1])return fallback('outside_response_range');
    const gate=region.adc/(region.adc+255);
    const response=[baseForceN*region.adc/totalAdc/100,...splineBasis(u).map(v=>gate*v)];
    const y=region.y/region.adc,x=region.x/region.adc;
    const iy=interval(y),ix=interval(x),axis=model.axis;
    const fy=(y-axis[iy])/(axis[iy+1]-axis[iy]),fx=(x-axis[ix])/(axis[ix+1]-axis[ix]);
    let correction=0;
    for(const [dr,wy] of [[0,1-fy],[1,fy]])for(const [dc,wx] of [[0,1-fx],[1,fx]]){
      const start=((iy+dr)*n+ix+dc)*response.length;
      correction+=wy*wx*response.reduce((sum,v,k)=>sum+v*model.coefficients[start+k],0);
    }
    corrections.push(correction);
  }
  const correctionN=corrections.reduce((s,v)=>s+v,0),forceN=baseForceN+correctionN;
  // A research extrapolation must never replace a usable baseline with an
  // invalid or negative force. Keep that baseline and record the fallback.
  if(!Number.isFinite(forceN)||forceN<0)return fallback('invalid_corrected_force');
  return {baseForceN,correctionN,forceN,regionalCorrectionsN:corrections,applied:true,reason:'applied'};
}
