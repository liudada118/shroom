import {seatTotalForceModel as model} from './seatTotalForce.generated';
import compensation from './seatForceCompensation.generated';

export const seatTotalForceModelVersion=compensation.version;
export function validateSeatAdc(matrix:number[][],size:number):void {
  if(!Array.isArray(matrix)||matrix.length!==size||matrix.some(row=>!Array.isArray(row)||row.length!==size||row.some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0||v>255)))throw new TypeError(`Complete native ${size}×${size} original ADC required`);
}
function sum(values:number[]):number {
  let high=0,low=0;
  for(const value of values){const next=high+value;low+=Math.abs(high)>=Math.abs(value)?(high-next)+value:(value-next)+high;high=next;}
  return high+low;
}
export function extractSeatForceFeatures(physical:number[][]):number[] {
  validateSeatAdc(physical,23);
  const flat=physical.flat(),total=sum(flat);if(total===0)return Array(12).fill(0);
  const rows=physical.map(sum);
  const h=physical.map((row,r)=>row.map(v=>v/(model.feature_mode==='raw'?255:Math.max(model.row_budget-rows[r],10))));
  const top=h.flat().sort((a,b)=>b-a),cy=sum(rows.map((v,r)=>r*v))/total;
  const cx=sum(physical.flatMap(row=>row.map((v,c)=>c*v)))/total;
  const vy:number[]=[],vx:number[]=[],entropy:number[]=[];
  for(let r=0;r<23;r++)for(let c=0;c<23;c++){
    const v=physical[r][c];vy.push(v*(r-cy)**2);vx.push(v*(c-cx)**2);if(v>0)entropy.push(v/total*Math.log(v/total));
  }
  const cols=Array.from({length:23},(_,c)=>sum(h.map(row=>row[c])));
  return [sum(top),sum(top.map(v=>v*v)),sum(top.slice(0,16))/16,cy,cx,Math.sqrt(sum(vy)/total),Math.sqrt(sum(vx)/total),-sum(entropy),
    total*total/sum(flat.map(v=>v*v)),sum([...rows].sort((a,b)=>b-a).slice(0,4)),sum(cols.sort((a,b)=>b-a).slice(0,4)),sum(top.slice(0,32))/32];
}
function predictBaseFeatures(features:number[]):number {
  if(features[0]===0)return 0;
  let force=model.baseline_N;
  for(const tree of model.trees){let index=0;while(true){const [feature,value,left,right]=tree[index];if(feature<0){force+=value;break;}const tolerance=4*Number.EPSILON*Math.max(1,Math.abs(value));index=features[feature]<=value+tolerance?left:right;}}
  return Math.max(0,force);
}

/** Continuous signed correction inferred from native ADC response and location. */
export function predictSeatForceDetails(physical:number[][]):{baseForceN:number;correctionN:number;forceN:number} {
  const features=extractSeatForceFeatures(physical);
  if(features[0]===0)return {baseForceN:0,correctionN:0,forceN:0};
  const baseForceN=predictBaseFeatures(features),q=compensation.normalizedFeatureQuantization;
  const z=compensation.indices.map((index,i)=>Math.floor(features[index]/compensation.scales[i]*q+.5)/q);
  const nearest=compensation.anchorCoordinates.map((anchor,index)=>({index,
    distance:anchor.reduce((total,value,j)=>total+(z[j]-value)**2,0)}))
    .sort((a,b)=>a.distance-b.distance||a.index-b.index).slice(0,compensation.neighbors);
  const weights=nearest.map(v=>1/(v.distance+compensation.epsilonSquared));
  // Local ADC reference interpolation bridges base-tree discontinuities.
  // No weight category, frame index or filename enters live inference.
  const forceN=Math.max(0,(sum(weights.map((w,i)=>w*compensation.anchorReferenceForcesN[nearest[i].index]))+
    compensation.zeroCorrectionPriorWeight*baseForceN)/(sum(weights)+compensation.zeroCorrectionPriorWeight));
  return {baseForceN,correctionN:forceN-baseForceN,forceN};
}
export function predictSeatTotalForce(physical:number[][]):number {
  return predictSeatForceDetails(physical).forceN;
}
